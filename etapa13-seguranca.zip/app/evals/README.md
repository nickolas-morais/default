# Avaliação da qualidade da análise

Conjunto de contratos com a resposta esperada (gabarito). A cada mudança de
prompt (`packages/shared/src/analysis-prompt.ts`), de modelo ou de esforço,
rode a avaliação e compare com a execução anterior.

```bash
pnpm eval                      # todos os casos
pnpm eval locacao-comercial    # só um caso
```

Usa `ANTHROPIC_API_KEY`, `ANTHROPIC_MODEL` e `ANTHROPIC_EFFORT` de `apps/worker/.env`.
Cada caso custa uma chamada real à API. O resultado fica em
`evals/resultados/` (fora do git) e o resumo aparece no terminal, com a
diferença em relação à última execução.

## Como montar um caso

```
evals/casos/<nome>/
  contrato.txt     texto do contrato; páginas separadas por form feed (\f).
                   Gere a partir de um PDF com: pdftotext -enc UTF-8 contrato.pdf contrato.txt
  esperado.json    gabarito, revisado por advogado
```

`esperado.json`:

- `extracao`: só os campos que devem ser conferidos. Texto confere se ao menos
  80% das palavras esperadas aparecem no valor extraído; datas, por igualdade;
  `""` exige campo vazio. `partes` confere por CPF/CNPJ (ou pelo nome, se o
  documento não for informado).
- `riscos`: cada risco que a análise **precisa** encontrar, com um `trecho`
  literal do contrato e o `nivel_minimo` aceitável (`baixo`, `medio`, `alto`).
  Riscos extras apontados pela IA não reduzem a nota; aparecem em "extras"
  para revisão.

**Use apenas contratos anonimizados ou fictícios.** Nunca inclua documentos de
clientes neste repositório.

## Métricas

| Métrica | O que mede |
|---|---|
| Extração | % dos campos esperados extraídos corretamente |
| Riscos encontrados | % dos riscos do gabarito que a análise apontou (recall) |
| Nível adequado | dos encontrados, % com nível igual ou acima do mínimo |
| Trechos localizados | % dos trechos citados pela IA achados no texto (destaque na tela) |
| Custo e tempo | por caso, com os preços da tabela `ai_model_prices` |
