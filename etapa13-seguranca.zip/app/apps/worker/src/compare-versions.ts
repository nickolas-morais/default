import { compareRisks, compareText, comparisonStats } from "@app/shared/compare";
import type { WorkerDb } from "./db.ts";
import { log } from "./log.ts";

/**
 * Depois de analisar uma nova versão: compara texto e riscos com a versão
 * anterior e herda a situação dos riscos mantidos. Falha aqui não afeta a análise.
 */
export async function compareWithPrevious(db: WorkerDb, documentId: string): Promise<void> {
  const input = await db.comparisonInputs(documentId);
  if (!input) return;
  const started = Date.now();
  const text = compareText(input.old_pages, input.new_pages);
  const risks = compareRisks(
    input.old_risks.map((r) => ({ ...r, note: r.note })),
    input.new_risks,
  );
  const inherit = risks
    .filter((r) => r.type === "mantido" && r.old.resolution && r.old.resolution !== "aberto")
    .map((r) => r.type === "mantido" ? { new_risk_id: r.new.id, resolution: r.old.resolution, note: r.old.note ?? "" } : null)
    .filter(Boolean);
  const stats = comparisonStats(text, risks);
  await db.saveComparison(documentId, input.previous_id, text, risks, stats, inherit);
  log.info("comparação de versões gravada", { document_id: documentId, ms: Date.now() - started, ...stats, inherited: inherit.length });
}
