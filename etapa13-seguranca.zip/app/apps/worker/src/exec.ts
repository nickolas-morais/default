import { spawn } from "node:child_process";
import { PipelineError } from "./errors.ts";

export type ExecResult = { code: number; stdout: string; stderr: string };

const MAX_OUTPUT = 64 * 1024 * 1024; // texto de 50 páginas cabe com folga

/** Executa um comando sem shell, com timeout e cancelamento. */
export function run(
  command: string,
  args: string[],
  options: { timeoutMs: number; signal?: AbortSignal; cwd?: string },
): Promise<ExecResult> {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd: options.cwd,
      stdio: ["ignore", "pipe", "pipe"],
      env: { ...process.env, LANG: "C.UTF-8", OMP_THREAD_LIMIT: "1" },
    });

    let stdout = "";
    let stderr = "";
    let killed: "timeout" | "abort" | null = null;

    child.stdout.setEncoding("utf8").on("data", (d: string) => {
      if (stdout.length < MAX_OUTPUT) stdout += d;
    });
    child.stderr.setEncoding("utf8").on("data", (d: string) => {
      if (stderr.length < 64 * 1024) stderr += d;
    });

    const kill = (reason: "timeout" | "abort") => {
      killed = reason;
      child.kill("SIGKILL");
    };
    const timer = setTimeout(() => kill("timeout"), options.timeoutMs);
    const onAbort = () => kill("abort");
    options.signal?.addEventListener("abort", onAbort, { once: true });

    child.on("error", (err) => {
      clearTimeout(timer);
      reject(new PipelineError("PROCESSING_FAILED", { retryable: true, cause: err }));
    });
    child.on("close", (code) => {
      clearTimeout(timer);
      options.signal?.removeEventListener("abort", onAbort);
      if (killed) return reject(new PipelineError("PROCESSING_TIMEOUT", { retryable: true }));
      resolve({ code: code ?? -1, stdout, stderr });
    });
  });
}
