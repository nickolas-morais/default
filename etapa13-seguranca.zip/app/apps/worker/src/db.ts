import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import type { Config } from "./config.ts";
import type { AiUsage } from "./pipeline/analyze.ts";
import type { PageText } from "@app/shared/text-match";
import { PipelineError } from "./errors.ts";

export const BUCKET = "documents";

export type QueueMessage = { msg_id: number; read_ct: number; message: { job_id?: string; document_id?: string } };

export type StartedJob = {
  document_id: string;
  office_id: string;
  file_type: "pdf" | "docx";
  original_path: string;
  kind: "initial" | "reprocess" | "perspective";
  attempts: number;
  client_party_name: string | null;
  client_party_role: string | null;
};

/**
 * Acesso do worker ao Supabase (secret key: ignora a RLS). Todas as operações
 * são por id de job/documento vindos da fila; nada lista dados de escritórios.
 */
export function createWorkerDb(config: Config) {
  const sb: SupabaseClient = createClient(config.supabaseUrl, config.supabaseSecretKey, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  });

  async function rpc<T>(fn: string, args: Record<string, unknown>): Promise<T> {
    const { data, error } = await sb.rpc(fn, args);
    if (error) throw new PipelineError("PROCESSING_FAILED", { retryable: true, cause: new Error(`${fn}: ${error.message}`) });
    return data as T;
  }

  return {
    readJobs: (vt: number, qty: number) =>
      rpc<QueueMessage[]>("worker_read_jobs", { p_vt_seconds: vt, p_qty: qty }),
    ack: (msgId: number, archive = false) => rpc<void>("worker_ack", { p_msg_id: msgId, p_archive: archive }),
    delay: (msgId: number, seconds: number) => rpc<void>("worker_delay", { p_msg_id: msgId, p_seconds: seconds }),
    startJob: async (jobId: string) =>
      (await rpc<StartedJob[]>("worker_start_job", { p_job_id: jobId }))[0] ?? null,
    setStage: (jobId: string, status: "preprocessing" | "analyzing") =>
      rpc<void>("worker_set_stage", { p_job_id: jobId, p_status: status }),
    savePages: (jobId: string, pages: PageText[], viewerPath: string | null, isScanned: boolean, pageCount: number) =>
      rpc<void>("worker_save_pages", {
        p_job_id: jobId, p_pages: pages, p_viewer_path: viewerPath, p_is_scanned: isScanned, p_page_count: pageCount,
      }),
    recordUsage: (jobId: string, u: AiUsage) =>
      rpc<number | null>("worker_record_ai_usage", {
        p_job_id: jobId, p_model: u.model, p_input_tokens: u.inputTokens, p_output_tokens: u.outputTokens,
        p_thinking_tokens: u.thinkingTokens, p_cache_creation_tokens: u.cacheCreationTokens,
        p_cache_read_tokens: u.cacheReadTokens, p_duration_ms: u.durationMs, p_stop_reason: u.stopReason,
      }),
    completeJob: (jobId: string, result: unknown, promptVersion: string, prepareMs: number, aiMs: number) =>
      rpc<boolean>("worker_complete_job", {
        p_job_id: jobId, p_result: result, p_prompt_version: promptVersion, p_prepare_ms: prepareMs, p_ai_ms: aiMs,
      }),
    retryJob: (jobId: string, code: string) => rpc<void>("worker_retry_job", { p_job_id: jobId, p_error_code: code }),
    failJob: (jobId: string, code: string, fileDeleted: boolean) =>
      rpc<void>("worker_fail_job", { p_job_id: jobId, p_error_code: code, p_file_deleted: fileDeleted }),
    documentExists: async (documentId: string) => {
      const { data, error } = await sb.from("documents").select("id").eq("id", documentId).maybeSingle();
      if (error) throw new PipelineError("PROCESSING_FAILED", { retryable: true, cause: error });
      return Boolean(data);
    },
    abandonedUploads: () =>
      rpc<{ document_id: string; original_path: string }[]>("worker_abandoned_uploads", { p_older_than_minutes: 120 }),
    deleteAbandoned: (documentId: string) => rpc<void>("worker_delete_abandoned", { p_document_id: documentId }),
    notifyClaim: (key: string, kind: string) => rpc<boolean>("notify_claim", { p_key: key, p_kind: kind }),
    notifyRelease: (key: string) => rpc<void>("notify_release", { p_key: key }),
    notifyOfficeAdmins: (officeId: string, onlyQuotaOptIn = false) =>
      rpc<{ email: string; full_name: string; office_name: string }[]>("notify_office_admins", {
        p_office_id: officeId, p_only_quota_optin: onlyQuotaOptIn,
      }),
    notifyUploader: async (documentId: string) =>
      (await rpc<{ email: string; full_name: string; file_name: string; risks: number; high_risks: number }[]>(
        "notify_document_uploader", { p_document_id: documentId }))[0] ?? null,
    notifyQuotaStatus: async (officeId: string) =>
      (await rpc<{ source: string; plan_name: string | null; doc_limit: number; used: number; period_start: string | null; period_end: string | null }[]>(
        "notify_quota_status", { p_office_id: officeId }))[0] ?? null,
    notifyExpiringContracts: () =>
      rpc<{ contract_id: string; office_id: string; ends_at: string; days_left: number }[]>("notify_expiring_contracts", {}),
    notifyQueueBacklog: async () =>
      (await rpc<{ waiting: number; oldest_minutes: number }[]>("notify_queue_backlog", { p_minutes: 15 }))[0] ?? { waiting: 0, oldest_minutes: 0 },
    notifyDueDeadlines: () =>
      rpc<{ deadline_id: string; document_id: string; office_id: string; file_name: string; title: string; due_date: string; days_left: number }[]>(
        "notify_due_deadlines", {}),
    notifyDeadlineRecipients: (documentId: string) =>
      rpc<{ email: string }[]>("notify_deadline_recipients", { p_document_id: documentId }),
    notifyPlatformAdmins: () => rpc<{ email: string }[]>("notify_platform_admins", {}),
    previousPages: (documentId: string) =>
      rpc<{ page: number; text: string }[] | null>("worker_previous_pages", { p_document_id: documentId }),
    playbookRules: (officeId: string) =>
      rpc<{ id: string; title: string; instruction: string; min_level: string | null; contract_types: string }[]>(
        "worker_playbook_rules", { p_office_id: officeId }),
    comparisonInputs: (documentId: string) =>
      rpc<{
        previous_id: string;
        old_pages: { page: number; text: string }[];
        new_pages: { page: number; text: string }[];
        old_risks: { id: string; title: string; excerpt: string; level: "alto" | "medio" | "baixo"; resolution: string; note: string }[];
        new_risks: { id: string; title: string; excerpt: string; level: "alto" | "medio" | "baixo" }[];
      } | null>("worker_comparison_inputs", { p_document_id: documentId }),
    saveComparison: (documentId: string, previousId: string, text: unknown, risks: unknown, stats: unknown, inherit: unknown) =>
      rpc<void>("worker_save_comparison", {
        p_document_id: documentId, p_previous_id: previousId, p_text: text, p_risks: risks, p_stats: stats, p_inherit: inherit,
      }),
    officesDueForDeletion: () =>
      rpc<{ office_id: string; member_ids: string[] }[]>("worker_offices_due_for_deletion", {}),
    deleteOffice: (officeId: string) => rpc<void>("worker_delete_office", { p_office_id: officeId }),
    deleteAuthUser: async (userId: string) => {
      const { error } = await sb.auth.admin.deleteUser(userId);
      // Usuário já removido não é erro.
      if (error && error.status !== 404) throw new PipelineError("PROCESSING_FAILED", { retryable: true, cause: error });
    },

    storage: {
      download: async (objectPath: string): Promise<Uint8Array> => {
        const { data, error } = await sb.storage.from(BUCKET).download(objectPath);
        if (error || !data) throw new PipelineError("STORAGE_UNAVAILABLE", { retryable: true, cause: error });
        return new Uint8Array(await data.arrayBuffer());
      },
      uploadPdf: async (objectPath: string, bytes: Uint8Array) => {
        const { error } = await sb.storage.from(BUCKET).upload(objectPath, bytes, {
          contentType: "application/pdf",
          upsert: true,
        });
        if (error) throw new PipelineError("STORAGE_UNAVAILABLE", { retryable: true, cause: error });
      },
      /** Remove tudo sob {escritório}/{documento}/. */
      removeFolder: async (prefix: string) => {
        const { data, error } = await sb.storage.from(BUCKET).list(prefix, { limit: 1000 });
        if (error) throw new PipelineError("STORAGE_UNAVAILABLE", { retryable: true, cause: error });
        if (data.length) {
          const { error: rmError } = await sb.storage.from(BUCKET).remove(data.map((f) => `${prefix}/${f.name}`));
          if (rmError) throw new PipelineError("STORAGE_UNAVAILABLE", { retryable: true, cause: rmError });
        }
      },
      /** Remove todos os arquivos do escritório ({office}/…, inclusive subpastas). */
      removeOfficeFiles: async (officeId: string) => {
        const top = await sb.storage.from(BUCKET).list(officeId, { limit: 1000 });
        if (top.error) throw new PipelineError("STORAGE_UNAVAILABLE", { retryable: true, cause: top.error });
        for (const entry of top.data) {
          const folder = `${officeId}/${entry.name}`;
          // Pastas (documento, templates) vêm sem id; arquivos soltos, com id.
          const paths = entry.id
            ? [folder]
            : ((await sb.storage.from(BUCKET).list(folder, { limit: 1000 })).data ?? []).map((f) => `${folder}/${f.name}`);
          if (paths.length) {
            const { error } = await sb.storage.from(BUCKET).remove(paths);
            if (error) throw new PipelineError("STORAGE_UNAVAILABLE", { retryable: true, cause: error });
          }
        }
      },
      remove: async (objectPath: string) => {
        await sb.storage.from(BUCKET).remove([objectPath]);
      },
    },
  };
}

export type WorkerDb = ReturnType<typeof createWorkerDb>;
