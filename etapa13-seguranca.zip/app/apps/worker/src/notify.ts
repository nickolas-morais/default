import { sendEmail, type EmailMessage } from "@app/shared/email";
import {
  analysisDoneEmail, contractExpiringEmail, deadlineReminderEmail, quotaEmail, queueBacklogEmail,
} from "@app/shared/email-templates";
import type { WorkerDb } from "./db.ts";
import { log } from "./log.ts";

type Send = (msg: EmailMessage) => ReturnType<typeof sendEmail>;

/**
 * Avisos por e-mail disparados pelo worker. Cada aviso tem uma chave única
 * (reservada antes do envio e liberada se falhar), então nunca sai duplicado.
 * Falha de e-mail nunca derruba o processamento.
 */
export function createNotifier(db: WorkerDb, siteUrl: string, send: Send = (m) => sendEmail(m)) {
  async function once(key: string, kind: string, build: () => Promise<EmailMessage | null>) {
    if (!(await db.notifyClaim(key, kind))) return;
    try {
      const msg = await build();
      if (!msg || !msg.to.length) return;
      const r = await send(msg);
      if (!r.ok) throw new Error(r.error);
      log.info("aviso enviado", { kind, recipients: msg.to.length });
    } catch (e) {
      await db.notifyRelease(key).catch(() => undefined);
      log.error("falha ao enviar aviso", { kind, cause: String(e).slice(0, 300) });
    }
  }

  return {
    /** Depois que uma análise termina: aviso ao autor e, se for o caso, de cota. */
    async afterCompleted(o: { jobId: string; documentId: string; officeId: string }) {
      await once(`analysis:${o.jobId}`, "analysis_done", async () => {
        const u = await db.notifyUploader(o.documentId);
        if (!u) return null;
        return {
          to: [u.email],
          ...analysisDoneEmail({ name: u.full_name, fileName: u.file_name, risks: u.risks, highRisks: u.high_risks,
            url: `${siteUrl}/documentos/${o.documentId}` }),
        };
      });

      const q = await db.notifyQuotaStatus(o.officeId);
      if (!q || q.source === "none" || q.doc_limit <= 0) return;
      const level = q.used >= q.doc_limit ? 100 : q.used / q.doc_limit >= 0.8 ? 80 : 0;
      if (!level) return;
      await once(`quota${level}:${o.officeId}:${q.period_start}`, "quota", async () => {
        const admins = await db.notifyOfficeAdmins(o.officeId, true);
        if (!admins.length) return null;
        return {
          to: admins.map((a) => a.email),
          ...quotaEmail({ officeName: admins[0]!.office_name, used: q.used, limit: q.doc_limit, periodEnd: q.period_end,
            url: `${siteUrl}/plano` }),
        };
      });
    },

    /** Rotina periódica: contratos vencendo (15 e 3 dias) e fila acumulada. */
    async periodic() {
      for (const c of await db.notifyExpiringContracts()) {
        const bucket = c.days_left <= 3 ? 3 : 15;
        await once(`contract${bucket}:${c.contract_id}`, "contract_expiring", async () => {
          const admins = await db.notifyOfficeAdmins(c.office_id);
          if (!admins.length) return null;
          return { to: admins.map((a) => a.email),
            ...contractExpiringEmail({ officeName: admins[0]!.office_name, daysLeft: c.days_left, endsAt: c.ends_at }) };
        });
      }

      // Lembretes de prazos: no dia e 1, 7 e 30 dias antes (uma vez cada).
      for (const d of await db.notifyDueDeadlines()) {
        await once(`deadline:${d.deadline_id}:${d.due_date}:${d.days_left}`, "deadline", async () => {
          const to = (await db.notifyDeadlineRecipients(d.document_id)).map((r) => r.email);
          return { to, ...deadlineReminderEmail({ title: d.title, fileName: d.file_name, dueDate: d.due_date,
            daysLeft: d.days_left, url: `${siteUrl}/documentos/${d.document_id}?aba=prazos` }) };
        });
      }

      const backlog = await db.notifyQueueBacklog();
      if (backlog.waiting > 0) {
        log.warn("fila acumulada", { waiting: backlog.waiting, oldest_minutes: backlog.oldest_minutes });
        await once(`queue:${new Date().toISOString().slice(0, 13)}`, "queue_backlog", async () => {
          const admins = await db.notifyPlatformAdmins();
          return { to: admins.map((a) => a.email),
            ...queueBacklogEmail({ waiting: backlog.waiting, oldestMinutes: backlog.oldest_minutes, url: `${siteUrl}/admin` }) };
        });
      }
    },
  };
}
