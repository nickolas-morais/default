import type { ErrorCode } from "@app/shared";

/** Falhas causadas pelo próprio arquivo: o arquivo é descartado. */
const FILE_PROBLEMS = new Set<ErrorCode>([
  "TOO_MANY_PAGES",
  "PASSWORD_PROTECTED",
  "FILE_CORRUPTED",
  "FILE_TYPE_MISMATCH",
  "OCR_ILLEGIBLE",
  "VERSION_UNRELATED",
]);

export class PipelineError extends Error {
  readonly code: ErrorCode;
  readonly retryable: boolean;

  constructor(code: ErrorCode, options: { retryable?: boolean; cause?: unknown } = {}) {
    super(code, { cause: options.cause });
    this.code = code;
    this.retryable = options.retryable ?? false;
  }

  get deletesFile(): boolean {
    return FILE_PROBLEMS.has(this.code);
  }
}

export function toPipelineError(error: unknown): PipelineError {
  if (error instanceof PipelineError) return error;
  return new PipelineError("PROCESSING_FAILED", { retryable: true, cause: error });
}
