import { test } from "node:test";
import assert from "node:assert/strict";
import type { WorkerDb } from "./db.ts";
import { createNotifier } from "./notify.ts";

function fake(o: { used: number; limit: number; sendFails?: boolean }) {
  const claimed = new Set<string>();
  const sent: string[] = [];
  const db = {
    notifyClaim: async (k: string) => (claimed.has(k) ? false : (claimed.add(k), true)),
    notifyRelease: async (k: string) => { claimed.delete(k); },
    notifyUploader: async () => ({ email: "ana@a.com", full_name: "Ana", file_name: "c.pdf", risks: 2, high_risks: 1 }),
    notifyQuotaStatus: async () => ({ source: "subscription", plan_name: "Essencial", doc_limit: o.limit, used: o.used,
      period_start: "2026-10-01T00:00:00Z", period_end: "2026-11-01T00:00:00Z" }),
    notifyOfficeAdmins: async () => [{ email: "titular@a.com", full_name: "T", office_name: "A" }],
    notifyExpiringContracts: async () => [{ contract_id: "c1", office_id: "o1", ends_at: "2026-10-10T00:00:00Z", days_left: 2 }],
    notifyQueueBacklog: async () => ({ waiting: 0, oldest_minutes: 0 }),
    notifyPlatformAdmins: async () => [],
    notifyDueDeadlines: async () => [{ deadline_id: "p1", document_id: "d1", office_id: "o1", file_name: "c.pdf",
      title: "Aviso de não renovação", due_date: "2026-10-08", days_left: 7 }],
    notifyDeadlineRecipients: async () => [{ email: "ana@a.com" }],
  } as unknown as WorkerDb;
  const n = createNotifier(db, "http://app", async (m) => {
    if (o.sendFails) return { ok: false, error: "smtp down" };
    sent.push(m.subject);
    return { ok: true, id: "1" };
  });
  return { n, sent, claimed };
}

const job = { jobId: "j1", documentId: "d1", officeId: "o1" };

test("análise concluída e cota em 80%, uma vez só", async () => {
  const f = fake({ used: 24, limit: 30 });
  await f.n.afterCompleted(job);
  await f.n.afterCompleted({ ...job, jobId: "j2" });
  assert.deepEqual(f.sent, ["Análise concluída: c.pdf", "Cota em 80%: A", "Análise concluída: c.pdf"]);
});

test("abaixo de 80% não avisa cota", async () => {
  const f = fake({ used: 10, limit: 30 });
  await f.n.afterCompleted(job);
  assert.equal(f.sent.length, 1);
});

test("falha no envio libera a chave para nova tentativa", async () => {
  const f = fake({ used: 30, limit: 30, sendFails: true });
  await f.n.afterCompleted(job);
  assert.equal(f.claimed.size, 0);
});

test("contrato vencendo em 3 dias", async () => {
  const f = fake({ used: 0, limit: 30 });
  await f.n.periodic();
  assert.deepEqual(f.sent, ["Contrato vence em 2 dias: A", "Prazo vence em 7 dias: Aviso de não renovação"]);
  assert.ok(f.claimed.has("contract3:c1"));
});
