/**
 * Avaliação da análise contra o gabarito em evals/casos/<nome>/.
 *   pnpm eval [caso ...]
 * Chama a API da Anthropic de verdade (custa uma análise por caso).
 */
import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import Anthropic from "@anthropic-ai/sdk";
import { PROMPT_VERSION } from "@app/shared/analysis-prompt";
import { analyzeDocument, type AiUsage } from "../pipeline/analyze.ts";
import { scoreCase, type CaseScore, type Expected } from "./score.ts";

const ROOT = new URL("../../../../evals/", import.meta.url);
const CASES = new URL("casos/", ROOT);
const RESULTS = new URL("resultados/", ROOT);

// USD por milhão de tokens (mesmos valores de ai_model_prices).
const PRICES: Record<string, [number, number, number, number]> = {
  "claude-sonnet-5-5": [2, 10, 2.5, 0.2],
  "claude-opus-5-5": [4, 20, 5, 0.2],
  "claude-haiku-4-5-20251001": [1, 5, 1.25, 0.1],
};
const cost = (u: AiUsage) => {
  const p = PRICES[u.model] ?? PRICES[Object.keys(PRICES).find((k) => u.model.startsWith(k)) ?? ""];
  return p ? (u.inputTokens * p[0] + u.outputTokens * p[1] + u.cacheCreationTokens * p[2] + u.cacheReadTokens * p[3]) / 1e6 : 0;
};

const apiKey = process.env.ANTHROPIC_API_KEY;
if (!apiKey || apiKey.includes("cole-a-")) {
  console.error("Defina ANTHROPIC_API_KEY em apps/worker/.env.");
  process.exit(1);
}
const model = process.env.ANTHROPIC_MODEL ?? "claude-sonnet-5-5";
const effort = (process.env.ANTHROPIC_EFFORT ?? "medium") as "low" | "medium" | "high";
const client = new Anthropic({ apiKey, maxRetries: 3, timeout: 10 * 60 * 1000 });

const only = process.argv.slice(2);
const names = readdirSync(CASES, { withFileTypes: true })
  .filter((d) => d.isDirectory() && (!only.length || only.includes(d.name)))
  .map((d) => d.name)
  .sort();
if (!names.length) {
  console.error("Nenhum caso encontrado em evals/casos/.");
  process.exit(1);
}

type CaseResult = { name: string; score: CaseScore; costUsd: number; seconds: number; error?: string };
const results: CaseResult[] = [];

for (const name of names) {
  const dir = new URL(`${name}/`, CASES);
  const txt = new URL("contrato.txt", dir);
  if (!existsSync(txt)) {
    console.warn(`- ${name}: sem contrato.txt, pulado`);
    continue;
  }
  const pages = readFileSync(txt, "utf8").split("\f").map((text, i) => ({ page: i + 1, text: text.trim() })).filter((p) => p.text);
  const expected = JSON.parse(readFileSync(new URL("esperado.json", dir), "utf8")) as Expected;
  const usages: AiUsage[] = [];
  const started = Date.now();
  process.stdout.write(`- ${name} (${pages.length} páginas)… `);
  try {
    const analysis = await analyzeDocument({
      client, model, effort, pages, signal: AbortSignal.timeout(10 * 60 * 1000),
      perspective: expected.perspectiva ? { name: expected.perspectiva.nome, role: expected.perspectiva.papel ?? null } : null,
      onUsage: async (u) => { usages.push(u); },
    });
    const score = scoreCase(analysis, expected, pages);
    results.push({ name, score, costUsd: usages.reduce((s, u) => s + cost(u), 0), seconds: (Date.now() - started) / 1000 });
    console.log(`extração ${score.extractionPct}%, riscos ${score.recallPct}%, nível ${score.levelPct}%`);
  } catch (e) {
    console.log("falhou");
    results.push({ name, error: e instanceof Error ? e.message : String(e), costUsd: usages.reduce((s, u) => s + cost(u), 0),
      seconds: (Date.now() - started) / 1000, score: undefined as unknown as CaseScore });
  }
}

const ok = results.filter((r) => !r.error);
const avg = (f: (s: CaseScore) => number) => (ok.length ? Math.round((10 * ok.reduce((s, r) => s + f(r.score), 0)) / ok.length) / 10 : 0);
const summary = {
  prompt_version: PROMPT_VERSION, model, effort, ran_at: new Date().toISOString(), cases: results.length, failed: results.length - ok.length,
  extraction_pct: avg((s) => s.extractionPct), recall_pct: avg((s) => s.recallPct), level_pct: avg((s) => s.levelPct),
  located_pct: avg((s) => s.locatedPct), cost_usd: Math.round(results.reduce((s, r) => s + r.costUsd, 0) * 10000) / 10000,
  avg_seconds: ok.length ? Math.round(ok.reduce((s, r) => s + r.seconds, 0) / ok.length) : 0,
};

mkdirSync(RESULTS, { recursive: true });
const previous = readdirSync(RESULTS).filter((f) => f.endsWith(".json")).sort().at(-1);
const prev = previous ? (JSON.parse(readFileSync(new URL(previous, RESULTS), "utf8")).summary as typeof summary) : null;
const file = `${summary.ran_at.slice(0, 16).replace(/[:T]/g, "-")}_${PROMPT_VERSION}_${model}.json`;
writeFileSync(new URL(file, RESULTS), JSON.stringify({ summary, results }, null, 2));

const delta = (k: keyof typeof summary) => {
  if (!prev || typeof summary[k] !== "number" || typeof prev[k] !== "number") return "";
  const d = Math.round(((summary[k] as number) - (prev[k] as number)) * 10) / 10;
  return d === 0 ? "  (=)" : `  (${d > 0 ? "+" : ""}${d})`;
};

console.log(`\nPrompt ${PROMPT_VERSION}, ${model}, esforço ${effort}${prev ? `; comparado a ${previous}` : ""}`);
console.log(`Extração             ${summary.extraction_pct}%${delta("extraction_pct")}`);
console.log(`Riscos encontrados   ${summary.recall_pct}%${delta("recall_pct")}`);
console.log(`Nível adequado       ${summary.level_pct}%${delta("level_pct")}`);
console.log(`Trechos localizados  ${summary.located_pct}%${delta("located_pct")}`);
console.log(`Custo total          US$ ${summary.cost_usd}${delta("cost_usd")}`);
console.log(`Tempo médio          ${summary.avg_seconds}s${delta("avg_seconds")}`);
for (const r of results) {
  if (r.error) { console.log(`\n${r.name}: ERRO ${r.error.slice(0, 200)}`); continue; }
  const missed = r.score.risks.filter((x) => !x.found).map((x) => x.id);
  const low = r.score.risks.filter((x) => x.found && !x.levelOk).map((x) => `${x.id} (${x.level})`);
  const badFields = r.score.fields.filter((f) => !f.ok).map((f) => f.field);
  if (missed.length) console.log(`\n${r.name}: riscos não encontrados: ${missed.join(", ")}`);
  if (low.length) console.log(`${r.name}: nível abaixo do esperado: ${low.join(", ")}`);
  if (badFields.length) console.log(`${r.name}: campos errados: ${badFields.join(", ")}`);
  if (r.score.extras.length) console.log(`${r.name}: riscos extras (revisar): ${r.score.extras.join("; ")}`);
}
console.log(`\nDetalhes: evals/resultados/${file}`);
