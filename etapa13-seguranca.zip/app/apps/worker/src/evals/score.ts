/**
 * Pontuação de uma análise contra o gabarito (esperado.json). Funções puras.
 */
import type { Analysis, RiskLevel } from "@app/shared/analysis";
import { normalizeCnpj } from "@app/shared";
import { findBestWindow, locateExcerpt, tokenize, type PageText } from "@app/shared/text-match";

export type Expected = {
  descricao?: string;
  /** Parte representada; ausente = análise neutra. */
  perspectiva?: { nome: string; papel?: string };
  extracao?: Partial<Record<Exclude<keyof Analysis["extracao"], "partes" | "multas">, string>> & {
    partes?: { nome: string; documento?: string }[];
  };
  riscos?: { id: string; trecho: string; nivel_minimo: RiskLevel }[];
};

export type CaseScore = {
  fields: { field: string; ok: boolean; expected: string; actual: string }[];
  risks: { id: string; found: boolean; levelOk: boolean; matchedTitle: string | null; level: RiskLevel | null }[];
  extras: string[];
  extractionPct: number;
  recallPct: number;
  levelPct: number;
  locatedPct: number;
};

const RANK: Record<RiskLevel, number> = { baixo: 1, medio: 2, alto: 3 };
const pct = (n: number, d: number) => (d ? Math.round((1000 * n) / d) / 10 : 100);

/** Palavras para comparar campos: separa também por pontuação ("Manaus/AM"). */
const words = (s: string) =>
  s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);

function textOk(expected: string, actual: string): boolean {
  if (expected === "") return actual.trim() === "";
  if (/^\d{4}-\d{2}-\d{2}$/.test(expected)) return actual.trim() === expected;
  const exp = words(expected);
  const act = new Set(words(actual));
  return exp.length > 0 && exp.filter((t) => act.has(t)).length / exp.length >= 0.8;
}

/** Semelhança entre dois trechos, nas duas direções (um pode conter o outro). */
export function excerptSimilarity(a: string, b: string): number {
  const ta = tokenize(a);
  const tb = tokenize(b);
  const ab = findBestWindow(ta, tb, 0)?.score ?? 0;
  const ba = findBestWindow(tb, ta, 0)?.score ?? 0;
  return Math.max(ab, ba);
}

export function scoreCase(analysis: Analysis, expected: Expected, pages: PageText[]): CaseScore {
  const fields: CaseScore["fields"] = [];
  const ex = expected.extracao ?? {};

  for (const p of ex.partes ?? []) {
    const doc = p.documento ? normalizeCnpj(p.documento) : null;
    const hit = analysis.extracao.partes.find((a) =>
      doc ? normalizeCnpj(a.documento) === doc : textOk(p.nome, a.nome),
    );
    fields.push({ field: `parte: ${p.nome}`, ok: Boolean(hit), expected: p.documento ?? p.nome, actual: hit ? `${hit.nome} ${hit.documento}` : "" });
  }
  for (const [key, value] of Object.entries(ex)) {
    if (key === "partes" || typeof value !== "string") continue;
    const actual = String((analysis.extracao as Record<string, unknown>)[key] ?? "");
    fields.push({ field: key, ok: textOk(value, actual), expected: value, actual });
  }

  const used = new Set<number>();
  const risks: CaseScore["risks"] = (expected.riscos ?? []).map((er) => {
    let best = -1;
    let bestScore = 0;
    analysis.riscos.forEach((r, i) => {
      const s = excerptSimilarity(er.trecho, r.trecho_original);
      if (s > bestScore) {
        bestScore = s;
        best = i;
      }
    });
    if (best < 0 || bestScore < 0.6) return { id: er.id, found: false, levelOk: false, matchedTitle: null, level: null };
    used.add(best);
    const r = analysis.riscos[best]!;
    return { id: er.id, found: true, levelOk: RANK[r.nivel] >= RANK[er.nivel_minimo], matchedTitle: r.titulo, level: r.nivel };
  });

  const found = risks.filter((r) => r.found);
  const located = analysis.riscos.filter((r) => locateExcerpt(pages, r.trecho_original)).length;

  return {
    fields,
    risks,
    extras: analysis.riscos.filter((_, i) => !used.has(i)).map((r) => `[${r.nivel}] ${r.titulo}`),
    extractionPct: pct(fields.filter((f) => f.ok).length, fields.length),
    recallPct: pct(found.length, risks.length),
    levelPct: pct(found.filter((r) => r.levelOk).length, found.length),
    locatedPct: pct(located, analysis.riscos.length),
  };
}
