import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import type { Analysis } from "@app/shared/analysis";
import { scoreCase, type Expected } from "./score.ts";

const root = new URL("../../../../evals/casos/locacao-comercial/", import.meta.url);
const expected = JSON.parse(readFileSync(new URL("esperado.json", root), "utf8")) as Expected;
const pages = readFileSync(new URL("contrato.txt", root), "utf8").split("\f").map((text, i) => ({ page: i + 1, text }));

const base: Analysis = {
  extracao: {
    partes: [
      { nome: "IMOBILIÁRIA HORIZONTE PAULISTA LTDA.", documento: "11222333000181", papel: "Locadora" },
      { nome: "Café Aurora", documento: "12.ABC.345/01DE-35", papel: "Locatária" },
    ],
    objeto: "", valor: "R$ 8.500,00 (oito mil e quinhentos reais) mensais", forma_pagamento: "", vigencia: "36 (trinta e seis) meses",
    data_inicio: "2026-10-01", data_fim: "", prazo_rescisao: "", multas: [], foro: "Comarca de Manaus/AM", indice_reajuste: "",
  },
  prazos: [],
  riscos: [
    { nivel: "alto", titulo: "Multa desproporcional", clausula: "9.1", pagina: 2,
      trecho_original: "Em caso de rescisão antecipada por iniciativa da LOCATÁRIA, esta pagará multa equivalente a 12 (doze) aluguéis vigentes, independentemente do tempo decorrido do contrato.",
      explicacao: "", sugestao_redacao: "", parte_prejudicada: "", regra_playbook: "" },
    { nivel: "baixo", titulo: "Foro", clausula: "13.1", pagina: 3,
      trecho_original: "Fica eleito o foro da Comarca de Manaus/AM para dirimir quaisquer dúvidas",
      explicacao: "", sugestao_redacao: "", parte_prejudicada: "", regra_playbook: "" },
    { nivel: "medio", titulo: "Seguro", clausula: "5.1", pagina: 2,
      trecho_original: "correrão por conta da LOCATÁRIA o IPTU, as taxas condominiais ordinárias e extraordinárias",
      explicacao: "", sugestao_redacao: "", parte_prejudicada: "", regra_playbook: "" },
  ],
  resumo: "",
};

test("pontua extração, riscos encontrados, nível e extras", () => {
  const s = scoreCase(base, expected, pages);
  // 3 partes + valor, datas, foro, vigência = 8 campos; faltam fiador e data_fim.
  assert.equal(s.fields.length, 8);
  assert.equal(s.extractionPct, 75);
  assert.equal(s.risks.find((r) => r.id === "multa-rescisao")?.found, true);
  assert.equal(s.risks.find((r) => r.id === "foro-distante")?.levelOk, false, "baixo < médio exigido");
  assert.equal(s.recallPct, Math.round((1000 * 2) / 12) / 10);
  assert.equal(s.levelPct, 50);
  assert.deepEqual(s.extras, ["[medio] Seguro"]);
  assert.equal(s.locatedPct, 100);
});
