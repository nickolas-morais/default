import { test } from "node:test";
import assert from "node:assert/strict";
import Anthropic from "@anthropic-ai/sdk";
import { analyzeDocument, type AiUsage, type MessagesClient } from "./analyze.ts";
import { PipelineError } from "../errors.ts";

const VALID = {
  extracao: {
    partes: [{ nome: "Fulano", documento: "529.982.247-25", papel: "Contratante" }],
    objeto: "Serviços", valor: "R$ 1.000,00", forma_pagamento: "Pix", vigencia: "12 meses",
    data_inicio: "2026-10-01", data_fim: "", prazo_rescisao: "30 dias", multas: [], foro: "São Paulo/SP",
    indice_reajuste: "IPCA",
  },
  riscos: [],
  resumo: "Resumo.",
};

function message(text: string, stop: string): Anthropic.Message {
  return {
    id: "msg", type: "message", role: "assistant", model: "claude-sonnet-5-5", stop_reason: stop,
    content: [{ type: "text", text, citations: null }],
    usage: { input_tokens: 1000, output_tokens: 200, cache_creation_input_tokens: 0, cache_read_input_tokens: 900,
      output_tokens_details: { thinking_tokens: 50 } },
  } as unknown as Anthropic.Message;
}

function client(responses: Array<Anthropic.Message | Error>) {
  const requests: Array<Record<string, unknown>> = [];
  const c = {
    messages: {
      stream: (params: Record<string, unknown>) => {
        requests.push(params);
        const next = responses.shift()!;
        return { finalMessage: async () => { if (next instanceof Error) throw next; return next; } };
      },
    },
  } as unknown as MessagesClient;
  return { c, requests };
}

async function run(responses: Array<Anthropic.Message | Error>) {
  const { c, requests } = client(responses);
  const usages: AiUsage[] = [];
  const promise = analyzeDocument({
    client: c, model: "claude-sonnet-5-5", effort: "medium",
    pages: [{ page: 1, text: "contrato" }], signal: new AbortController().signal,
    onUsage: async (u) => { usages.push(u); },
  });
  return { promise, requests, usages };
}

const code = (c: string, retryable?: boolean) => (e: unknown) =>
  e instanceof PipelineError && e.code === c && (retryable === undefined || e.retryable === retryable);

test("resposta válida: devolve a análise e registra o uso", async () => {
  const r = await run([message(JSON.stringify(VALID), "end_turn")]);
  const analysis = await r.promise;
  assert.equal(analysis.extracao.partes[0]!.nome, "Fulano");
  assert.equal(r.usages.length, 1);
  assert.equal(r.usages[0]!.cacheReadTokens, 900);
  assert.equal(r.usages[0]!.thinkingTokens, 50);
});

test("requisição usa saída estruturada, esforço e cache do system prompt", async () => {
  const r = await run([message(JSON.stringify(VALID), "end_turn")]);
  await r.promise;
  const req = r.requests[0]!;
  const out = req.output_config as { effort: string; format: { type: string } };
  assert.equal(out.effort, "medium");
  assert.equal(out.format.type, "json_schema");
  const system = req.system as Array<{ cache_control?: unknown }>;
  assert.deepEqual(system[0]!.cache_control, { type: "ephemeral" });
});

test("limite de tokens: tenta de novo com limite maior e registra as duas chamadas", async () => {
  const r = await run([message("{\"extracao\":", "max_tokens"), message(JSON.stringify(VALID), "end_turn")]);
  await r.promise;
  assert.equal(r.usages.length, 2);
  assert.equal(r.requests[1]!.max_tokens, 64_000);
});

test("recusa do modelo", async () => {
  const r = await run([message("", "refusal")]);
  await assert.rejects(r.promise, code("AI_REFUSED", false));
});

test("JSON fora dos limites de validação", async () => {
  const r = await run([message(JSON.stringify({ ...VALID, riscos: [{ nivel: "gravissimo" }] }), "end_turn")]);
  await assert.rejects(r.promise, code("AI_INVALID_OUTPUT", true));
});

test("API sobrecarregada é temporária; requisição inválida não", async () => {
  const overloaded = await run([new Anthropic.APIError(529, undefined, "overloaded", new Headers())]);
  await assert.rejects(overloaded.promise, code("AI_UNAVAILABLE", true));
  const invalid = await run([new Anthropic.APIError(400, undefined, "bad request", new Headers())]);
  await assert.rejects(invalid.promise, code("PROCESSING_FAILED", false));
});
