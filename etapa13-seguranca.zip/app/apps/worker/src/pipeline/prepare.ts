import { existsSync } from "node:fs";
import path from "node:path";
import { MAX_PAGES, type AcceptedFileType } from "@app/shared";
import type { PageText } from "@app/shared/text-match";
import { PipelineError } from "../errors.ts";
import { run } from "../exec.ts";

export type Prepared = {
  /** PDF final (convertido, sem proteção e com camada de texto). */
  pdfPath: string;
  /** true se o PDF final difere do original e precisa ser guardado como viewer.pdf. */
  viewerChanged: boolean;
  pages: PageText[];
  pageCount: number;
  isScanned: boolean;
  ocrApplied: boolean;
};

/** Página com menos letras que isto é tratada como imagem (precisa de OCR). */
const MIN_LETTERS_PER_PAGE = 40;

function letters(text: string): number {
  return text.match(/\p{L}/gu)?.length ?? 0;
}

async function docxToPdf(input: string, workDir: string, signal: AbortSignal): Promise<string> {
  const result = await run(
    "soffice",
    [
      "--headless", "--norestore", "--nolockcheck", "--nodefault",
      // Perfil próprio por job: permite conversões em paralelo.
      `-env:UserInstallation=file://${path.join(workDir, "lo-profile")}`,
      "--convert-to", "pdf", "--outdir", path.join(workDir, "docx"), input,
    ],
    { timeoutMs: 180_000, signal },
  );
  const output = path.join(workDir, "docx", `${path.parse(input).name}.pdf`);
  // O LibreOffice pode sair com código 0 sem gerar o arquivo.
  if (result.code !== 0 || !existsSync(output)) throw new PipelineError("FILE_CORRUPTED");
  return output;
}

/** Remove proteção sem senha de abertura; recusa se houver senha de abertura. */
async function removeProtection(input: string, workDir: string, signal: AbortSignal): Promise<string | null> {
  // --requires-password: 0 = exige senha, 2 = não criptografado,
  // 3 = criptografado sem senha de abertura.
  const check = await run("qpdf", ["--requires-password", input], { timeoutMs: 30_000, signal });
  if (check.code === 2) return null;
  if (check.code === 0) throw new PipelineError("PASSWORD_PROTECTED");
  if (check.code !== 3) throw new PipelineError("FILE_CORRUPTED");

  const output = path.join(workDir, "decrypted.pdf");
  const decrypt = await run("qpdf", ["--decrypt", input, output], { timeoutMs: 60_000, signal });
  // qpdf: 0 = ok, 3 = ok com avisos.
  if ((decrypt.code !== 0 && decrypt.code !== 3) || !existsSync(output)) {
    throw new PipelineError("PASSWORD_PROTECTED");
  }
  return output;
}

async function countPages(input: string, signal: AbortSignal): Promise<number> {
  const result = await run("qpdf", ["--show-npages", input], { timeoutMs: 30_000, signal });
  const n = Number.parseInt(result.stdout.trim(), 10);
  if ((result.code !== 0 && result.code !== 3) || !Number.isFinite(n) || n <= 0) {
    throw new PipelineError("FILE_CORRUPTED");
  }
  return n;
}

async function extractText(input: string, pageCount: number, signal: AbortSignal): Promise<PageText[]> {
  const result = await run("pdftotext", ["-enc", "UTF-8", input, "-"], { timeoutMs: 120_000, signal });
  if (result.code !== 0) throw new PipelineError("FILE_CORRUPTED");
  // pdftotext separa páginas com form feed.
  const chunks = result.stdout.split("\f");
  return Array.from({ length: pageCount }, (_, i) => ({ page: i + 1, text: (chunks[i] ?? "").trim() }));
}

async function ocr(input: string, workDir: string, signal: AbortSignal, jobs: number): Promise<string> {
  const output = path.join(workDir, "ocr.pdf");
  const result = await run(
    "ocrmypdf",
    [
      "--language", "por",
      "--skip-text",          // só reconhece páginas sem texto (documentos mistos)
      "--rotate-pages",
      "--output-type", "pdf", // sem conversão PDF/A: mais rápido e fiel ao original
      "--optimize", "1",
      "--jobs", String(jobs),
      "--tesseract-timeout", "180",
      "--quiet",
      input, output,
    ],
    { timeoutMs: 9 * 60_000, signal },
  );
  // Códigos do ocrmypdf: 2 = entrada inválida, 6 = já tem OCR, 8 = criptografado.
  if (result.code === 6) return input;
  if (result.code === 2) throw new PipelineError("FILE_CORRUPTED");
  if (result.code === 8) throw new PipelineError("PASSWORD_PROTECTED");
  if (result.code !== 0 || !existsSync(output)) {
    throw new PipelineError("PROCESSING_FAILED", { retryable: true });
  }
  return output;
}

export async function prepareDocument(options: {
  inputPath: string;
  fileType: AcceptedFileType;
  workDir: string;
  signal: AbortSignal;
  ocrJobs?: number;
}): Promise<Prepared> {
  const { workDir, signal } = options;
  let pdfPath = options.inputPath;
  let viewerChanged = false;

  if (options.fileType === "docx") {
    pdfPath = await docxToPdf(pdfPath, workDir, signal);
    viewerChanged = true;
  } else {
    const decrypted = await removeProtection(pdfPath, workDir, signal);
    if (decrypted) {
      pdfPath = decrypted;
      viewerChanged = true;
    }
  }

  const pageCount = await countPages(pdfPath, signal);
  if (pageCount > MAX_PAGES) throw new PipelineError("TOO_MANY_PAGES");

  let pages = await extractText(pdfPath, pageCount, signal);
  const needsOcr = pages.filter((p) => letters(p.text) < MIN_LETTERS_PER_PAGE).length;
  let ocrApplied = false;

  if (needsOcr > 0) {
    const ocrPath = await ocr(pdfPath, workDir, signal, options.ocrJobs ?? 2);
    if (ocrPath !== pdfPath) {
      pdfPath = ocrPath;
      viewerChanged = true;
      ocrApplied = true;
      pages = await extractText(pdfPath, pageCount, signal);
    }
  }

  // Ilegível: menos de 30% das páginas com texto útil, ou quase nenhum texto.
  const readable = pages.filter((p) => letters(p.text) >= MIN_LETTERS_PER_PAGE).length;
  const totalLetters = pages.reduce((sum, p) => sum + letters(p.text), 0);
  if (readable / pageCount < 0.3 || totalLetters < 200) throw new PipelineError("OCR_ILLEGIBLE");

  return {
    pdfPath,
    viewerChanged,
    pages,
    pageCount,
    isScanned: needsOcr / pageCount >= 0.5,
    ocrApplied,
  };
}
