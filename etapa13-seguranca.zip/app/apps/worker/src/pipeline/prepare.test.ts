/**
 * Testes de integração com as ferramentas reais (qpdf, pdftotext, ocrmypdf,
 * LibreOffice, Ghostscript). Rodam dentro da imagem Docker do worker:
 *   docker run --rm app-worker node --experimental-strip-types --test apps/worker/src/pipeline/prepare.test.ts
 * Fora dela, são pulados se as ferramentas não estiverem instaladas.
 */
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdtempSync, rmSync, writeFileSync, mkdirSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { PDFDocument, StandardFonts } from "pdf-lib";
import { prepareDocument } from "./prepare.ts";
import { PipelineError } from "../errors.ts";

const hasTools = ["qpdf", "pdftotext", "ocrmypdf", "soffice", "gs"].every((cmd) => {
  try {
    execFileSync("which", [cmd], { stdio: "ignore" });
    return true;
  } catch {
    return false;
  }
});

const CLAUSES = [
  "CONTRATO DE PRESTAÇÃO DE SERVIÇOS. Cláusula Primeira. A CONTRATADA prestará serviços de consultoria tributária à CONTRATANTE.",
  "Cláusula Segunda. Pelo serviço, a CONTRATANTE pagará o valor mensal de R$ 12.500,00 até o quinto dia útil de cada mês.",
  "Cláusula Terceira. Em caso de rescisão antecipada, a parte que der causa pagará multa de doze mensalidades vigentes.",
];

let dir = "";
const f = (name: string) => path.join(dir, name);
const signal = new AbortController().signal;

async function textPdf(pages: number, file: string) {
  const doc = await PDFDocument.create();
  const font = await doc.embedFont(StandardFonts.Helvetica);
  for (let i = 0; i < pages; i++) {
    const page = doc.addPage([595, 842]);
    const words = (CLAUSES[i % CLAUSES.length] ?? "").split(" ");
    let line = "";
    let y = 780;
    for (const w of words) {
      if ((line + w).length > 70) {
        page.drawText(line, { x: 50, y, size: 13, font });
        y -= 22;
        line = "";
      }
      line += `${w} `;
    }
    page.drawText(line, { x: 50, y, size: 13, font });
  }
  writeFileSync(file, await doc.save());
}

async function expectCode(promise: Promise<unknown>, code: string) {
  await assert.rejects(promise, (e: unknown) => e instanceof PipelineError && e.code === code);
}

before(async () => {
  if (!hasTools) return;
  dir = mkdtempSync(path.join(os.tmpdir(), "prepare-test-"));
  await textPdf(3, f("texto.pdf"));
  await textPdf(51, f("grande.pdf"));
  // Imagem sem camada de texto (simula digitalização).
  execFileSync("gs", ["-q", "-dNOPAUSE", "-dBATCH", "-sDEVICE=pdfimage24", "-r200",
    `-sOutputFile=${f("escaneado.pdf")}`, f("texto.pdf")]);
  // Páginas em branco digitalizadas: nada para reconhecer.
  const blank = await PDFDocument.create();
  blank.addPage([595, 842]);
  blank.addPage([595, 842]);
  writeFileSync(f("branco-vetor.pdf"), await blank.save());
  execFileSync("gs", ["-q", "-dNOPAUSE", "-dBATCH", "-sDEVICE=pdfimage24", "-r100",
    `-sOutputFile=${f("branco.pdf")}`, f("branco-vetor.pdf")]);
  execFileSync("qpdf", ["--encrypt", "", "dono", "256", "--", f("texto.pdf"), f("protegido-sem-senha.pdf")]);
  execFileSync("qpdf", ["--encrypt", "senha", "senha", "256", "--", f("texto.pdf"), f("com-senha.pdf")]);
  writeFileSync(f("contrato.txt"), CLAUSES.join("\n\n"));
  execFileSync("soffice", ["--headless", `-env:UserInstallation=file://${f("lo")}`,
    "--convert-to", "docx", "--outdir", dir, f("contrato.txt")], { stdio: "ignore" });
  writeFileSync(f("corrompido.pdf"), "%PDF-1.7\nlixo sem estrutura");
});

after(() => {
  if (dir) rmSync(dir, { recursive: true, force: true });
});

function workDir(name: string) {
  const d = f(`work-${name}`);
  mkdirSync(d, { recursive: true });
  return d;
}

test("PDF com texto: sem OCR e sem cópia de visualização", { skip: !hasTools }, async () => {
  const r = await prepareDocument({ inputPath: f("texto.pdf"), fileType: "pdf", workDir: workDir("texto"), signal });
  assert.equal(r.pageCount, 3);
  assert.equal(r.ocrApplied, false);
  assert.equal(r.viewerChanged, false);
  assert.match(r.pages[1]!.text, /R\$ 12\.500,00/);
});

test("PDF digitalizado: aplica OCR em português", { skip: !hasTools, timeout: 300_000 }, async () => {
  const r = await prepareDocument({ inputPath: f("escaneado.pdf"), fileType: "pdf", workDir: workDir("scan"), signal });
  assert.equal(r.isScanned, true);
  assert.equal(r.ocrApplied, true);
  assert.equal(r.viewerChanged, true);
  assert.match(r.pages[0]!.text, /CONSULTORIA/i);
});

test("DOCX: converte para PDF", { skip: !hasTools, timeout: 180_000 }, async () => {
  const r = await prepareDocument({ inputPath: f("contrato.docx"), fileType: "docx", workDir: workDir("docx"), signal });
  assert.equal(r.viewerChanged, true);
  assert.match(r.pages.map((p) => p.text).join(" "), /doze mensalidades/);
});

test("PDF com restrição sem senha de abertura: proteção removida", { skip: !hasTools }, async () => {
  const r = await prepareDocument({ inputPath: f("protegido-sem-senha.pdf"), fileType: "pdf", workDir: workDir("enc"), signal });
  assert.equal(r.viewerChanged, true);
  assert.equal(r.pageCount, 3);
});

test("PDF com senha de abertura", { skip: !hasTools }, async () => {
  await expectCode(prepareDocument({ inputPath: f("com-senha.pdf"), fileType: "pdf", workDir: workDir("senha"), signal }),
    "PASSWORD_PROTECTED");
});

test("mais de 50 páginas", { skip: !hasTools }, async () => {
  await expectCode(prepareDocument({ inputPath: f("grande.pdf"), fileType: "pdf", workDir: workDir("grande"), signal }),
    "TOO_MANY_PAGES");
});

test("digitalização sem texto reconhecível", { skip: !hasTools, timeout: 300_000 }, async () => {
  await expectCode(prepareDocument({ inputPath: f("branco.pdf"), fileType: "pdf", workDir: workDir("branco"), signal }),
    "OCR_ILLEGIBLE");
});

test("PDF corrompido", { skip: !hasTools }, async () => {
  await expectCode(prepareDocument({ inputPath: f("corrompido.pdf"), fileType: "pdf", workDir: workDir("corr"), signal }),
    "FILE_CORRUPTED");
});
