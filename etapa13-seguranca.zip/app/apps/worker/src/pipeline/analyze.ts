import Anthropic from "@anthropic-ai/sdk";
import { AnalysisSchema, ANALYSIS_JSON_SCHEMA, type Analysis } from "@app/shared/analysis";
import { ANALYSIS_SYSTEM_PROMPT, buildDocumentMessage, type Perspective, type PlaybookRule } from "@app/shared/analysis-prompt";
import type { PageText } from "@app/shared/text-match";
import { PipelineError } from "../errors.ts";

export type AiUsage = {
  model: string;
  inputTokens: number;
  outputTokens: number;
  thinkingTokens: number;
  cacheCreationTokens: number;
  cacheReadTokens: number;
  durationMs: number;
  stopReason: string | null;
};

/** Subconjunto do cliente usado aqui (facilita testar com um cliente falso). */
export type MessagesClient = {
  messages: { stream: Anthropic["messages"]["stream"] };
};

export type AnalyzeOptions = {
  client: MessagesClient;
  model: string;
  effort: "low" | "medium" | "high";
  pages: PageText[];
  /** Parte representada pelo escritório; ausente = análise neutra. */
  perspective?: Perspective | null;
  /** Regras do Playbook do escritório (códigos R1, R2...). */
  rules?: PlaybookRule[];
  signal: AbortSignal;
  /** Chamado a cada resposta da API, inclusive as descartadas: o custo é real. */
  onUsage: (usage: AiUsage) => Promise<void>;
};

const MAX_TOKENS = [32_000, 64_000]; // 2ª tentativa só se a 1ª estourar o limite

function classifyApiError(error: unknown): PipelineError {
  if (error instanceof Anthropic.APIUserAbortError) {
    return new PipelineError("PROCESSING_TIMEOUT", { retryable: true, cause: error });
  }
  if (error instanceof Anthropic.APIConnectionError) {
    return new PipelineError("AI_UNAVAILABLE", { retryable: true, cause: error });
  }
  if (error instanceof Anthropic.APIError) {
    const status = error.status ?? 0;
    // 408/409/429 e 5xx (inclui 529 overloaded) são temporários.
    const transient = status === 408 || status === 409 || status === 429 || status >= 500;
    // 4xx restantes (requisição inválida, chave errada): erro nosso, não do usuário.
    return new PipelineError(transient ? "AI_UNAVAILABLE" : "PROCESSING_FAILED", { retryable: transient, cause: error });
  }
  return new PipelineError("AI_UNAVAILABLE", { retryable: true, cause: error });
}

function parseAnalysis(message: Anthropic.Message): Analysis | null {
  const text = message.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("");
  try {
    const parsed = AnalysisSchema.safeParse(JSON.parse(text));
    return parsed.success ? parsed.data : null;
  } catch {
    return null;
  }
}

/**
 * Uma única chamada devolve extração, riscos e resumo (saída estruturada).
 * O documento é lido uma vez só; o system prompt, fixo e sem dados de
 * clientes, fica em cache entre documentos.
 */
export async function analyzeDocument(options: AnalyzeOptions): Promise<Analysis> {
  const content = buildDocumentMessage(options.pages, options.perspective, options.rules ?? []);

  for (let attempt = 0; attempt < MAX_TOKENS.length; attempt++) {
    const started = Date.now();
    let message: Anthropic.Message;
    try {
      const stream = options.client.messages.stream(
        {
          model: options.model,
          max_tokens: MAX_TOKENS[attempt]!,
          system: [{ type: "text", text: ANALYSIS_SYSTEM_PROMPT, cache_control: { type: "ephemeral" } }],
          messages: [{ role: "user", content }],
          output_config: {
            effort: options.effort,
            format: { type: "json_schema", schema: ANALYSIS_JSON_SCHEMA as unknown as Record<string, unknown> },
          },
        },
        { signal: options.signal },
      );
      message = await stream.finalMessage();
    } catch (error) {
      throw classifyApiError(error);
    }

    await options.onUsage({
      model: message.model,
      inputTokens: message.usage.input_tokens,
      outputTokens: message.usage.output_tokens,
      thinkingTokens: message.usage.output_tokens_details?.thinking_tokens ?? 0,
      cacheCreationTokens: message.usage.cache_creation_input_tokens ?? 0,
      cacheReadTokens: message.usage.cache_read_input_tokens ?? 0,
      durationMs: Date.now() - started,
      stopReason: message.stop_reason,
    });

    if (message.stop_reason === "refusal") throw new PipelineError("AI_REFUSED");
    if (message.stop_reason === "max_tokens") continue;

    const analysis = parseAnalysis(message);
    if (analysis) return analysis;
    // JSON válido pela gramática mas fora dos limites do Zod: não adianta
    // repetir a mesma chamada agora; a fila tenta de novo mais tarde.
    throw new PipelineError("AI_INVALID_OUTPUT", { retryable: true });
  }

  throw new PipelineError("AI_INVALID_OUTPUT", { retryable: true });
}
