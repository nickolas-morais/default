import { test } from "node:test";
import assert from "node:assert/strict";
import os from "node:os";
import type { Analysis } from "@app/shared/analysis";
import type { StartedJob, WorkerDb } from "../db.ts";
import { PipelineError } from "../errors.ts";
import { createProcessor } from "./process-job.ts";

const JOB: StartedJob = {
  document_id: "doc-1", office_id: "office-1", file_type: "pdf",
  original_path: "office-1/doc-1/original.pdf", kind: "initial", attempts: 1,
  client_party_name: null, client_party_role: null,
};

const PAGES = [
  { page: 1, text: "CONTRATO DE LOCAÇÃO. Cláusula 1ª do objeto." },
  { page: 2, text: "Cláusula 9ª A locatária pagará multa de dez aluguéis em caso de rescisão." },
];

const ANALYSIS: Analysis = {
  extracao: {
    partes: [], objeto: "", valor: "", forma_pagamento: "", vigencia: "", data_inicio: "", data_fim: "",
    prazo_rescisao: "", multas: [], foro: "", indice_reajuste: "",
  },
  prazos: [],
  riscos: [
    { nivel: "alto", titulo: "Multa", clausula: "9ª", trecho_original: "pagará multa de dez aluguéis", pagina: 3,
      explicacao: "", sugestao_redacao: "", parte_prejudicada: "Locatária", regra_playbook: "R1" },
    { nivel: "baixo", titulo: "Inventado", clausula: "", trecho_original: "o fiador renuncia a todos os seus direitos",
      pagina: 1, explicacao: "", sugestao_redacao: "", parte_prejudicada: "", regra_playbook: "" },
  ],
  resumo: "Resumo.",
};

function fakeDb(overrides: { job?: StartedJob | null; completeResult?: boolean; exists?: boolean; previous?: { page: number; text: string }[] } = {}) {
  const calls: Array<[string, ...unknown[]]> = [];
  const rec = (name: string) => async (...args: unknown[]) => {
    calls.push([name, ...args]);
  };
  const db = {
    ack: rec("ack"),
    delay: rec("delay"),
    setStage: rec("setStage"),
    savePages: rec("savePages"),
    retryJob: rec("retryJob"),
    failJob: rec("failJob"),
    startJob: async () => (overrides.job === undefined ? JOB : overrides.job),
    recordUsage: async () => 0.01,
    previousPages: async () => overrides.previous ?? null,
    playbookRules: async () => [{ id: "rule-1", title: "Foro SP", instruction: "Foro deve ser São Paulo", min_level: "alto", contract_types: "" }],
    completeJob: async (...args: unknown[]) => {
      calls.push(["completeJob", ...args]);
      return overrides.completeResult ?? true;
    },
    documentExists: async () => overrides.exists ?? true,
    storage: {
      download: async () => new Uint8Array([1, 2, 3]),
      uploadPdf: rec("uploadPdf"),
      removeFolder: rec("removeFolder"),
      remove: rec("remove"),
    },
  } as unknown as WorkerDb;
  return { db, calls, names: () => calls.map((c) => c[0]) };
}

function processor(db: WorkerDb, analyze: () => Promise<Analysis>, viewerChanged = false) {
  return createProcessor({
    db,
    prepare: async () => ({ pdfPath: new URL(import.meta.url).pathname, viewerChanged, pages: PAGES, pageCount: 2, isScanned: false, ocrApplied: false }),
    analyze,
    tmpDir: os.tmpdir(),
    jobTimeoutMs: 10_000,
    maxAttempts: 3,
  });
}

const MSG = { msg_id: 7, read_ct: 1, message: { job_id: "job-1" } };

test("sucesso: localiza trechos, conclui e confirma a mensagem", async () => {
  const f = fakeDb();
  await processor(f.db, async () => ANALYSIS)(MSG);
  const complete = f.calls.find((c) => c[0] === "completeJob")!;
  const result = complete[2] as { riscos: Array<{ pagina_localizada: number | null }> };
  assert.equal(result.riscos[0]!.pagina_localizada, 2, "usa a página onde o trecho foi achado, não a sugerida pela IA");
  assert.equal(result.riscos[1]!.pagina_localizada, null, "trecho inexistente fica sem página");
  assert.deepEqual(f.names().slice(-1), ["ack"]);
});

test("PDF convertido é guardado como viewer.pdf", async () => {
  const f = fakeDb();
  await processor(f.db, async () => ANALYSIS, true)(MSG);
  const upload = f.calls.find((c) => c[0] === "uploadPdf")!;
  assert.equal(upload[1], "office-1/doc-1/viewer.pdf");
});

test("falha temporária: volta para a fila com espera", async () => {
  const f = fakeDb();
  await processor(f.db, async () => {
    throw new PipelineError("AI_UNAVAILABLE", { retryable: true });
  })(MSG);
  assert.deepEqual(f.names().filter((n) => ["retryJob", "delay", "failJob", "ack"].includes(n)), ["retryJob", "delay"]);
  assert.equal(f.calls.find((c) => c[0] === "delay")![2], 60);
});

test("falha temporária na última tentativa: falha definitiva, mantém o arquivo", async () => {
  const f = fakeDb({ job: { ...JOB, attempts: 3 } });
  await processor(f.db, async () => {
    throw new PipelineError("AI_UNAVAILABLE", { retryable: true });
  })(MSG);
  assert.deepEqual(f.calls.find((c) => c[0] === "failJob"), ["failJob", "job-1", "AI_UNAVAILABLE", false]);
  assert.ok(!f.names().includes("removeFolder"));
  assert.deepEqual(f.calls.at(-1), ["ack", 7, true]);
});

test("problema no arquivo: descarta o arquivo", async () => {
  const f = fakeDb();
  const proc = createProcessor({
    db: f.db,
    prepare: async () => {
      throw new PipelineError("OCR_ILLEGIBLE");
    },
    analyze: async () => ANALYSIS,
    tmpDir: os.tmpdir(), jobTimeoutMs: 10_000, maxAttempts: 3,
  });
  await proc(MSG);
  assert.deepEqual(f.calls.find((c) => c[0] === "removeFolder"), ["removeFolder", "office-1/doc-1"]);
  assert.deepEqual(f.calls.find((c) => c[0] === "failJob"), ["failJob", "job-1", "OCR_ILLEGIBLE", true]);
});

test("documento excluído durante o processamento: limpa a pasta", async () => {
  const f = fakeDb({ completeResult: false });
  await processor(f.db, async () => ANALYSIS, true)(MSG);
  assert.ok(f.names().includes("removeFolder"));
  assert.equal(f.names().at(-1), "ack");
});

test("job inexistente ou encerrado: só confirma a mensagem", async () => {
  const f = fakeDb({ job: null });
  await processor(f.db, async () => ANALYSIS)(MSG);
  assert.deepEqual(f.names(), ["ack"]);
});

test("worker caiu vezes demais: falha por tempo", async () => {
  const f = fakeDb({ job: { ...JOB, attempts: 4 } });
  await processor(f.db, async () => ANALYSIS)(MSG);
  assert.deepEqual(f.calls[0], ["failJob", "job-1", "PROCESSING_TIMEOUT", false]);
});

test("perspectiva do documento chega à análise", async () => {
  const f = fakeDb({ job: { ...JOB, kind: "perspective", client_party_name: "Café Aurora", client_party_role: "Locatária" } });
  let received: unknown = null;
  await createProcessor({
    db: f.db,
    prepare: async () => ({ pdfPath: new URL(import.meta.url).pathname, viewerChanged: false, pages: PAGES, pageCount: 2, isScanned: false, ocrApplied: false }),
    analyze: async (o) => { received = o.perspective; return ANALYSIS; },
    tmpDir: os.tmpdir(), jobTimeoutMs: 10_000, maxAttempts: 3,
  })(MSG);
  assert.deepEqual(received, { name: "Café Aurora", role: "Locatária" });
});

test("regra do Playbook citada pela IA vira o id da regra", async () => {
  const f = fakeDb();
  await processor(f.db, async () => ANALYSIS)(MSG);
  const result = f.calls.find((c) => c[0] === "completeJob")![2] as { riscos: Array<{ playbook_rule_id: string | null }> };
  assert.equal(result.riscos[0]!.playbook_rule_id, "rule-1");
  assert.equal(result.riscos[1]!.playbook_rule_id, null);
});

test("arquivo que não é versão do anterior é recusado antes da IA", async () => {
  const f = fakeDb({ previous: [{ page: 1, text: "Contrato de compra e venda de veículo usado com pagamento à vista e garantia de noventa dias" }] });
  let analyzed = false;
  await processor(f.db, async () => { analyzed = true; return ANALYSIS; })(MSG);
  assert.equal(analyzed, false);
  assert.deepEqual(f.calls.find((c) => c[0] === "failJob"), ["failJob", "job-1", "VERSION_UNRELATED", true]);
});
