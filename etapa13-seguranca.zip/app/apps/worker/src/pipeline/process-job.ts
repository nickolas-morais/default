import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import type { Analysis } from "@app/shared/analysis";
import { PROMPT_VERSION } from "@app/shared/analysis-prompt";
import { locateExcerpt, type PageText } from "@app/shared/text-match";
import { textSimilarity } from "@app/shared/compare";
import type { PlaybookRule } from "@app/shared/analysis-prompt";
import type { QueueMessage, WorkerDb } from "../db.ts";
import { PipelineError, toPipelineError } from "../errors.ts";
import { log } from "../log.ts";
import type { AiUsage } from "./analyze.ts";
import type { Prepared } from "./prepare.ts";

export type ProcessorDeps = {
  db: WorkerDb;
  prepare: (o: { inputPath: string; fileType: "pdf" | "docx"; workDir: string; signal: AbortSignal }) => Promise<Prepared>;
  analyze: (o: {
    pages: PageText[];
    perspective: { name: string; role: string | null } | null;
    rules: PlaybookRule[];
    signal: AbortSignal;
    onUsage: (u: AiUsage) => Promise<void>;
  }) => Promise<Analysis>;
  tmpDir: string;
  jobTimeoutMs: number;
  maxAttempts: number;
  /** Depois de concluir (avisos por e-mail). Erros aqui nunca afetam o job. */
  onCompleted?: (o: { jobId: string; documentId: string; officeId: string }) => Promise<void>;
  /** Falhas inesperadas (monitoramento). Problemas do arquivo não são enviados. */
  reportError?: (error: unknown, context: Record<string, string | number>) => void;
};

/** Espera antes de nova tentativa: 1, 2, 4 min. */
const backoffSeconds = (attempt: number) => 60 * 2 ** Math.max(0, attempt - 1);

/** Localiza cada trecho no texto para o destaque na tela. */
export function locateRisks(analysis: Analysis, pages: PageText[]) {
  return analysis.riscos.map((r) => {
    const found = locateExcerpt(pages, r.trecho_original);
    return { ...r, pagina_localizada: found?.page ?? null, score: found?.score ?? null };
  });
}

export function createProcessor(deps: ProcessorDeps) {
  const { db } = deps;

  return async function processMessage(msg: QueueMessage): Promise<void> {
    const jobId = msg.message.job_id;
    if (!jobId) {
      log.warn("mensagem sem job_id descartada", { msg_id: msg.msg_id });
      await db.ack(msg.msg_id, true);
      return;
    }

    const job = await db.startJob(jobId);
    if (!job) {
      // Documento excluído ou job já encerrado.
      await db.ack(msg.msg_id);
      return;
    }

    const ctx = { job_id: jobId, document_id: job.document_id, attempt: job.attempts, kind: job.kind };
    const folder = `${job.office_id}/${job.document_id}`;

    // Worker anterior caiu no meio (a mensagem reapareceu) vezes demais.
    if (job.attempts > deps.maxAttempts) {
      await db.failJob(jobId, "PROCESSING_TIMEOUT", false);
      await db.ack(msg.msg_id, true);
      log.warn("job excedeu tentativas", ctx);
      return;
    }

    const started = Date.now();
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), deps.jobTimeoutMs);
    const workDir = await mkdtemp(path.join(deps.tmpDir, "job-"));

    try {
      log.info("job iniciado", ctx);

      // 1. Preparação: conversão, proteção, páginas, texto, OCR.
      const inputPath = path.join(workDir, `original.${job.file_type}`);
      await writeFile(inputPath, await db.storage.download(job.original_path));
      const prepared = await deps.prepare({ inputPath, fileType: job.file_type, workDir, signal: abort.signal });

      let viewerPath: string | null = null;
      if (prepared.viewerChanged) {
        viewerPath = `${folder}/viewer.pdf`;
        await db.storage.uploadPdf(viewerPath, new Uint8Array(await readFile(prepared.pdfPath)));
      }
      await db.savePages(jobId, prepared.pages, viewerPath, prepared.isScanned, prepared.pageCount);

      // Nova versão: confere, antes de gastar com IA, se é mesmo o mesmo contrato.
      if (job.kind === "initial") {
        const previous = await db.previousPages(job.document_id);
        if (previous?.length) {
          const similarity = textSimilarity(previous, prepared.pages);
          log.info("semelhança com a versão anterior", { ...ctx, similarity: Math.round(similarity * 100) / 100 });
          if (similarity < 0.3) throw new PipelineError("VERSION_UNRELATED");
        }
      }
      const prepareMs = Date.now() - started;
      log.info("documento preparado", {
        ...ctx, pages: prepared.pageCount, scanned: prepared.isScanned, ocr: prepared.ocrApplied, ms: prepareMs,
      });

      // 2. Análise por IA.
      await db.setStage(jobId, "analyzing");
      const rulesRaw = await db.playbookRules(job.office_id);
      const rules: PlaybookRule[] = rulesRaw.map((r, i) => ({
        code: `R${i + 1}`, title: r.title, instruction: r.instruction, minLevel: r.min_level, contractTypes: r.contract_types,
      }));
      const ruleIdByCode = new Map(rulesRaw.map((r, i) => [`R${i + 1}`, r.id]));
      const aiStarted = Date.now();
      const analysis = await deps.analyze({
        pages: prepared.pages,
        perspective: job.client_party_name ? { name: job.client_party_name, role: job.client_party_role } : null,
        rules,
        signal: abort.signal,
        onUsage: async (usage) => {
          const cost = await db.recordUsage(jobId, usage);
          log.info("chamada de IA", {
            ...ctx, model: usage.model, input: usage.inputTokens, output: usage.outputTokens,
            thinking: usage.thinkingTokens, cache_read: usage.cacheReadTokens, cost_usd: cost,
            ms: usage.durationMs, stop: usage.stopReason,
          });
        },
      });
      const aiMs = Date.now() - aiStarted;

      // 3. Resultado, cota e conclusão (uma transação no banco).
      const result = {
        ...analysis,
        riscos: locateRisks(analysis, prepared.pages).map((r) => ({
          ...r, playbook_rule_id: ruleIdByCode.get(r.regra_playbook.trim().toUpperCase()) ?? null,
        })),
      };
      const completed = await db.completeJob(jobId, result, PROMPT_VERSION, prepareMs, aiMs);
      if (!completed) await db.storage.removeFolder(folder); // excluído durante o processamento
      if (completed && deps.onCompleted) {
        await deps.onCompleted({ jobId, documentId: job.document_id, officeId: job.office_id }).catch(() => undefined);
      }

      await db.ack(msg.msg_id);
      log.info("job concluído", {
        ...ctx, ms: Date.now() - started, risks: result.riscos.length,
        located: result.riscos.filter((r) => r.pagina_localizada !== null).length,
      });
    } catch (raw) {
      const error = abort.signal.aborted ? new PipelineError("PROCESSING_TIMEOUT", { retryable: true }) : toPipelineError(raw);
      await handleFailure(error, raw);
    } finally {
      clearTimeout(timer);
      await rm(workDir, { recursive: true, force: true });
    }

    async function handleFailure(error: PipelineError, raw: unknown) {
      const cause = raw instanceof Error ? (raw.cause instanceof Error ? raw.cause.message : raw.message) : String(raw);
      log.error("job falhou", { ...ctx, code: error.code, retryable: error.retryable, cause: cause.slice(0, 300) });
      if (!error.deletesFile) deps.reportError?.(raw, { ...ctx, code: error.code });

      try {
        if (!(await db.documentExists(job!.document_id))) {
          await db.storage.removeFolder(folder);
          await db.ack(msg.msg_id);
          return;
        }

        if (error.retryable && job!.attempts < deps.maxAttempts) {
          await db.retryJob(jobId!, error.code);
          await db.delay(msg.msg_id, backoffSeconds(job!.attempts));
          return;
        }

        // Falha definitiva. Arquivo com problema é descartado (minimização);
        // falhas nossas (IA, timeout) mantêm o arquivo para "Reprocessar".
        if (error.deletesFile) await db.storage.removeFolder(folder);
        await db.failJob(jobId!, error.code, error.deletesFile);
        await db.ack(msg.msg_id, true);
      } catch (inner) {
        // Nem o registro da falha funcionou: a mensagem reaparece após o
        // tempo de visibilidade e o job é tentado de novo.
        log.error("falha ao registrar erro do job", {
          ...ctx, cause: inner instanceof Error ? inner.message.slice(0, 300) : String(inner),
        });
      }
    }
  };
}
