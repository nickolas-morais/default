import http from "node:http";
import Anthropic from "@anthropic-ai/sdk";
import { loadConfig } from "./config.ts";
import { createWorkerDb } from "./db.ts";
import { log } from "./log.ts";
import { analyzeDocument } from "./pipeline/analyze.ts";
import { prepareDocument } from "./pipeline/prepare.ts";
import { createProcessor } from "./pipeline/process-job.ts";
import * as Sentry from "@sentry/node";
import { createNotifier } from "./notify.ts";
import { compareWithPrevious } from "./compare-versions.ts";

const config = loadConfig();

// Monitoramento opcional. Sem dados pessoais: só erro, pilha e ids.
if (config.sentryDsn) {
  Sentry.init({
    dsn: config.sentryDsn,
    tracesSampleRate: 0,
    environment: process.env.NODE_ENV ?? "development",
    // Nada de usuário, cookies, cabeçalhos, corpos ou parâmetros: só o erro.
    dataCollection: { userInfo: false, cookies: false, httpHeaders: false, httpBodies: [], urlQueryParams: false },
  });
}
const report = (error: unknown, context: Record<string, string | number> = {}) => {
  if (config.sentryDsn) Sentry.captureException(error, { extra: context });
};
const db = createWorkerDb(config);
const notifier = createNotifier(db, config.siteUrl);
// Novas tentativas ficam a cargo da fila (com espera crescente).
const anthropic = new Anthropic({ apiKey: config.anthropicApiKey, maxRetries: 2, timeout: 10 * 60 * 1000 });

const processMessage = createProcessor({
  db,
  prepare: (o) => prepareDocument({ ...o, ocrJobs: 2 }),
  analyze: (o) => analyzeDocument({ ...o, client: anthropic, model: config.model, effort: config.effort }),
  tmpDir: config.tmpDir,
  jobTimeoutMs: config.jobTimeoutMs,
  maxAttempts: config.maxAttempts,
  onCompleted: async (o) => {
    await compareWithPrevious(db, o.documentId).catch((e) => {
      log.error("falha na comparação de versões", { document_id: o.documentId, cause: String(e).slice(0, 300) });
      report(e, { where: "compare", document_id: o.documentId });
    });
    await notifier.afterCompleted(o);
  },
  reportError: report,
});

let active = 0;
let stopping = false;
let lastPollOk = Date.now();

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function pollLoop() {
  while (!stopping) {
    const free = config.concurrency - active;
    if (free > 0) {
      try {
        const messages = await db.readJobs(config.visibilityTimeoutS, free);
        lastPollOk = Date.now();
        for (const msg of messages) {
          active++;
          processMessage(msg)
            .catch((e) => {
              log.error("erro inesperado no job", { msg_id: msg.msg_id, cause: String(e).slice(0, 300) });
              report(e, { msg_id: msg.msg_id });
            })
            .finally(() => active--);
        }
        if (messages.length) continue;
      } catch (e) {
        log.error("falha ao ler a fila", { cause: String(e).slice(0, 300) });
        report(e, { where: "poll" });
      }
    }
    await sleep(config.pollIntervalMs);
  }
}

/** Remove envios que nunca foram concluídos no navegador. */
async function cleanupLoop() {
  while (!stopping) {
    try {
      const abandoned = await db.abandonedUploads();
      for (const doc of abandoned) {
        await db.storage.remove(doc.original_path);
        await db.deleteAbandoned(doc.document_id);
      }
      if (abandoned.length) log.info("envios abandonados removidos", { count: abandoned.length });

      // Escritórios com exclusão agendada e prazo vencido: arquivos, dados e contas.
      for (const office of await db.officesDueForDeletion()) {
        await db.storage.removeOfficeFiles(office.office_id);
        await db.deleteOffice(office.office_id);
        for (const userId of office.member_ids) await db.deleteAuthUser(userId);
        log.info("escritório excluído", { office_id: office.office_id, users: office.member_ids.length });
      }
    } catch (e) {
      log.error("falha na rotina de limpeza", { cause: String(e).slice(0, 300) });
      report(e, { where: "cleanup" });
    }
    await sleep(15 * 60 * 1000);
  }
}

/** Avisos periódicos (contratos vencendo, fila acumulada), a cada 5 minutos. */
async function notifyLoop() {
  while (!stopping) {
    try {
      await notifier.periodic();
    } catch (e) {
      log.error("falha nos avisos periódicos", { cause: String(e).slice(0, 300) });
      report(e, { where: "notify" });
    }
    await sleep(5 * 60 * 1000);
  }
}

// Health check para a plataforma de hospedagem.
const server = http.createServer((_req, res) => {
  const healthy = Date.now() - lastPollOk < 5 * 60 * 1000;
  res.writeHead(healthy ? 200 : 503, { "content-type": "application/json" });
  res.end(JSON.stringify({ ok: healthy, active }));
});
server.listen(config.healthPort);

async function shutdown(signal: string) {
  if (stopping) return;
  stopping = true;
  log.info("encerrando: aguardando jobs em andamento", { signal, active });
  const deadline = Date.now() + 10 * 60 * 1000;
  while (active > 0 && Date.now() < deadline) await sleep(1000);
  server.close();
  process.exit(0);
}
process.on("SIGTERM", () => void shutdown("SIGTERM"));
process.on("SIGINT", () => void shutdown("SIGINT"));

log.info("worker iniciado", {
  model: config.model, effort: config.effort, concurrency: config.concurrency,
  email: process.env.EMAIL_MODE ?? "console", sentry: Boolean(config.sentryDsn),
});
void pollLoop();
void cleanupLoop();
void notifyLoop();
