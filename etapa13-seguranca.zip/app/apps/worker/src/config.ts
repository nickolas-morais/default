import os from "node:os";

type Effort = "low" | "medium" | "high";

function required(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Variável de ambiente ausente: ${name}. Veja apps/worker/.env.example.`);
  return value;
}

function int(name: string, fallback: number): number {
  const n = Number.parseInt(process.env[name] ?? "", 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

function effort(): Effort {
  const v = process.env.ANTHROPIC_EFFORT ?? "medium";
  if (v === "low" || v === "medium" || v === "high") return v;
  throw new Error("ANTHROPIC_EFFORT deve ser low, medium ou high.");
}

export function loadConfig() {
  return {
    supabaseUrl: required("SUPABASE_URL").replace(/\/$/, ""),
    supabaseSecretKey: required("SUPABASE_SECRET_KEY"),
    anthropicApiKey: required("ANTHROPIC_API_KEY"),
    model: process.env.ANTHROPIC_MODEL ?? "claude-sonnet-5-5",
    effort: effort(),
    concurrency: int("WORKER_CONCURRENCY", 2),
    pollIntervalMs: int("WORKER_POLL_MS", 3000),
    // Um job nunca passa de 12 min; a mensagem fica invisível por 15 min, então
    // outro worker só a pega de novo se este tiver caído.
    jobTimeoutMs: int("WORKER_JOB_TIMEOUT_MS", 12 * 60 * 1000),
    visibilityTimeoutS: 15 * 60,
    maxAttempts: 3,
    tmpDir: process.env.WORKER_TMP_DIR ?? os.tmpdir(),
    healthPort: int("PORT", 8080),
    siteUrl: (process.env.SITE_URL ?? "http://localhost:3000").replace(/\/$/, ""),
    sentryDsn: process.env.SENTRY_DSN || null,
  };
}

export type Config = ReturnType<typeof loadConfig>;
