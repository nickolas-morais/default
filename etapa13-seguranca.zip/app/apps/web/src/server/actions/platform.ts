"use server";

import { revalidatePath } from "next/cache";
import { codeFromDbError } from "@app/shared";
import { createClient } from "@/lib/supabase/server";
import { env } from "@/lib/env";
import { formError, type FormState } from "@/lib/errors";

// Todas as funções chamadas aqui conferem, no banco, admin da plataforma + 2FA
// (aal2) e registram auditoria. Nenhuma usa a secret key.

export type AdminFormState = FormState & { link?: string; officeId?: string };

const str = (f: FormData, k: string) => String(f.get(k) ?? "").trim();
const int = (f: FormData, k: string) => {
  const n = Number.parseInt(str(f, k), 10);
  return Number.isFinite(n) ? n : null;
};
/** "AAAA-MM-DD" do formulário → início do dia em Brasília. */
const date = (f: FormData, k: string) => (str(f, k) ? new Date(`${str(f, k)}T00:00:00-03:00`).toISOString() : null);

async function run(fn: () => PromiseLike<{ error: { message?: string } | null }>, officeId?: string, ok = "Salvo.") {
  const { error } = await fn();
  if (error) return formError(codeFromDbError(error));
  revalidatePath("/admin", "layout");
  if (officeId) revalidatePath(`/admin/escritorios/${officeId}`);
  return { ok: true, message: ok };
}

export async function createClientOffice(_p: AdminFormState, f: FormData): Promise<AdminFormState> {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("admin_create_office", {
    p_name: str(f, "name"), p_owner_email: str(f, "email"),
    p_trial_days: int(f, "trialDays") ?? 14, p_trial_docs: int(f, "trialDocs") ?? 5,
  });
  const row = data?.[0];
  if (error || !row) return formError(codeFromDbError(error));
  revalidatePath("/admin");
  return {
    ok: true, officeId: row.office_id, link: `${env.siteUrl}/convite/${row.invite_token}`,
    message: "Escritório criado. Envie o link ao titular; ele vale por 14 dias.",
  };
}

export async function resendOwnerInvite(_p: AdminFormState, f: FormData): Promise<AdminFormState> {
  const supabase = await createClient();
  const officeId = str(f, "officeId");
  const { data, error } = await supabase.rpc("admin_resend_owner_invite", { p_office_id: officeId, p_email: str(f, "email") });
  if (error || !data) return formError(codeFromDbError(error));
  revalidatePath(`/admin/escritorios/${officeId}`);
  return { ok: true, link: `${env.siteUrl}/convite/${data}`, message: "Novo convite gerado; o anterior foi cancelado." };
}

export async function createContract(_p: AdminFormState, f: FormData): Promise<AdminFormState> {
  const supabase = await createClient();
  const officeId = str(f, "officeId");
  const starts = date(f, "startsAt");
  const ends = date(f, "endsAt");
  if (!starts || !ends) return formError("VALIDATION");
  const method = str(f, "billing") as "boleto" | "nota_fiscal" | "transferencia" | "outro";
  return run(() => supabase.rpc("admin_create_contract", {
    p_office_id: officeId, p_plan_id: str(f, "planId") || null, p_doc_limit: int(f, "docLimit"),
    p_starts_at: starts, p_ends_at: ends, p_billing_method: method, p_notes: str(f, "notes"),
  }), officeId, "Contrato registrado.");
}

export async function cancelContract(_p: AdminFormState, f: FormData): Promise<AdminFormState> {
  const supabase = await createClient();
  return run(() => supabase.rpc("admin_cancel_contract", { p_contract_id: str(f, "contractId") }), str(f, "officeId"), "Contrato cancelado.");
}

export async function setTrial(_p: AdminFormState, f: FormData): Promise<AdminFormState> {
  const supabase = await createClient();
  const officeId = str(f, "officeId");
  return run(() => supabase.rpc("admin_set_trial", {
    p_office_id: officeId, p_ends_at: date(f, "endsAt"), p_doc_limit: int(f, "docLimit"),
  }), officeId, "Avaliação atualizada.");
}

export async function setSuspension(_p: AdminFormState, f: FormData): Promise<AdminFormState> {
  const supabase = await createClient();
  const officeId = str(f, "officeId");
  const suspend = str(f, "suspend") === "1";
  return run(() => supabase.rpc("admin_set_suspension", {
    p_office_id: officeId, p_suspended: suspend, p_reason: str(f, "reason") || null,
  }), officeId, suspend ? "Escritório suspenso." : "Escritório reativado.");
}

export async function setFailureLimit(_p: AdminFormState, f: FormData): Promise<AdminFormState> {
  const supabase = await createClient();
  const officeId = str(f, "officeId");
  const limit = int(f, "limit");
  if (!limit || limit < 1 || limit > 1000) return formError("VALIDATION");
  return run(() => supabase.rpc("admin_set_failure_limit", { p_office_id: officeId, p_limit: limit }), officeId);
}
