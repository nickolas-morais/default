"use server";

import { revalidatePath } from "next/cache";
import { codeFromDbError } from "@app/shared";
import { createClient } from "@/lib/supabase/server";
import { getSessionContext } from "@/lib/auth/context";
import { env } from "@/lib/env";
import { formError, type FormState } from "@/lib/errors";

export type FeedState = FormState & { url?: string };

/** Gera (ou substitui) o endereço secreto do calendário. O token só é mostrado agora. */
export async function createCalendarFeed(_prev: FeedState, formData: FormData): Promise<FeedState> {
  await getSessionContext();
  const supabase = await createClient();
  const { data: token, error } = await supabase.rpc("create_calendar_feed", {
    p_include_details: formData.get("includeDetails") === "on",
  });
  if (error || !token) return formError(codeFromDbError(error));
  revalidatePath("/prazos");
  return { ok: true, url: `${env.siteUrl}/api/prazos/feed/${token}.ics` };
}

export async function revokeCalendarFeed(_prev: FeedState): Promise<FeedState> {
  await getSessionContext();
  const supabase = await createClient();
  const { error } = await supabase.rpc("revoke_calendar_feed");
  if (error) return formError(codeFromDbError(error));
  revalidatePath("/prazos");
  return { ok: true, message: "Endereço revogado. As agendas que o usavam deixam de receber os prazos." };
}
