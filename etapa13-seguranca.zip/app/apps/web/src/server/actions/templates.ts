"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { codeFromDbError } from "@app/shared";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient, DOCUMENTS_BUCKET } from "@/lib/supabase/admin";
import { getSessionContext } from "@/lib/auth/context";
import { formError, type FormState } from "@/lib/errors";

export async function deleteTemplate(_prev: FormState, formData: FormData): Promise<FormState> {
  const ctx = await getSessionContext();
  if (!ctx.isAdmin) return formError("FORBIDDEN");

  const supabase = await createClient();
  const { data: path, error } = await supabase.rpc("delete_template", {
    p_template_id: String(formData.get("templateId") ?? ""),
  });
  if (error || !path) return formError(codeFromDbError(error));

  // O registro já saiu; se a remoção do arquivo falhar, ele fica órfão no
  // bucket, sem nenhum acesso possível (o caminho só existia no registro).
  await createAdminClient().storage.from(DOCUMENTS_BUCKET).remove([path]);
  revalidatePath("/modelos");
  redirect("/modelos");
}
