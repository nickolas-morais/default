"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { getSessionContext } from "@/lib/auth/context";
import { getPlanPrices, getStripe } from "@/lib/billing/stripe";
import { env } from "@/lib/env";
import { formError, type FormState } from "@/lib/errors";

/** Cliente do Stripe do escritório (criado na primeira assinatura). */
async function ensureCustomer(officeId: string, officeName: string, email: string): Promise<string | null> {
  const stripe = getStripe()!;
  const supabase = await createClient();
  const { data: office } = await supabase.from("offices").select("stripe_customer_id, cnpj").eq("id", officeId).single();
  if (office?.stripe_customer_id) return office.stripe_customer_id;

  const customer = await stripe.customers.create(
    { name: officeName, email, metadata: { office_id: officeId } },
    // Cliques repetidos não criam clientes duplicados.
    { idempotencyKey: `customer-${officeId}` },
  );
  const { error } = await createAdminClient().rpc("stripe_set_customer", { p_office_id: officeId, p_customer_id: customer.id });
  return error ? null : customer.id;
}

async function portalUrl(customerId: string) {
  const session = await getStripe()!.billingPortal.sessions.create({
    customer: customerId,
    return_url: `${env.siteUrl}/plano`,
    locale: "pt-BR",
  });
  return session.url;
}

/** Assinar um plano (titular ou administrador). */
export async function startCheckout(_prev: FormState, formData: FormData): Promise<FormState> {
  const ctx = await getSessionContext();
  if (!ctx.isAdmin) return formError("FORBIDDEN");
  const stripe = getStripe();
  if (!stripe) return formError("BILLING_NOT_CONFIGURED");

  const supabase = await createClient();
  const planId = String(formData.get("planId") ?? "");
  const [{ data: plan }, { data: ent }] = await Promise.all([
    supabase.from("plans").select("id, stripe_lookup_key").eq("id", planId).maybeSingle(),
    supabase.rpc("current_entitlement"),
  ]);
  if (!plan) return formError("VALIDATION");

  let url: string;
  try {
    const customerId = await ensureCustomer(ctx.office.id, ctx.office.name, ctx.email);
    if (!customerId) return formError("BILLING_UNAVAILABLE");

    // Já assina: troca de plano, cartão e cancelamento ficam no portal do Stripe.
    if (ent?.[0]?.source === "subscription") {
      url = await portalUrl(customerId);
    } else {
      const price = (await getPlanPrices([plan.stripe_lookup_key])).get(plan.stripe_lookup_key);
      if (!price) return formError("BILLING_NOT_CONFIGURED");
      const session = await stripe.checkout.sessions.create({
        mode: "subscription",
        customer: customerId,
        client_reference_id: ctx.office.id,
        line_items: [{ price: price.priceId, quantity: 1 }],
        subscription_data: { metadata: { office_id: ctx.office.id } },
        customer_update: { name: "auto", address: "auto" },
        billing_address_collection: "required",
        tax_id_collection: { enabled: true },
        allow_promotion_codes: true,
        locale: "pt-BR",
        success_url: `${env.siteUrl}/plano?assinatura=ok`,
        cancel_url: `${env.siteUrl}/plano`,
      });
      if (!session.url) return formError("BILLING_UNAVAILABLE");
      url = session.url;
    }
  } catch {
    return formError("BILLING_UNAVAILABLE");
  }
  redirect(url);
}

/** Portal do Stripe: trocar plano, cartão, ver faturas, cancelar. */
export async function openBillingPortal(_prev: FormState): Promise<FormState> {
  const ctx = await getSessionContext();
  if (!ctx.isAdmin) return formError("FORBIDDEN");
  if (!getStripe()) return formError("BILLING_NOT_CONFIGURED");

  const supabase = await createClient();
  const { data: office } = await supabase.from("offices").select("stripe_customer_id").eq("id", ctx.office.id).single();
  if (!office?.stripe_customer_id) return formError("NO_ACTIVE_PLAN");

  let url: string;
  try {
    url = await portalUrl(office.stripe_customer_id);
  } catch {
    return formError("BILLING_UNAVAILABLE");
  }
  redirect(url);
}
