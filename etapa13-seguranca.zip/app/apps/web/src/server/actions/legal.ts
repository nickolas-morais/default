"use server";

import { redirect } from "next/navigation";
import { codeFromDbError } from "@app/shared";
import { createClient } from "@/lib/supabase/server";
import { getRequestMeta } from "@/lib/request-meta";
import { formError, type FormState } from "@/lib/errors";
import { acceptLegalSchema, fieldErrorsOf, formToObject } from "@/lib/validation";
import { LEGAL_VERSIONS } from "@/content/legal/versions";

export async function acceptLegal(_prev: FormState, formData: FormData): Promise<FormState> {
  const parsed = acceptLegalSchema.safeParse(formToObject(formData));
  if (!parsed.success) return formError("VALIDATION", { fieldErrors: fieldErrorsOf(parsed.error) });

  const { ip, userAgent } = await getRequestMeta();
  const supabase = await createClient();
  const { error } = await supabase.rpc("accept_current_legal", {
    p_terms_version: LEGAL_VERSIONS.terms,
    p_privacy_version: LEGAL_VERSIONS.privacy,
    p_ip: ip,
    p_user_agent: userAgent,
  });
  if (error) return formError(codeFromDbError(error));
  redirect("/documentos");
}
