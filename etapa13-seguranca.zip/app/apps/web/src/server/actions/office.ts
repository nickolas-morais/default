"use server";

import { revalidatePath } from "next/cache";
import { codeFromDbError } from "@app/shared";
import { createClient } from "@/lib/supabase/server";
import { env } from "@/lib/env";
import { getSessionContext } from "@/lib/auth/context";
import { formError, type FormState } from "@/lib/errors";
import { fieldErrorsOf, formToObject, inviteSchema, officeSchema } from "@/lib/validation";

export async function updateOffice(_prev: FormState, formData: FormData): Promise<FormState> {
  const ctx = await getSessionContext();
  if (!ctx.isAdmin) return formError("FORBIDDEN");

  const raw = formToObject(formData);
  const values = {
    name: raw.name ?? "", cnpj: raw.cnpj ?? "", address: raw.address ?? "", phone: raw.phone ?? "",
    contactEmail: raw.contactEmail ?? "", oabRegistration: raw.oabRegistration ?? "",
  };
  const parsed = officeSchema.safeParse(raw);
  if (!parsed.success) return formError("VALIDATION", { fieldErrors: fieldErrorsOf(parsed.error), values });

  const supabase = await createClient();
  const { data, error } = await supabase
    .from("offices")
    .update({
      name: parsed.data.name, cnpj: parsed.data.cnpj, address: parsed.data.address, phone: parsed.data.phone,
      contact_email: parsed.data.contactEmail, oab_registration: parsed.data.oabRegistration,
    })
    .eq("id", ctx.office.id)
    .select("id");

  if (error) return formError("UNEXPECTED", { values });
  if (!data?.length) return formError("FORBIDDEN", { values }); // RLS filtrou

  revalidatePath("/", "layout");
  return { ok: true, message: "Dados do escritório salvos." };
}

export type InviteState = FormState & { link?: string; email?: string };

export async function inviteMember(_prev: InviteState, formData: FormData): Promise<InviteState> {
  const raw = formToObject(formData);
  const values = { email: raw.email ?? "", role: raw.role ?? "member" };
  const parsed = inviteSchema.safeParse(raw);
  if (!parsed.success) return formError("VALIDATION", { fieldErrors: fieldErrorsOf(parsed.error), values });

  const supabase = await createClient();
  const { data: token, error } = await supabase.rpc("create_office_invitation", {
    p_email: parsed.data.email,
    p_role: parsed.data.role,
  });
  if (error || !token) return formError(codeFromDbError(error), { values });

  revalidatePath("/configuracoes/membros");
  return {
    ok: true,
    email: parsed.data.email,
    link: `${env.siteUrl}/convite/${token}`,
    message: "Convite criado. Copie o link e envie para a pessoa convidada; ele vale por 7 dias.",
  };
}

export async function revokeInvitation(_prev: FormState, formData: FormData): Promise<FormState> {
  const supabase = await createClient();
  const { error } = await supabase.rpc("revoke_office_invitation", {
    p_invitation_id: String(formData.get("invitationId") ?? ""),
  });
  if (error) return formError(codeFromDbError(error));
  revalidatePath("/configuracoes/membros");
  return { ok: true, message: "Convite cancelado." };
}

export async function removeMember(_prev: FormState, formData: FormData): Promise<FormState> {
  const supabase = await createClient();
  const { error } = await supabase.rpc("remove_office_member", {
    p_user_id: String(formData.get("userId") ?? ""),
  });
  if (error) return formError(codeFromDbError(error));
  revalidatePath("/configuracoes/membros");
  return { ok: true, message: "Membro removido do escritório." };
}

export async function setMemberRole(_prev: FormState, formData: FormData): Promise<FormState> {
  const supabase = await createClient();
  const role = formData.get("role") === "admin" ? "admin" : "member";
  const { error } = await supabase.rpc("set_member_role", { p_user_id: String(formData.get("userId") ?? ""), p_role: role });
  if (error) return formError(codeFromDbError(error));
  revalidatePath("/configuracoes/membros");
  return { ok: true, message: role === "admin" ? "Agora é administrador." : "Agora é membro." };
}

export async function transferOwnership(_prev: FormState, formData: FormData): Promise<FormState> {
  const supabase = await createClient();
  const { error } = await supabase.rpc("transfer_ownership", { p_user_id: String(formData.get("userId") ?? "") });
  if (error) return formError(codeFromDbError(error));
  revalidatePath("/", "layout");
  return { ok: true, message: "Titularidade transferida. Você agora é administrador." };
}

export async function requestOfficeDeletion(_prev: FormState, formData: FormData): Promise<FormState> {
  const ctx = await getSessionContext();
  if (String(formData.get("confirm") ?? "").trim() !== ctx.office.name) return formError("CONFIRMATION_MISMATCH");
  const supabase = await createClient();
  const { error } = await supabase.rpc("request_office_deletion");
  if (error) return formError(codeFromDbError(error));
  revalidatePath("/", "layout");
  return { ok: true, message: "Exclusão agendada." };
}

export async function cancelOfficeDeletion(_prev: FormState): Promise<FormState> {
  const supabase = await createClient();
  const { error } = await supabase.rpc("cancel_office_deletion");
  if (error) return formError(codeFromDbError(error));
  revalidatePath("/", "layout");
  return { ok: true, message: "Exclusão cancelada." };
}
