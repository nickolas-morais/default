"use server";

import { revalidatePath } from "next/cache";
import { codeFromDbError } from "@app/shared";
import { createClient } from "@/lib/supabase/server";
import { getSessionContext } from "@/lib/auth/context";
import { formError, type FormState } from "@/lib/errors";

export async function savePlaybookRule(_prev: FormState, f: FormData): Promise<FormState> {
  const ctx = await getSessionContext();
  if (!ctx.isAdmin) return formError("FORBIDDEN");
  const title = String(f.get("title") ?? "").trim();
  const instruction = String(f.get("instruction") ?? "").trim();
  const values = { title, instruction, minLevel: String(f.get("minLevel") ?? ""), contractTypes: String(f.get("contractTypes") ?? "") };
  if (title.length < 3) return formError("VALIDATION", { fieldErrors: { title: "Dê um título curto à regra." }, values });
  if (instruction.length < 10) return formError("VALIDATION", { fieldErrors: { instruction: "Descreva o critério em uma ou duas frases." }, values });
  const level = values.minLevel === "alto" || values.minLevel === "medio" || values.minLevel === "baixo" ? values.minLevel : null;
  const supabase = await createClient();
  const { error } = await supabase.rpc("save_playbook_rule", {
    p_id: String(f.get("id") ?? "") || null, p_title: title, p_instruction: instruction, p_min_level: level,
    p_contract_types: values.contractTypes, p_active: f.get("active") !== "off",
  });
  if (error) return formError(codeFromDbError(error), { values });
  revalidatePath("/configuracoes/playbook");
  return { ok: true, message: "Regra salva. Vale para as próximas análises." };
}

export async function togglePlaybookRule(id: string, active: boolean, rule: { title: string; instruction: string; min_level: string | null; contract_types: string }) {
  const ctx = await getSessionContext();
  if (!ctx.isAdmin) return formError("FORBIDDEN");
  const supabase = await createClient();
  const level = rule.min_level === "alto" || rule.min_level === "medio" || rule.min_level === "baixo" ? rule.min_level : null;
  const { error } = await supabase.rpc("save_playbook_rule", {
    p_id: id, p_title: rule.title, p_instruction: rule.instruction, p_min_level: level, p_contract_types: rule.contract_types, p_active: active,
  });
  if (error) return formError(codeFromDbError(error));
  revalidatePath("/configuracoes/playbook");
  return { ok: true };
}

export async function deletePlaybookRule(id: string): Promise<FormState> {
  const ctx = await getSessionContext();
  if (!ctx.isAdmin) return formError("FORBIDDEN");
  const supabase = await createClient();
  const { error } = await supabase.rpc("delete_playbook_rule", { p_id: id });
  if (error) return formError(codeFromDbError(error));
  revalidatePath("/configuracoes/playbook");
  return { ok: true };
}
