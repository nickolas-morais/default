"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { codeFromDbError } from "@app/shared";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { getSessionContext } from "@/lib/auth/context";
import { env } from "@/lib/env";
import { codeFromAuthError, formError, type FormState } from "@/lib/errors";
import { changeEmailSchema, changePasswordSchema, fieldErrorsOf, formToObject, profileSchema } from "@/lib/validation";

export async function updateProfile(_prev: FormState, formData: FormData): Promise<FormState> {
  const ctx = await getSessionContext();
  const raw = formToObject(formData);
  const values = { fullName: raw.fullName ?? "", phone: raw.phone ?? "", oabNumber: raw.oabNumber ?? "" };
  const parsed = profileSchema.safeParse(raw);
  if (!parsed.success) return formError("VALIDATION", { fieldErrors: fieldErrorsOf(parsed.error), values });

  const supabase = await createClient();
  const { error } = await supabase
    .from("profiles")
    .update({ full_name: parsed.data.fullName, phone: parsed.data.phone, oab_number: parsed.data.oabNumber })
    .eq("id", ctx.userId);
  if (error) return formError("UNEXPECTED", { values });
  revalidatePath("/", "layout");
  return { ok: true, message: "Dados salvos." };
}

export async function changeEmail(_prev: FormState, formData: FormData): Promise<FormState> {
  const ctx = await getSessionContext();
  const parsed = changeEmailSchema.safeParse(formToObject(formData));
  if (!parsed.success) return formError("VALIDATION", { fieldErrors: fieldErrorsOf(parsed.error) });
  if (parsed.data.email === ctx.email) return formError("SAME_EMAIL");

  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser(
    { email: parsed.data.email },
    { emailRedirectTo: `${env.siteUrl}/auth/confirm?next=/configuracoes/conta` },
  );
  if (error) return formError(error.code === "email_exists" ? "EMAIL_IN_USE" : codeFromAuthError(error));
  return {
    ok: true,
    message: `Enviamos um link de confirmação para ${parsed.data.email}. O e-mail só muda depois da confirmação (e, se a confirmação dupla estiver ativa, também pelo e-mail atual).`,
  };
}

export async function changePassword(_prev: FormState, formData: FormData): Promise<FormState> {
  const ctx = await getSessionContext();
  const parsed = changePasswordSchema.safeParse(formToObject(formData));
  if (!parsed.success) return formError("VALIDATION", { fieldErrors: fieldErrorsOf(parsed.error) });

  const supabase = await createClient();
  // Confirma a senha atual antes de trocar.
  const check = await supabase.auth.signInWithPassword({ email: ctx.email, password: parsed.data.current });
  if (check.error) {
    return check.error.code === "invalid_credentials" ? formError("WRONG_PASSWORD") : formError(codeFromAuthError(check.error));
  }
  const { error } = await supabase.auth.updateUser({ password: parsed.data.password });
  if (error) {
    if (error.code === "same_password") return { ok: false, message: "A nova senha precisa ser diferente da atual." };
    return formError(codeFromAuthError(error));
  }
  await supabase.auth.signOut({ scope: "others" });
  return { ok: true, message: "Senha alterada. As outras sessões abertas foram encerradas." };
}

export async function signOutEverywhere(): Promise<void> {
  const supabase = await createClient();
  await supabase.auth.signOut({ scope: "global" });
  redirect("/entrar");
}

/** Exclui a conta do usuário (dados do escritório permanecem com o escritório). */
export async function deleteAccount(_prev: FormState, formData: FormData): Promise<FormState> {
  const ctx = await getSessionContext();
  const supabase = await createClient();

  const { error: checkError } = await supabase.rpc("check_account_deletion");
  if (checkError) return formError(codeFromDbError(checkError));

  const auth = await supabase.auth.signInWithPassword({ email: ctx.email, password: String(formData.get("password") ?? "") });
  if (auth.error) return formError("WRONG_PASSWORD");

  const { error } = await createAdminClient().auth.admin.deleteUser(ctx.userId);
  if (error) return formError("UNEXPECTED");
  await supabase.auth.signOut();
  redirect("/entrar?conta=excluida");
}

export async function updateNotificationPrefs(_prev: FormState, formData: FormData): Promise<FormState> {
  const ctx = await getSessionContext();
  const supabase = await createClient();
  const { error } = await supabase
    .from("profiles")
    .update({
      notify_analysis_done: formData.get("analysisDone") === "on",
      notify_quota: formData.get("quota") === "on",
      notify_deadlines: formData.get("deadlines") === "on",
    })
    .eq("id", ctx.userId);
  if (error) return formError("UNEXPECTED");
  return { ok: true, message: "Preferências salvas." };
}
