"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { codeFromDbError, fileTypeFromName, messageFor, type ErrorCode } from "@app/shared";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient, DOCUMENTS_BUCKET } from "@/lib/supabase/admin";
import { getSessionContext } from "@/lib/auth/context";
import { getRequestMeta } from "@/lib/request-meta";
import { validateFile } from "@app/shared/file-validation";
import { ExtractionSchema } from "@app/shared/analysis";
import { formError, type FormState } from "@/lib/errors";

type Result<T> = ({ ok: true } & T) | { ok: false; code: ErrorCode; message: string };

function fail(code: ErrorCode): { ok: false; code: ErrorCode; message: string } {
  return { ok: false, code, message: messageFor(code) };
}

/** Passo 1: reserva o documento e devolve o caminho autorizado para o upload. */
export async function startUpload(input: {
  fileName: string;
  sizeBytes: number;
  clientId?: string | null;
  parentId?: string | null;
}): Promise<Result<{ documentId: string; storagePath: string }>> {
  await getSessionContext();
  if (!fileTypeFromName(input.fileName)) return fail("UNSUPPORTED_TYPE");

  const { ip, userAgent } = await getRequestMeta();
  const supabase = await createClient();
  if (input.parentId) {
    // Nova versão: liga à anterior (herda cliente, responsável e perspectiva); até 3 gratuitas.
    const { data: v, error: vError } = await supabase.rpc("create_version_upload", {
      p_parent_id: input.parentId, p_file_name: input.fileName, p_size_bytes: input.sizeBytes, p_ip: ip, p_user_agent: userAgent,
    });
    const vr = v?.[0];
    if (vError || !vr) return fail(codeFromDbError(vError));
    return { ok: true, documentId: vr.document_id, storagePath: vr.storage_path };
  }
  const { data, error } = await supabase.rpc("create_document_upload", {
    p_file_name: input.fileName,
    p_size_bytes: input.sizeBytes,
    p_ip: ip,
    p_user_agent: userAgent,
  });
  const row = data?.[0];
  if (error || !row) return fail(codeFromDbError(error));
  if (input.clientId) {
    // Envio a partir da página do cliente: já vincula o documento.
    await supabase.rpc("set_document_organization", { p_document_id: row.document_id, p_client_id: input.clientId, p_ip: ip, p_user_agent: userAgent });
  }
  return { ok: true, documentId: row.document_id, storagePath: row.storage_path };
}

/** Upload interrompido no navegador: remove a reserva (não conta como falha). */
export async function cancelUpload(documentId: string): Promise<void> {
  await getSessionContext();
  const supabase = await createClient();
  const { data: doc } = await supabase
    .from("documents")
    .select("id, original_path, status")
    .eq("id", documentId)
    .maybeSingle();
  if (!doc || doc.status !== "uploading") return;

  // Remove eventual arquivo parcial; ignora erro se não existir.
  await createAdminClient().storage.from(DOCUMENTS_BUCKET).remove([doc.original_path]);
  await supabase.rpc("cancel_document_upload", { p_document_id: documentId });
}

/**
 * Passo 3: confere o arquivo que chegou ao Storage e libera para análise.
 * Arquivo inválido é removido do Storage (minimização de dados) e o documento
 * fica com status 'failed' e o motivo, contando no limite diário de falhas.
 */
export async function confirmUpload(documentId: string): Promise<Result<{ status: "queued" | "failed" }>> {
  await getSessionContext();
  const supabase = await createClient();

  // Autorização pela RLS: só encontra documentos do escritório atual.
  const { data: doc, error } = await supabase
    .from("documents")
    .select("id, original_path, file_type, status, uploaded_by")
    .eq("id", documentId)
    .maybeSingle();
  if (error) return fail("UNEXPECTED");
  if (!doc || doc.status !== "uploading") return fail("DOCUMENT_NOT_FOUND");

  const admin = createAdminClient();
  const { data: blob, error: downloadError } = await admin.storage
    .from(DOCUMENTS_BUCKET)
    .download(doc.original_path);

  if (downloadError || !blob) {
    // O arquivo não chegou: provavelmente queda de conexão. Não é abuso.
    await supabase.rpc("cancel_document_upload", { p_document_id: documentId });
    return fail("UPLOAD_FAILED");
  }

  const bytes = new Uint8Array(await blob.arrayBuffer());
  const result = await validateFile(bytes, doc.file_type);

  if (!result.ok) {
    await admin.storage.from(DOCUMENTS_BUCKET).remove([doc.original_path]);
    const { error: failError } = await admin.rpc("fail_document", {
      p_document_id: documentId,
      p_error_code: result.code,
      p_file_deleted: true,
    });
    if (failError) return fail("UNEXPECTED");
    revalidatePath("/documentos");
    return fail(result.code);
  }

  const { error: queueError } = await admin.rpc("mark_document_queued", {
    p_document_id: documentId,
    p_size_bytes: bytes.byteLength,
    p_page_count: result.pageCount,
  });
  if (queueError) return fail("UNEXPECTED");

  revalidatePath("/documentos");
  return { ok: true, status: "queued" };
}

/** Exclusão definitiva: arquivos no Storage e depois o registro (com cascade). */
export async function deleteDocument(_prev: FormState, formData: FormData): Promise<FormState> {
  await getSessionContext();
  const documentId = String(formData.get("documentId") ?? "");
  const supabase = await createClient();

  const { data: allowed, error: permError } = await supabase.rpc("can_delete_document", {
    p_document_id: documentId,
  });
  if (permError) return formError("UNEXPECTED");
  if (!allowed) return formError("FORBIDDEN");

  // Remove tudo sob {escritório}/{documento}/ (original e, nas próximas
  // etapas, PDF de visualização e minutas geradas).
  const { data: doc } = await supabase
    .from("documents")
    .select("office_id")
    .eq("id", documentId)
    .single();
  if (!doc) return formError("DOCUMENT_NOT_FOUND");

  const admin = createAdminClient();
  const prefix = `${doc.office_id}/${documentId}`;
  const { data: files, error: listError } = await admin.storage.from(DOCUMENTS_BUCKET).list(prefix, { limit: 1000 });
  if (listError) return formError("STORAGE_UNAVAILABLE");

  if (files.length) {
    const { error: removeError } = await admin.storage
      .from(DOCUMENTS_BUCKET)
      .remove(files.map((f) => `${prefix}/${f.name}`));
    // Falhou no Storage: mantém o registro para permitir nova tentativa.
    if (removeError) return formError("STORAGE_UNAVAILABLE");
  }

  const { ip, userAgent } = await getRequestMeta();
  const { error: deleteError } = await supabase.rpc("delete_document", {
    p_document_id: documentId,
    p_ip: ip,
    p_user_agent: userAgent,
  });
  if (deleteError) return formError(codeFromDbError(deleteError));

  revalidatePath("/documentos");
  if (formData.get("redirectTo") === "list") redirect("/documentos?excluido=1");
  return { ok: true, message: "Documento excluído definitivamente." };
}

/** Reprocessa um documento pronto ou com falha (não consome cota). */
export async function reprocessDocument(_prev: FormState, formData: FormData): Promise<FormState> {
  await getSessionContext();
  const documentId = String(formData.get("documentId") ?? "");
  const { ip, userAgent } = await getRequestMeta();
  const supabase = await createClient();
  const { error } = await supabase.rpc("request_document_reprocess", {
    p_document_id: documentId,
    p_ip: ip,
    p_user_agent: userAgent,
  });
  if (error) return formError(codeFromDbError(error));
  revalidatePath(`/documentos/${documentId}`);
  revalidatePath("/documentos");
  return { ok: true, message: "Documento enviado para nova análise." };
}

/** Salva os dados editados pelo advogado; null descarta as edições (volta à IA). */
export async function saveExtraction(documentId: string, data: unknown | null): Promise<FormState> {
  await getSessionContext();
  let payload = null;
  if (data !== null) {
    const parsed = ExtractionSchema.safeParse(data);
    if (!parsed.success) return formError("VALIDATION");
    payload = parsed.data;
  }
  const { ip, userAgent } = await getRequestMeta();
  const supabase = await createClient();
  const { error } = await supabase.rpc("save_extraction", {
    p_document_id: documentId, p_data: payload, p_ip: ip, p_user_agent: userAgent,
  });
  if (error) return formError(codeFromDbError(error));
  revalidatePath(`/documentos/${documentId}`);
  return { ok: true, message: data === null ? "Dados da IA restaurados." : "Dados salvos." };
}

/** Salva o resumo editado; null ou vazio volta ao resumo gerado pela IA. */
export async function saveSummary(documentId: string, content: string | null): Promise<FormState> {
  await getSessionContext();
  if (content !== null && content.length > 20000) return formError("VALIDATION");
  const { ip, userAgent } = await getRequestMeta();
  const supabase = await createClient();
  const { error } = await supabase.rpc("save_summary", {
    p_document_id: documentId, p_content: content, p_ip: ip, p_user_agent: userAgent,
  });
  if (error) return formError(codeFromDbError(error));
  revalidatePath(`/documentos/${documentId}`);
  return { ok: true, message: content === null ? "Resumo da IA restaurado." : "Resumo salvo." };
}

/** Avaliação do advogado sobre um risco (null retira a avaliação). */
export async function rateRisk(riskId: string, verdict: "util" | "nao_procede" | null, comment = ""): Promise<FormState> {
  await getSessionContext();
  const supabase = await createClient();
  const { error } = await supabase.rpc("set_risk_feedback", { p_risk_id: riskId, p_verdict: verdict, p_comment: comment.slice(0, 1000) });
  if (error) return formError(codeFromDbError(error));
  return { ok: true };
}

/** Riscos que a análise deixou de apontar (texto livre; fica no escritório). */
export async function reportMissingRisks(documentId: string, text: string): Promise<FormState> {
  await getSessionContext();
  const supabase = await createClient();
  const { error } = await supabase.rpc("set_document_feedback", { p_document_id: documentId, p_missing_risks: text.slice(0, 3000) });
  if (error) return formError(codeFromDbError(error));
  return { ok: true, message: text.trim() ? "Obrigado. Isso ajuda a melhorar as próximas análises." : "Comentário removido." };
}

/** "Nosso cliente é…": refaz riscos e resumo do ponto de vista da parte (null = neutra). */
export async function setPerspective(_prev: FormState, formData: FormData): Promise<FormState> {
  await getSessionContext();
  const documentId = String(formData.get("documentId") ?? "");
  const choice = String(formData.get("party") ?? "");
  let name: string | null = null;
  let role: string | null = null;
  if (choice) {
    try {
      const parsed = JSON.parse(choice) as { name?: string; role?: string };
      name = parsed.name?.trim() || null;
      role = parsed.role?.trim() || null;
    } catch {
      return formError("VALIDATION");
    }
  }
  const { ip, userAgent } = await getRequestMeta();
  const supabase = await createClient();
  const { error } = await supabase.rpc("request_document_perspective", {
    p_document_id: documentId, p_name: name, p_role: role, p_ip: ip, p_user_agent: userAgent,
  });
  if (error) return formError(codeFromDbError(error));
  revalidatePath(`/documentos/${documentId}`);
  return { ok: true };
}

export async function saveDeadline(_prev: FormState, formData: FormData): Promise<FormState> {
  await getSessionContext();
  const documentId = String(formData.get("documentId") ?? "");
  const due = String(formData.get("dueDate") ?? "");
  const title = String(formData.get("title") ?? "").trim();
  if (title.length < 2 || !/^\d{4}-\d{2}-\d{2}$/.test(due)) return formError("VALIDATION");
  const supabase = await createClient();
  const { error } = await supabase.rpc("save_deadline", {
    p_id: String(formData.get("id") ?? "") || null,
    p_document_id: documentId, p_title: title, p_due_date: due,
    p_recurrence: String(formData.get("recurrence") ?? "none"),
  });
  if (error) return formError(codeFromDbError(error));
  revalidatePath(`/documentos/${documentId}`);
  revalidatePath("/prazos");
  return { ok: true, message: "Prazo salvo." };
}

export async function completeDeadline(id: string, done: boolean): Promise<FormState> {
  await getSessionContext();
  const supabase = await createClient();
  const { error } = await supabase.rpc("complete_deadline", { p_id: id, p_done: done });
  if (error) return formError(codeFromDbError(error));
  revalidatePath("/prazos");
  return { ok: true };
}

export async function deleteDeadline(id: string): Promise<FormState> {
  await getSessionContext();
  const supabase = await createClient();
  const { error } = await supabase.rpc("delete_deadline", { p_id: id });
  if (error) return formError(codeFromDbError(error));
  revalidatePath("/prazos");
  return { ok: true };
}

export type OrgState = FormState & { clientId?: string };

/** Cadastro rápido de cliente (a partir da página do documento). */
export async function quickCreateClient(name: string): Promise<OrgState> {
  await getSessionContext();
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("save_client", { p_id: null, p_name: name });
  if (error || !data) return formError(codeFromDbError(error));
  return { ok: true, clientId: data };
}

export async function setDocumentOrganization(
  documentId: string,
  change: { clientId?: string | null; assigneeId?: string | null; reviewStatus?: "pendente" | "em_revisao" | "enviado" | "aprovado" },
): Promise<FormState> {
  await getSessionContext();
  const { ip, userAgent } = await getRequestMeta();
  const supabase = await createClient();
  const { error } = await supabase.rpc("set_document_organization", {
    p_document_id: documentId,
    p_client_id: change.clientId ?? null,
    p_assignee_id: change.assigneeId ?? null,
    p_review_status: change.reviewStatus ?? null,
    p_clear_client: change.clientId === null,
    p_clear_assignee: change.assigneeId === null,
    p_ip: ip, p_user_agent: userAgent,
  });
  if (error) return formError(codeFromDbError(error));
  revalidatePath(`/documentos/${documentId}`);
  revalidatePath("/documentos");
  return { ok: true };
}

export async function setRiskResolution(
  riskId: string, resolution: "aberto" | "aceito" | "negociado" | "resolvido", note = "",
): Promise<FormState> {
  await getSessionContext();
  const supabase = await createClient();
  const { error } = await supabase.rpc("set_risk_resolution", { p_risk_id: riskId, p_resolution: resolution, p_note: note.slice(0, 1000) });
  if (error) return formError(codeFromDbError(error));
  return { ok: true };
}

export async function saveClientForm(_prev: FormState, formData: FormData): Promise<FormState & { clientId?: string }> {
  await getSessionContext();
  const name = String(formData.get("name") ?? "").trim();
  const doc = String(formData.get("documentNumber") ?? "").trim();
  const email = String(formData.get("email") ?? "").trim();
  const values = { name, documentNumber: doc, email, notes: String(formData.get("notes") ?? "") };
  if (name.length < 2) return formError("VALIDATION", { fieldErrors: { name: "Informe o nome do cliente." }, values });
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    return formError("VALIDATION", { fieldErrors: { email: "Informe um e-mail válido." }, values });
  }
  const supabase = await createClient();
  const id = String(formData.get("id") ?? "") || null;
  const { data, error } = await supabase.rpc("save_client", {
    p_id: id, p_name: name, p_document_number: doc || null, p_email: email || null, p_notes: values.notes.slice(0, 2000),
  });
  if (error || !data) return formError(codeFromDbError(error), { values });
  revalidatePath("/clientes");
  revalidatePath(`/clientes/${data}`);
  return { ok: true, message: id ? "Cliente atualizado." : "Cliente cadastrado.", clientId: data };
}

export async function archiveClientForm(_prev: FormState, formData: FormData): Promise<FormState> {
  await getSessionContext();
  const id = String(formData.get("id") ?? "");
  const archived = formData.get("archived") === "1";
  const supabase = await createClient();
  const { error } = await supabase.rpc("archive_client", { p_id: id, p_archived: archived });
  if (error) return formError(codeFromDbError(error));
  revalidatePath("/clientes");
  revalidatePath(`/clientes/${id}`);
  return { ok: true, message: archived ? "Cliente arquivado." : "Cliente reativado." };
}
