import * as Sentry from "@sentry/nextjs";

const privacy = { userInfo: false, cookies: false, httpHeaders: false, httpBodies: [], urlQueryParams: false } as const;

export async function register() {
  const dsn = process.env.NEXT_PUBLIC_SENTRY_DSN;
  if (!dsn) return;
  // Servidor (Node e edge): só o erro e a pilha, sem dados de usuário ou requisição.
  Sentry.init({ dsn, tracesSampleRate: 0, dataCollection: { ...privacy, httpBodies: [] } });
}

// Erros de Server Components, Server Actions e Route Handlers.
export const onRequestError = Sentry.captureRequestError;
