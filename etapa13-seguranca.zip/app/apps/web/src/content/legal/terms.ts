import type { LegalSection } from "./legal-document";

// TEXTO PROVISÓRIO. Substituir pela redação validada pelo advogado.
export const TERMS_SECTIONS: LegalSection[] = [
  {
    title: "Objeto",
    paragraphs: [
      "[Provisório] Estes termos regulam o uso da plataforma de análise de contratos por escritórios de advocacia e seus integrantes.",
    ],
  },
  {
    title: "Conta e escritório",
    paragraphs: [
      "[Provisório] Cada conta pertence a um único escritório. O titular responde pelos acessos concedidos aos integrantes convidados.",
    ],
  },
  {
    title: "Natureza das análises",
    paragraphs: [
      "[Provisório] Extrações, classificações de risco, resumos e minutas são gerados com apoio de inteligência artificial e não substituem a revisão e o juízo profissional do advogado responsável.",
    ],
  },
  {
    title: "Planos, limites e pagamento",
    paragraphs: ["[Provisório] Condições de planos, limites mensais de documentos, cobrança e cancelamento."],
  },
  {
    title: "Responsabilidades e limitações",
    paragraphs: ["[Provisório] Responsabilidades das partes, limitação de responsabilidade e disponibilidade do serviço."],
  },
  {
    title: "Foro e legislação aplicável",
    paragraphs: ["[Provisório] Legislação brasileira e foro competente."],
  },
];
