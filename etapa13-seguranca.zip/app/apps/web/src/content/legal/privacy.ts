import type { LegalSection } from "./legal-document";

// TEXTO PROVISÓRIO. Substituir pela redação validada pelo advogado.
export const PRIVACY_SECTIONS: LegalSection[] = [
  {
    title: "Papéis no tratamento de dados",
    paragraphs: [
      "[Provisório] Quanto aos dados dos documentos enviados, o escritório atua como controlador e a plataforma como operadora, nos termos da LGPD. Quanto aos dados de cadastro dos usuários, a plataforma atua como controladora.",
    ],
  },
  {
    title: "Dados tratados",
    paragraphs: [
      "[Provisório] Dados de cadastro (nome, e-mail, escritório), registros de acesso e de aceite destes termos (data, hora, versão, IP e navegador), e o conteúdo dos documentos enviados.",
    ],
  },
  {
    title: "Armazenamento e suboperadores",
    paragraphs: [
      "[Provisório] Os dados são armazenados em servidores na região de São Paulo. Suboperadores: Supabase (banco de dados e arquivos), Anthropic (processamento por inteligência artificial) e Stripe (pagamentos).",
    ],
  },
  {
    title: "Transferência internacional",
    paragraphs: [
      "[Provisório] O processamento por inteligência artificial ocorre fora do Brasil. Descrever as salvaguardas adotadas conforme os arts. 33 a 36 da LGPD.",
    ],
  },
  {
    title: "Retenção e exclusão",
    paragraphs: [
      "[Provisório] Prazos de retenção e a exclusão definitiva de documentos a pedido do escritório.",
    ],
  },
  {
    title: "Direitos dos titulares e contato",
    paragraphs: ["[Provisório] Como exercer os direitos do art. 18 da LGPD e contato do encarregado (DPO)."],
  },
];
