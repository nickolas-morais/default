/**
 * Versões vigentes dos documentos legais.
 * DEVEM coincidir com a última linha de public.legal_documents: o banco recusa
 * cadastros e aceites de versões diferentes. Para publicar uma nova versão,
 * veja o cabeçalho de supabase/migrations/20260925000200_legal.sql.
 */
export const LEGAL_VERSIONS = {
  terms: "2026-09-provisoria",
  privacy: "2026-09-provisoria",
} as const;
