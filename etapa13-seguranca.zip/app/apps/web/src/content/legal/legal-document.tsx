import { Alert } from "@/components/ui/alert";

export type LegalSection = { title: string; paragraphs: string[] };

/** Renderiza um documento legal com o aviso de texto provisório. */
export function LegalDocument({
  title,
  version,
  sections,
}: {
  title: string;
  version: string;
  sections: LegalSection[];
}) {
  return (
    <article className="max-w-[68ch]">
      <h1 className="font-serif text-3xl font-semibold">{title}</h1>
      <p className="mt-2 text-sm text-muted">Versão {version}</p>
      <Alert tone="warning" className="mt-6">
        Texto provisório, pendente de revisão jurídica. Não utilizar em produção.
      </Alert>
      {sections.map((s, i) => (
        <section key={s.title} className="mt-10">
          <h2 className="font-serif text-xl font-semibold">
            {i + 1}. {s.title}
          </h2>
          {s.paragraphs.map((p) => (
            <p key={p} className="mt-3 font-serif text-[17px] leading-8">{p}</p>
          ))}
        </section>
      ))}
    </article>
  );
}
