import type { DocumentStatusEnum } from "@/types/database";
import { cn } from "@/components/ui/cn";
import { STATUS_LABEL, STATUS_TONE } from "./status";

export function StatusBadge({ status }: { status: DocumentStatusEnum }) {
  return (
    <span className={cn("inline-flex whitespace-nowrap rounded px-2 py-0.5 text-xs font-medium", STATUS_TONE[status])}>
      {STATUS_LABEL[status]}
    </span>
  );
}
