import type { DocumentStatusEnum } from "@/types/database";

export const STATUS_LABEL: Record<DocumentStatusEnum, string> = {
  uploading: "Envio não concluído",
  queued: "Na fila",
  preprocessing: "Preparando",
  analyzing: "Analisando",
  ready: "Pronto",
  failed: "Com erro",
};

export const STATUS_TONE: Record<DocumentStatusEnum, string> = {
  uploading: "bg-warning-soft text-warning",
  queued: "bg-paper text-muted ring-1 ring-inset ring-line-strong",
  preprocessing: "bg-accent-soft text-accent-strong",
  analyzing: "bg-accent-soft text-accent-strong",
  ready: "bg-accent text-white",
  failed: "bg-danger-soft text-danger",
};

export const PROCESSING: DocumentStatusEnum[] = ["queued", "preprocessing", "analyzing"];

export function isProcessing(status: DocumentStatusEnum) {
  return PROCESSING.includes(status);
}
