"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { messageFor } from "@app/shared";
import { quickCreateClient, setDocumentOrganization } from "@/server/actions/documents";
import { cn } from "@/components/ui/cn";
import type { ReviewStatusEnum } from "@/types/database";
import { REVIEW_LABEL, REVIEW_STATUSES } from "./review";

const select = "h-9 rounded border border-line-strong bg-surface px-2 text-sm";

/** Cliente, responsável e status de revisão do documento. Salva a cada mudança. */
export function OrganizationBar({ documentId, clients, members, clientId, assigneeId, reviewStatus }: {
  documentId: string;
  clients: { id: string; name: string }[];
  members: { id: string; name: string }[];
  clientId: string | null;
  assigneeId: string | null;
  reviewStatus: ReviewStatusEnum;
}) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");

  const save = (change: Parameters<typeof setDocumentOrganization>[1]) =>
    start(async () => {
      const r = await setDocumentOrganization(documentId, change);
      setError(r.ok ? null : r.message ?? messageFor("UNEXPECTED"));
      router.refresh();
    });

  const create = () =>
    start(async () => {
      const r = await quickCreateClient(newName.trim());
      if (!r.ok || !r.clientId) return setError(r.message ?? messageFor("UNEXPECTED"));
      const o = await setDocumentOrganization(documentId, { clientId: r.clientId });
      setError(o.ok ? null : o.message ?? null);
      setCreating(false);
      setNewName("");
      router.refresh();
    });

  return (
    <section aria-label="Organização" className={cn("rounded border border-line bg-surface px-4 py-3", pending && "opacity-70")}>
      <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <label htmlFor="org-client" className="text-sm font-medium">Cliente</label>
          {creating ? (
            <span className="flex gap-2">
              <input autoFocus value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Nome do cliente"
                aria-label="Nome do novo cliente" className={`${select} w-56`} maxLength={200}
                onKeyDown={(e) => e.key === "Enter" && newName.trim().length >= 2 && (e.preventDefault(), create())} />
              <button type="button" disabled={pending || newName.trim().length < 2} onClick={create}
                className="h-9 rounded border border-line-strong px-3 text-sm disabled:opacity-60">Criar</button>
              <button type="button" onClick={() => setCreating(false)} className="text-sm text-muted underline underline-offset-4">Cancelar</button>
            </span>
          ) : (
            <select id="org-client" value={clientId ?? ""} disabled={pending} className={select}
              onChange={(e) => (e.target.value === "__new" ? setCreating(true) : save({ clientId: e.target.value || null }))}>
              <option value="">Sem cliente</option>
              {clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              <option value="__new">+ Novo cliente…</option>
            </select>
          )}
        </div>
        <div className="flex items-center gap-2">
          <label htmlFor="org-assignee" className="text-sm font-medium">Responsável</label>
          <select id="org-assignee" value={assigneeId ?? ""} disabled={pending} className={select}
            onChange={(e) => save({ assigneeId: e.target.value || null })}>
            <option value="">Ninguém</option>
            {members.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
          </select>
        </div>
        <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Status de revisão">
          <span className="text-sm font-medium">Revisão</span>
          {REVIEW_STATUSES.map((s) => (
            <button key={s} type="button" disabled={pending} aria-pressed={reviewStatus === s}
              onClick={() => reviewStatus !== s && save({ reviewStatus: s })}
              className={cn("h-8 rounded px-2.5 text-sm", reviewStatus === s ? "bg-ink text-white" : "border border-line-strong bg-surface hover:bg-paper")}>
              {REVIEW_LABEL[s]}
            </button>
          ))}
        </div>
      </div>
      {error ? <p className="mt-2 text-sm text-danger">{error}</p> : null}
    </section>
  );
}
