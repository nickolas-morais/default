"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  ACCEPTED_FILE_TYPES,
  MAX_FILE_BYTES,
  fileTypeFromName,
  formatBytes,
  messageFor,
} from "@app/shared";
import { cancelUpload, confirmUpload, startUpload } from "@/server/actions/documents";
import { createClient } from "@/lib/supabase/browser";
import { env } from "@/lib/env";
import { cn } from "@/components/ui/cn";

type Phase = "waiting" | "uploading" | "checking" | "done" | "error";

type Item = {
  key: string;
  file: File;
  phase: Phase;
  progress: number;
  error?: string;
};

const PHASE_LABEL: Record<Phase, string> = {
  waiting: "Aguardando",
  uploading: "Enviando",
  checking: "Conferindo o arquivo",
  done: "Enviado, na fila para análise",
  error: "Não enviado",
};

/** Envia o arquivo direto ao Storage (com progresso), autorizado pela RLS. */
function putToStorage(path: string, file: File, accessToken: string, onProgress: (p: number) => void) {
  const type = fileTypeFromName(file.name)!;
  return new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const encodedPath = path.split("/").map(encodeURIComponent).join("/");
    xhr.open("POST", `${env.supabaseUrl}/storage/v1/object/documents/${encodedPath}`);
    xhr.setRequestHeader("Authorization", `Bearer ${accessToken}`);
    xhr.setRequestHeader("apikey", env.supabaseKey);
    xhr.setRequestHeader("Content-Type", ACCEPTED_FILE_TYPES[type]);
    xhr.setRequestHeader("x-upsert", "false");
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(e.loaded / e.total);
    xhr.onload = () => (xhr.status >= 200 && xhr.status < 300 ? resolve() : reject(new Error(String(xhr.status))));
    xhr.onerror = () => reject(new Error("network"));
    xhr.send(file);
  });
}

function checkLocally(file: File): string | null {
  if (!fileTypeFromName(file.name)) return messageFor("UNSUPPORTED_TYPE");
  if (file.size === 0) return messageFor("FILE_EMPTY");
  if (file.size > MAX_FILE_BYTES) return messageFor("FILE_TOO_LARGE");
  return null;
}

export function Uploader({ clientId, clientName, parentId, single }: {
  clientId?: string; clientName?: string; parentId?: string; single?: boolean;
} = {}) {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [items, setItems] = useState<Item[]>([]);
  const [dragging, setDragging] = useState(false);
  const running = useRef(false);
  const queue = useRef<Item[]>([]);

  const update = useCallback((key: string, patch: Partial<Item>) => {
    setItems((list) => list.map((i) => (i.key === key ? { ...i, ...patch } : i)));
  }, []);

  const busy = items.some((i) => i.phase === "uploading" || i.phase === "checking" || i.phase === "waiting");

  // Avisa antes de fechar a aba durante um envio.
  useEffect(() => {
    if (!busy) return;
    const onBeforeUnload = (e: BeforeUnloadEvent) => e.preventDefault();
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => window.removeEventListener("beforeunload", onBeforeUnload);
  }, [busy]);

  const processItem = useCallback(
    async (item: Item) => {
      const local = checkLocally(item.file);
      if (local) return update(item.key, { phase: "error", error: local });

      update(item.key, { phase: "uploading", progress: 0 });
      const started = await startUpload({ fileName: item.file.name, sizeBytes: item.file.size, clientId, parentId });
      if (!started.ok) return update(item.key, { phase: "error", error: started.message });

      const { data } = await createClient().auth.getSession();
      const token = data.session?.access_token;
      if (!token) {
        await cancelUpload(started.documentId);
        return update(item.key, { phase: "error", error: messageFor("NOT_AUTHENTICATED") });
      }

      try {
        await putToStorage(started.storagePath, item.file, token, (p) => update(item.key, { progress: p }));
      } catch {
        await cancelUpload(started.documentId);
        return update(item.key, { phase: "error", error: messageFor("UPLOAD_FAILED") });
      }

      update(item.key, { phase: "checking", progress: 1 });
      const confirmed = await confirmUpload(started.documentId);
      update(item.key, confirmed.ok ? { phase: "done" } : { phase: "error", error: confirmed.message });
      router.refresh();
    },
    [router, update, clientId, parentId],
  );

  const enqueue = useCallback(
    (files: FileList | File[]) => {
      const fresh = Array.from(files).map((file) => ({
        key: `${file.name}-${file.size}-${crypto.randomUUID()}`,
        file,
        phase: "waiting" as Phase,
        progress: 0,
      }));
      setItems((list) => [...fresh, ...list]);
      queue.current.push(...fresh);

      // Fila sequencial: um arquivo por vez.
      if (running.current) return;
      running.current = true;
      void (async () => {
        try {
          let next: Item | undefined;
          while ((next = queue.current.shift())) {
            const current = next;
            await processItem(current).catch(() =>
              update(current.key, { phase: "error", error: messageFor("UNEXPECTED") }),
            );
          }
        } finally {
          running.current = false;
        }
      })();
    },
    [processItem, update],
  );

  return (
    <section aria-label="Enviar documentos">
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragging(false);
          if (e.dataTransfer.files.length) enqueue(single ? [e.dataTransfer.files[0]!] : e.dataTransfer.files);
        }}
        className={cn(
          "flex flex-col items-start gap-3 rounded border border-dashed px-6 py-6 sm:flex-row sm:items-center sm:justify-between",
          dragging ? "border-accent bg-accent-soft" : "border-line-strong bg-surface",
        )}
      >
        <div>
          <p className="font-medium">
            Arraste contratos para cá ou escolha os arquivos{clientName ? <span className="font-normal text-muted"> (serão vinculados a {clientName})</span> : null}
          </p>
          <p className="mt-1 text-sm text-muted">
            {parentId ? "A nova versão é analisada por inteiro e comparada com esta; as 3 primeiras novas versões de cada contrato não consomem a cota. " : ""}
            PDF (inclusive digitalizado) ou DOCX, até 50 páginas e 25 MB{single ? "" : " cada"}.
          </p>
        </div>
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="inline-flex h-10 shrink-0 items-center rounded bg-accent px-4 text-sm font-medium text-white hover:bg-accent-strong"
        >
          Escolher arquivos
        </button>
        <input
          ref={inputRef}
          type="file"
          multiple={!single}
          accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
          className="sr-only"
          onChange={(e) => {
            if (e.target.files?.length) enqueue(e.target.files);
            e.target.value = "";
          }}
        />
      </div>

      {items.length ? (
        <ul className="mt-3 divide-y divide-line rounded border border-line bg-surface text-sm" aria-live="polite">
          {items.map((item) => (
            <li key={item.key} className="px-4 py-3">
              <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
                <p className="min-w-0 truncate font-medium">{item.file.name}</p>
                <p className={cn("shrink-0", item.phase === "error" ? "text-danger" : "text-muted")}>
                  {PHASE_LABEL[item.phase]}
                  {item.phase === "uploading" ? ` ${Math.round(item.progress * 100)}%` : ""}
                  <span className="text-muted"> · {formatBytes(item.file.size)}</span>
                </p>
              </div>
              {item.phase === "uploading" || item.phase === "checking" ? (
                <div className="mt-2 h-1 overflow-hidden rounded bg-paper" role="progressbar"
                  aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(item.progress * 100)}>
                  <div className="h-full bg-accent transition-[width]" style={{ width: `${item.progress * 100}%` }} />
                </div>
              ) : null}
              {item.error ? <p className="mt-1 text-danger">{item.error}</p> : null}
            </li>
          ))}
        </ul>
      ) : null}
    </section>
  );
}
