import type { ReviewStatusEnum, RiskResolutionEnum } from "@/types/database";

export const REVIEW_STATUSES: ReviewStatusEnum[] = ["pendente", "em_revisao", "enviado", "aprovado"];

export const REVIEW_LABEL: Record<ReviewStatusEnum, string> = {
  pendente: "Pendente",
  em_revisao: "Em revisão",
  enviado: "Enviado ao cliente",
  aprovado: "Aprovado",
};

export const REVIEW_TONE: Record<ReviewStatusEnum, string> = {
  pendente: "bg-paper text-muted ring-1 ring-inset ring-line-strong",
  em_revisao: "bg-warning-soft text-warning",
  enviado: "bg-accent-soft text-accent-strong",
  aprovado: "bg-accent text-white",
};

export const RESOLUTION_LABEL: Record<RiskResolutionEnum, string> = {
  aberto: "Em aberto",
  aceito: "Aceito",
  negociado: "Em negociação",
  resolvido: "Resolvido",
};

export const RESOLUTION_HINT: Record<RiskResolutionEnum, string> = {
  aberto: "Ainda não tratado",
  aceito: "O cliente assume o risco",
  negociado: "Proposta enviada à outra parte",
  resolvido: "Cláusula ajustada ou risco eliminado",
};
