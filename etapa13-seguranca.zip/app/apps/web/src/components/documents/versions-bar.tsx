import Link from "next/link";
import { cn } from "@/components/ui/cn";
import { Uploader } from "./uploader";

type Version = { id: string; version_number: number; file_name: string; status: string; has_comparison: boolean };

/** Histórico de versões, comparação e envio de nova versão. */
export function VersionsBar({ currentId, versions, canUploadNew }: { currentId: string; versions: Version[]; canUploadNew: boolean }) {
  const current = versions.find((v) => v.id === currentId);
  const latest = versions[versions.length - 1];
  return (
    <section aria-label="Versões" className="rounded border border-line bg-surface px-4 py-3">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
        <span className="text-sm font-medium">Versões</span>
        {versions.length > 1 ? (
          <ol className="flex flex-wrap items-center gap-1">
            {versions.map((v) => (
              <li key={v.id}>
                <Link href={`/documentos/${v.id}`} title={v.file_name}
                  className={cn("rounded px-2.5 py-1 text-sm", v.id === currentId ? "bg-ink text-white" : "border border-line-strong hover:bg-paper")}>
                  v{v.version_number}
                </Link>
              </li>
            ))}
          </ol>
        ) : <span className="text-sm text-muted">v1 (única)</span>}
        {current?.has_comparison ? (
          <Link href={`/documentos/${currentId}/comparar`} className="text-sm font-medium text-accent underline underline-offset-4">
            Comparar com a v{current.version_number - 1}
          </Link>
        ) : null}
        {latest && latest.id !== currentId ? (
          <span className="text-sm text-warning">
            Existe uma versão mais nova: <Link href={`/documentos/${latest.id}`} className="underline underline-offset-4">v{latest.version_number}</Link>
          </span>
        ) : null}
      </div>
      {canUploadNew && latest?.id === currentId ? (
        <details className="mt-3">
          <summary className="cursor-pointer text-sm font-medium text-accent">Enviar nova versão deste contrato</summary>
          <div className="mt-3"><Uploader parentId={currentId} single /></div>
        </details>
      ) : null}
    </section>
  );
}
