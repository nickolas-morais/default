import Link from "next/link";
import type { VariableMapping } from "@app/shared/template-vars";

const code = "rounded bg-paper px-1.5 py-0.5 font-mono text-[13px]";

/** Quais variáveis serão preenchidas pelos dados extraídos e quais ficam para a tela. */
export function MappingView({ mapping }: { mapping: VariableMapping }) {
  const knownLoops = mapping.loops.filter((l) => l.key);
  const unknownLoops = mapping.loops.filter((l) => !l.key);
  const total = mapping.automatic.length + mapping.manual.length + mapping.loops.length;

  if (!total) {
    return (
      <p className="text-sm text-muted">
        Nenhuma variável encontrada. Use marcações como <span className={code}>{"{{locatario}}"}</span> no Word.{" "}
        <Link href="/modelos/ajuda" className="text-accent underline underline-offset-4">Ver variáveis disponíveis</Link>
      </p>
    );
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <section>
        <h3 className="font-semibold">
          Preenchidas com os dados do documento ({mapping.automatic.length + knownLoops.length})
        </h3>
        <p className="mt-1 text-sm text-muted">Podem ser conferidas e corrigidas antes de gerar.</p>
        <ul className="mt-2 space-y-1.5 text-sm">
          {mapping.automatic.map((a) => (
            <li key={a.tag}>
              <span className={code}>{`{{${a.tag}}}`}</span> <span className="text-muted">{a.label}</span>
            </li>
          ))}
          {knownLoops.map((l) => (
            <li key={l.name}>
              <span className={code}>{`{{#${l.name}}}`}</span> <span className="text-muted">{l.label}</span>
              {l.unknownFields.length ? (
                <span className="block text-warning">
                  Campos não reconhecidos na lista, que ficarão em branco: {l.unknownFields.join(", ")}
                </span>
              ) : null}
            </li>
          ))}
          {!mapping.automatic.length && !knownLoops.length ? <li className="text-muted">Nenhuma</li> : null}
        </ul>
      </section>
      <section>
        <h3 className="font-semibold">Preenchimento manual ({mapping.manual.length + unknownLoops.length})</h3>
        <p className="mt-1 text-sm text-muted">Pedidas na hora de gerar a minuta.</p>
        <ul className="mt-2 space-y-1.5 text-sm">
          {mapping.manual.map((m) => (
            <li key={m}><span className={code}>{`{{${m}}}`}</span></li>
          ))}
          {unknownLoops.map((l) => (
            <li key={l.name} className="text-warning">
              <span className={code}>{`{{#${l.name}}}`}</span> lista não reconhecida, ficará vazia
            </li>
          ))}
          {!mapping.manual.length && !unknownLoops.length ? <li className="text-muted">Nenhuma</li> : null}
        </ul>
      </section>
    </div>
  );
}
