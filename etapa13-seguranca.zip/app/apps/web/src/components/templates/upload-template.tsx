"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import type { VariableMapping } from "@app/shared/template-vars";
import { Field } from "@/components/ui/field";
import { Alert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { MappingView } from "./mapping-view";

type Result =
  | { ok: true; templateId: string; mapping: VariableMapping }
  | { ok: false; message: string; details?: string[] };

export function UploadTemplate() {
  const router = useRouter();
  const formRef = useRef<HTMLFormElement>(null);
  const [pending, setPending] = useState(false);
  const [result, setResult] = useState<Result | null>(null);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setPending(true);
    setResult(null);
    try {
      const res = await fetch("/api/modelos", { method: "POST", body: new FormData(e.currentTarget) });
      const body = (await res.json()) as Result;
      setResult(body);
      if (body.ok) {
        formRef.current?.reset();
        router.refresh();
      }
    } catch {
      setResult({ ok: false, message: "Não foi possível enviar o modelo. Verifique sua conexão e tente de novo." });
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="space-y-5">
      <form ref={formRef} onSubmit={submit} className="grid gap-4 rounded border border-line bg-surface p-5 md:grid-cols-2">
        <Field label="Nome do modelo" name="name" required placeholder="Ex.: Notificação de rescisão de locação" />
        <Field label="Descrição (opcional)" name="description" placeholder="Quando usar este modelo" />
        <div className="space-y-1.5 md:col-span-2">
          <label htmlFor="file" className="block text-sm font-medium">Arquivo DOCX</label>
          <input
            id="file"
            name="file"
            type="file"
            required
            accept=".docx"
            className="block w-full text-sm file:mr-3 file:rounded file:border file:border-line-strong file:bg-surface file:px-3 file:py-2 file:text-sm"
          />
          <p className="text-sm text-muted">
            Até 4 MB. Use variáveis entre chaves duplas, como {"{{locatario}}"}.{" "}
            <Link href="/modelos/ajuda" className="text-accent underline underline-offset-4">Ver variáveis reconhecidas</Link>
          </p>
        </div>
        <div className="md:col-span-2">
          <Button type="submit" disabled={pending}>{pending ? "Conferindo o modelo…" : "Enviar modelo"}</Button>
        </div>
      </form>

      {result && !result.ok ? (
        <Alert tone="error">
          <p>{result.message}</p>
          {result.details?.length ? (
            <ul className="mt-2 list-disc space-y-1 pl-5">
              {result.details.map((d) => <li key={d}>{d}</li>)}
            </ul>
          ) : null}
        </Alert>
      ) : null}

      {result?.ok ? (
        <div className="space-y-4 rounded border border-accent/30 bg-surface p-5">
          <p className="font-medium text-accent-strong">
            Modelo salvo. Confira como as variáveis serão preenchidas.{" "}
            <Link href={`/modelos/${result.templateId}`} className="underline underline-offset-4">Abrir modelo</Link>
          </p>
          <MappingView mapping={result.mapping} />
        </div>
      ) : null}
    </div>
  );
}
