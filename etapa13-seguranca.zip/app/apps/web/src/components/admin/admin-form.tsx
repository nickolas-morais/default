"use client";

import { useActionState, useState } from "react";
import type { AdminFormState } from "@/server/actions/platform";
import { FormMessage } from "@/components/ui/alert";
import { Button, SubmitButton } from "@/components/ui/button";

/** Formulário do painel: mensagem de retorno, confirmação e link copiável. */
export function AdminForm({
  action, children, submitLabel, confirmText, variant = "primary", className = "space-y-4",
}: {
  action: (prev: AdminFormState, f: FormData) => Promise<AdminFormState>;
  children?: React.ReactNode;
  submitLabel: string;
  confirmText?: string;
  variant?: "primary" | "secondary" | "danger";
  className?: string;
}) {
  const [state, formAction] = useActionState<AdminFormState, FormData>(action, {});
  const [copied, setCopied] = useState(false);
  return (
    <form action={formAction} className={className}
      onSubmit={(e) => { if (confirmText && !window.confirm(confirmText)) e.preventDefault(); }}>
      {children}
      <SubmitButton variant={variant} pendingLabel="Aguarde…">{submitLabel}</SubmitButton>
      <FormMessage state={state} />
      {state.link ? (
        <div className="flex flex-wrap items-center gap-2">
          <input readOnly value={state.link} aria-label="Link do convite" onFocus={(e) => e.currentTarget.select()}
            className="h-9 min-w-0 flex-1 rounded border border-line-strong bg-surface px-2 font-mono text-xs" />
          <Button type="button" variant="secondary" className="h-9"
            onClick={() => navigator.clipboard.writeText(state.link!).then(() => setCopied(true))}>
            {copied ? "Copiado" : "Copiar link"}
          </Button>
        </div>
      ) : null}
    </form>
  );
}
