import Link from "next/link";
import { dateFmt } from "@/lib/format/dates";
import { cn } from "@/components/ui/cn";

export type Entitlement = {
  plan_name: string | null; doc_limit: number; period_start: string | null; period_end: string | null;
  source: "contract" | "subscription" | "trial" | "none"; subscription_status: string | null; cancel_at_period_end: boolean;
  used: number; reserved: number; valid_until?: string | null; suspended?: boolean;
};

const DAY = 24 * 60 * 60 * 1000;

/** Consumo do período do plano, com avisos de fim de cota, atraso e cancelamento. */
export function UsageMeter({ ent, showPlanLink = false }: { ent: Entitlement; showPlanLink?: boolean }) {
  if (ent.source === "none") {
    return (
      <div className="rounded border border-danger/30 bg-danger-soft p-5 text-danger">
        <p className="font-medium">
          {ent.subscription_status ? "A assinatura do escritório foi encerrada." : "A avaliação gratuita terminou."}
        </p>
        <p className="mt-1 text-sm">
          Os documentos já analisados continuam disponíveis. Para enviar novos, escolha um plano.
        </p>
        {showPlanLink ? <Link href="/plano" className="mt-3 inline-block text-sm font-medium underline underline-offset-4">Ver planos</Link> : null}
      </div>
    );
  }

  const total = ent.used + ent.reserved;
  const pct = Math.min(100, Math.round((total / Math.max(1, ent.doc_limit)) * 100));
  const left = Math.max(0, ent.doc_limit - total);
  const end = ent.period_end ? dateFmt.format(new Date(ent.period_end)) : "";
  const contractEnd = ent.valid_until ? new Date(ent.valid_until) : null;
  const daysLeft = contractEnd ? Math.ceil((contractEnd.getTime() - Date.now()) / DAY) : null;

  return (
    <div className="rounded border border-line bg-surface p-5">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <p className="font-medium">{ent.plan_name}</p>
        <p className="text-sm text-muted">
          {ent.source === "trial"
            ? `Avaliação até ${end}`
            : ent.source === "contract"
              ? `Contrato até ${contractEnd ? dateFmt.format(contractEnd) : ""}; cota renova em ${end}`
              : ent.cancel_at_period_end ? `Encerra em ${end}` : `Renova em ${end}`}
        </p>
      </div>
      <p className="mt-3 font-serif text-4xl font-semibold tabular-nums">
        {ent.used}<span className="text-xl font-normal text-muted"> de {ent.doc_limit} documentos</span>
      </p>
      <div className="mt-3 h-2 overflow-hidden rounded bg-paper" role="progressbar" aria-valuemin={0}
        aria-valuemax={ent.doc_limit} aria-valuenow={total} aria-label="Documentos usados no período">
        <div className={cn("h-full", pct >= 100 ? "bg-danger" : pct >= 80 ? "bg-warning" : "bg-accent")} style={{ width: `${pct}%` }} />
      </div>
      <p className="mt-2 text-sm text-muted">
        {ent.reserved ? `${ent.reserved} em processamento já reservados. ` : ""}
        {left ? `Restam ${left} no período.` : "Cota do período esgotada."}
      </p>
      {ent.source === "contract" && daysLeft !== null && daysLeft <= 15 ? (
        <p className="mt-3 text-sm text-warning">
          O contrato vence em {daysLeft} {daysLeft === 1 ? "dia" : "dias"}. Fale com o suporte para renovar e evitar a
          interrupção de novos envios.
        </p>
      ) : null}
      {ent.suspended ? (
        <p className="mt-3 text-sm text-danger">O acesso a novos envios está suspenso. Fale com o suporte.</p>
      ) : null}
      {ent.subscription_status === "past_due" && ent.source === "subscription" ? (
        <p className="mt-3 text-sm text-warning">
          O último pagamento não foi aprovado. O acesso continua enquanto o Stripe tenta a cobrança novamente;
          atualize a forma de pagamento para evitar a interrupção.
        </p>
      ) : null}
      {showPlanLink && pct >= 80 ? (
        <Link href="/plano" className="mt-3 inline-block text-sm font-medium text-accent underline underline-offset-4">
          Mudar de plano
        </Link>
      ) : null}
    </div>
  );
}
