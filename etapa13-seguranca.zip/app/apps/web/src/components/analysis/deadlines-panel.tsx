"use client";

import { useActionState, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { completeDeadline, deleteDeadline, saveDeadline } from "@/server/actions/documents";
import { FormMessage } from "@/components/ui/alert";
import { SubmitButton } from "@/components/ui/button";
import { cn } from "@/components/ui/cn";
import type { FormState } from "@/lib/errors";
import type { DeadlineRow } from "@/types/database";

const fmt = (d: string) =>
  new Intl.DateTimeFormat("pt-BR", { dateStyle: "long", timeZone: "UTC" }).format(new Date(`${d}T00:00:00Z`));
const REC: Record<string, string> = { none: "", yearly: "anual", monthly: "mensal" };
const input = "h-9 rounded border border-line-strong bg-surface px-2 text-sm";

function rule(d: DeadlineRow) {
  if (d.base === "fixed") return null;
  const ref = d.base === "data_fim" ? "fim da vigência" : "início da vigência";
  if (!d.offset_days) return `na data de ${ref}`;
  return `${Math.abs(d.offset_days)} dias ${d.offset_days < 0 ? "antes do" : "depois do"} ${ref}`;
}

function DeadlineForm({ documentId, deadline, onDone }: { documentId: string; deadline?: DeadlineRow; onDone: () => void }) {
  const router = useRouter();
  const [state, action] = useActionState<FormState, FormData>(async (p, f) => {
    const r = await saveDeadline(p, f);
    if (r.ok) { onDone(); router.refresh(); }
    return r;
  }, {});
  return (
    <form action={action} className="space-y-2 rounded border border-line bg-paper p-3">
      <input type="hidden" name="documentId" value={documentId} />
      {deadline ? <input type="hidden" name="id" value={deadline.id} /> : null}
      <input name="title" required defaultValue={deadline?.title} placeholder="Ex.: Enviar aviso de não renovação"
        aria-label="Descrição" className={`${input} w-full`} maxLength={200} />
      <div className="flex flex-wrap gap-2">
        <input type="date" name="dueDate" required defaultValue={deadline?.due_date ?? ""} aria-label="Data" className={input} />
        <select name="recurrence" defaultValue={deadline?.recurrence ?? "none"} aria-label="Repetição" className={input}>
          <option value="none">Não repete</option><option value="yearly">Todo ano</option><option value="monthly">Todo mês</option>
        </select>
        <SubmitButton className="h-9 px-3" pendingLabel="Salvando…">Salvar</SubmitButton>
        <button type="button" onClick={onDone} className="h-9 px-2 text-sm text-muted underline underline-offset-4">Cancelar</button>
      </div>
      {deadline?.source === "ai" ? <p className="text-xs text-muted">Ao editar, o prazo passa a ter data fixa e não é alterado em novas análises.</p> : null}
      <FormMessage state={state} />
    </form>
  );
}

/** Aba "Prazos" da análise. */
export function DeadlinesPanel({ documentId, deadlines }: { documentId: string; deadlines: DeadlineRow[] }) {
  const router = useRouter();
  const [editing, setEditing] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const act = (fn: () => Promise<unknown>) => start(async () => { await fn(); router.refresh(); });

  const open = deadlines.filter((d) => d.due_date);
  const closed = deadlines.filter((d) => !d.due_date);

  return (
    <div className="space-y-4 p-5">
      <p className="text-sm leading-6 text-muted">
        Prazos encontrados no contrato e os cadastrados pela equipe. Prazos relativos (ex.: 180 dias antes do fim)
        acompanham as datas da aba “Dados extraídos”. Lembretes por e-mail 30, 7 e 1 dia antes e no dia.
      </p>
      {open.length ? (
        <ul className="space-y-2">
          {open.map((d) => editing === d.id ? (
            <li key={d.id}><DeadlineForm documentId={documentId} deadline={d} onDone={() => setEditing(null)} /></li>
          ) : (
            <li key={d.id} className="rounded border border-line bg-surface p-3">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <p className="font-medium">{d.title}</p>
                <p className={cn("text-sm tabular-nums", (d.days_left ?? 99) < 0 ? "font-medium text-danger" : (d.days_left ?? 99) <= 7 ? "font-medium text-warning" : "text-muted")}>
                  {fmt(d.due_date!)}{d.days_left !== null ? ` (${d.days_left < 0 ? `venceu há ${-d.days_left} dias` : d.days_left === 0 ? "hoje" : `em ${d.days_left} dias`})` : ""}
                </p>
              </div>
              <p className="mt-1 text-xs text-muted">
                {[d.source === "ai" ? "Encontrado no contrato" : "Cadastrado pela equipe", d.clause_ref && `cláusula ${d.clause_ref}`,
                  rule(d), REC[d.recurrence] && `repete ${REC[d.recurrence]}`].filter(Boolean).join(", ")}
              </p>
              {d.excerpt ? <p className="mt-2 border-l-2 border-line-strong pl-3 font-serif text-sm leading-6 text-muted">{d.excerpt}</p> : null}
              <div className="mt-2 flex flex-wrap gap-3 text-sm">
                <button type="button" disabled={pending} onClick={() => act(() => completeDeadline(d.id, true))}
                  className="font-medium text-accent underline underline-offset-4">
                  {d.recurrence === "none" ? "Concluir" : "Concluir esta ocorrência"}
                </button>
                <button type="button" onClick={() => setEditing(d.id)} className="text-muted underline underline-offset-4">Editar</button>
                <button type="button" disabled={pending}
                  onClick={() => window.confirm(`Excluir o prazo “${d.title}”?`) && act(() => deleteDeadline(d.id))}
                  className="text-muted underline underline-offset-4 hover:text-danger">Excluir</button>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-muted">Nenhum prazo em aberto.</p>
      )}

      {editing === "new" ? <DeadlineForm documentId={documentId} onDone={() => setEditing(null)} /> : (
        <button type="button" onClick={() => setEditing("new")} className="text-sm font-medium text-accent underline underline-offset-4">
          Adicionar prazo
        </button>
      )}

      {closed.length ? (
        <details className="text-sm">
          <summary className="cursor-pointer text-muted">Concluídos ou sem data ({closed.length})</summary>
          <ul className="mt-2 space-y-1">
            {closed.map((d) => (
              <li key={d.id} className="flex flex-wrap justify-between gap-2">
                <span className="text-muted">{d.title}</span>
                <button type="button" disabled={pending} onClick={() => act(() => completeDeadline(d.id, false))}
                  className="text-muted underline underline-offset-4">Reabrir</button>
              </li>
            ))}
          </ul>
        </details>
      ) : null}
    </div>
  );
}
