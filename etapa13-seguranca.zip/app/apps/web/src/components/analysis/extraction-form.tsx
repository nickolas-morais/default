"use client";

import { useState, useTransition } from "react";
import type { Extraction } from "@app/shared/analysis";
import { formatCnpj, formatCpf, isValidCnpj, isValidCpf, normalizeCnpj } from "@app/shared";
import { saveExtraction } from "@/server/actions/documents";
import { Button } from "@/components/ui/button";
import { FormMessage } from "@/components/ui/alert";
import type { FormState } from "@/lib/errors";

const input =
  "block w-full rounded border border-line-strong bg-surface px-3 py-2 text-[15px] focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20";

function docWarning(value: string): string | null {
  const n = normalizeCnpj(value);
  if (!n) return null;
  if (/^\d{11}$/.test(n)) return isValidCpf(n) ? null : "CPF com dígitos verificadores inválidos. Confira no documento.";
  if (n.length === 14) return isValidCnpj(n) ? null : "CNPJ com dígitos verificadores inválidos. Confira no documento.";
  return "Não parece um CPF (11 dígitos) nem um CNPJ (14 caracteres).";
}

function formatDoc(value: string) {
  const n = normalizeCnpj(value);
  if (/^\d{11}$/.test(n) && isValidCpf(n)) return formatCpf(n);
  if (n.length === 14 && isValidCnpj(n)) return formatCnpj(n);
  return value;
}

function TextField({ label, value, onChange, rows = 1, id }: {
  label: string; value: string; onChange: (v: string) => void; rows?: number; id: string;
}) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="block text-sm font-medium">{label}</label>
      {rows > 1 ? (
        <textarea id={id} rows={rows} value={value} onChange={(e) => onChange(e.target.value)} className={input} />
      ) : (
        <input id={id} value={value} onChange={(e) => onChange(e.target.value)} className={input} />
      )}
    </div>
  );
}

export function ExtractionForm({ documentId, initial, edited }: {
  documentId: string; initial: Extraction; edited: boolean;
}) {
  const [data, setData] = useState<Extraction>(initial);
  const [dirty, setDirty] = useState(false);
  const [state, setState] = useState<FormState>({});
  const [pending, start] = useTransition();

  const set = <K extends keyof Extraction>(key: K, value: Extraction[K]) => {
    setData((d) => ({ ...d, [key]: value }));
    setDirty(true);
  };

  const save = () =>
    start(async () => {
      const result = await saveExtraction(documentId, data);
      setState(result);
      if (result.ok) setDirty(false);
    });

  const restore = () => {
    if (!window.confirm("Descartar as edições e voltar aos dados extraídos pela IA?")) return;
    start(async () => setState(await saveExtraction(documentId, null)));
  };

  return (
    <form
      className="space-y-6 p-5"
      onSubmit={(e) => {
        e.preventDefault();
        save();
      }}
    >
      {edited ? <p className="text-sm text-muted">Estes dados foram editados manualmente.</p> : null}

      <fieldset className="space-y-3">
        <legend className="text-sm font-semibold">Partes</legend>
        {data.partes.map((p, i) => {
          const warning = docWarning(p.documento);
          const update = (patch: Partial<typeof p>) =>
            set("partes", data.partes.map((x, j) => (j === i ? { ...x, ...patch } : x)));
          return (
            <div key={i} className="space-y-2 rounded border border-line p-3">
              <input aria-label={`Nome da parte ${i + 1}`} placeholder="Nome ou razão social" value={p.nome}
                onChange={(e) => update({ nome: e.target.value })} className={input} />
              <div className="grid gap-2 sm:grid-cols-2">
                <input aria-label={`CPF ou CNPJ da parte ${i + 1}`} placeholder="CPF ou CNPJ" value={p.documento}
                  onChange={(e) => update({ documento: e.target.value })}
                  onBlur={(e) => update({ documento: formatDoc(e.target.value) })}
                  className={`${input} tabular-nums`} />
                <input aria-label={`Papel da parte ${i + 1}`} placeholder="Papel (ex.: Locatária)" value={p.papel}
                  onChange={(e) => update({ papel: e.target.value })} className={input} />
              </div>
              {warning ? <p className="text-sm text-warning">{warning}</p> : null}
              <button type="button" onClick={() => set("partes", data.partes.filter((_, j) => j !== i))}
                className="text-sm text-muted underline underline-offset-4 hover:text-danger">
                Remover parte
              </button>
            </div>
          );
        })}
        <button type="button" onClick={() => set("partes", [...data.partes, { nome: "", documento: "", papel: "" }])}
          className="text-sm font-medium text-accent underline underline-offset-4">
          Adicionar parte
        </button>
      </fieldset>

      <TextField id="objeto" label="Objeto" rows={3} value={data.objeto} onChange={(v) => set("objeto", v)} />
      <TextField id="valor" label="Valor" value={data.valor} onChange={(v) => set("valor", v)} />
      <TextField id="forma_pagamento" label="Forma de pagamento" rows={2} value={data.forma_pagamento}
        onChange={(v) => set("forma_pagamento", v)} />
      <TextField id="vigencia" label="Vigência" rows={2} value={data.vigencia} onChange={(v) => set("vigencia", v)} />
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <label htmlFor="data_inicio" className="block text-sm font-medium">Início</label>
          <input id="data_inicio" type="date" value={data.data_inicio} onChange={(e) => set("data_inicio", e.target.value)} className={input} />
        </div>
        <div className="space-y-1.5">
          <label htmlFor="data_fim" className="block text-sm font-medium">Término</label>
          <input id="data_fim" type="date" value={data.data_fim} onChange={(e) => set("data_fim", e.target.value)} className={input} />
        </div>
      </div>
      <TextField id="prazo_rescisao" label="Rescisão (hipóteses e prazos)" rows={3} value={data.prazo_rescisao}
        onChange={(v) => set("prazo_rescisao", v)} />

      <fieldset className="space-y-3">
        <legend className="text-sm font-semibold">Multas</legend>
        {data.multas.map((m, i) => (
          <div key={i} className="grid gap-2 sm:grid-cols-[1fr_12rem_auto] sm:items-start">
            <input aria-label={`Hipótese da multa ${i + 1}`} placeholder="Hipótese" value={m.descricao}
              onChange={(e) => set("multas", data.multas.map((x, j) => (j === i ? { ...x, descricao: e.target.value } : x)))}
              className={input} />
            <input aria-label={`Valor da multa ${i + 1}`} placeholder="Valor ou percentual" value={m.valor}
              onChange={(e) => set("multas", data.multas.map((x, j) => (j === i ? { ...x, valor: e.target.value } : x)))}
              className={input} />
            <button type="button" onClick={() => set("multas", data.multas.filter((_, j) => j !== i))}
              className="h-10 text-sm text-muted underline underline-offset-4 hover:text-danger">
              Remover
            </button>
          </div>
        ))}
        <button type="button" onClick={() => set("multas", [...data.multas, { descricao: "", valor: "" }])}
          className="text-sm font-medium text-accent underline underline-offset-4">
          Adicionar multa
        </button>
      </fieldset>

      <TextField id="foro" label="Foro" value={data.foro} onChange={(v) => set("foro", v)} />
      <TextField id="indice_reajuste" label="Índice de reajuste" value={data.indice_reajuste}
        onChange={(v) => set("indice_reajuste", v)} />

      <FormMessage state={state} />
      <div className="sticky bottom-0 -mx-5 flex flex-wrap items-center gap-3 border-t border-line bg-surface px-5 py-3">
        <Button type="submit" disabled={!dirty || pending}>{pending ? "Salvando…" : "Salvar dados"}</Button>
        {dirty ? <span className="text-sm text-muted">Alterações não salvas</span> : null}
        {edited && !dirty ? (
          <button type="button" onClick={restore} disabled={pending}
            className="ml-auto text-sm text-muted underline underline-offset-4 hover:text-ink">
            Restaurar dados da IA
          </button>
        ) : null}
      </div>
    </form>
  );
}
