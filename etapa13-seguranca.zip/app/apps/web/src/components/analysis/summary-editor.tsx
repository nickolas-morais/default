"use client";

import { useState, useTransition } from "react";
import { saveSummary } from "@/server/actions/documents";
import { Button } from "@/components/ui/button";
import { FormMessage } from "@/components/ui/alert";
import type { FormState } from "@/lib/errors";
import { CopyButton } from "./risk-panel";

export function SummaryEditor({ documentId, initial, edited }: { documentId: string; initial: string; edited: boolean }) {
  const [text, setText] = useState(initial);
  const [dirty, setDirty] = useState(false);
  const [state, setState] = useState<FormState>({});
  const [pending, start] = useTransition();
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;

  return (
    <div className="space-y-4 p-5">
      <p className="text-sm leading-6 text-muted">
        Resumo em linguagem simples para enviar ao cliente. Revise e ajuste o texto antes de enviar.
        {edited ? " Este resumo foi editado manualmente." : ""}
      </p>
      <label htmlFor="resumo" className="sr-only">Resumo</label>
      <textarea
        id="resumo"
        rows={22}
        value={text}
        onChange={(e) => {
          setText(e.target.value);
          setDirty(true);
        }}
        className="block w-full rounded border border-line-strong bg-surface p-4 font-serif text-[16px] leading-7 focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20"
      />
      <p className="text-xs tabular-nums text-muted">{words} palavras</p>
      <FormMessage state={state} />
      <div className="flex flex-wrap items-center gap-3">
        <Button
          type="button"
          disabled={!dirty || pending}
          onClick={() => start(async () => {
            const r = await saveSummary(documentId, text);
            setState(r);
            if (r.ok) setDirty(false);
          })}
        >
          {pending ? "Salvando…" : "Salvar resumo"}
        </Button>
        <CopyButton text={text} label="Copiar resumo" />
        {edited && !dirty ? (
          <button
            type="button"
            disabled={pending}
            onClick={() => {
              if (!window.confirm("Descartar as edições e voltar ao resumo gerado pela IA?")) return;
              start(async () => setState(await saveSummary(documentId, null)));
            }}
            className="ml-auto text-sm text-muted underline underline-offset-4 hover:text-ink"
          >
            Restaurar resumo da IA
          </button>
        ) : null}
      </div>
    </div>
  );
}
