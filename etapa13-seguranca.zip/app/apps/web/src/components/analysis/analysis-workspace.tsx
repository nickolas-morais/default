"use client";

import dynamic from "next/dynamic";
import { useState } from "react";
import type { Extraction } from "@app/shared/analysis";
import { cn } from "@/components/ui/cn";
import type { Highlight } from "./pdf-viewer";
import { RiskPanel, type RiskItem } from "./risk-panel";
import { ExtractionForm } from "./extraction-form";
import { SummaryEditor } from "./summary-editor";
import { DeadlinesPanel } from "./deadlines-panel";
import type { DeadlineRow } from "@/types/database";

// PDF.js depende do navegador: sem renderização no servidor.
const PdfViewer = dynamic(() => import("./pdf-viewer"), {
  ssr: false,
  loading: () => <p className="p-6 text-sm text-muted">Carregando visualizador…</p>,
});

type Tab = "riscos" | "dados" | "prazos" | "resumo";

export function AnalysisWorkspace(props: {
  documentId: string;
  fileUrl: string;
  risks: RiskItem[];
  extraction: Extraction;
  extractionEdited: boolean;
  extractionKey: string;
  summary: string;
  summaryEdited: boolean;
  summaryKey: string;
  missingRisks: string;
  deadlines: DeadlineRow[];
  initialTab?: Tab;
}) {
  const [tab, setTab] = useState<Tab>(props.initialTab ?? "riscos");
  const [active, setActive] = useState<RiskItem | null>(null);
  const [highlight, setHighlight] = useState<Highlight | null>(null);

  const select = (risk: RiskItem) => {
    const same = active?.id === risk.id;
    setActive(same ? null : risk);
    setHighlight(
      same || !risk.page_number
        ? null
        : { key: `${risk.id}-${Date.now()}`, page: risk.page_number, excerpt: risk.excerpt, level: risk.level },
    );
  };

  const counts = { alto: 0, medio: 0, baixo: 0 };
  props.risks.forEach((r) => counts[r.level]++);

  const tabs: { id: Tab; label: string }[] = [
    { id: "riscos", label: `Riscos (${props.risks.length})` },
    { id: "dados", label: "Dados" },
    { id: "prazos", label: `Prazos (${props.deadlines.filter((d) => d.due_date).length})` },
    { id: "resumo", label: "Resumo" },
  ];

  return (
    <div className="grid gap-4 lg:h-[calc(100dvh-11rem)] lg:grid-cols-[minmax(0,1fr)_minmax(400px,520px)]">
      <section aria-label="Documento" className="h-[70vh] overflow-hidden rounded border border-line lg:h-auto">
        <PdfViewer fileUrl={props.fileUrl} highlight={highlight} />
      </section>

      <section aria-label="Análise" className="flex min-h-0 flex-col overflow-hidden rounded border border-line bg-surface">
        <div role="tablist" aria-label="Análise" className="flex shrink-0 border-b border-line">
          {tabs.map((t) => (
            <button
              key={t.id}
              role="tab"
              id={`tab-${t.id}`}
              aria-selected={tab === t.id}
              aria-controls={`panel-${t.id}`}
              onClick={() => setTab(t.id)}
              className={cn(
                "-mb-px flex-1 border-b-2 px-3 py-3 text-sm",
                tab === t.id ? "border-accent font-semibold text-ink" : "border-transparent text-muted hover:text-ink",
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
        {tab === "riscos" && props.risks.length ? (
          <p className="shrink-0 border-b border-line px-5 py-2 text-sm text-muted">
            {counts.alto} alto, {counts.medio} médio, {counts.baixo} baixo. Clique em um risco para ver o trecho no documento.
          </p>
        ) : null}
        <div role="tabpanel" id={`panel-${tab}`} aria-labelledby={`tab-${tab}`} className="min-h-0 flex-1 overflow-y-auto">
          {tab === "riscos" ? <RiskPanel risks={props.risks} activeId={active?.id ?? null} onSelect={select}
            documentId={props.documentId} missingRisks={props.missingRisks} /> : null}
          {tab === "dados" ? (
            <ExtractionForm key={props.extractionKey} documentId={props.documentId}
              initial={props.extraction} edited={props.extractionEdited} />
          ) : null}
          {tab === "prazos" ? <DeadlinesPanel documentId={props.documentId} deadlines={props.deadlines} /> : null}
          {tab === "resumo" ? (
            <SummaryEditor key={props.summaryKey} documentId={props.documentId}
              initial={props.summary} edited={props.summaryEdited} />
          ) : null}
        </div>
      </section>
    </div>
  );
}
