"use client";

import { useState } from "react";
import type { RiskLevelEnum } from "@/types/database";
import { cn } from "@/components/ui/cn";
import { MissingRisks, RiskFeedback } from "./risk-feedback";
import { RiskResolution } from "./risk-resolution";
import { RESOLUTION_LABEL } from "@/components/documents/review";

export type RiskItem = {
  id: string; level: RiskLevelEnum; title: string; clause_ref: string; excerpt: string;
  explanation: string; suggestion: string; affected_party: string; page_number: number | null;
  feedback?: "util" | "nao_procede" | null;
  resolution?: "aberto" | "aceito" | "negociado" | "resolvido";
  resolution_note?: string;
  playbook_rule_title?: string | null;
};

const LEVEL_LABEL: Record<RiskLevelEnum, string> = { alto: "Alto", medio: "Médio", baixo: "Baixo" };
const LEVEL_TONE: Record<RiskLevelEnum, string> = {
  alto: "bg-danger-soft text-danger",
  medio: "bg-warning-soft text-warning",
  baixo: "bg-paper text-muted ring-1 ring-inset ring-line-strong",
};
const LEVEL_BAR: Record<RiskLevelEnum, string> = { alto: "bg-danger", medio: "bg-warning", baixo: "bg-line-strong" };

function CopyButton({ text, label }: { text: string; label: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      type="button"
      onClick={async (e) => {
        e.stopPropagation();
        await navigator.clipboard.writeText(text).catch(() => undefined);
        setDone(true);
        setTimeout(() => setDone(false), 2000);
      }}
      className="text-sm font-medium text-accent underline underline-offset-4"
    >
      {done ? "Copiado" : label}
    </button>
  );
}

export function RiskPanel({
  risks, activeId, onSelect, documentId, missingRisks,
}: {
  risks: RiskItem[];
  activeId: string | null;
  onSelect: (risk: RiskItem) => void;
  documentId: string;
  missingRisks: string;
}) {
  const [filter, setFilter] = useState<RiskLevelEnum | "todos">("todos");
  const [resolutions, setResolutions] = useState<Record<string, string>>(
    Object.fromEntries(risks.map((r) => [r.id, r.resolution ?? "aberto"])),
  );
  const openCount = Object.values(resolutions).filter((v) => v === "aberto").length;
  const shown = filter === "todos" ? risks : risks.filter((r) => r.level === filter);

  if (!risks.length) {
    return (
      <div className="p-5">
        <p className="text-muted">Nenhuma cláusula de risco relevante foi identificada neste documento.</p>
        <MissingRisks documentId={documentId} initial={missingRisks} />
      </div>
    );
  }

  return (
    <div className="p-5">
      <div className="flex flex-wrap gap-2" role="group" aria-label="Filtrar por nível">
        {(["todos", "alto", "medio", "baixo"] as const).map((f) => {
          const count = f === "todos" ? risks.length : risks.filter((r) => r.level === f).length;
          return (
            <button
              key={f}
              type="button"
              aria-pressed={filter === f}
              onClick={() => setFilter(f)}
              className={cn(
                "rounded px-3 py-1 text-sm",
                filter === f ? "bg-ink text-white" : "border border-line-strong bg-surface text-ink hover:bg-paper",
              )}
            >
              {f === "todos" ? "Todos" : LEVEL_LABEL[f]} <span className="tabular-nums opacity-70">{count}</span>
            </button>
          );
        })}
      </div>
      <p className="mt-3 text-xs text-muted">
        {openCount} de {risks.length} em aberto. Análise gerada por IA: revise cada ponto antes de usar com o cliente.
      </p>

      <ol className="mt-4 space-y-3">
        {shown.map((r) => {
          const active = r.id === activeId;
          return (
            <li key={r.id}>
              <div
                role="button"
                tabIndex={0}
                aria-expanded={active}
                onClick={() => onSelect(r)}
                onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && (e.preventDefault(), onSelect(r))}
                className={cn(
                  "relative cursor-pointer overflow-hidden rounded border bg-surface py-3 pl-5 pr-4 text-left",
                  active ? "border-ink" : "border-line hover:border-line-strong",
                )}
              >
                <span className={cn("absolute inset-y-0 left-0 w-1", LEVEL_BAR[r.level])} aria-hidden />
                <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                  <span className={cn("rounded px-1.5 py-0.5 text-xs font-medium", LEVEL_TONE[r.level])}>
                    {LEVEL_LABEL[r.level]}
                  </span>
                  <span className="font-semibold">{r.title}</span>
                  {r.playbook_rule_title ? (
                    <span className="rounded bg-ink px-1.5 py-0.5 text-xs text-white" title={`Regra do escritório: ${r.playbook_rule_title}`}>
                      Regra do escritório
                    </span>
                  ) : null}
                  {resolutions[r.id] && resolutions[r.id] !== "aberto" ? (
                    <span className="rounded bg-accent-soft px-1.5 py-0.5 text-xs text-accent-strong">
                      {RESOLUTION_LABEL[resolutions[r.id] as keyof typeof RESOLUTION_LABEL]}
                    </span>
                  ) : null}
                </div>
                <p className="mt-1 text-sm text-muted">
                  {[r.clause_ref, r.page_number ? `pág. ${r.page_number}` : "trecho não localizado no PDF"]
                    .filter(Boolean).join(", ")}
                </p>

                {active ? (
                  <div className="mt-3 space-y-3" onClick={(e) => e.stopPropagation()}>
                    {r.playbook_rule_title ? <p className="text-sm font-medium">Regra do escritório: {r.playbook_rule_title}</p> : null}
                    <blockquote className="border-l-2 border-line-strong pl-3 font-serif text-[15px] leading-7 text-muted">
                      {r.excerpt}
                    </blockquote>
                    <p className="leading-7">{r.explanation}</p>
                    {r.affected_party ? <p className="text-sm text-muted">Desfavorece: {r.affected_party}</p> : null}
                    <div>
                      <div className="flex items-center justify-between gap-3">
                        <p className="text-sm font-medium">Sugestão de redação</p>
                        <CopyButton text={r.suggestion} label="Copiar" />
                      </div>
                      <p className="mt-2 whitespace-pre-line rounded bg-paper p-3 font-serif text-[15px] leading-7">
                        {r.suggestion}
                      </p>
                    </div>
                    <RiskResolution riskId={r.id} initial={r.resolution ?? "aberto"} initialNote={r.resolution_note ?? ""}
                      onChange={(v) => setResolutions((m) => ({ ...m, [r.id]: v }))} />
                    <RiskFeedback riskId={r.id} initial={r.feedback ?? null} />
                  </div>
                ) : null}
              </div>
            </li>
          );
        })}
      </ol>
      <MissingRisks documentId={documentId} initial={missingRisks} />
    </div>
  );
}

export { CopyButton };
