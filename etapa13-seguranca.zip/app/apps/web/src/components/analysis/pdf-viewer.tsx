"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Document, Page, pdfjs } from "react-pdf";
import "react-pdf/dist/Page/TextLayer.css";
import { findBestWindow, tokenize, tokenizeWithOffsets } from "@app/shared/text-match";
import type { RiskLevelEnum } from "@/types/database";

// Worker copiado para public/ no postinstall (scripts/copy-pdf-worker.mjs).
pdfjs.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.mjs";

export type Highlight = { key: string; page: number; excerpt: string; level: RiskLevelEnum };

type TextItemLike = { str: string; hasEOL?: boolean };

const escapeHtml = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

/**
 * Índices dos itens da camada de texto que contêm o trecho. Usa o mesmo
 * algoritmo do worker (@app/shared/text-match), com tolerância maior porque o
 * trecho pode continuar na página seguinte.
 */
function matchItems(items: TextItemLike[], excerpt: string): Set<number> {
  let text = "";
  const itemAt: number[] = []; // item de cada caractere de `text`
  items.forEach((item, i) => {
    text += item.str;
    for (let k = 0; k < item.str.length; k++) itemAt.push(i);
    const sep = item.hasEOL ? "\n" : " ";
    text += sep;
    itemAt.push(i);
  });

  const tokens = tokenizeWithOffsets(text);
  const match = findBestWindow(tokens.map((t) => t.word), tokenize(excerpt), 0.5);
  const result = new Set<number>();
  if (!match) return result;
  const first = itemAt[tokens[match.start]!.start] ?? 0;
  const lastToken = tokens[match.end - 1]!;
  const last = itemAt[lastToken.start + Math.max(0, lastToken.word.length - 1)] ?? first;
  for (let i = first; i <= Math.max(first, last); i++) result.add(i);
  return result;
}

/** Página renderizada só quando se aproxima da área visível. */
function LazyPage({
  pageNumber, width, highlight, onHighlightRendered, registerRef,
}: {
  pageNumber: number;
  width: number;
  highlight: Highlight | null;
  onHighlightRendered: (el: HTMLElement) => void;
  registerRef: (page: number, el: HTMLDivElement | null) => void;
}) {
  const box = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(pageNumber <= 2);
  const [items, setItems] = useState<TextItemLike[] | null>(null);
  const active = highlight?.page === pageNumber ? highlight : null;

  useEffect(() => {
    if (visible || !box.current) return;
    const io = new IntersectionObserver((entries) => entries.some((e) => e.isIntersecting) && setVisible(true), {
      rootMargin: "800px 0px",
    });
    io.observe(box.current);
    return () => io.disconnect();
  }, [visible]);

  // Destaque pedido para esta página: garante que ela seja renderizada.
  useEffect(() => {
    if (active) setVisible(true);
  }, [active]);

  const marked = useMemo(
    () => (active && items ? matchItems(items, active.excerpt) : new Set<number>()),
    [active, items],
  );

  const renderText = useCallback(
    ({ str, itemIndex }: { str: string; itemIndex: number }) =>
      marked.has(itemIndex) && active
        ? `<mark class="risk-mark risk-mark-${active.level}">${escapeHtml(str)}</mark>`
        : escapeHtml(str),
    [marked, active],
  );

  return (
    <div
      ref={(el) => {
        box.current = el;
        registerRef(pageNumber, el);
      }}
      data-page={pageNumber}
      className="relative mx-auto mb-4 bg-white shadow-[0_0_0_1px_var(--color-line)]"
      style={{ width, minHeight: visible ? undefined : Math.round(width * 1.414) }}
    >
      {visible ? (
        <Page
          pageNumber={pageNumber}
          width={width}
          renderAnnotationLayer={false}
          customTextRenderer={renderText}
          onGetTextSuccess={(content) => setItems(content.items as TextItemLike[])}
          onRenderTextLayerSuccess={() => {
            if (!active || !box.current) return;
            const mark = box.current.querySelector("mark.risk-mark");
            if (mark instanceof HTMLElement) onHighlightRendered(mark);
          }}
          loading={<div style={{ height: Math.round(width * 1.414) }} />}
        />
      ) : null}
      <span className="absolute -left-10 top-1 hidden text-xs tabular-nums text-muted xl:block">{pageNumber}</span>
    </div>
  );
}

export default function PdfViewer({ fileUrl, highlight }: { fileUrl: string; highlight: Highlight | null }) {
  const scroller = useRef<HTMLDivElement>(null);
  const pageRefs = useRef(new Map<number, HTMLDivElement>());
  const [numPages, setNumPages] = useState(0);
  const [width, setWidth] = useState(600);
  const [error, setError] = useState(false);
  const scrolledFor = useRef<string | null>(null);

  // Largura da página acompanha a coluna.
  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    const ro = new ResizeObserver(([entry]) => {
      const w = Math.floor((entry?.contentRect.width ?? 600) - 32);
      setWidth(Math.max(280, Math.min(w, 900)));
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // Ao escolher um risco: leva até a página; depois, até o trecho.
  useEffect(() => {
    if (!highlight) return;
    scrolledFor.current = null;
    pageRefs.current.get(highlight.page)?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [highlight]);

  const onHighlightRendered = useCallback(
    (mark: HTMLElement) => {
      if (!highlight || scrolledFor.current === highlight.key) return;
      scrolledFor.current = highlight.key;
      mark.scrollIntoView({ behavior: "smooth", block: "center" });
    },
    [highlight],
  );

  const registerRef = useCallback((page: number, el: HTMLDivElement | null) => {
    if (el) pageRefs.current.set(page, el);
    else pageRefs.current.delete(page);
  }, []);

  if (error) {
    return (
      <div className="p-6 text-sm text-danger">
        Não foi possível carregar a visualização do documento. Recarregue a página ou use “Baixar original”.
      </div>
    );
  }

  return (
    <div ref={scroller} className="h-full overflow-y-auto bg-paper px-4 py-4">
      <Document
        file={fileUrl}
        onLoadSuccess={(pdf) => setNumPages(pdf.numPages)}
        onLoadError={() => setError(true)}
        loading={<p className="p-6 text-sm text-muted">Carregando documento…</p>}
      >
        {Array.from({ length: numPages }, (_, i) => (
          <LazyPage
            key={i + 1}
            pageNumber={i + 1}
            width={width}
            highlight={highlight}
            onHighlightRendered={onHighlightRendered}
            registerRef={registerRef}
          />
        ))}
      </Document>
    </div>
  );
}
