"use client";

import { useActionState, useState } from "react";
import { setPerspective } from "@/server/actions/documents";
import { SubmitButton } from "@/components/ui/button";
import type { FormState } from "@/lib/errors";

type Party = { name: string; role: string };

/**
 * "Nosso cliente é…". Trocar refaz riscos e resumo do ponto de vista da parte
 * escolhida; os dados extraídos (e as edições) são mantidos.
 */
export function PerspectiveSelector({ documentId, parties, current }: {
  documentId: string;
  parties: Party[];
  current: { name: string; role: string | null } | null;
}) {
  const [state, action] = useActionState<FormState, FormData>(setPerspective, {});
  const encode = (p: Party | null) => (p ? JSON.stringify({ name: p.name, role: p.role }) : "");
  const currentValue = current ? encode({ name: current.name, role: current.role ?? "" }) : "";
  const [value, setValue] = useState(currentValue);

  // Parte atual pode ter sido renomeada na extração: continua na lista.
  const options = [...parties];
  if (current && !parties.some((p) => p.name === current.name)) options.push({ name: current.name, role: current.role ?? "" });

  return (
    <form
      action={action}
      onSubmit={(e) => {
        const label = value ? (JSON.parse(value) as Party).name : "neutra";
        if (!window.confirm(
          `Refazer os riscos e o resumo do ponto de vista: ${label}?\n\nLeva de 1 a 3 minutos e não consome a cota. Os dados extraídos são mantidos; edições no resumo, avaliações e situações dos riscos (aceito, em negociação, resolvido) são substituídas. Conta no limite de 3 reanálises por dia.`,
        )) e.preventDefault();
      }}
      className="flex flex-wrap items-center gap-2 rounded border border-line bg-surface px-4 py-3"
    >
      <input type="hidden" name="documentId" value={documentId} />
      <label htmlFor="party" className="text-sm font-medium">Nosso cliente é</label>
      <select id="party" name="party" value={value} onChange={(e) => setValue(e.target.value)}
        className="h-9 min-w-56 rounded border border-line-strong bg-surface px-2 text-sm">
        <option value="">Nenhuma parte (análise neutra)</option>
        {options.map((p) => (
          <option key={`${p.name}|${p.role}`} value={encode(p)}>{p.name}{p.role ? ` (${p.role})` : ""}</option>
        ))}
      </select>
      <SubmitButton variant="secondary" className="h-9 px-3" disabled={value === currentValue} pendingLabel="Enviando…">
        Refazer análise
      </SubmitButton>
      <p className="basis-full text-xs text-muted">
        {current
          ? `Riscos, sugestões e resumo escritos a favor de ${current.name}.`
          : "A análise atual aponta riscos para as duas partes. Escolha quem o escritório representa para uma análise a favor do seu cliente."}
      </p>
      {state.ok === false && state.message ? <p className="basis-full text-sm text-danger">{state.message}</p> : null}
    </form>
  );
}
