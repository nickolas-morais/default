"use client";

import { useState, useTransition } from "react";
import { setRiskResolution } from "@/server/actions/documents";
import { cn } from "@/components/ui/cn";
import type { RiskResolutionEnum } from "@/types/database";
import { RESOLUTION_HINT, RESOLUTION_LABEL } from "@/components/documents/review";

const OPTIONS: RiskResolutionEnum[] = ["aberto", "aceito", "negociado", "resolvido"];

/** Situação do risco no trabalho do advogado, com anotação opcional. */
export function RiskResolution({ riskId, initial, initialNote, onChange }: {
  riskId: string;
  initial: RiskResolutionEnum;
  initialNote: string;
  onChange: (r: RiskResolutionEnum) => void;
}) {
  const [value, setValue] = useState<RiskResolutionEnum>(initial);
  const [note, setNote] = useState(initialNote);
  const [pending, start] = useTransition();
  const [error, setError] = useState(false);

  const save = (v: RiskResolutionEnum, n: string) =>
    start(async () => {
      const prev = value;
      setValue(v);
      onChange(v);
      const r = await setRiskResolution(riskId, v, n);
      if (!r.ok) { setValue(prev); onChange(prev); setError(true); } else setError(false);
    });

  return (
    <div className="space-y-2 border-t border-line pt-3">
      <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Situação do risco">
        <span className="mr-1 text-sm text-muted">Situação:</span>
        {OPTIONS.map((o) => (
          <button key={o} type="button" disabled={pending} aria-pressed={value === o} title={RESOLUTION_HINT[o]}
            onClick={() => value !== o && save(o, note)}
            className={cn("rounded px-2 py-1 text-xs", value === o ? "bg-ink text-white" : "border border-line-strong bg-surface hover:bg-paper")}>
            {RESOLUTION_LABEL[o]}
          </button>
        ))}
      </div>
      {value !== "aberto" ? (
        <div className="flex gap-2">
          <input value={note} onChange={(e) => setNote(e.target.value)} maxLength={1000} aria-label="Anotação"
            placeholder={value === "aceito" ? "Ex.: cliente ciente em reunião de 10/10" : value === "negociado" ? "Ex.: proposta enviada em 12/10" : "Ex.: cláusula alterada na versão 2"}
            className="h-8 min-w-0 flex-1 rounded border border-line-strong bg-surface px-2 text-sm" />
          <button type="button" disabled={pending || note === initialNote} onClick={() => save(value, note)}
            className="h-8 rounded border border-line-strong bg-surface px-3 text-xs disabled:opacity-60">Salvar nota</button>
        </div>
      ) : null}
      {error ? <p className="text-xs text-danger">Não foi possível salvar. Tente de novo.</p> : null}
    </div>
  );
}
