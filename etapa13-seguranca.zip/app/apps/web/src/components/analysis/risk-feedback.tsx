"use client";

import { useState, useTransition } from "react";
import { rateRisk, reportMissingRisks } from "@/server/actions/documents";
import { cn } from "@/components/ui/cn";

type Verdict = "util" | "nao_procede" | null;

/** "Útil" / "Não procede" em cada risco. */
export function RiskFeedback({ riskId, initial }: { riskId: string; initial: Verdict }) {
  const [verdict, setVerdict] = useState<Verdict>(initial);
  const [comment, setComment] = useState("");
  const [asking, setAsking] = useState(false);
  const [pending, start] = useTransition();
  const [error, setError] = useState(false);

  const send = (v: Verdict, c = "") =>
    start(async () => {
      const previous = verdict;
      setVerdict(v);
      const r = await rateRisk(riskId, v, c);
      if (!r.ok) {
        setVerdict(previous);
        setError(true);
      } else setError(false);
    });

  const btn = (active: boolean) =>
    cn("rounded border px-2.5 py-1 text-sm", active ? "border-ink bg-ink text-white" : "border-line-strong bg-surface hover:bg-paper");

  return (
    <div className="border-t border-line pt-3">
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-sm text-muted">Este apontamento foi:</span>
        <button type="button" disabled={pending} aria-pressed={verdict === "util"} className={btn(verdict === "util")}
          onClick={() => { setAsking(false); send(verdict === "util" ? null : "util"); }}>
          Útil
        </button>
        <button type="button" disabled={pending} aria-pressed={verdict === "nao_procede"} className={btn(verdict === "nao_procede")}
          onClick={() => { if (verdict === "nao_procede") send(null); else { send("nao_procede"); setAsking(true); } }}>
          Não procede
        </button>
      </div>
      {asking && verdict === "nao_procede" ? (
        <div className="mt-2 flex flex-wrap gap-2">
          <input value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Por quê? (opcional, fica só no escritório)"
            aria-label="Motivo" className="h-9 min-w-0 flex-1 rounded border border-line-strong bg-surface px-2 text-sm" maxLength={1000} />
          <button type="button" disabled={pending} onClick={() => { send("nao_procede", comment); setAsking(false); }}
            className="h-9 rounded border border-line-strong bg-surface px-3 text-sm">Enviar</button>
        </div>
      ) : null}
      {error ? <p className="mt-1 text-xs text-danger">Não foi possível salvar. Tente de novo.</p> : null}
    </div>
  );
}

/** "Faltou algum risco?" no fim da lista. */
export function MissingRisks({ documentId, initial }: { documentId: string; initial: string }) {
  const [text, setText] = useState(initial);
  const [saved, setSaved] = useState<string | null>(null);
  const [pending, start] = useTransition();
  return (
    <div className="mt-6 rounded border border-line bg-paper p-4">
      <label htmlFor="missing" className="block text-sm font-medium">Faltou apontar algum risco?</label>
      <p className="mt-1 text-xs text-muted">Descreva brevemente. Fica registrado apenas no seu escritório e ajuda a medir a qualidade da análise.</p>
      <textarea id="missing" rows={3} value={text} onChange={(e) => { setText(e.target.value); setSaved(null); }} maxLength={3000}
        className="mt-2 block w-full rounded border border-line-strong bg-surface p-2 text-sm" />
      <div className="mt-2 flex items-center gap-3">
        <button type="button" disabled={pending || text === initial}
          onClick={() => start(async () => { const r = await reportMissingRisks(documentId, text); setSaved(r.message ?? null); })}
          className="h-9 rounded border border-line-strong bg-surface px-3 text-sm disabled:opacity-60">
          {pending ? "Salvando…" : "Salvar"}
        </button>
        {saved ? <span className="text-sm text-muted">{saved}</span> : null}
      </div>
    </div>
  );
}
