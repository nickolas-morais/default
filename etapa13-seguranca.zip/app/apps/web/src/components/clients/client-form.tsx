"use client";

import { useActionState } from "react";
import { useRouter } from "next/navigation";
import { formatCnpj, formatCpf, isValidCnpj, isValidCpf, normalizeCnpj } from "@app/shared";
import { saveClientForm } from "@/server/actions/documents";
import { Field } from "@/components/ui/field";
import { FormMessage } from "@/components/ui/alert";
import { SubmitButton } from "@/components/ui/button";
import type { FormState } from "@/lib/errors";

function prettyDoc(v: string) {
  const n = normalizeCnpj(v);
  if (/^\d{11}$/.test(n) && isValidCpf(n)) return formatCpf(n);
  if (n.length === 14 && isValidCnpj(n)) return formatCnpj(n);
  return v;
}

export function ClientForm({ client, onSavedGoTo }: {
  client?: { id: string; name: string; document_number: string | null; email: string | null; notes: string };
  onSavedGoTo?: boolean;
}) {
  const router = useRouter();
  const [state, action] = useActionState<FormState & { clientId?: string }, FormData>(async (p, f) => {
    const r = await saveClientForm(p, f);
    if (r.ok && onSavedGoTo && r.clientId) router.push(`/clientes/${r.clientId}`);
    return r;
  }, {});
  const v = (state.values as Record<string, string> | undefined) ?? {
    name: client?.name ?? "", documentNumber: client?.document_number ? prettyDoc(client.document_number) : "",
    email: client?.email ?? "", notes: client?.notes ?? "",
  };
  const e = state.fieldErrors ?? {};
  return (
    <form action={action} className="space-y-4" noValidate>
      {client ? <input type="hidden" name="id" value={client.id} /> : null}
      <FormMessage state={state} />
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Nome ou razão social" name="name" required defaultValue={v.name} error={e.name} />
        <Field label="CPF ou CNPJ (opcional)" name="documentNumber" defaultValue={v.documentNumber} error={e.documentNumber}
          hint="Aceita o CNPJ alfanumérico." />
      </div>
      <Field label="E-mail (opcional)" name="email" type="email" defaultValue={v.email} error={e.email} />
      <div className="space-y-1.5">
        <label htmlFor="notes" className="block text-sm font-medium">Observações internas (opcional)</label>
        <textarea id="notes" name="notes" rows={3} defaultValue={v.notes} maxLength={2000}
          className="block w-full rounded border border-line-strong bg-surface p-3 text-[15px]" />
      </div>
      <SubmitButton pendingLabel="Salvando…">{client ? "Salvar alterações" : "Cadastrar cliente"}</SubmitButton>
    </form>
  );
}
