export function PageHeader({ title, description, actions }: {
  title: string;
  description?: string;
  actions?: React.ReactNode;
}) {
  return (
    <header className="flex flex-wrap items-end justify-between gap-4 border-b border-line pb-6">
      <div>
        <h1 className="font-serif text-[28px] font-semibold leading-tight">{title}</h1>
        {description ? <p className="mt-2 max-w-[65ch] text-muted">{description}</p> : null}
      </div>
      {actions}
    </header>
  );
}
