"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/components/ui/cn";

export function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  const pathname = usePathname();
  const active = pathname === href || pathname.startsWith(`${href}/`);
  return (
    <Link
      href={href}
      aria-current={active ? "page" : undefined}
      className={cn(
        "block whitespace-nowrap rounded px-3 py-2 text-sm",
        active ? "bg-accent-soft font-medium text-accent-strong" : "text-muted hover:bg-paper hover:text-ink",
      )}
    >
      {children}
    </Link>
  );
}
