import { signOut } from "@/server/actions/auth";
import type { SessionContext } from "@/lib/auth/context";
import { NavLink } from "./nav-link";

const ROLE_LABEL = { owner: "Titular", admin: "Administrador", member: "Membro" } as const;

/**
 * O nome do escritório fica no topo, em destaque: é a âncora do multi-tenant
 * e confirma, a todo momento, em qual escritório o advogado está trabalhando.
 */
export function Sidebar({ ctx }: { ctx: SessionContext }) {
  return (
    <aside className="flex shrink-0 flex-col border-b border-line bg-surface md:sticky md:top-0 md:h-dvh md:w-64 md:border-b-0 md:border-r">
      <div className="border-b border-line px-5 py-5">
        <p className="text-xs text-muted">App</p>
        <p className="mt-1 font-serif text-lg font-semibold leading-snug">{ctx.office.name}</p>
      </div>
      <nav aria-label="Principal" className="flex gap-1 overflow-x-auto px-3 py-3 md:flex-1 md:flex-col">
        <NavLink href="/documentos">Documentos</NavLink>
        <NavLink href="/clientes">Clientes</NavLink>
        <NavLink href="/prazos">Prazos</NavLink>
        {ctx.isAdmin ? <NavLink href="/acompanhamento">Acompanhamento</NavLink> : null}
        <NavLink href="/modelos">Modelos</NavLink>
        <NavLink href="/uso">Uso</NavLink>
        <NavLink href="/plano">Plano</NavLink>
        <NavLink href="/configuracoes">Configurações</NavLink>
      </nav>
      <div className="hidden border-t border-line px-5 py-4 md:block">
        <a href="/configuracoes/conta" className="block truncate text-sm font-medium hover:underline">{ctx.fullName}</a>
        <p className="truncate text-xs text-muted">
          {ctx.email} · {ROLE_LABEL[ctx.role]}
        </p>
        <form action={signOut} className="mt-3">
          <button type="submit" className="text-sm text-muted underline underline-offset-4 hover:text-ink">
            Sair
          </button>
        </form>
      </div>
    </aside>
  );
}
