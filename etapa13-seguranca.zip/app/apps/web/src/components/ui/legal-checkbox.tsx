import Link from "next/link";
import { LEGAL_VERSIONS } from "@/content/legal/versions";

const versionLabel =
  LEGAL_VERSIONS.terms === LEGAL_VERSIONS.privacy
    ? `versão ${LEGAL_VERSIONS.terms}`
    : `termos ${LEGAL_VERSIONS.terms}, privacidade ${LEGAL_VERSIONS.privacy}`;

export function LegalCheckbox({ error }: { error?: string }) {
  return (
    <div className="space-y-1.5">
      <label className="flex items-start gap-3 text-sm leading-5">
        <input
          type="checkbox"
          name="acceptLegal"
          required
          aria-invalid={error ? true : undefined}
          className="mt-0.5 size-4 shrink-0 accent-accent"
        />
        <span>
          Li e aceito os{" "}
          <Link href="/termos" target="_blank" className="font-medium text-accent underline underline-offset-2">
            termos de uso
          </Link>{" "}
          e a{" "}
          <Link href="/privacidade" target="_blank" className="font-medium text-accent underline underline-offset-2">
            política de privacidade
          </Link>
          <span className="text-muted"> ({versionLabel})</span>.
        </span>
      </label>
      {error ? <p className="text-sm text-danger">{error}</p> : null}
    </div>
  );
}
