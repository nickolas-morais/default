import { cn } from "./cn";

type Tone = "error" | "success" | "info" | "warning";

const tones: Record<Tone, string> = {
  error: "border-danger/30 bg-danger-soft text-danger",
  success: "border-accent/30 bg-accent-soft text-accent-strong",
  info: "border-line-strong bg-surface text-ink",
  warning: "border-warning/30 bg-warning-soft text-warning",
};

export function Alert({ tone = "info", children, className }: { tone?: Tone; children: React.ReactNode; className?: string }) {
  return (
    <div role={tone === "error" ? "alert" : "status"} className={cn("rounded border px-4 py-3 text-sm", tones[tone], className)}>
      {children}
    </div>
  );
}

/** Mensagem de retorno de uma server action, se houver. */
export function FormMessage({ state }: { state: { ok?: boolean; message?: string } }) {
  if (!state.message) return null;
  return <Alert tone={state.ok ? "success" : "error"}>{state.message}</Alert>;
}
