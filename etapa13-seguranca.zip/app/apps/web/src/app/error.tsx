"use client";

import { Button } from "@/components/ui/button";

export default function ErrorPage({ reset }: { error: Error; reset: () => void }) {
  return (
    <main className="mx-auto max-w-lg px-6 py-24">
      <h1 className="font-serif text-2xl font-semibold">Não foi possível carregar esta página</h1>
      <p className="mt-3 text-muted">
        Houve uma falha de comunicação com o servidor. Seus dados não foram alterados.
      </p>
      <Button className="mt-6" onClick={reset}>Tentar novamente</Button>
    </main>
  );
}
