import { NextResponse, type NextRequest } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient, DOCUMENTS_BUCKET } from "@/lib/supabase/admin";
import { getRequestMeta } from "@/lib/request-meta";

const VIEW_TTL_SECONDS = 300; // o visualizador do navegador pode pedir trechos depois
const DOWNLOAD_TTL_SECONDS = 60;

const noStore = { "Cache-Control": "private, no-store" };

/**
 * Único caminho de leitura de arquivos: confere a permissão (RLS), registra o
 * acesso e redireciona para uma URL assinada de curta duração. A URL assinada
 * nunca é gravada no HTML das páginas.
 *   GET /api/documentos/:id/arquivo            → visualizar (inline)
 *   GET /api/documentos/:id/arquivo?baixar=1   → baixar
 */
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const download = request.nextUrl.searchParams.get("baixar") === "1";

  const supabase = await createClient();
  const { data: claims } = await supabase.auth.getClaims();
  if (!claims?.claims?.sub) {
    return NextResponse.json({ error: "NOT_AUTHENTICATED" }, { status: 401, headers: noStore });
  }

  const { data: doc } = await supabase
    .from("documents")
    .select("id, file_name, original_path, viewer_path, status, file_deleted_at")
    .eq("id", id)
    .maybeSingle();
  if (!doc || doc.status === "uploading" || doc.file_deleted_at) {
    return NextResponse.json({ error: "DOCUMENT_NOT_FOUND" }, { status: 404, headers: noStore });
  }

  const { ip, userAgent } = await getRequestMeta();
  const { error: logError } = await supabase.rpc("log_document_access", {
    p_document_id: doc.id,
    p_action: download ? "download" : "view",
    p_ip: ip,
    p_user_agent: userAgent,
  });
  // Sem registro de acesso, sem acesso.
  if (logError) return NextResponse.json({ error: "UNEXPECTED" }, { status: 500, headers: noStore });

  const { data: signed, error } = await createAdminClient()
    .storage.from(DOCUMENTS_BUCKET)
    // Visualizar usa o PDF preparado (DOCX convertido, OCR); baixar, o original.
    .createSignedUrl(download ? doc.original_path : (doc.viewer_path ?? doc.original_path),
      download ? DOWNLOAD_TTL_SECONDS : VIEW_TTL_SECONDS, {
      download: download ? doc.file_name : false,
    });
  if (error || !signed) {
    return NextResponse.json({ error: "STORAGE_UNAVAILABLE" }, { status: 503, headers: noStore });
  }

  return NextResponse.redirect(signed.signedUrl, { status: 302, headers: noStore });
}
