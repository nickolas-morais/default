import { rejectCrossOrigin } from "@/lib/security/same-origin";
import { NextResponse, type NextRequest } from "next/server";
import { codeFromDbError } from "@app/shared";
import { renderTemplate } from "@app/shared/docx-template";
import { buildLoopValues, buildRenderData, buildStandardValues } from "@app/shared/template-vars";
import { createClient } from "@/lib/supabase/server";
import { getRequestMeta } from "@/lib/request-meta";
import { loadTemplateFile } from "@/lib/templates/server";
import { parseExtraction } from "@/app/(app)/documentos/[id]/results";

const MAX_VALUE = 5000;

function backWithError(request: NextRequest, id: string, templateId: string, code: string) {
  const url = new URL(`/documentos/${id}/minuta`, request.url);
  if (templateId) url.searchParams.set("modelo", templateId);
  url.searchParams.set("erro", code);
  return NextResponse.redirect(url, { status: 303 });
}

/** "Contrato: aditivo.docx" → nome seguro, com versão UTF-8 (RFC 5987). */
function contentDisposition(name: string) {
  const ascii = name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^\w .()-]+/g, "_").slice(0, 150);
  return `attachment; filename="${ascii}.docx"; filename*=UTF-8''${encodeURIComponent(name.slice(0, 150))}.docx`;
}

/**
 * Gera a minuta e devolve o DOCX para download. Nada é guardado no Storage;
 * fica registrado quem gerou (draft_exports e log de acesso).
 */
export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const forbidden = rejectCrossOrigin(request);
  if (forbidden) return forbidden;
  const { id } = await params;
  const form = await request.formData();
  const templateId = String(form.get("template_id") ?? "");

  const supabase = await createClient();
  const { data: claims } = await supabase.auth.getClaims();
  if (!claims?.claims?.sub) return NextResponse.redirect(new URL("/entrar", request.url), { status: 303 });

  // Tudo pela RLS: documento, extração, modelo e escritório do usuário.
  const [doc, extraction, tpl, membership] = await Promise.all([
    supabase.from("documents").select("id, file_name, status").eq("id", id).maybeSingle(),
    supabase.from("extractions").select("ai_data, edited_data").eq("document_id", id).maybeSingle(),
    supabase.from("templates").select("id, name, storage_path").eq("id", templateId).maybeSingle(),
    supabase.rpc("current_membership"),
  ]);
  const [{ data: officeRow }, { data: me }] = await Promise.all([
    supabase.from("offices").select("cnpj, address, phone, contact_email, oab_registration").maybeSingle(),
    supabase.from("profiles").select("full_name, oab_number").eq("id", claims.claims.sub).maybeSingle(),
  ]);
  if (!doc.data) return backWithError(request, id, templateId, "DOCUMENT_NOT_FOUND");
  if (doc.data.status !== "ready") return backWithError(request, id, templateId, "DOCUMENT_NOT_READY");
  if (!tpl.data) return backWithError(request, id, templateId, "TEMPLATE_NOT_FOUND");

  const file = await loadTemplateFile(tpl.data.storage_path);
  if (!file) return backWithError(request, id, templateId, "DRAFT_FAILED");

  const overrides: Record<string, string> = {};
  for (const tag of file.parsed.variables) {
    const value = form.get(`var:${tag}`);
    if (typeof value === "string") overrides[tag] = value.slice(0, MAX_VALUE);
  }

  const data = parseExtraction(extraction.data?.edited_data ?? extraction.data?.ai_data);
  const standard = buildStandardValues(data, {
    officeName: membership.data?.[0]?.office_name ?? "",
    today: new Date(),
    office: officeRow ? { cnpj: officeRow.cnpj, address: officeRow.address, phone: officeRow.phone,
      contactEmail: officeRow.contact_email, oab: officeRow.oab_registration } : undefined,
    user: me ? { name: me.full_name, oab: me.oab_number } : undefined,
  });

  let output: Uint8Array;
  try {
    output = renderTemplate(file.bytes, buildRenderData(file.parsed, standard, buildLoopValues(data), overrides));
  } catch {
    return backWithError(request, id, templateId, "DRAFT_FAILED");
  }

  const { ip, userAgent } = await getRequestMeta();
  const { error } = await supabase.rpc("record_draft_export", {
    p_document_id: id, p_template_id: templateId, p_ip: ip, p_user_agent: userAgent,
  });
  if (error) return backWithError(request, id, templateId, codeFromDbError(error));

  const baseName = doc.data.file_name.replace(/\.(pdf|docx)$/i, "");
  return new NextResponse(Buffer.from(output), {
    headers: {
      "Content-Type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "Content-Disposition": contentDisposition(`${tpl.data.name} - ${baseName}`),
      "Cache-Control": "private, no-store",
    },
  });
}
