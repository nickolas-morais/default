import { NextResponse, type NextRequest } from "next/server";
import { buildIcs } from "@app/shared/ics";
import { createClient } from "@/lib/supabase/server";
import { env } from "@/lib/env";

/** Calendário .ics com os prazos do escritório (download; exige sessão). */
export async function GET(request: NextRequest) {
  const supabase = await createClient();
  const { data: claims } = await supabase.auth.getClaims();
  if (!claims?.claims?.sub) return NextResponse.json({ error: "NOT_AUTHENTICATED" }, { status: 401 });
  const { error: limitError } = await supabase.rpc("hit_rate_limit", { p_bucket: "ics" });
  if (limitError) return NextResponse.json({ error: "RATE_LIMITED" }, { status: 429 });

  const days = Math.min(Math.max(Number(request.nextUrl.searchParams.get("dias")) || 365, 1), 730);
  const today = new Date();
  const [{ data: deadlines, error }, { data: membership }] = await Promise.all([
    supabase.rpc("list_deadlines", {
      p_from: today.toISOString().slice(0, 10),
      p_to: new Date(today.getTime() + days * 86_400_000).toISOString().slice(0, 10),
    }),
    supabase.rpc("current_membership"),
  ]);
  if (error) return NextResponse.json({ error: "UNEXPECTED" }, { status: 500 });

  const ics = buildIcs({
    name: `Prazos · ${membership?.[0]?.office_name ?? "Escritório"}`,
    events: deadlines.map((d) => ({
      uid: `${d.id}@prazos`,
      date: d.due_date!,
      title: `${d.title} · ${d.file_name.replace(/\.(pdf|docx)$/i, "")}`,
      description: [d.clause_ref && `Cláusula ${d.clause_ref}`, d.excerpt].filter(Boolean).join("\n"),
      url: `${env.siteUrl}/documentos/${d.document_id}?aba=prazos`,
      // A próxima ocorrência já vem calculada; a recorrência continua no calendário.
      recurrence: d.recurrence,
      alarmDaysBefore: [7, 1],
    })),
  });

  return new NextResponse(ics, {
    headers: {
      "Content-Type": "text/calendar; charset=utf-8",
      "Content-Disposition": `attachment; filename="prazos-${today.toISOString().slice(0, 10)}.ics"`,
      "Cache-Control": "private, no-store",
    },
  });
}
