import { NextResponse, type NextRequest } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient, DOCUMENTS_BUCKET } from "@/lib/supabase/admin";

/** Baixa o arquivo original do modelo (qualquer membro do escritório). */
export async function GET(_request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: tpl } = await supabase.from("templates").select("name, storage_path").eq("id", id).maybeSingle();
  if (!tpl) return NextResponse.json({ error: "TEMPLATE_NOT_FOUND" }, { status: 404 });

  const { data, error } = await createAdminClient().storage.from(DOCUMENTS_BUCKET)
    .createSignedUrl(tpl.storage_path, 60, { download: `${tpl.name}.docx` });
  if (error || !data) return NextResponse.json({ error: "STORAGE_UNAVAILABLE" }, { status: 503 });
  return NextResponse.redirect(data.signedUrl, { status: 302, headers: { "Cache-Control": "private, no-store" } });
}
