import { NextResponse, type NextRequest } from "next/server";
import type Stripe from "stripe";
import { getStripe } from "@/lib/billing/stripe";
import { SUBSCRIPTION_EVENTS, subscriptionToUpsert } from "@/lib/billing/sync";
import { createAdminClient } from "@/lib/supabase/admin";
import { notifyPaymentFailed } from "@/lib/billing/notify";

/**
 * Webhook do Stripe. A assinatura é sempre relida da API do Stripe antes de
 * gravar: eventos fora de ordem ou repetidos não deixam o estado desatualizado.
 */
export async function POST(request: NextRequest) {
  const stripe = getStripe();
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!stripe || !secret) return NextResponse.json({ error: "BILLING_NOT_CONFIGURED" }, { status: 503 });

  const payload = await request.text();
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(payload, request.headers.get("stripe-signature") ?? "", secret);
  } catch {
    return NextResponse.json({ error: "invalid signature" }, { status: 400 });
  }

  if (!SUBSCRIPTION_EVENTS.has(event.type)) return NextResponse.json({ received: true });

  const admin = createAdminClient();
  const object = event.data.object as unknown as Record<string, unknown>;

  let subscriptionId: string | null = null;
  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    if (session.mode !== "subscription") return NextResponse.json({ received: true });
    // Garante o vínculo cliente ↔ escritório (definido ao abrir o checkout).
    const customer = typeof session.customer === "string" ? session.customer : session.customer?.id;
    if (session.client_reference_id && customer) {
      await admin.rpc("stripe_set_customer", { p_office_id: session.client_reference_id, p_customer_id: customer });
    }
    subscriptionId = typeof session.subscription === "string" ? session.subscription : session.subscription?.id ?? null;
  } else if (event.type.startsWith("invoice.")) {
    const parent = (object.parent as { subscription_details?: { subscription?: string | { id: string } } } | null)
      ?.subscription_details?.subscription;
    const legacy = object.subscription as string | { id: string } | null | undefined;
    const ref = parent ?? legacy;
    subscriptionId = typeof ref === "string" ? ref : ref?.id ?? null;
  } else {
    subscriptionId = String(object.id);
  }
  if (!subscriptionId) return NextResponse.json({ received: true });

  let subscription: Stripe.Subscription;
  try {
    subscription = await stripe.subscriptions.retrieve(subscriptionId);
  } catch {
    return NextResponse.json({ error: "retrieve failed" }, { status: 502 }); // o Stripe reenviará
  }

  const { data: known, error } = await admin.rpc("stripe_upsert_subscription", subscriptionToUpsert(subscription));
  if (error) return NextResponse.json({ error: "db" }, { status: 500 });
  if (!known) {
    // Cliente sem escritório (criado fora do app): não há o que sincronizar.
    return NextResponse.json({ received: true, ignored: "unknown customer" });
  }

  if (event.type === "invoice.payment_failed") {
    const customer = typeof subscription.customer === "string" ? subscription.customer : subscription.customer.id;
    // Falha no aviso não pode fazer o Stripe reenviar o evento.
    await notifyPaymentFailed(String(object.id), customer).catch(() => undefined);
  }

  await admin.rpc("stripe_record_event", { p_event_id: event.id, p_type: event.type });
  return NextResponse.json({ received: true });
}
