import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

/**
 * Exportação dos dados do escritório (LGPD: portabilidade). Somente titular.
 * Tudo lido com a sessão do usuário: a RLS garante que só sai o que é dele.
 */
export async function GET() {
  const supabase = await createClient();
  const { data: claims } = await supabase.auth.getClaims();
  if (!claims?.claims?.sub) return NextResponse.json({ error: "NOT_AUTHENTICATED" }, { status: 401 });
  const { data: membership } = await supabase.rpc("current_membership");
  const current = membership?.[0];
  if (current?.role !== "owner") return NextResponse.json({ error: "FORBIDDEN" }, { status: 403 });
  const { error: limitError } = await supabase.rpc("hit_rate_limit", { p_bucket: "export" });
  if (limitError) return NextResponse.json({ error: "RATE_LIMITED" }, { status: 429 });

  const q = <T,>(p: PromiseLike<{ data: T | null; error: unknown }>) => p.then((r) => { if (r.error) throw r.error; return r.data; });
  const [office, members, profiles, documents, extractions, risks, summaries, templates, drafts, accessLogs, usage] =
    await Promise.all([
      q(supabase.from("offices").select("id, name, cnpj, address, phone, contact_email, oab_registration, created_at").single()),
      q(supabase.from("office_members").select("user_id, role, created_at")),
      q(supabase.from("profiles").select("id, full_name, email, phone, oab_number")),
      q(supabase.from("documents").select("id, file_name, file_type, size_bytes, page_count, status, error_code, uploaded_by, created_at, processed_at")),
      q(supabase.from("extractions").select("document_id, ai_data, edited_data, edited_at")),
      q(supabase.from("risks").select("document_id, position, level, title, clause_ref, excerpt, explanation, suggestion, affected_party, page_number")),
      q(supabase.from("summaries").select("document_id, ai_content, edited_content, edited_at")),
      q(supabase.from("templates").select("id, name, description, variables, created_at")),
      q(supabase.from("draft_exports").select("document_id, template_id, created_by, created_at")),
      q(supabase.from("document_access_logs").select("document_id, user_id, action, file_name, ip, created_at").order("created_at")),
      q(supabase.from("usage_counters").select("period_start, documents_processed")),
    ]);

  const body = JSON.stringify({
    exported_at: new Date().toISOString(),
    format_version: 1,
    office, members, profiles, documents, extractions, risks, summaries, templates,
    draft_exports: drafts, document_access_logs: accessLogs, usage_counters: usage,
  }, null, 2);

  const date = new Date().toISOString().slice(0, 10);
  return new NextResponse(body, {
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Disposition": `attachment; filename="exportacao-escritorio-${date}.json"`,
      "Cache-Control": "private, no-store",
    },
  });
}
