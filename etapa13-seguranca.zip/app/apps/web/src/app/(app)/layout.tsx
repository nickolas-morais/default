import { getSessionContext } from "@/lib/auth/context";
import { Sidebar } from "@/components/shell/sidebar";
import { createClient } from "@/lib/supabase/server";

// Páginas autenticadas dependem da sessão: nunca pré-renderizar.
export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const ctx = await getSessionContext(); // redireciona se faltar sessão, aceite ou escritório
  const supabase = await createClient();
  const { data: office } = await supabase.from("offices").select("deletion_scheduled_for, suspended_at").eq("id", ctx.office.id).single();
  const deletion = office?.deletion_scheduled_for
    ? new Intl.DateTimeFormat("pt-BR", { dateStyle: "long", timeZone: "America/Sao_Paulo" }).format(new Date(office.deletion_scheduled_for))
    : null;
  return (
    <div className="min-h-dvh md:flex">
      <Sidebar ctx={ctx} />
      <main className="min-w-0 flex-1 px-6 py-8 md:px-10 md:py-10">
        <div className="mx-auto max-w-[1600px]">
          {deletion ? (
            <div role="alert" className="mb-6 rounded border border-danger/30 bg-danger-soft px-4 py-3 text-sm text-danger">
              Este escritório será excluído definitivamente em {deletion}. Novos envios estão bloqueados.
              {ctx.role === "owner" ? " Para desistir, vá em Configurações → Escritório." : " Fale com o titular do escritório."}
            </div>
          ) : null}
          {office?.suspended_at ? (
            <div role="alert" className="mb-6 rounded border border-danger/30 bg-danger-soft px-4 py-3 text-sm text-danger">
              O acesso do escritório a novos envios está suspenso. Os documentos existentes continuam disponíveis.
              Fale com o suporte para regularizar.
            </div>
          ) : null}
          {children}
        </div>
      </main>
    </div>
  );
}
