import { ExtractionSchema, EMPTY_EXTRACTION, type Extraction } from "@app/shared/analysis";
import type { Json, RiskLevelEnum } from "@/types/database";

export type RiskRow = {
  id: string; level: RiskLevelEnum; title: string; clause_ref: string; excerpt: string;
  explanation: string; suggestion: string; affected_party: string; page_number: number | null;
  feedback?: "util" | "nao_procede" | null;
  resolution?: "aberto" | "aceito" | "negociado" | "resolvido";
  resolution_note?: string;
  playbook_rule_title?: string | null;
};

export function parseExtraction(data: Json | null | undefined): Extraction {
  const parsed = ExtractionSchema.safeParse(data);
  return parsed.success ? parsed.data : EMPTY_EXTRACTION;
}
