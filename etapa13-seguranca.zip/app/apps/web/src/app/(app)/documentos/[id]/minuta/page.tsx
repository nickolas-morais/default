import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { isErrorCode, messageFor } from "@app/shared";
import { buildLoopValues, buildStandardValues, findStandardVariable, mapVariables } from "@app/shared/template-vars";
import { getSessionContext } from "@/lib/auth/context";
import { createClient } from "@/lib/supabase/server";
import { loadTemplateFile } from "@/lib/templates/server";
import { Alert } from "@/components/ui/alert";
import { parseExtraction } from "../results";

export const metadata: Metadata = { title: "Gerar minuta" };

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const input =
  "block w-full rounded border border-line-strong bg-surface px-3 py-2 text-[15px] focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20";
const code = "rounded bg-paper px-1.5 py-0.5 font-mono text-[12px]";

export default async function DraftPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ modelo?: string; erro?: string }>;
}) {
  const { id } = await params;
  const { modelo, erro } = await searchParams;
  if (!UUID_RE.test(id)) notFound();

  const ctx = await getSessionContext();
  const supabase = await createClient();
  const [doc, templates, extraction, officeRow, me] = await Promise.all([
    supabase.from("documents").select("id, file_name, status").eq("id", id).maybeSingle(),
    supabase.from("templates").select("id, name, description, storage_path").order("name"),
    supabase.from("extractions").select("ai_data, edited_data").eq("document_id", id).maybeSingle(),
    supabase.from("offices").select("cnpj, address, phone, contact_email, oab_registration").eq("id", ctx.office.id).maybeSingle(),
    supabase.from("profiles").select("full_name, oab_number").eq("id", ctx.userId).maybeSingle(),
  ]);
  if (doc.error || templates.error) throw doc.error ?? templates.error;
  if (!doc.data) notFound();

  const selected = templates.data.find((t) => t.id === modelo) ?? null;
  const file = selected ? await loadTemplateFile(selected.storage_path) : null;
  const data = parseExtraction(extraction.data?.edited_data ?? extraction.data?.ai_data);
  const o = officeRow.data;
  const standard = buildStandardValues(data, {
    officeName: ctx.office.name,
    today: new Date(),
    office: o ? { cnpj: o.cnpj, address: o.address, phone: o.phone, contactEmail: o.contact_email, oab: o.oab_registration } : undefined,
    user: me.data ? { name: me.data.full_name, oab: me.data.oab_number } : undefined,
  });
  const loops = buildLoopValues(data);
  const mapping = file ? mapVariables(file.parsed) : null;

  return (
    <div className="max-w-4xl">
      <Link href={`/documentos/${id}`} className="text-sm text-muted underline underline-offset-4 hover:text-ink">
        Voltar para o documento
      </Link>
      <header className="mt-4 border-b border-line pb-6">
        <h1 className="font-serif text-[28px] font-semibold leading-tight">Gerar minuta</h1>
        <p className="mt-2 text-muted">A partir de {doc.data.file_name}</p>
      </header>

      <div className="mt-8 space-y-8">
        {erro ? <Alert tone="error">{isErrorCode(erro) ? messageFor(erro) : messageFor("UNEXPECTED")}</Alert> : null}

        {doc.data.status !== "ready" ? (
          <Alert tone="warning">A minuta pode ser gerada quando a análise do documento estiver concluída.</Alert>
        ) : !templates.data.length ? (
          <p className="text-muted">
            Nenhum modelo cadastrado.{" "}
            {ctx.isAdmin ? (
              <Link href="/modelos" className="text-accent underline underline-offset-4">Enviar um modelo</Link>
            ) : (
              "Peça ao titular ou a um administrador para enviar os modelos do escritório."
            )}
          </p>
        ) : (
          <>
            <form method="get" className="flex flex-wrap items-end gap-3">
              <div className="min-w-72 flex-1 space-y-1.5">
                <label htmlFor="modelo" className="block text-sm font-medium">Modelo</label>
                <select id="modelo" name="modelo" defaultValue={selected?.id ?? ""} className={input}>
                  <option value="" disabled>Escolha um modelo</option>
                  {templates.data.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>
              <button type="submit" className="h-10 rounded border border-line-strong bg-surface px-4 text-sm font-medium hover:bg-paper">
                Usar este modelo
              </button>
            </form>

            {selected && !file ? <Alert tone="error">{messageFor("DRAFT_FAILED")}</Alert> : null}

            {selected && file && mapping ? (
              <form method="post" action={`/api/documentos/${id}/minuta`} className="space-y-8">
                <input type="hidden" name="template_id" value={selected.id} />

                {mapping.manual.length ? (
                  <section>
                    <h2 className="font-serif text-xl font-semibold">Preencha</h2>
                    <p className="mt-1 text-sm text-muted">Campos do modelo que não vêm do contrato. Em branco, saem como “__________”.</p>
                    <div className="mt-4 space-y-4">
                      {mapping.manual.map((tag) => (
                        <div key={tag} className="space-y-1.5">
                          <label htmlFor={`var-${tag}`} className="block text-sm font-medium">
                            {tag} <span className={code}>{`{{${tag}}}`}</span>
                          </label>
                          <input id={`var-${tag}`} name={`var:${tag}`} className={input} />
                        </div>
                      ))}
                    </div>
                  </section>
                ) : null}

                {mapping.automatic.length ? (
                  <section>
                    <h2 className="font-serif text-xl font-semibold">Confira os dados do contrato</h2>
                    <p className="mt-1 text-sm text-muted">
                      Preenchidos com os dados extraídos. Alterações aqui valem só para esta minuta; para corrigir o
                      documento, use a aba “Dados extraídos”.
                    </p>
                    <div className="mt-4 space-y-4">
                      {mapping.automatic.map((a) => {
                        const std = findStandardVariable(a.tag);
                        const value = std ? standard[std.key] ?? "" : "";
                        const multiline = value.includes("\n") || value.length > 90;
                        return (
                          <div key={a.tag} className="space-y-1.5">
                            <label htmlFor={`var-${a.tag}`} className="block text-sm font-medium">
                              {a.label} <span className={code}>{`{{${a.tag}}}`}</span>
                            </label>
                            {multiline ? (
                              <textarea id={`var-${a.tag}`} name={`var:${a.tag}`} defaultValue={value}
                                rows={Math.min(8, value.split("\n").length + 2)} className={input} />
                            ) : (
                              <input id={`var-${a.tag}`} name={`var:${a.tag}`} defaultValue={value} className={input} />
                            )}
                            {!value ? <p className="text-sm text-warning">Não consta no documento. Preencha ou deixe em branco.</p> : null}
                          </div>
                        );
                      })}
                    </div>
                  </section>
                ) : null}

                {mapping.loops.length ? (
                  <section>
                    <h2 className="font-serif text-xl font-semibold">Listas</h2>
                    <ul className="mt-3 space-y-1.5 text-sm">
                      {mapping.loops.map((l) => (
                        <li key={l.name}>
                          <span className={code}>{`{{#${l.name}}}`}</span>{" "}
                          {l.key
                            ? `${loops[l.key]?.length ?? 0} itens, a partir dos dados extraídos`
                            : "lista não reconhecida, ficará vazia"}
                        </li>
                      ))}
                    </ul>
                  </section>
                ) : null}

                <div className="flex flex-wrap items-center gap-4 border-t border-line pt-6">
                  <button type="submit" className="inline-flex h-10 items-center rounded bg-accent px-4 text-sm font-medium text-white hover:bg-accent-strong">
                    Gerar e baixar DOCX
                  </button>
                  <p className="text-sm text-muted">A minuta não fica guardada no sistema; o download é registrado no log de acesso.</p>
                </div>
              </form>
            ) : null}
          </>
        )}
      </div>
    </div>
  );
}
