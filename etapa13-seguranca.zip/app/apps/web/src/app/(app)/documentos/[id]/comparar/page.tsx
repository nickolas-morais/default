import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { RiskChange, TextChange } from "@app/shared/compare";
import { getSessionContext } from "@/lib/auth/context";
import { createClient } from "@/lib/supabase/server";
import { cn } from "@/components/ui/cn";
import { RESOLUTION_LABEL } from "@/components/documents/review";

export const metadata: Metadata = { title: "Comparação de versões" };

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const LEVEL: Record<string, string> = { alto: "Alto", medio: "Médio", baixo: "Baixo" };
const LEVEL_TONE: Record<string, string> = {
  alto: "bg-danger-soft text-danger", medio: "bg-warning-soft text-warning", baixo: "bg-paper text-muted ring-1 ring-inset ring-line-strong",
};
type Stats = { changed: number; added: number; removed: number; risksResolved: number; risksKept: number; risksNew: number; risksLevelChanged: number };

function Level({ l }: { l: string }) {
  return <span className={cn("rounded px-1.5 py-0.5 text-xs font-medium", LEVEL_TONE[l])}>{LEVEL[l] ?? l}</span>;
}

function Words({ c }: { c: Extract<TextChange, { type: "alterado" }> }) {
  return (
    <p className="font-serif text-[15px] leading-7">
      {c.words.map((w, i) =>
        w.op === "eq" ? <span key={i}>{w.text}</span>
        : w.op === "del" ? <del key={i} className="bg-danger-soft text-danger decoration-danger/60">{w.text}</del>
        : <ins key={i} className="bg-accent-soft text-accent-strong no-underline">{w.text}</ins>,
      ).reduce<React.ReactNode[]>((acc, el, i) => (i ? [...acc, " ", el] : [el]), [])}
    </p>
  );
}

export default async function ComparePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!UUID_RE.test(id)) notFound();
  await getSessionContext();
  const supabase = await createClient();
  const [{ data: cmp }, { data: doc }] = await Promise.all([
    supabase.from("document_comparisons").select("previous_document_id, text_changes, risk_changes, stats, created_at").eq("document_id", id).maybeSingle(),
    supabase.from("documents").select("id, file_name, version_number").eq("id", id).maybeSingle(),
  ]);
  if (!doc) notFound();
  const { data: prev } = cmp?.previous_document_id
    ? await supabase.from("documents").select("id, file_name, version_number").eq("id", cmp.previous_document_id).maybeSingle()
    : { data: null };

  if (!cmp) {
    return (
      <div className="max-w-3xl">
        <Link href={`/documentos/${id}`} className="text-sm text-muted underline underline-offset-4">Voltar para o documento</Link>
        <h1 className="mt-4 font-serif text-[28px] font-semibold">Comparação indisponível</h1>
        <p className="mt-2 text-muted">A comparação aparece quando a análise desta versão termina e existe uma versão anterior pronta.</p>
      </div>
    );
  }

  const text = cmp.text_changes as unknown as TextChange[];
  const risks = cmp.risk_changes as unknown as RiskChange[];
  const s = cmp.stats as unknown as Stats;
  const resolved = risks.filter((r): r is Extract<RiskChange, { type: "resolvido" }> => r.type === "resolvido");
  const added = risks.filter((r): r is Extract<RiskChange, { type: "novo" }> => r.type === "novo");
  const kept = risks.filter((r): r is Extract<RiskChange, { type: "mantido" }> => r.type === "mantido");

  const card = "rounded border border-line bg-surface p-4";
  return (
    <div className="max-w-5xl">
      <Link href={`/documentos/${id}`} className="text-sm text-muted underline underline-offset-4">Voltar para o documento</Link>
      <header className="mt-4 border-b border-line pb-6">
        <h1 className="font-serif text-[28px] font-semibold leading-tight">Comparação: v{prev?.version_number ?? "?"} → v{doc.version_number}</h1>
        <p className="mt-2 text-sm text-muted">
          {prev ? <Link href={`/documentos/${prev.id}`} className="underline underline-offset-4">{prev.file_name}</Link> : "Versão anterior excluída"}
          {" → "}{doc.file_name}
        </p>
      </header>

      <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-4">
        <div className={card}><p className="text-xs text-muted">Riscos resolvidos</p><p className="mt-1 text-2xl font-semibold tabular-nums text-accent-strong">{s.risksResolved}</p></div>
        <div className={card}><p className="text-xs text-muted">Riscos novos</p><p className={cn("mt-1 text-2xl font-semibold tabular-nums", s.risksNew > 0 && "text-danger")}>{s.risksNew}</p></div>
        <div className={card}><p className="text-xs text-muted">Riscos mantidos</p><p className="mt-1 text-2xl font-semibold tabular-nums">{s.risksKept}</p></div>
        <div className={card}><p className="text-xs text-muted">Texto</p><p className="mt-1 text-sm leading-6 tabular-nums">{s.changed} alteradas<br />{s.added} incluídas, {s.removed} removidas</p></div>
      </div>

      <section className="mt-10">
        <h2 className="font-serif text-xl font-semibold">Riscos</h2>
        <div className="mt-4 grid gap-6 lg:grid-cols-2">
          <div>
            <h3 className="font-semibold text-accent-strong">Resolvidos na nova versão ({resolved.length})</h3>
            <ul className="mt-2 space-y-2 text-sm">
              {resolved.map((r) => <li key={r.old.id} className={card}><Level l={r.old.level} /> <span className="ml-1 font-medium line-through decoration-muted">{r.old.title}</span></li>)}
              {!resolved.length ? <li className="text-muted">Nenhum.</li> : null}
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-danger">Novos ({added.length})</h3>
            <ul className="mt-2 space-y-2 text-sm">
              {added.map((r) => <li key={r.new.id} className={card}><Level l={r.new.level} /> <span className="ml-1 font-medium">{r.new.title}</span></li>)}
              {!added.length ? <li className="text-muted">Nenhum.</li> : null}
            </ul>
          </div>
        </div>
        <h3 className="mt-6 font-semibold">Mantidos ({kept.length})</h3>
        <ul className="mt-2 space-y-2 text-sm">
          {kept.map((r) => (
            <li key={r.new.id} className={cn(card, "flex flex-wrap items-center gap-2")}>
              {r.levelChanged ? <><Level l={r.old.level} /><span aria-label="passou para">→</span></> : null}
              <Level l={r.new.level} />
              <span className="font-medium">{r.new.title}</span>
              {r.old.resolution && r.old.resolution !== "aberto" ? (
                <span className="text-xs text-muted">
                  situação herdada: {RESOLUTION_LABEL[r.old.resolution as keyof typeof RESOLUTION_LABEL]}{r.old.note ? ` (“${r.old.note}”)` : ""}
                </span>
              ) : null}
            </li>
          ))}
          {!kept.length ? <li className="text-muted">Nenhum.</li> : null}
        </ul>
        <p className="mt-3 text-xs text-muted">
          Riscos são casados pelo trecho citado em cada versão. Riscos mantidos herdam a situação marcada na versão anterior
          (aceito, em negociação, resolvido); confira na aba Riscos da nova versão.
        </p>
      </section>

      <section className="mt-10 pb-8">
        <h2 className="font-serif text-xl font-semibold">Alterações no texto</h2>
        <p className="mt-1 text-sm text-muted">
          <del className="bg-danger-soft px-1 text-danger">removido</del> <ins className="bg-accent-soft px-1 text-accent-strong no-underline">incluído</ins>.
          Comparação automática do texto extraído; pequenas diferenças de formatação são ignoradas.
        </p>
        <ol className="mt-4 space-y-3">
          {text.map((c, i) => (
            <li key={i} className={card}>
              <p className="mb-2 flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted">
                <span className={cn("rounded px-1.5 py-0.5 normal-case tracking-normal",
                  c.type === "alterado" ? "bg-warning-soft text-warning" : c.type === "incluido" ? "bg-accent-soft text-accent-strong" : "bg-danger-soft text-danger")}>
                  {c.type === "alterado" ? "Alterada" : c.type === "incluido" ? "Incluída" : "Removida"}
                </span>
                {c.label}
              </p>
              {c.type === "alterado" ? <Words c={c} />
                : c.type === "incluido" ? <p className="bg-accent-soft/60 font-serif text-[15px] leading-7">{c.after}</p>
                : <p className="font-serif text-[15px] leading-7 text-danger line-through decoration-danger/50">{c.before}</p>}
            </li>
          ))}
          {!text.length ? <li className="text-muted">Nenhuma diferença de texto encontrada.</li> : null}
        </ol>
      </section>
    </div>
  );
}
