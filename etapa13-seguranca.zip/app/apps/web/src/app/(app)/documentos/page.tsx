import type { Metadata } from "next";
import Link from "next/link";
import { formatBytes } from "@app/shared";
import { getSessionContext } from "@/lib/auth/context";
import { createClient } from "@/lib/supabase/server";
import { dateTimeFmt, endOfDayBrt, startOfDayBrt } from "@/lib/format/dates";
import { PageHeader } from "@/components/shell/page-header";
import { Uploader } from "@/components/documents/uploader";
import { StatusBadge } from "@/components/documents/status-badge";
import { Alert } from "@/components/ui/alert";
import { AutoRefresh } from "@/components/documents/auto-refresh";
import { isProcessing } from "@/components/documents/status";
import { REVIEW_LABEL, REVIEW_STATUSES, REVIEW_TONE } from "@/components/documents/review";
import { cn } from "@/components/ui/cn";
import type { ReviewStatusEnum } from "@/types/database";

export const metadata: Metadata = { title: "Documentos" };

const PAGE_SIZE = 25;

type Search = {
  q?: string; de?: string; ate?: string; pagina?: string; excluido?: string;
  cliente?: string; resp?: string; revisao?: string;
};

const UUID = /^[0-9a-f-]{36}$/i;

export default async function DocumentsPage({ searchParams }: { searchParams: Promise<Search> }) {
  const ctx = await getSessionContext();
  const params = await searchParams;
  const clientFilter = params.cliente === "sem" ? "sem" : params.cliente && UUID.test(params.cliente) ? params.cliente : "";
  const respFilter = params.resp === "eu" ? ctx.userId : params.resp && UUID.test(params.resp) ? params.resp : "";
  const reviewFilter = REVIEW_STATUSES.includes(params.revisao as ReviewStatusEnum) ? (params.revisao as ReviewStatusEnum) : null;
  const q = params.q?.trim().slice(0, 120) ?? "";
  const from = startOfDayBrt(params.de);
  const to = endOfDayBrt(params.ate);
  const page = Math.max(1, Number.parseInt(params.pagina ?? "1", 10) || 1);

  const supabase = await createClient();
  // Busca por nome do arquivo, nome da parte ou CPF/CNPJ (RLS aplicada).
  const { data: docs, error } = await supabase.rpc("search_documents", {
    p_query: q || null,
    p_from: from,
    p_to: to,
    p_limit: PAGE_SIZE,
    p_offset: (page - 1) * PAGE_SIZE,
    p_client_id: clientFilter && clientFilter !== "sem" ? clientFilter : null,
    p_no_client: clientFilter === "sem",
    p_assignee_id: respFilter || null,
    p_review_status: reviewFilter,
  });
  const [{ data: clients }, { data: membersRaw }] = await Promise.all([
    supabase.from("clients").select("id, name").is("archived_at", null).order("name"),
    supabase.from("office_members").select("user_id, profiles(full_name)"),
  ]);
  const members = (membersRaw ?? []).map((m) => ({ id: m.user_id, name: m.profiles?.full_name ?? "—" }));
  if (error) throw error;
  const count = docs[0]?.total_count ?? 0;

  const filtered = Boolean(q || from || to || clientFilter || respFilter || reviewFilter);
  const totalPages = Math.max(1, Math.ceil((count ?? 0) / PAGE_SIZE));
  const pageHref = (p: number) => {
    const sp = new URLSearchParams();
    if (q) sp.set("q", q);
    if (params.de) sp.set("de", params.de);
    if (params.ate) sp.set("ate", params.ate);
    if (clientFilter) sp.set("cliente", clientFilter);
    if (params.resp) sp.set("resp", params.resp);
    if (reviewFilter) sp.set("revisao", reviewFilter);
    if (p > 1) sp.set("pagina", String(p));
    const s = sp.toString();
    return s ? `/documentos?${s}` : "/documentos";
  };

  return (
    <div className="max-w-6xl">
      <PageHeader title="Documentos" description="Contratos enviados pelo escritório, com dados extraídos e análise de riscos." />

      <div className="mt-8 space-y-8">
        <AutoRefresh active={docs.some((d) => isProcessing(d.status))} />
        {params.excluido ? <Alert tone="success">Documento excluído definitivamente.</Alert> : null}

        <Uploader />

        <section aria-label="Documentos enviados">
          <form className="flex flex-wrap items-end gap-3" role="search">
            <div className="min-w-56 flex-1 space-y-1.5">
              <label htmlFor="q" className="block text-sm font-medium">Buscar por arquivo, cliente, parte ou CPF/CNPJ</label>
              <input id="q" name="q" defaultValue={q} type="search"
                className="block h-10 w-full rounded border border-line-strong bg-surface px-3" />
            </div>
            <div className="space-y-1.5">
              <label htmlFor="de" className="block text-sm font-medium">Enviado de</label>
              <input id="de" name="de" type="date" defaultValue={params.de}
                className="block h-10 rounded border border-line-strong bg-surface px-3" />
            </div>
            <div className="space-y-1.5">
              <label htmlFor="ate" className="block text-sm font-medium">até</label>
              <input id="ate" name="ate" type="date" defaultValue={params.ate}
                className="block h-10 rounded border border-line-strong bg-surface px-3" />
            </div>
            <div className="space-y-1.5">
              <label htmlFor="cliente" className="block text-sm font-medium">Cliente</label>
              <select id="cliente" name="cliente" defaultValue={clientFilter} className="block h-10 rounded border border-line-strong bg-surface px-2">
                <option value="">Todos</option>
                <option value="sem">Sem cliente</option>
                {(clients ?? []).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div className="space-y-1.5">
              <label htmlFor="resp" className="block text-sm font-medium">Responsável</label>
              <select id="resp" name="resp" defaultValue={params.resp ?? ""} className="block h-10 rounded border border-line-strong bg-surface px-2">
                <option value="">Todos</option>
                <option value="eu">Meus documentos</option>
                {members.filter((m) => m.id !== ctx.userId).map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
              </select>
            </div>
            <div className="space-y-1.5">
              <label htmlFor="revisao" className="block text-sm font-medium">Revisão</label>
              <select id="revisao" name="revisao" defaultValue={reviewFilter ?? ""} className="block h-10 rounded border border-line-strong bg-surface px-2">
                <option value="">Todas</option>
                {REVIEW_STATUSES.map((r) => <option key={r} value={r}>{REVIEW_LABEL[r]}</option>)}
              </select>
            </div>
            <button type="submit"
              className="h-10 rounded border border-line-strong bg-surface px-4 text-sm font-medium hover:bg-paper">
              Buscar
            </button>
            {filtered ? (
              <Link href="/documentos" className="h-10 px-2 text-sm leading-10 text-muted underline underline-offset-4">
                Limpar filtros
              </Link>
            ) : null}
          </form>

          {docs.length ? (
            <div className="mt-4 overflow-x-auto rounded border border-line bg-surface">
              <table className="w-full min-w-[980px] text-left text-sm">
                <thead className="border-b border-line text-muted">
                  <tr>
                    <th scope="col" className="px-4 py-3 font-medium">Documento</th>
                    <th scope="col" className="px-4 py-3 font-medium">Cliente</th>
                    <th scope="col" className="px-4 py-3 font-medium">Situação</th>
                    <th scope="col" className="px-4 py-3 text-right font-medium">Riscos altos em aberto</th>
                    <th scope="col" className="px-4 py-3 font-medium">Responsável</th>
                    <th scope="col" className="px-4 py-3 font-medium">Enviado em</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {docs.map((d) => (
                    <tr key={d.id} className="hover:bg-paper/60">
                      <td className="max-w-80 px-4 py-3">
                        <Link href={`/documentos/${d.id}`} className="block truncate font-medium hover:underline">
                          {d.file_name}
                        </Link>
                        <p className="truncate text-muted" title={d.parties ?? undefined}>
                          {d.parties ?? `${d.file_type.toUpperCase()}, ${formatBytes(d.size_bytes)}`}
                        </p>
                      </td>
                      <td className="px-4 py-3">{d.client_name ?? <span className="text-muted">—</span>}</td>
                      <td className="space-y-1 px-4 py-3">
                        <StatusBadge status={d.status} />
                        {d.status === "ready" ? (
                          <span className={cn("block w-fit rounded px-2 py-0.5 text-xs font-medium", REVIEW_TONE[d.review_status])}>
                            {REVIEW_LABEL[d.review_status]}
                          </span>
                        ) : null}
                      </td>
                      <td className={cn("px-4 py-3 text-right tabular-nums", d.open_high_risks ? "font-medium text-danger" : "text-muted")}>
                        {d.status === "ready" ? d.open_high_risks : "—"}
                      </td>
                      <td className="px-4 py-3 text-muted">{d.assignee_name ?? "—"}</td>
                      <td className="px-4 py-3 tabular-nums text-muted">{dateTimeFmt.format(new Date(d.created_at))}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="mt-8 max-w-xl">
              <h2 className="font-serif text-xl font-semibold">
                {filtered ? "Nenhum documento encontrado" : "Nenhum documento ainda"}
              </h2>
              <p className="mt-2 text-muted">
                {filtered
                  ? "Ajuste o nome ou o período da busca."
                  : "Envie o primeiro contrato pela área acima. Ele fica visível apenas para o seu escritório."}
              </p>
            </div>
          )}

          {totalPages > 1 ? (
            <nav aria-label="Paginação" className="mt-4 flex items-center justify-between text-sm">
              <p className="text-muted">Página {page} de {totalPages}, {count} documentos</p>
              <div className="flex gap-2">
                {page > 1 ? (
                  <Link href={pageHref(page - 1)} className="rounded border border-line-strong bg-surface px-3 py-1.5 hover:bg-paper">
                    Anterior
                  </Link>
                ) : null}
                {page < totalPages ? (
                  <Link href={pageHref(page + 1)} className="rounded border border-line-strong bg-surface px-3 py-1.5 hover:bg-paper">
                    Próxima
                  </Link>
                ) : null}
              </div>
            </nav>
          ) : null}
        </section>
      </div>
    </div>
  );
}
