import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { formatBytes, isErrorCode, messageFor } from "@app/shared";
import { getSessionContext } from "@/lib/auth/context";
import { createClient } from "@/lib/supabase/server";
import { dateTimeFmt } from "@/lib/format/dates";
import { StatusBadge } from "@/components/documents/status-badge";
import { Alert } from "@/components/ui/alert";
import type { AccessActionEnum, DeadlineRow } from "@/types/database";
import { DeleteDocumentButton } from "./delete-button";
import { ReprocessButton } from "./reprocess-button";
import { parseExtraction, type RiskRow } from "./results";
import { AnalysisWorkspace } from "@/components/analysis/analysis-workspace";
import { PerspectiveSelector } from "@/components/analysis/perspective-selector";
import { OrganizationBar } from "@/components/documents/organization-bar";
import { VersionsBar } from "@/components/documents/versions-bar";
import { AutoRefresh } from "@/components/documents/auto-refresh";
import { isProcessing } from "@/components/documents/status";

const STEPS = [
  { status: "queued", label: "Na fila de processamento" },
  { status: "preprocessing", label: "Preparando o arquivo (conversão e leitura do texto; digitalizados passam por OCR)" },
  { status: "analyzing", label: "Analisando o contrato (dados, riscos e resumo); costuma levar de 1 a 3 minutos" },
] as const;

export const metadata: Metadata = { title: "Documento" };

const ACTION_LABEL: Record<AccessActionEnum, string> = {
  upload: "Enviou",
  view: "Visualizou",
  download: "Baixou",
  delete: "Excluiu",
  edit: "Editou",
  export: "Exportou",
  reprocess: "Reprocessou",
};

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export default async function DocumentPage({
  params, searchParams,
}: { params: Promise<{ id: string }>; searchParams: Promise<{ aba?: string }> }) {
  const { id } = await params;
  const { aba } = await searchParams;
  if (!UUID_RE.test(id)) notFound();

  const ctx = await getSessionContext();
  const supabase = await createClient();

  const { data: doc, error } = await supabase
    .from("documents")
    .select("id, file_name, file_type, size_bytes, page_count, status, error_code, created_at, uploaded_by, file_deleted_at, is_scanned, client_party_name, client_party_role, client_id, assignee_id, review_status, profiles(full_name)")
    .eq("id", id)
    .maybeSingle();
  if (error) throw error;
  if (!doc) notFound(); // inexistente ou de outro escritório: mesma resposta

  const [clientsRes, membersRes, versionsRes] = await Promise.all([
    supabase.from("clients").select("id, name").is("archived_at", null).order("name"),
    supabase.from("office_members").select("user_id, profiles(full_name)"),
    supabase.rpc("document_versions", { p_document_id: doc.id }),
  ]);
  const versions = versionsRes.data ?? [];
  const clients = clientsRes.data ?? [];
  const members = (membersRes.data ?? []).map((m) => ({ id: m.user_id, name: m.profiles?.full_name ?? "—" }))
    .sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));

  const logs = ctx.isAdmin
    ? await supabase
        .from("document_access_logs")
        .select("id, action, created_at, ip, profiles(full_name)")
        .eq("document_id", doc.id)
        .order("created_at", { ascending: false })
        .limit(50)
    : null;
  if (logs?.error) throw logs.error;

  const canDelete = ctx.isAdmin || doc.uploaded_by === ctx.userId;
  const hasFile = doc.status !== "uploading" && !doc.file_deleted_at;
  const processing = isProcessing(doc.status);
  const fileUrl = `/api/documentos/${doc.id}/arquivo`;

  let results: {
    extraction: ReturnType<typeof parseExtraction>; edited: boolean; risks: RiskRow[]; summary: string;
    extractionEdited: boolean; extractionKey: string; summaryEdited: boolean; summaryKey: string; missingRisks: string;
    deadlines: DeadlineRow[];
  } | null = null;
  if (doc.status === "ready") {
    const [ex, rk, sm, fb, dfb, dl] = await Promise.all([
      supabase.from("extractions").select("ai_data, edited_data, edited_at").eq("document_id", doc.id).maybeSingle(),
      supabase.from("risks")
        .select("id, level, title, clause_ref, excerpt, explanation, suggestion, affected_party, page_number, resolution, resolution_note, office_playbook_rules(title)")
        .eq("document_id", doc.id).order("position"),
      supabase.from("summaries").select("ai_content, edited_content, edited_at").eq("document_id", doc.id).maybeSingle(),
      supabase.from("risk_feedback").select("risk_id, verdict").eq("document_id", doc.id).eq("user_id", ctx.userId),
      supabase.from("document_feedback").select("missing_risks").eq("document_id", doc.id).eq("user_id", ctx.userId).maybeSingle(),
      supabase.rpc("list_deadlines", { p_document_id: doc.id }),
    ]);
    const verdicts = new Map((fb.data ?? []).map((f) => [f.risk_id, f.verdict]));
    if (ex.error || rk.error || sm.error) throw ex.error ?? rk.error ?? sm.error;
    results = {
      extraction: parseExtraction(ex.data?.edited_data ?? ex.data?.ai_data),
      edited: Boolean(ex.data?.edited_data || sm.data?.edited_content),
      risks: rk.data.map(({ office_playbook_rules: rule, ...r }) => ({
        ...r, feedback: verdicts.get(r.id) ?? null, playbook_rule_title: rule?.title ?? null,
      })),
      missingRisks: dfb.data?.missing_risks ?? "",
      deadlines: dl.data ?? [],
      summary: sm.data?.edited_content ?? sm.data?.ai_content ?? "",
      extractionEdited: Boolean(ex.data?.edited_data),
      extractionKey: ex.data?.edited_at ?? "ai",
      summaryEdited: Boolean(sm.data?.edited_content),
      summaryKey: sm.data?.edited_at ?? "ai",
    };
  }
  return (
    <>
      <Link href="/documentos" className="text-sm text-muted underline underline-offset-4 hover:text-ink">
        Voltar para documentos
      </Link>

      <header className="mt-4 flex flex-wrap items-start justify-between gap-4 border-b border-line pb-6">
        <div className="min-w-0">
          <h1 className="break-words font-serif text-[28px] font-semibold leading-tight">{doc.file_name}</h1>
          <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-muted">
            <StatusBadge status={doc.status} />
            <span>{doc.file_type.toUpperCase()}, {formatBytes(doc.size_bytes)}</span>
            {doc.page_count ? <span>{doc.page_count} páginas</span> : null}
            {doc.client_party_name ? (
              <span className="rounded bg-accent-soft px-2 py-0.5 text-xs font-medium text-accent-strong">
                Cliente: {doc.client_party_name}{doc.client_party_role ? ` (${doc.client_party_role})` : ""}
              </span>
            ) : null}
            <span>
              Enviado por {doc.profiles?.full_name ?? "usuário removido"} em {dateTimeFmt.format(new Date(doc.created_at))}
            </span>
          </div>
        </div>
        <div className="flex flex-wrap items-start gap-2">
          {hasFile ? (
            <a href={`${fileUrl}?baixar=1`}
              className="inline-flex h-10 items-center rounded border border-line-strong bg-surface px-4 text-sm font-medium hover:bg-paper">
              Baixar original
            </a>
          ) : null}
          {doc.status === "ready" ? (
            <Link href={`/documentos/${doc.id}/minuta`}
              className="inline-flex h-10 items-center rounded bg-accent px-4 text-sm font-medium text-white hover:bg-accent-strong">
              Gerar minuta
            </Link>
          ) : null}
          {canDelete && hasFile && (doc.status === "ready" || doc.status === "failed") ? (
            <ReprocessButton documentId={doc.id} hasEdits={results?.edited ?? false} />
          ) : null}
          {canDelete ? <DeleteDocumentButton documentId={doc.id} fileName={doc.file_name} /> : null}
        </div>
      </header>

      <div className="mt-8 space-y-10">
        <AutoRefresh active={processing} />

        {doc.status === "ready" || versions.length > 1 ? (
          <VersionsBar currentId={doc.id} versions={versions} canUploadNew={doc.status === "ready"} />
        ) : null}

        {doc.status !== "uploading" ? (
          <OrganizationBar documentId={doc.id} clients={clients} members={members}
            clientId={doc.client_id} assigneeId={doc.assignee_id} reviewStatus={doc.review_status} />
        ) : null}

        {doc.status === "failed" ? (
          <Alert tone="error">
            <p className="font-medium">Este arquivo não pôde ser processado.</p>
            <p className="mt-1">
              {isErrorCode(doc.error_code) ? messageFor(doc.error_code) : messageFor("UNEXPECTED")}
            </p>
            <p className="mt-2">
              {hasFile
                ? "O arquivo continua guardado. Use “Reprocessar” para tentar de novo."
                : "O arquivo foi descartado. Corrija o problema e envie novamente pela lista de documentos."}
            </p>
          </Alert>
        ) : null}

        {doc.status === "uploading" ? (
          <Alert tone="warning">
            O envio deste arquivo não foi concluído. Exclua este registro e envie o arquivo novamente.
          </Alert>
        ) : null}

        {processing ? (
          <section aria-live="polite" className="rounded border border-line bg-surface p-5">
            <h2 className="font-serif text-xl font-semibold">Processando</h2>
            <ol className="mt-4 space-y-3">
              {STEPS.map((step, i) => {
                const current = STEPS.findIndex((s) => s.status === doc.status);
                const state = i < current ? "done" : i === current ? "current" : "todo";
                return (
                  <li key={step.status} className="flex items-start gap-3">
                    <span className={
                      state === "done" ? "mt-1.5 size-2.5 shrink-0 rounded-full bg-accent"
                        : state === "current" ? "mt-1.5 size-2.5 shrink-0 animate-pulse rounded-full bg-accent"
                        : "mt-1.5 size-2.5 shrink-0 rounded-full bg-line-strong"
                    } />
                    <span className={state === "todo" ? "text-muted" : state === "current" ? "font-medium" : ""}>
                      {step.label}
                    </span>
                  </li>
                );
              })}
            </ol>
            <p className="mt-4 text-sm text-muted">Esta página se atualiza sozinha. Você pode sair e voltar depois.</p>
          </section>
        ) : null}

        {results ? (
          <PerspectiveSelector
            documentId={doc.id}
            parties={results.extraction.partes.filter((p) => p.nome.trim()).map((p) => ({ name: p.nome.trim(), role: p.papel.trim() }))}
            current={doc.client_party_name ? { name: doc.client_party_name, role: doc.client_party_role } : null}
          />
        ) : null}

        {results ? (
          <AnalysisWorkspace
            documentId={doc.id}
            fileUrl={fileUrl}
            risks={results.risks}
            extraction={results.extraction}
            extractionEdited={results.extractionEdited}
            extractionKey={results.extractionKey}
            summary={results.summary}
            summaryEdited={results.summaryEdited}
            summaryKey={results.summaryKey}
            missingRisks={results.missingRisks}
            deadlines={results.deadlines}
            initialTab={aba === "prazos" ? "prazos" : undefined}
          />
        ) : null}

        {hasFile && doc.file_type === "pdf" && doc.status !== "ready" ? (
          <section aria-label="Visualização do documento">
            <h2 className="mb-4 font-serif text-xl font-semibold">Documento</h2>
            <iframe
              src={fileUrl}
              title={`Visualização de ${doc.file_name}`}
              className="h-[75vh] w-full rounded border border-line bg-surface"
            />
          </section>
        ) : null}

        {hasFile && doc.file_type === "docx" && doc.status !== "ready" ? (
          <p className="text-muted">
            A visualização do DOCX fica disponível ao fim do processamento, quando ele é convertido para PDF.
            Enquanto isso, use “Baixar original”.
          </p>
        ) : null}

        {logs ? (
          <section>
            <h2 className="font-serif text-xl font-semibold">Registro de acesso</h2>
            <p className="mt-1 text-sm text-muted">Visível apenas para titular e administradores. Últimos 50 acessos.</p>
            {logs.data.length ? (
              <div className="mt-4 overflow-x-auto rounded border border-line bg-surface">
                <table className="w-full min-w-[520px] text-left text-sm">
                  <thead className="border-b border-line text-muted">
                    <tr>
                      <th scope="col" className="px-4 py-3 font-medium">Quando</th>
                      <th scope="col" className="px-4 py-3 font-medium">Quem</th>
                      <th scope="col" className="px-4 py-3 font-medium">Ação</th>
                      <th scope="col" className="px-4 py-3 font-medium">IP</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line">
                    {logs.data.map((log) => (
                      <tr key={log.id}>
                        <td className="px-4 py-2.5 tabular-nums">{dateTimeFmt.format(new Date(log.created_at))}</td>
                        <td className="px-4 py-2.5">{log.profiles?.full_name ?? "Usuário removido"}</td>
                        <td className="px-4 py-2.5">{ACTION_LABEL[log.action]}</td>
                        <td className="px-4 py-2.5 tabular-nums text-muted">{log.ip ?? "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="mt-4 text-muted">Nenhum acesso registrado.</p>
            )}
          </section>
        ) : null}
      </div>
    </>
  );
}
