"use client";

import { useActionState } from "react";
import { deleteDocument } from "@/server/actions/documents";
import { SubmitButton } from "@/components/ui/button";
import type { FormState } from "@/lib/errors";

export function DeleteDocumentButton({ documentId, fileName }: { documentId: string; fileName: string }) {
  const [state, action] = useActionState<FormState, FormData>(deleteDocument, {});
  return (
    <form
      action={action}
      onSubmit={(e) => {
        const ok = window.confirm(
          `Excluir definitivamente “${fileName}”?\n\nO arquivo e todos os dados extraídos serão apagados. Esta ação não pode ser desfeita.`,
        );
        if (!ok) e.preventDefault();
      }}
      className="flex flex-col items-end gap-1"
    >
      <input type="hidden" name="documentId" value={documentId} />
      <input type="hidden" name="redirectTo" value="list" />
      <SubmitButton variant="danger" pendingLabel="Excluindo…">Excluir definitivamente</SubmitButton>
      {state.ok === false && state.message ? <p className="max-w-64 text-right text-xs text-danger">{state.message}</p> : null}
    </form>
  );
}
