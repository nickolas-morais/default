"use client";

import { useActionState } from "react";
import { reprocessDocument } from "@/server/actions/documents";
import { SubmitButton } from "@/components/ui/button";
import type { FormState } from "@/lib/errors";

export function ReprocessButton({ documentId, hasEdits }: { documentId: string; hasEdits: boolean }) {
  const [state, action] = useActionState<FormState, FormData>(reprocessDocument, {});
  return (
    <form
      action={action}
      onSubmit={(e) => {
        const text = hasEdits
          ? "Reprocessar este documento? As edições nos dados e no resumo, as avaliações e as situações dos riscos (aceito, em negociação, resolvido) serão descartadas. Não consome a cota do plano."
          : "Reprocessar este documento? Não consome a cota do plano.";
        if (!window.confirm(text)) e.preventDefault();
      }}
      className="flex flex-col items-end gap-1"
    >
      <input type="hidden" name="documentId" value={documentId} />
      <SubmitButton variant="secondary" pendingLabel="Enviando…">Reprocessar</SubmitButton>
      {state.ok === false && state.message ? <p className="max-w-64 text-right text-xs text-danger">{state.message}</p> : null}
    </form>
  );
}
