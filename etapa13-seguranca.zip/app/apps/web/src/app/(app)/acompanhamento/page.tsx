import type { Metadata } from "next";
import Link from "next/link";
import { requireAdmin } from "@/lib/auth/context";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shell/page-header";
import { cn } from "@/components/ui/cn";

export const metadata: Metadata = { title: "Acompanhamento" };

/** Carga de trabalho da equipe (titular e administradores). */
export default async function TeamPage() {
  await requireAdmin();
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("team_overview");
  if (error) throw error;

  const rows = data.filter((r) => r.assignee_id || r.pending + r.in_review + r.sent + r.processing > 0);
  const total = (k: keyof (typeof data)[number]) => data.reduce((s, r) => s + (Number(r[k]) || 0), 0);
  const link = (assignee: string | null, revisao?: string) => {
    const sp = new URLSearchParams();
    if (assignee) sp.set("resp", assignee);
    if (revisao) sp.set("revisao", revisao);
    return `/documentos?${sp}`;
  };
  const cell = (n: number, href: string, alert = false) =>
    n ? <Link href={href} className={cn("hover:underline", alert && "font-medium text-danger")}>{n}</Link> : <span className="text-muted">—</span>;

  return (
    <div className="max-w-6xl">
      <PageHeader title="Acompanhamento" description="Documentos por responsável e status de revisão, riscos altos em aberto e prazos. Visível para titular e administradores." />

      <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { label: "Pendentes de revisão", v: total("pending") },
          { label: "Em revisão", v: total("in_review") },
          { label: "Riscos altos em aberto", v: total("open_high_risks"), alert: true },
          { label: "Prazos vencidos", v: total("overdue_deadlines"), alert: true },
        ].map((k) => (
          <div key={k.label} className="rounded border border-line bg-surface p-4">
            <p className="text-xs text-muted">{k.label}</p>
            <p className={cn("mt-1 text-2xl font-semibold tabular-nums", k.alert && k.v > 0 && "text-danger")}>{k.v}</p>
          </div>
        ))}
      </div>

      <div className="mt-6 overflow-x-auto rounded border border-line bg-surface">
        <table className="w-full min-w-[900px] text-left text-sm">
          <thead className="border-b border-line text-muted">
            <tr>
              {["Responsável", "Pendentes", "Em revisão", "Enviados", "Aprovados", "Processando", "Riscos altos em aberto", "Prazos vencidos", "Prazos em 7 dias"]
                .map((h, i) => <th key={h} className={cn("px-4 py-3 font-medium", i > 0 && "text-right")}>{h}</th>)}
            </tr>
          </thead>
          <tbody className="divide-y divide-line tabular-nums">
            {rows.map((r) => (
              <tr key={r.assignee_id ?? "none"}>
                <td className="px-4 py-3 font-medium">{r.assignee_name ?? <span className="text-warning">Sem responsável</span>}</td>
                <td className="px-4 py-3 text-right">{cell(r.pending, link(r.assignee_id, "pendente"))}</td>
                <td className="px-4 py-3 text-right">{cell(r.in_review, link(r.assignee_id, "em_revisao"))}</td>
                <td className="px-4 py-3 text-right">{cell(r.sent, link(r.assignee_id, "enviado"))}</td>
                <td className="px-4 py-3 text-right">{cell(r.approved, link(r.assignee_id, "aprovado"))}</td>
                <td className="px-4 py-3 text-right">{r.processing || <span className="text-muted">—</span>}</td>
                <td className="px-4 py-3 text-right">{cell(r.open_high_risks, link(r.assignee_id), true)}</td>
                <td className="px-4 py-3 text-right">{cell(r.overdue_deadlines, "/prazos", true)}</td>
                <td className="px-4 py-3 text-right">{cell(r.deadlines_7d, "/prazos?periodo=30")}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-xs text-muted">
        Riscos altos em aberto contam só documentos ainda não aprovados. Os números levam à lista de documentos já filtrada.
        Documentos “Sem responsável” podem ser atribuídos na página de cada documento.
      </p>
    </div>
  );
}
