import type { Metadata } from "next";
import Link from "next/link";
import { STANDARD_LOOPS, STANDARD_VARIABLES, type VariableGroup } from "@app/shared/template-vars";
import { PageHeader } from "@/components/shell/page-header";

export const metadata: Metadata = { title: "Variáveis de modelos" };

const GROUPS: { id: VariableGroup; title: string; intro: string }[] = [
  {
    id: "partes",
    title: "Partes",
    intro:
      "Preenchidas pela parte cujo papel no contrato contém a palavra indicada. Se houver mais de uma (por exemplo, dois fiadores), os nomes vêm unidos por “e”.",
  },
  { id: "contrato", title: "Dados do contrato", intro: "Vêm dos dados extraídos, já com as correções feitas pelo advogado." },
  { id: "gerais", title: "Gerais", intro: "Não dependem do contrato." },
];

const code = "rounded bg-paper px-1.5 py-0.5 font-mono text-[13px] whitespace-nowrap";

export default function TemplateHelpPage() {
  return (
    <div className="max-w-5xl">
      <Link href="/modelos" className="text-sm text-muted underline underline-offset-4 hover:text-ink">
        Voltar para modelos
      </Link>
      <div className="mt-4">
        <PageHeader
          title="Variáveis reconhecidas automaticamente"
          description="Escreva as variáveis no seu modelo em Word entre chaves duplas. As da lista abaixo são preenchidas com os dados extraídos do contrato; qualquer outra vira um campo para preencher na hora de gerar a minuta."
        />
      </div>

      <section className="mt-8 max-w-[70ch] space-y-3 leading-7">
        <h2 className="font-serif text-xl font-semibold">Como escrever</h2>
        <p>
          Digite a variável direto no texto do Word, por exemplo: “A <span className={code}>{"{{locatario}}"}</span>,
          inscrita no CNPJ <span className={code}>{"{{locatario_documento}}"}</span>, fica notificada…”. A formatação
          aplicada à variável (negrito, fonte, tamanho) é mantida no texto preenchido.
        </p>
        <p>
          Maiúsculas, acentos e espaços não importam: <span className={code}>{"{{Locatária}}"}</span>,{" "}
          <span className={code}>{"{{LOCATARIO}}"}</span> e <span className={code}>{"{{locatario}}"}</span> são a mesma
          variável. Variáveis também funcionam no cabeçalho e no rodapé.
        </p>
        <p>
          Campo sem valor no contrato sai como <span className={code}>__________</span>, para ser notado na revisão.
          Você pode conferir e corrigir cada valor antes de gerar.
        </p>
      </section>

      {GROUPS.map((g) => (
        <section key={g.id} className="mt-10">
          <h2 className="font-serif text-xl font-semibold">{g.title}</h2>
          <p className="mt-1 max-w-[70ch] text-sm text-muted">{g.intro}</p>
          <div className="mt-4 overflow-x-auto rounded border border-line bg-surface">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead className="border-b border-line text-muted">
                <tr>
                  <th scope="col" className="px-4 py-3 font-medium">Variável</th>
                  <th scope="col" className="px-4 py-3 font-medium">O que traz</th>
                  <th scope="col" className="px-4 py-3 font-medium">Exemplo</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {STANDARD_VARIABLES.filter((v) => v.group === g.id).map((v) => (
                  <tr key={v.key} className="align-top">
                    <td className="px-4 py-3">
                      <span className={code}>{`{{${v.key}}}`}</span>
                      {v.aliases?.length ? (
                        <p className="mt-1.5 text-xs text-muted">Também: {v.aliases.map((a) => `{{${a}}}`).join(", ")}</p>
                      ) : null}
                    </td>
                    <td className="px-4 py-3">{v.description}</td>
                    <td className="px-4 py-3 text-muted">{v.example}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {g.id === "partes" ? (
            <p className="mt-3 text-sm text-muted">
              Formas no feminino e sinônimos também são reconhecidos: locadora, locatária, inquilino(a), fiadora,
              vendedora, compradora e contratado. Para o CPF/CNPJ, use o sufixo _documento, _cpf ou _cnpj.
            </p>
          ) : null}
        </section>
      ))}

      <section className="mt-10 max-w-[70ch]">
        <h2 className="font-serif text-xl font-semibold">Listas que se repetem</h2>
        <p className="mt-2 leading-7">
          Para repetir um trecho para cada parte ou multa, coloque a abertura e o fechamento em parágrafos próprios. O
          parágrafo do meio é repetido uma vez por item:
        </p>
        <pre className="mt-3 overflow-x-auto rounded border border-line bg-surface p-4 font-mono text-[13px] leading-6">
{`{{#lista_partes}}
{{nome}}, {{papel}}, CPF/CNPJ {{documento}};
{{/lista_partes}}`}
        </pre>
        <div className="mt-4 space-y-3">
          {STANDARD_LOOPS.map((l) => (
            <div key={l.key}>
              <p className="font-medium">
                <span className={code}>{`{{#${l.key}}}`}</span> {l.label}
              </p>
              <p className="mt-1 text-sm text-muted">
                Campos: {l.fields.map((f) => `{{${f.key}}} (${f.description.toLowerCase()})`).join(", ")}.
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-10 max-w-[70ch] pb-8">
        <h2 className="font-serif text-xl font-semibold">Se o modelo for recusado</h2>
        <p className="mt-2 leading-7">
          A mensagem indica o trecho com problema. Os casos mais comuns são chave faltando
          (<span className={code}>{"{{locatario}"}</span>), lista aberta sem fechamento
          (<span className={code}>{"{{#lista_partes}}"}</span> sem <span className={code}>{"{{/lista_partes}}"}</span>)
          e arquivo salvo em .doc ou protegido por senha. Corrija no Word, salve como .docx e envie de novo.
        </p>
      </section>
    </div>
  );
}
