import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { mapVariables } from "@app/shared/template-vars";
import { getSessionContext } from "@/lib/auth/context";
import { createClient } from "@/lib/supabase/server";
import { dateFmt } from "@/lib/format/dates";
import { fromStoredVariables } from "@/lib/templates/server";
import { MappingView } from "@/components/templates/mapping-view";
import { DeleteTemplateButton } from "./delete-template-button";

export const metadata: Metadata = { title: "Modelo" };

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export default async function TemplatePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!UUID_RE.test(id)) notFound();
  const ctx = await getSessionContext();
  const supabase = await createClient();

  const { data: tpl, error } = await supabase
    .from("templates")
    .select("id, name, description, variables, created_at, profiles(full_name)")
    .eq("id", id)
    .maybeSingle();
  if (error) throw error;
  if (!tpl) notFound();

  const mapping = mapVariables(fromStoredVariables(tpl.variables));

  return (
    <div className="max-w-5xl">
      <Link href="/modelos" className="text-sm text-muted underline underline-offset-4 hover:text-ink">
        Voltar para modelos
      </Link>
      <header className="mt-4 flex flex-wrap items-start justify-between gap-4 border-b border-line pb-6">
        <div>
          <h1 className="font-serif text-[28px] font-semibold leading-tight">{tpl.name}</h1>
          {tpl.description ? <p className="mt-2 text-muted">{tpl.description}</p> : null}
          <p className="mt-2 text-sm text-muted">
            Enviado por {tpl.profiles?.full_name ?? "usuário removido"} em {dateFmt.format(new Date(tpl.created_at))}
          </p>
        </div>
        <div className="flex flex-wrap items-start gap-2">
          <a
            href={`/api/modelos/${tpl.id}/arquivo`}
            className="inline-flex h-10 items-center rounded border border-line-strong bg-surface px-4 text-sm font-medium hover:bg-paper"
          >
            Baixar modelo
          </a>
          {ctx.isAdmin ? <DeleteTemplateButton templateId={tpl.id} name={tpl.name} /> : null}
        </div>
      </header>

      <section className="mt-8">
        <h2 className="font-serif text-xl font-semibold">Variáveis do modelo</h2>
        <div className="mt-4 rounded border border-line bg-surface p-5">
          <MappingView mapping={mapping} />
        </div>
        <p className="mt-4 max-w-[65ch] text-sm text-muted">
          Para gerar uma minuta, abra um documento analisado e clique em “Gerar minuta”. Para alterar o modelo, edite o
          arquivo no Word, exclua este modelo e envie a nova versão.
        </p>
      </section>
    </div>
  );
}
