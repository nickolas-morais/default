"use client";

import { useActionState } from "react";
import { deleteTemplate } from "@/server/actions/templates";
import { SubmitButton } from "@/components/ui/button";
import type { FormState } from "@/lib/errors";

export function DeleteTemplateButton({ templateId, name }: { templateId: string; name: string }) {
  const [state, action] = useActionState<FormState, FormData>(deleteTemplate, {});
  return (
    <form
      action={action}
      onSubmit={(e) => {
        if (!window.confirm(`Excluir o modelo “${name}”? As minutas já geradas não são afetadas.`)) e.preventDefault();
      }}
      className="flex flex-col items-end gap-1"
    >
      <input type="hidden" name="templateId" value={templateId} />
      <SubmitButton variant="danger" pendingLabel="Excluindo…">Excluir modelo</SubmitButton>
      {state.ok === false && state.message ? <p className="text-xs text-danger">{state.message}</p> : null}
    </form>
  );
}
