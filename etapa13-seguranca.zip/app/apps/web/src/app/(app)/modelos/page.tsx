import type { Metadata } from "next";
import Link from "next/link";
import { getSessionContext } from "@/lib/auth/context";
import { createClient } from "@/lib/supabase/server";
import { dateFmt } from "@/lib/format/dates";
import { PageHeader } from "@/components/shell/page-header";
import { UploadTemplate } from "@/components/templates/upload-template";

export const metadata: Metadata = { title: "Modelos" };

export default async function TemplatesPage() {
  const ctx = await getSessionContext();
  const supabase = await createClient();
  const { data: templates, error } = await supabase
    .from("templates")
    .select("id, name, description, variables, created_at")
    .order("name");
  if (error) throw error;

  return (
    <div className="max-w-5xl">
      <PageHeader
        title="Modelos de minuta"
        description="Modelos do escritório em Word, com variáveis preenchidas a partir dos dados extraídos de cada contrato."
        actions={
          <Link href="/modelos/ajuda" className="text-sm font-medium text-accent underline underline-offset-4">
            Variáveis disponíveis
          </Link>
        }
      />

      {ctx.isAdmin ? (
        <section className="mt-8">
          <h2 className="font-serif text-xl font-semibold">Novo modelo</h2>
          <div className="mt-4"><UploadTemplate /></div>
        </section>
      ) : null}

      <section className="mt-10">
        <h2 className="font-serif text-xl font-semibold">Modelos do escritório</h2>
        {templates.length ? (
          <ul className="mt-4 divide-y divide-line rounded border border-line bg-surface">
            {templates.map((t) => (
              <li key={t.id} className="flex flex-wrap items-baseline justify-between gap-2 px-5 py-4">
                <div className="min-w-0">
                  <Link href={`/modelos/${t.id}`} className="font-medium hover:underline">{t.name}</Link>
                  {t.description ? <p className="text-sm text-muted">{t.description}</p> : null}
                </div>
                <p className="text-sm tabular-nums text-muted">
                  {t.variables.length} variáveis, enviado em {dateFmt.format(new Date(t.created_at))}
                </p>
              </li>
            ))}
          </ul>
        ) : (
          <p className="mt-4 max-w-[65ch] text-muted">
            {ctx.isAdmin
              ? "Envie o primeiro modelo acima. Depois, gere minutas a partir da página de qualquer documento analisado."
              : "Nenhum modelo cadastrado. Peça ao titular ou a um administrador para enviar os modelos do escritório."}
          </p>
        )}
      </section>
    </div>
  );
}
