import type { Metadata } from "next";
import { getSessionContext } from "@/lib/auth/context";
import { createClient } from "@/lib/supabase/server";
import { getPlanPrices, getStripe, type PlanPrice } from "@/lib/billing/stripe";
import { PageHeader } from "@/components/shell/page-header";
import { UsageMeter } from "@/components/billing/usage-meter";
import { Alert } from "@/components/ui/alert";
import { cn } from "@/components/ui/cn";
import { PortalButton, SubscribeButton } from "./plan-buttons";

export const metadata: Metadata = { title: "Plano" };

const money = (cents: number, currency: string) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: currency.toUpperCase() }).format(cents / 100);

export default async function PlanPage({ searchParams }: { searchParams: Promise<{ assinatura?: string }> }) {
  const { assinatura } = await searchParams;
  const ctx = await getSessionContext();
  const supabase = await createClient();
  const [{ data: plans, error }, { data: entRows }] = await Promise.all([
    supabase.from("plans").select("id, name, monthly_doc_limit, stripe_lookup_key, description, playbook").order("sort_order"),
    supabase.rpc("current_entitlement"),
  ]);
  if (error) throw error;
  const ent = entRows?.[0];

  const configured = Boolean(getStripe());
  let prices = new Map<string, PlanPrice>();
  let pricesFailed = false;
  if (configured) {
    try {
      prices = await getPlanPrices(plans.map((p) => p.stripe_lookup_key));
    } catch {
      pricesFailed = true;
    }
  }
  const subscribed = ent?.source === "subscription";
  const contract = ent?.source === "contract";

  return (
    <div className="max-w-5xl">
      <PageHeader title="Plano" description="Cada plano libera um número de documentos analisados por período de cobrança." />

      <div className="mt-8 space-y-8">
        {assinatura === "ok" ? (
          <Alert tone="success">
            Pagamento recebido. A assinatura aparece aqui em alguns segundos, assim que o Stripe confirmar.
          </Alert>
        ) : null}
        {!configured ? <Alert tone="warning">Os pagamentos ainda não foram configurados neste ambiente (STRIPE_SECRET_KEY).</Alert> : null}
        {pricesFailed ? <Alert tone="error">Não foi possível carregar os preços do Stripe agora. Tente de novo em instantes.</Alert> : null}

        {ent ? (
          <section>
            <h2 className="font-serif text-xl font-semibold">Situação atual</h2>
            <div className="mt-4 max-w-xl"><UsageMeter ent={ent} /></div>
            {subscribed && ctx.isAdmin ? <div className="mt-4"><PortalButton /></div> : null}
            {contract ? (
              <p className="mt-4 max-w-[65ch] text-sm text-muted">
                O escritório tem um contrato personalizado, cobrado fora do cartão. Para alterar o plano, o limite ou a
                vigência, fale com o suporte.
              </p>
            ) : null}
          </section>
        ) : null}

        <section>
          <h2 className="font-serif text-xl font-semibold">Planos</h2>
          <p className="mt-1 text-sm text-muted">
            Conta cada documento uma única vez, quando a primeira análise termina. Reprocessar e envios com erro não
            consomem. Troque ou cancele quando quiser.
          </p>
          <div className="mt-4 grid gap-4 md:grid-cols-3">
            {plans.map((p) => {
              const price = prices.get(p.stripe_lookup_key);
              const current = subscribed && ent?.plan_id === p.id;
              return (
                <div key={p.id} className={cn("flex flex-col rounded border bg-surface p-5", current ? "border-accent" : "border-line")}>
                  <p className="font-serif text-lg font-semibold">{p.name}</p>
                  <p className="mt-1 text-sm text-muted">{p.description}</p>
                  <p className="mt-4 text-2xl font-semibold tabular-nums">
                    {price?.amount != null ? money(price.amount, price.currency) : "—"}
                    <span className="text-sm font-normal text-muted"> /mês</span>
                  </p>
                  <p className="mt-1 text-sm">{p.monthly_doc_limit} documentos por mês</p>
                  <p className="mt-1 text-sm text-muted">3 novas versões grátis por contrato</p>
                  {p.playbook ? <p className="mt-1 text-sm font-medium text-accent-strong">Inclui o Playbook do escritório</p> : null}
                  <div className="mt-5 flex-1" />
                  {current ? (
                    <p className="text-sm font-medium text-accent-strong">Plano atual</p>
                  ) : ctx.isAdmin && !contract ? (
                    configured && price ? (
                      <SubscribeButton planId={p.id} label={subscribed ? "Mudar para este plano" : "Assinar"}
                        variant={subscribed ? "secondary" : "primary"} />
                    ) : (
                      <p className="text-sm text-muted">Indisponível no momento</p>
                    )
                  ) : null}
                </div>
              );
            })}
          </div>
          {!ctx.isAdmin ? (
            <p className="mt-4 text-sm text-muted">Somente o titular e os administradores podem assinar ou mudar de plano.</p>
          ) : null}
          <p className="mt-4 text-xs text-muted">
            Pagamento processado pelo Stripe. O app não recebe nem guarda dados de cartão.
          </p>
        </section>
      </div>
    </div>
  );
}
