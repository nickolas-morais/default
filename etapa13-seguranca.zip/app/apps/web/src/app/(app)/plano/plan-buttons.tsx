"use client";

import { useActionState } from "react";
import { openBillingPortal, startCheckout } from "@/server/actions/billing";
import { SubmitButton } from "@/components/ui/button";
import type { FormState } from "@/lib/errors";

export function SubscribeButton({ planId, label, variant = "primary" }: {
  planId: string; label: string; variant?: "primary" | "secondary";
}) {
  const [state, action] = useActionState<FormState, FormData>(startCheckout, {});
  return (
    <form action={action} className="space-y-2">
      <input type="hidden" name="planId" value={planId} />
      <SubmitButton variant={variant} className="w-full" pendingLabel="Abrindo o pagamento…">{label}</SubmitButton>
      {state.message ? <p className="text-sm text-danger">{state.message}</p> : null}
    </form>
  );
}

export function PortalButton() {
  const [state, action] = useActionState<FormState>(openBillingPortal, {});
  return (
    <form action={action} className="space-y-2">
      <SubmitButton variant="secondary" pendingLabel="Abrindo…">Gerenciar assinatura e pagamento</SubmitButton>
      {state.message ? <p className="text-sm text-danger">{state.message}</p> : null}
    </form>
  );
}
