import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { formatCnpj, formatCpf } from "@app/shared";
import { getSessionContext } from "@/lib/auth/context";
import { createClient } from "@/lib/supabase/server";
import { dateFmt } from "@/lib/format/dates";
import { Uploader } from "@/components/documents/uploader";
import { StatusBadge } from "@/components/documents/status-badge";
import { AutoRefresh } from "@/components/documents/auto-refresh";
import { isProcessing } from "@/components/documents/status";
import { REVIEW_LABEL, REVIEW_TONE } from "@/components/documents/review";
import { ClientForm } from "@/components/clients/client-form";
import { cn } from "@/components/ui/cn";
import { ArchiveClientButton } from "./archive-button";

export const metadata: Metadata = { title: "Cliente" };

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const docFmt = (n: string | null) => (!n ? "" : n.length === 11 ? formatCpf(n) : n.length === 14 ? formatCnpj(n) : n);
const day = new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeZone: "UTC" });

export default async function ClientPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!UUID_RE.test(id)) notFound();
  await getSessionContext();
  const supabase = await createClient();

  const [{ data: client }, { data: stats }, { data: docs, error }] = await Promise.all([
    supabase.from("clients").select("id, name, document_number, email, notes, archived_at").eq("id", id).maybeSingle(),
    supabase.rpc("list_clients", { p_include_archived: true }),
    supabase.rpc("search_documents", { p_client_id: id, p_limit: 100 }),
  ]);
  if (error) throw error;
  if (!client) notFound();
  const s = stats?.find((x) => x.id === id);

  const today = new Date();
  const { data: allDeadlines } = await supabase.rpc("list_deadlines", {
    p_from: today.toISOString().slice(0, 10),
    p_to: new Date(today.getTime() + 90 * 86_400_000).toISOString().slice(0, 10),
  });
  const docIds = new Set(docs.map((d) => d.id));
  const deadlines = (allDeadlines ?? []).filter((d) => docIds.has(d.document_id)).slice(0, 10);

  const kpis = [
    { label: "Documentos", value: s?.documents ?? 0 },
    { label: "Pendentes", value: s?.pending ?? 0 },
    { label: "Em revisão", value: s?.in_review ?? 0 },
    { label: "Enviados ao cliente", value: s?.sent ?? 0 },
    { label: "Riscos altos em aberto", value: s?.open_high_risks ?? 0, alert: true },
  ];

  return (
    <div className="max-w-6xl">
      <Link href="/clientes" className="text-sm text-muted underline underline-offset-4 hover:text-ink">Voltar para clientes</Link>
      <header className="mt-4 flex flex-wrap items-start justify-between gap-4 border-b border-line pb-6">
        <div>
          <h1 className="font-serif text-[28px] font-semibold leading-tight">{client.name}</h1>
          <p className="mt-2 text-sm text-muted">
            {[docFmt(client.document_number), client.email].filter(Boolean).join(", ") || "Sem CPF/CNPJ ou e-mail cadastrados"}
            {client.archived_at ? ` — arquivado em ${dateFmt.format(new Date(client.archived_at))}` : ""}
          </p>
        </div>
        <ArchiveClientButton id={client.id} archived={Boolean(client.archived_at)} />
      </header>

      <AutoRefresh active={docs.some((d) => isProcessing(d.status))} />

      <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-5">
        {kpis.map((k) => (
          <div key={k.label} className="rounded border border-line bg-surface p-4">
            <p className="text-xs text-muted">{k.label}</p>
            <p className={cn("mt-1 text-2xl font-semibold tabular-nums", k.alert && k.value > 0 && "text-danger")}>{k.value}</p>
          </div>
        ))}
      </div>

      {!client.archived_at ? <div className="mt-8"><Uploader clientId={client.id} clientName={client.name} /></div> : null}

      <div className="mt-8 grid gap-8 lg:grid-cols-[minmax(0,1fr)_340px]">
        <section>
          <h2 className="font-serif text-xl font-semibold">Documentos</h2>
          {docs.length ? (
            <ul className="mt-3 divide-y divide-line rounded border border-line bg-surface">
              {docs.map((d) => (
                <li key={d.id} className="flex flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3 text-sm">
                  <Link href={`/documentos/${d.id}`} className="min-w-0 flex-1 truncate font-medium hover:underline">{d.file_name}</Link>
                  <StatusBadge status={d.status} />
                  {d.status === "ready" ? (
                    <span className={cn("rounded px-2 py-0.5 text-xs font-medium", REVIEW_TONE[d.review_status])}>{REVIEW_LABEL[d.review_status]}</span>
                  ) : null}
                  {d.open_high_risks > 0 ? <span className="text-xs font-medium text-danger">{d.open_high_risks} alto(s) em aberto</span> : null}
                  <span className="text-muted">{d.assignee_name ?? "Sem responsável"}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-3 text-muted">Nenhum documento vinculado. Envie acima ou vincule pela página de um documento.</p>
          )}
        </section>

        <aside className="space-y-6">
          <section className="rounded border border-line bg-surface p-5">
            <h2 className="font-serif text-lg font-semibold">Próximos prazos (90 dias)</h2>
            {deadlines.length ? (
              <ul className="mt-3 space-y-2 text-sm">
                {deadlines.map((d) => (
                  <li key={d.id}>
                    <span className="tabular-nums text-muted">{day.format(new Date(`${d.due_date}T00:00:00Z`))}</span>{" "}
                    <Link href={`/documentos/${d.document_id}?aba=prazos`} className="font-medium hover:underline">{d.title}</Link>
                  </li>
                ))}
              </ul>
            ) : <p className="mt-2 text-sm text-muted">Nenhum prazo nos próximos 90 dias.</p>}
          </section>
          <details className="rounded border border-line bg-surface p-5">
            <summary className="cursor-pointer font-serif text-lg font-semibold">Dados do cliente</summary>
            <div className="mt-4"><ClientForm client={client} /></div>
          </details>
        </aside>
      </div>
    </div>
  );
}
