import type { Metadata } from "next";
import Link from "next/link";
import { formatCnpj, formatCpf } from "@app/shared";
import { getSessionContext } from "@/lib/auth/context";
import { createClient } from "@/lib/supabase/server";
import { dateFmt } from "@/lib/format/dates";
import { PageHeader } from "@/components/shell/page-header";
import { ClientForm } from "@/components/clients/client-form";
import { cn } from "@/components/ui/cn";

export const metadata: Metadata = { title: "Clientes" };

const docFmt = (n: string | null) => (!n ? "" : n.length === 11 ? formatCpf(n) : n.length === 14 ? formatCnpj(n) : n);

export default async function ClientsPage({ searchParams }: { searchParams: Promise<{ q?: string; arquivados?: string }> }) {
  await getSessionContext();
  const { q = "", arquivados } = await searchParams;
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("list_clients", { p_query: q || null, p_include_archived: arquivados === "1" });
  if (error) throw error;

  return (
    <div className="max-w-6xl">
      <PageHeader title="Clientes" description="Clientes do escritório e a situação dos contratos de cada um." />

      <div className="mt-8 grid gap-8 lg:grid-cols-[minmax(0,1fr)_360px]">
        <section>
          <form className="flex flex-wrap items-end gap-3" role="search">
            <div className="min-w-56 flex-1 space-y-1.5">
              <label htmlFor="q" className="block text-sm font-medium">Buscar por nome ou CPF/CNPJ</label>
              <input id="q" name="q" type="search" defaultValue={q} className="block h-10 w-full rounded border border-line-strong bg-surface px-3" />
            </div>
            <label className="flex h-10 items-center gap-2 text-sm">
              <input type="checkbox" name="arquivados" value="1" defaultChecked={arquivados === "1"} className="size-4 accent-accent" />
              Incluir arquivados
            </label>
            <button className="h-10 rounded border border-line-strong bg-surface px-4 text-sm font-medium hover:bg-paper">Buscar</button>
          </form>

          {data.length ? (
            <div className="mt-4 overflow-x-auto rounded border border-line bg-surface">
              <table className="w-full min-w-[720px] text-left text-sm">
                <thead className="border-b border-line text-muted">
                  <tr>
                    <th className="px-4 py-3 font-medium">Cliente</th>
                    <th className="px-4 py-3 text-right font-medium">Documentos</th>
                    <th className="px-4 py-3 text-right font-medium">Em revisão</th>
                    <th className="px-4 py-3 text-right font-medium">Enviados</th>
                    <th className="px-4 py-3 text-right font-medium">Riscos altos em aberto</th>
                    <th className="px-4 py-3 font-medium">Último envio</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line tabular-nums">
                  {data.map((c) => (
                    <tr key={c.id} className={cn("hover:bg-paper/60", c.archived_at && "text-muted")}>
                      <td className="px-4 py-3">
                        <Link href={`/clientes/${c.id}`} className="font-medium hover:underline">{c.name}</Link>
                        {c.archived_at ? <span className="ml-2 rounded bg-paper px-1.5 text-xs">Arquivado</span> : null}
                        {c.document_number ? <p className="text-muted">{docFmt(c.document_number)}</p> : null}
                      </td>
                      <td className="px-4 py-3 text-right">{c.documents}</td>
                      <td className="px-4 py-3 text-right">{c.in_review || "—"}</td>
                      <td className="px-4 py-3 text-right">{c.sent || "—"}</td>
                      <td className={cn("px-4 py-3 text-right", c.open_high_risks > 0 && "font-medium text-danger")}>{c.open_high_risks || "—"}</td>
                      <td className="px-4 py-3 text-muted">{c.last_document_at ? dateFmt.format(new Date(c.last_document_at)) : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="mt-6 text-muted">{q ? "Nenhum cliente encontrado." : "Nenhum cliente cadastrado ainda."}</p>
          )}
        </section>

        <aside className="h-fit rounded border border-line bg-surface p-5">
          <h2 className="font-serif text-lg font-semibold">Novo cliente</h2>
          <div className="mt-4"><ClientForm onSavedGoTo /></div>
        </aside>
      </div>
    </div>
  );
}
