"use client";

import { useActionState } from "react";
import { archiveClientForm } from "@/server/actions/documents";
import { SubmitButton } from "@/components/ui/button";
import type { FormState } from "@/lib/errors";

export function ArchiveClientButton({ id, archived }: { id: string; archived: boolean }) {
  const [state, action] = useActionState<FormState, FormData>(archiveClientForm, {});
  return (
    <form action={action} className="flex flex-col items-end gap-1"
      onSubmit={(e) => { if (!archived && !window.confirm("Arquivar este cliente? Os documentos continuam vinculados e acessíveis.")) e.preventDefault(); }}>
      <input type="hidden" name="id" value={id} />
      <input type="hidden" name="archived" value={archived ? "0" : "1"} />
      <SubmitButton variant="secondary" pendingLabel="Aguarde…">{archived ? "Reativar cliente" : "Arquivar cliente"}</SubmitButton>
      {state.ok === false && state.message ? <p className="text-xs text-danger">{state.message}</p> : null}
    </form>
  );
}
