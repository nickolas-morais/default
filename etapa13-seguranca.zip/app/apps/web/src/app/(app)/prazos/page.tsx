import type { Metadata } from "next";
import Link from "next/link";
import { getSessionContext } from "@/lib/auth/context";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shell/page-header";
import { cn } from "@/components/ui/cn";
import { DeadlineDoneButton } from "./deadline-done-button";
import { CalendarSubscription } from "./calendar-subscription";
import { env } from "@/lib/env";

export const metadata: Metadata = { title: "Prazos" };

const RANGES = [
  { id: "30", label: "Próximos 30 dias", days: 30 },
  { id: "90", label: "Próximos 90 dias", days: 90 },
  { id: "365", label: "Próximos 12 meses", days: 365 },
] as const;

const iso = (d: Date) => d.toISOString().slice(0, 10);
const month = new Intl.DateTimeFormat("pt-BR", { month: "long", year: "numeric", timeZone: "UTC" });
const day = new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "short", timeZone: "UTC" });

export default async function DeadlinesPage({ searchParams }: { searchParams: Promise<{ periodo?: string }> }) {
  const ctx = await getSessionContext();
  const { periodo = "90" } = await searchParams;
  const range = RANGES.find((r) => r.id === periodo) ?? RANGES[1];
  const today = new Date();
  const to = new Date(today.getTime() + range.days * 86_400_000);

  const supabase = await createClient();
  const [{ data: upcoming, error }, { data: overdue }, { data: feed }] = await Promise.all([
    supabase.rpc("list_deadlines", { p_from: iso(today), p_to: iso(to) }),
    supabase.rpc("list_deadlines", { p_from: iso(new Date(today.getTime() - 365 * 86_400_000)), p_to: iso(new Date(today.getTime() - 86_400_000)) }),
    supabase.from("calendar_feeds").select("created_at, last_accessed_at, include_details").eq("user_id", ctx.userId).maybeSingle(),
  ]);
  if (error) throw error;

  const groups = new Map<string, typeof upcoming>();
  for (const d of upcoming) {
    const key = d.due_date!.slice(0, 7);
    groups.set(key, [...(groups.get(key) ?? []), d]);
  }

  const Row = ({ d }: { d: (typeof upcoming)[number] }) => (
    <li className="flex flex-wrap items-baseline gap-x-4 gap-y-1 px-5 py-3">
      <span className={cn("w-16 shrink-0 tabular-nums", (d.days_left ?? 99) < 0 ? "font-medium text-danger" : (d.days_left ?? 99) <= 7 ? "font-medium text-warning" : "text-muted")}>
        {day.format(new Date(`${d.due_date}T00:00:00Z`))}
      </span>
      <span className="min-w-0 flex-1">
        <span className="font-medium">{d.title}</span>
        <Link href={`/documentos/${d.document_id}?aba=prazos`} className="block truncate text-sm text-muted hover:underline">{d.file_name}</Link>
      </span>
      <span className="text-sm tabular-nums text-muted">
        {d.days_left === 0 ? "hoje" : d.days_left! < 0 ? `venceu há ${-d.days_left!} dias` : `em ${d.days_left} dias`}
      </span>
      <DeadlineDoneButton id={d.id} recurring={d.recurrence !== "none"} />
    </li>
  );

  return (
    <div className="max-w-5xl">
      <PageHeader
        title="Prazos"
        description="Datas-chave dos contratos do escritório: fim de vigência, aviso de não renovação, reajustes e prazos cadastrados pela equipe."
        actions={
          <a href={`/api/prazos/ics?dias=${range.days}`}
            className="inline-flex h-10 items-center rounded border border-line-strong bg-surface px-4 text-sm font-medium hover:bg-paper">
            Baixar calendário (.ics)
          </a>
        }
      />

      {overdue?.length ? (
        <section className="mt-8">
          <h2 className="font-serif text-xl font-semibold text-danger">Vencidos e não concluídos ({overdue.length})</h2>
          <ul className="mt-3 divide-y divide-line rounded border border-danger/30 bg-surface">
            {overdue.map((d) => <Row key={d.id} d={d} />)}
          </ul>
        </section>
      ) : null}

      <div className="mt-8 flex flex-wrap gap-2">
        {RANGES.map((r) => (
          <Link key={r.id} href={`/prazos?periodo=${r.id}`}
            className={cn("rounded px-3 py-1 text-sm", r.id === range.id ? "bg-ink text-white" : "border border-line-strong bg-surface")}>
            {r.label}
          </Link>
        ))}
      </div>

      {upcoming.length ? (
        [...groups].map(([key, items]) => (
          <section key={key} className="mt-6">
            <h2 className="font-serif text-lg font-semibold capitalize">{month.format(new Date(`${key}-01T00:00:00Z`))}</h2>
            <ul className="mt-2 divide-y divide-line rounded border border-line bg-surface">
              {items!.map((d) => <Row key={d.id} d={d} />)}
            </ul>
          </section>
        ))
      ) : (
        <p className="mt-6 max-w-[65ch] text-muted">
          Nenhum prazo no período. Os prazos aparecem quando os contratos são analisados; também podem ser
          cadastrados na aba “Prazos” de cada documento.
        </p>
      )}
      <CalendarSubscription feed={feed} localOnly={/localhost|127\.0\.0\.1/.test(env.siteUrl)} />
    </div>
  );
}
