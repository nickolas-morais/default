"use client";

import { useActionState, useState } from "react";
import { createCalendarFeed, revokeCalendarFeed, type FeedState } from "@/server/actions/calendar";
import { FormMessage } from "@/components/ui/alert";
import { Button, SubmitButton } from "@/components/ui/button";

const fmt = (d: string) =>
  new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short", timeZone: "America/Sao_Paulo" }).format(new Date(d));

/**
 * Assinatura do calendário: endereço secreto por usuário, lido pelo Google
 * Agenda, Outlook ou Apple, que passam a mostrar e atualizar os prazos sozinhos.
 */
export function CalendarSubscription({ feed, localOnly }: {
  feed: { created_at: string; last_accessed_at: string | null; include_details: boolean } | null;
  localOnly: boolean;
}) {
  const [created, createAction] = useActionState<FeedState, FormData>(createCalendarFeed, {});
  const [revoked, revokeAction] = useActionState<FeedState>(revokeCalendarFeed, {});
  const [copied, setCopied] = useState(false);
  const url = created.url;
  const webcal = url?.replace(/^https?:/, "webcal:");
  const link = "inline-flex h-9 items-center rounded border border-line-strong bg-surface px-3 text-sm font-medium hover:bg-paper";

  return (
    <section className="mt-10 rounded border border-line bg-surface p-5">
      <h2 className="font-serif text-xl font-semibold">Assinar na sua agenda</h2>
      <p className="mt-1 max-w-[70ch] text-sm leading-6 text-muted">
        Um endereço secreto e pessoal que o Google Agenda, o Outlook ou o Apple Calendar consultam de tempos em tempos
        (em geral, a cada poucas horas): prazos novos, alterados ou concluídos aparecem sozinhos. Quem tiver o endereço
        vê os prazos do escritório; se ele vazar, gere outro ou revogue.
      </p>
      {localOnly ? (
        <p className="mt-2 text-sm text-warning">
          O app está em um endereço local ({"localhost"}): o Google e a Microsoft não conseguem acessá-lo. A assinatura
          funciona depois da publicação; até lá, use “Baixar calendário (.ics)” ou abra o endereço no navegador para conferir.
        </p>
      ) : null}

      {url ? (
        <div className="mt-4 space-y-3">
          <p className="text-sm font-medium text-accent-strong">Endereço criado. Copie agora: por segurança, ele não será mostrado de novo.</p>
          <div className="flex flex-wrap gap-2">
            <input readOnly value={url} aria-label="Endereço do calendário" onFocus={(e) => e.currentTarget.select()}
              className="h-9 min-w-0 flex-1 rounded border border-line-strong bg-surface px-2 font-mono text-xs" />
            <Button type="button" variant="secondary" className="h-9"
              onClick={() => navigator.clipboard.writeText(url).then(() => setCopied(true))}>
              {copied ? "Copiado" : "Copiar"}
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            <a className={link} target="_blank" rel="noreferrer"
              href={`https://calendar.google.com/calendar/r?cid=${encodeURIComponent(webcal!)}`}>Adicionar ao Google Agenda</a>
            <a className={link} target="_blank" rel="noreferrer"
              href={`https://outlook.office.com/calendar/0/addfromweb?url=${encodeURIComponent(url)}&name=Prazos`}>Outlook (Microsoft 365)</a>
            <a className={link} target="_blank" rel="noreferrer"
              href={`https://outlook.live.com/calendar/0/addfromweb?url=${encodeURIComponent(url)}&name=Prazos`}>Outlook.com</a>
            <a className={link} href={webcal}>Apple Calendar</a>
          </div>
          <p className="text-xs text-muted">No Google Agenda, também é possível colar o endereço em Outras agendas → “Do URL”.</p>
        </div>
      ) : feed ? (
        <p className="mt-4 text-sm">
          Endereço ativo desde {fmt(feed.created_at)}
          {feed.last_accessed_at ? `, última leitura pela agenda em ${fmt(feed.last_accessed_at)}` : ", ainda não lido por nenhuma agenda"}.
          {feed.include_details ? " Inclui nomes dos documentos." : " Mostra só o tipo de cada prazo."}
        </p>
      ) : null}

      <form action={createAction} className="mt-4 space-y-3"
        onSubmit={(e) => { if (feed && !window.confirm("Gerar um novo endereço? O atual deixa de funcionar nas agendas que o usam.")) e.preventDefault(); }}>
        <label className="flex items-start gap-3 text-sm leading-5">
          <input type="checkbox" name="includeDetails" defaultChecked={feed?.include_details ?? false} className="mt-0.5 size-4 shrink-0 accent-accent" />
          <span>
            Incluir o nome do documento e a cláusula nos eventos.
            <span className="block text-xs text-muted">
              Desmarcado, cada evento mostra só o tipo do prazo (ex.: “Aviso de não renovação”), porque o conteúdo fica
              armazenado nos servidores da sua agenda. Os detalhes continuam no app, pelo link do evento.
            </span>
          </span>
        </label>
        <div className="flex flex-wrap gap-2">
          <SubmitButton variant={feed ? "secondary" : "primary"} pendingLabel="Gerando…">
            {feed ? "Gerar novo endereço" : "Gerar endereço da agenda"}
          </SubmitButton>
        </div>
        <FormMessage state={created.ok ? {} : created} />
      </form>

      {feed && !url ? (
        <form action={revokeAction} className="mt-3"
          onSubmit={(e) => { if (!window.confirm("Revogar o endereço? As agendas que o usam deixam de receber os prazos.")) e.preventDefault(); }}>
          <SubmitButton variant="danger" className="h-9 px-3" pendingLabel="Revogando…">Revogar endereço</SubmitButton>
          <FormMessage state={revoked} />
        </form>
      ) : null}
    </section>
  );
}
