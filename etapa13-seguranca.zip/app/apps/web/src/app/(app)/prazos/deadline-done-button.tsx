"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { completeDeadline } from "@/server/actions/documents";

export function DeadlineDoneButton({ id, recurring }: { id: string; recurring: boolean }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  return (
    <button type="button" disabled={pending}
      onClick={() => start(async () => { await completeDeadline(id, true); router.refresh(); })}
      className="text-sm font-medium text-accent underline underline-offset-4 disabled:opacity-60">
      {pending ? "…" : recurring ? "Concluir ocorrência" : "Concluir"}
    </button>
  );
}
