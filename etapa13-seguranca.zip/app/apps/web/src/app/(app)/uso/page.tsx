import type { Metadata } from "next";
import { getSessionContext } from "@/lib/auth/context";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shell/page-header";
import { UsageMeter } from "@/components/billing/usage-meter";

export const metadata: Metadata = { title: "Uso" };

const monthFmt = new Intl.DateTimeFormat("pt-BR", { month: "long", year: "numeric", timeZone: "UTC" });

function currentPeriodStart(): string {
  // Mês corrente no fuso de Brasília (UTC−3), no mesmo critério do banco.
  const now = new Date(Date.now() - 3 * 60 * 60 * 1000);
  return `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, "0")}-01`;
}

export default async function UsagePage() {
  const ctx = await getSessionContext();
  const supabase = await createClient();
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

  const [counters, failures, office, processing, ent] = await Promise.all([
    supabase.from("usage_counters").select("period_start, documents_processed")
      .order("period_start", { ascending: false }).limit(12),
    supabase.from("document_failures").select("id", { count: "exact", head: true }).gte("created_at", since),
    supabase.from("offices").select("daily_failure_limit").eq("id", ctx.office.id).single(),
    supabase.from("documents").select("id", { count: "exact", head: true })
      .in("status", ["queued", "preprocessing", "analyzing"]),
    supabase.rpc("current_entitlement"),
  ]);
  if (counters.error || failures.error || office.error || processing.error) {
    throw counters.error ?? failures.error ?? office.error ?? processing.error;
  }

  const period = currentPeriodStart();
  const thisMonth = counters.data.find((c) => c.period_start === period)?.documents_processed ?? 0;
  const history = counters.data.filter((c) => c.period_start !== period);
  const label = (d: string) => monthFmt.format(new Date(`${d}T00:00:00Z`));

  return (
    <div className="max-w-5xl">
      <PageHeader title="Uso" description="Documentos analisados pelo escritório, para acompanhar o consumo do plano." />

      <section className="mt-10 max-w-xl">
        <h2 className="font-serif text-xl font-semibold">Período do plano</h2>
        <div className="mt-4">{ent.data?.[0] ? <UsageMeter ent={ent.data[0]} showPlanLink /> : null}</div>
        <p className="mt-3 text-sm text-muted">
          {thisMonth} documentos analisados em {label(period)}. Reprocessamentos e envios com erro não entram na conta.
        </p>
      </section>

      <section className="mt-10 grid gap-6 sm:grid-cols-2">
        <div className="rounded border border-line bg-surface p-5">
          <p className="text-sm text-muted">Em processamento agora</p>
          <p className="mt-1 text-2xl font-semibold tabular-nums">{processing.count ?? 0}</p>
        </div>
        <div className="rounded border border-line bg-surface p-5">
          <p className="text-sm text-muted">Envios com erro nas últimas 24 horas</p>
          <p className="mt-1 text-2xl font-semibold tabular-nums">
            {failures.count ?? 0} <span className="text-base font-normal text-muted">de {office.data.daily_failure_limit} permitidos</span>
          </p>
        </div>
      </section>

      {history.length ? (
        <section className="mt-10">
          <h2 className="font-serif text-xl font-semibold">Meses anteriores</h2>
          <table className="mt-4 w-full max-w-md text-left text-sm">
            <tbody className="divide-y divide-line">
              {history.map((c) => (
                <tr key={c.period_start}>
                  <td className="py-2.5 capitalize">{label(c.period_start)}</td>
                  <td className="py-2.5 text-right tabular-nums">{c.documents_processed} documentos</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      ) : null}
    </div>
  );
}
