import type { Metadata } from "next";
import Link from "next/link";
import { getSessionContext } from "@/lib/auth/context";
import { createClient } from "@/lib/supabase/server";
import { Alert } from "@/components/ui/alert";
import { PlaybookEditor } from "./rule-forms";

export const metadata: Metadata = { title: "Playbook" };

export default async function PlaybookPage() {
  const ctx = await getSessionContext();
  const supabase = await createClient();
  const [{ data: rules, error }, { data: features }] = await Promise.all([
    supabase.from("office_playbook_rules").select("id, title, instruction, min_level, contract_types, active").order("position"),
    supabase.rpc("current_features"),
  ]);
  if (error) throw error;
  const enabled = Boolean(features?.playbook);

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h2 className="font-serif text-xl font-semibold">Playbook do escritório</h2>
        <p className="mt-1 leading-7 text-muted">
          Critérios próprios do escritório, aplicados em todas as análises novas: quando um contrato não atende a uma regra,
          a análise aponta o risco com o nível mínimo definido e a marca “Regra do escritório”. Até 30 regras.
          {ctx.isAdmin ? "" : " Somente titular e administradores editam as regras."}
        </p>
      </div>
      {!enabled ? (
        <Alert tone="warning">
          O Playbook faz parte dos planos Profissional e Escritório. As regras podem ser cadastradas, mas só entram nas
          análises depois da mudança de plano. <Link href="/plano" className="font-medium underline underline-offset-4">Ver planos</Link>
        </Alert>
      ) : null}
      <PlaybookEditor rules={rules} canEdit={ctx.isAdmin} />
      <p className="text-xs text-muted">
        As regras valem para análises feitas depois de salvas. Para aplicá-las a um documento já analisado, use “Reprocessar”.
      </p>
    </div>
  );
}
