"use client";

import { useActionState, useState } from "react";
import { inviteMember, removeMember, revokeInvitation, setMemberRole, transferOwnership, type InviteState } from "@/server/actions/office";
import { Field } from "@/components/ui/field";
import { Alert, FormMessage } from "@/components/ui/alert";
import { Button, SubmitButton } from "@/components/ui/button";
import type { FormState } from "@/lib/errors";

export function InviteForm({ canInviteAdmin }: { canInviteAdmin: boolean }) {
  const [state, action] = useActionState<InviteState, FormData>(inviteMember, {});
  const [copied, setCopied] = useState(false);

  async function copy(link: string) {
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className="mt-6 space-y-5">
      {state.ok && state.link ? (
        <Alert tone="success">
          <p>Convite criado para {state.email}. Copie o link e envie para a pessoa convidada.</p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <input
              readOnly
              value={state.link}
              aria-label="Link do convite"
              onFocus={(e) => e.currentTarget.select()}
              className="h-9 min-w-0 flex-1 rounded border border-accent/30 bg-surface px-2 font-mono text-xs text-ink"
            />
            <Button type="button" variant="secondary" className="h-9" onClick={() => copy(state.link!)}>
              {copied ? "Link copiado" : "Copiar link"}
            </Button>
          </div>
        </Alert>
      ) : (
        <FormMessage state={state} />
      )}

      <form action={action} onSubmit={() => setCopied(false)} className="flex flex-wrap items-end gap-3" noValidate>
        <Field
          label="E-mail"
          name="email"
          type="email"
          required
          className="min-w-64 flex-1"
          defaultValue={state.ok ? "" : state.values?.email}
          error={state.fieldErrors?.email}
        />
        <div className="space-y-1.5">
          <label htmlFor="role" className="block text-sm font-medium">Papel</label>
          <select
            id="role"
            name="role"
            defaultValue={state.ok ? "member" : (state.values?.role ?? "member")}
            className="block h-10 rounded border border-line-strong bg-surface px-3 text-[15px]"
          >
            <option value="member">Membro</option>
            {canInviteAdmin ? <option value="admin">Administrador</option> : null}
          </select>
        </div>
        <SubmitButton pendingLabel="Gerando…">Gerar convite</SubmitButton>
      </form>
    </div>
  );
}

function ConfirmActionButton({
  action,
  hidden,
  confirmText,
  label,
}: {
  action: (prev: FormState, formData: FormData) => Promise<FormState>;
  hidden: Record<string, string>;
  confirmText: string;
  label: string;
}) {
  const [state, formAction] = useActionState<FormState, FormData>(action, {});
  return (
    <form
      action={formAction}
      onSubmit={(e) => {
        if (!window.confirm(confirmText)) e.preventDefault();
      }}
      className="inline-flex flex-col items-end gap-1"
    >
      {Object.entries(hidden).map(([k, v]) => (
        <input key={k} type="hidden" name={k} value={v} />
      ))}
      <SubmitButton variant="danger" className="h-8 px-3" pendingLabel="Aguarde…">{label}</SubmitButton>
      {state.ok === false && state.message ? <p className="text-xs text-danger">{state.message}</p> : null}
    </form>
  );
}

export function RemoveMemberButton({ userId, name }: { userId: string; name: string }) {
  return (
    <ConfirmActionButton
      action={removeMember}
      hidden={{ userId }}
      confirmText={`Remover ${name} do escritório? A pessoa perde o acesso imediatamente.`}
      label="Remover"
    />
  );
}

export function RevokeInvitationButton({ invitationId }: { invitationId: string }) {
  return (
    <ConfirmActionButton
      action={revokeInvitation}
      hidden={{ invitationId }}
      confirmText="Cancelar este convite? O link deixará de funcionar."
      label="Cancelar convite"
    />
  );
}

export function RoleControls({ userId, name, role }: { userId: string; name: string; role: "admin" | "member" }) {
  const [roleState, roleAction] = useActionState<FormState, FormData>(setMemberRole, {});
  const [ownState, ownAction] = useActionState<FormState, FormData>(transferOwnership, {});
  return (
    <div className="flex flex-wrap items-center justify-end gap-2">
      <form action={roleAction}>
        <input type="hidden" name="userId" value={userId} />
        <input type="hidden" name="role" value={role === "admin" ? "member" : "admin"} />
        <SubmitButton variant="ghost" className="h-8 px-3" pendingLabel="Aguarde…">
          {role === "admin" ? "Tornar membro" : "Tornar administrador"}
        </SubmitButton>
      </form>
      <form
        action={ownAction}
        onSubmit={(e) => {
          if (!window.confirm(`Transferir a titularidade para ${name}? Você passará a ser administrador e só ${name} poderá desfazer.`)) e.preventDefault();
        }}
      >
        <input type="hidden" name="userId" value={userId} />
        <SubmitButton variant="ghost" className="h-8 px-3" pendingLabel="Aguarde…">Tornar titular</SubmitButton>
      </form>
      {[roleState, ownState].map((s, i) =>
        s.ok === false && s.message ? <p key={i} className="w-full text-right text-xs text-danger">{s.message}</p> : null,
      )}
    </div>
  );
}
