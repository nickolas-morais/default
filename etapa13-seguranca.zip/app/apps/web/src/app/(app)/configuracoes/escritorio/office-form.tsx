"use client";

import { useActionState } from "react";
import { updateOffice } from "@/server/actions/office";
import { Field } from "@/components/ui/field";
import { FormMessage } from "@/components/ui/alert";
import { SubmitButton } from "@/components/ui/button";
import type { FormState } from "@/lib/errors";

type Values = { name: string; cnpj: string; address: string; phone: string; contactEmail: string; oabRegistration: string };

export function OfficeForm({ canEdit, initial }: { canEdit: boolean; initial: Values }) {
  const [state, action] = useActionState<FormState, FormData>(updateOffice, {});
  const v = (state.values as Values | undefined) ?? initial;
  const e = state.fieldErrors ?? {};
  const ro = !canEdit;
  return (
    <form action={action} className="mt-6 space-y-5" noValidate>
      <FormMessage state={state} />
      <Field label="Nome do escritório" name="name" required readOnly={ro} defaultValue={v.name} error={e.name} />
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="CNPJ (opcional)" name="cnpj" readOnly={ro} defaultValue={v.cnpj} placeholder="00.000.000/0000-00"
          hint="Aceita o formato numérico e o alfanumérico." error={e.cnpj} />
        <Field label="Registro na OAB (opcional)" name="oabRegistration" readOnly={ro} defaultValue={v.oabRegistration}
          placeholder="Ex.: OAB/SP 12.345" error={e.oabRegistration} />
      </div>
      <Field label="Endereço (opcional)" name="address" readOnly={ro} defaultValue={v.address} error={e.address} />
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Telefone (opcional)" name="phone" readOnly={ro} defaultValue={v.phone} error={e.phone} />
        <Field label="E-mail de contato (opcional)" name="contactEmail" type="email" readOnly={ro}
          defaultValue={v.contactEmail} error={e.contactEmail} />
      </div>
      <p className="text-sm text-muted">Estes dados podem ser usados nas minutas, como {"{{escritorio_endereco}}"}.</p>
      {canEdit ? <SubmitButton pendingLabel="Salvando…">Salvar alterações</SubmitButton> : null}
    </form>
  );
}
