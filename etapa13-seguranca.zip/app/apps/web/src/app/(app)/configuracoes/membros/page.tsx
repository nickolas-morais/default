import type { Metadata } from "next";
import { getSessionContext } from "@/lib/auth/context";
import { createClient } from "@/lib/supabase/server";
import type { OfficeRoleEnum } from "@/types/database";
import { InviteForm, RemoveMemberButton, RevokeInvitationButton, RoleControls } from "./member-actions";

export const metadata: Metadata = { title: "Membros" };

const ROLE_LABEL: Record<OfficeRoleEnum, string> = { owner: "Titular", admin: "Administrador", member: "Membro" };
const dateFmt = new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeZone: "America/Sao_Paulo" });

function canRemove(actor: OfficeRoleEnum, target: OfficeRoleEnum, isSelf: boolean) {
  if (isSelf || target === "owner") return false;
  return actor === "owner" || (actor === "admin" && target === "member");
}

export default async function MembersPage() {
  const ctx = await getSessionContext();
  const supabase = await createClient();

  const [members, invitations] = await Promise.all([
    supabase
      .from("office_members")
      .select("user_id, role, created_at, profiles(full_name, email)")
      .order("created_at", { ascending: true }),
    ctx.isAdmin
      ? supabase
          .from("office_invitations")
          .select("id, email, role, expires_at")
          .is("accepted_at", null)
          .is("revoked_at", null)
          .order("created_at", { ascending: false })
      : Promise.resolve({ data: [], error: null }),
  ]);
  if (members.error) throw members.error;
  if (invitations.error) throw invitations.error;

  return (
    <div className="space-y-12">
      <section>
        <h2 className="font-serif text-xl font-semibold">Membros do escritório</h2>
        <div className="mt-4 overflow-x-auto rounded border border-line bg-surface">
          <table className="w-full min-w-[720px] text-left text-sm">
            <thead className="border-b border-line text-muted">
              <tr>
                <th scope="col" className="px-4 py-3 font-medium">Nome</th>
                <th scope="col" className="px-4 py-3 font-medium">Papel</th>
                <th scope="col" className="px-4 py-3 font-medium">Desde</th>
                <th scope="col" className="px-4 py-3"><span className="sr-only">Ações</span></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {members.data.map((m) => (
                <tr key={m.user_id}>
                  <td className="px-4 py-3">
                    <p className="font-medium">
                      {m.profiles?.full_name}
                      {m.user_id === ctx.userId ? <span className="font-normal text-muted"> (você)</span> : null}
                    </p>
                    <p className="text-muted">{m.profiles?.email}</p>
                  </td>
                  <td className="px-4 py-3">{ROLE_LABEL[m.role]}</td>
                  <td className="px-4 py-3 tabular-nums text-muted">{dateFmt.format(new Date(m.created_at))}</td>
                  <td className="space-y-1 px-4 py-3 text-right">
                    {ctx.role === "owner" && m.role !== "owner" ? (
                      <RoleControls userId={m.user_id} name={m.profiles?.full_name ?? "este membro"} role={m.role} />
                    ) : null}
                    {canRemove(ctx.role, m.role, m.user_id === ctx.userId) ? (
                      <RemoveMemberButton userId={m.user_id} name={m.profiles?.full_name ?? "este membro"} />
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {ctx.isAdmin ? (
        <section className="max-w-2xl">
          <h2 className="font-serif text-xl font-semibold">Convidar pessoa</h2>
          <p className="mt-1 text-sm text-muted">
            Gere um link de convite e envie para o colega. O link vale por 7 dias e só funciona com o e-mail informado.
          </p>
          <InviteForm canInviteAdmin={ctx.role === "owner"} />

          {invitations.data.length ? (
            <>
              <h3 className="mt-10 text-base font-semibold">Convites pendentes</h3>
              <ul className="mt-3 divide-y divide-line rounded border border-line bg-surface text-sm">
                {invitations.data.map((inv) => (
                  <li key={inv.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-3">
                    <div>
                      <p className="font-medium">{inv.email}</p>
                      <p className="text-muted">
                        {ROLE_LABEL[inv.role]}, expira em {dateFmt.format(new Date(inv.expires_at))}
                      </p>
                    </div>
                    <RevokeInvitationButton invitationId={inv.id} />
                  </li>
                ))}
              </ul>
            </>
          ) : null}
        </section>
      ) : null}
    </div>
  );
}
