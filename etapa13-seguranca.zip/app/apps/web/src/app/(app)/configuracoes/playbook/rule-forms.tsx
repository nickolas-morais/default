"use client";

import { useActionState, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { deletePlaybookRule, savePlaybookRule, togglePlaybookRule } from "@/server/actions/playbook";
import { Field } from "@/components/ui/field";
import { FormMessage } from "@/components/ui/alert";
import { SubmitButton } from "@/components/ui/button";
import { cn } from "@/components/ui/cn";
import type { FormState } from "@/lib/errors";

type Rule = { id: string; title: string; instruction: string; min_level: string | null; contract_types: string; active: boolean };

const PRESETS = [
  { title: "Foro na nossa comarca", instruction: "O foro de eleição deve ser a Comarca de São Paulo/SP. Qualquer outro foro deve ser apontado.", min_level: "alto", contract_types: "" },
  { title: "Multa rescisória máxima", instruction: "Multa por rescisão antecipada acima de 3 meses de contraprestação ou sem proporcionalidade ao tempo restante deve ser apontada.", min_level: "alto", contract_types: "" },
  { title: "Reajuste pelo IPCA", instruction: "O índice de reajuste deve ser o IPCA/IBGE. IGP-M, outro índice ou índice a critério de uma das partes deve ser apontado.", min_level: "medio", contract_types: "locação, prestação de serviços" },
  { title: "Cláusula de LGPD", instruction: "Contratos com tratamento de dados pessoais devem ter cláusula de proteção de dados (LGPD) com papéis, finalidade e segurança. Ausência deve ser apontada.", min_level: "medio", contract_types: "" },
  { title: "Limitação de responsabilidade", instruction: "Deve haver limitação de responsabilidade do nosso cliente ao valor do contrato, excluídos dolo e culpa grave. Ausência deve ser apontada.", min_level: "medio", contract_types: "prestação de serviços, fornecimento" },
];

const LEVEL: Record<string, string> = { alto: "Alto", medio: "Médio", baixo: "Baixo" };
const select = "block h-10 w-full rounded border border-line-strong bg-surface px-2";

function RuleForm({ rule, onDone }: { rule?: Partial<Rule>; onDone?: () => void }) {
  const router = useRouter();
  const [state, action] = useActionState<FormState, FormData>(async (p, f) => {
    const r = await savePlaybookRule(p, f);
    if (r.ok) { onDone?.(); router.refresh(); }
    return r;
  }, {});
  const v = (state.values as Record<string, string> | undefined) ?? {
    title: rule?.title ?? "", instruction: rule?.instruction ?? "", minLevel: rule?.min_level ?? "", contractTypes: rule?.contract_types ?? "",
  };
  return (
    <form action={action} className="space-y-3" key={`${rule?.id ?? "new"}-${v.title}`}>
      {rule?.id ? <input type="hidden" name="id" value={rule.id} /> : null}
      {rule?.active === false ? <input type="hidden" name="active" value="off" /> : null}
      <FormMessage state={state} />
      <Field label="Título" name="title" required defaultValue={v.title} error={state.fieldErrors?.title} maxLength={120} />
      <div className="space-y-1.5">
        <label htmlFor={`instr-${rule?.id ?? "new"}`} className="block text-sm font-medium">Critério</label>
        <textarea id={`instr-${rule?.id ?? "new"}`} name="instruction" required rows={3} defaultValue={v.instruction} maxLength={600}
          className="block w-full rounded border border-line-strong bg-surface p-3 text-[15px]" />
        {state.fieldErrors?.instruction ? <p className="text-sm text-danger">{state.fieldErrors.instruction}</p>
          : <p className="text-sm text-muted">Escreva como orientaria um advogado da equipe: o que o contrato deve ter e o que apontar se não tiver.</p>}
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-1.5">
          <label htmlFor={`lvl-${rule?.id ?? "new"}`} className="block text-sm font-medium">Nível mínimo quando violada</label>
          <select id={`lvl-${rule?.id ?? "new"}`} name="minLevel" defaultValue={v.minLevel} className={select}>
            <option value="">A critério da análise</option><option value="alto">Alto</option><option value="medio">Médio</option><option value="baixo">Baixo</option>
          </select>
        </div>
        <Field label="Tipos de contrato (opcional)" name="contractTypes" defaultValue={v.contractTypes} maxLength={120}
          placeholder="Ex.: locação, prestação de serviços" hint="Vazio = vale para todos." />
      </div>
      <div className="flex gap-3">
        <SubmitButton pendingLabel="Salvando…">{rule?.id ? "Salvar regra" : "Adicionar regra"}</SubmitButton>
        {onDone ? <button type="button" onClick={onDone} className="text-sm text-muted underline underline-offset-4">Cancelar</button> : null}
      </div>
    </form>
  );
}

export function PlaybookEditor({ rules, canEdit }: { rules: Rule[]; canEdit: boolean }) {
  const router = useRouter();
  const [editing, setEditing] = useState<string | null>(null);
  const [preset, setPreset] = useState<Partial<Rule> | undefined>(undefined);
  const [pending, start] = useTransition();
  const act = (fn: () => Promise<unknown>) => start(async () => { await fn(); router.refresh(); });

  return (
    <div className="space-y-8">
      <ol className="space-y-3">
        {rules.map((r, i) => (
          <li key={r.id} className={cn("rounded border bg-surface p-4", r.active ? "border-line" : "border-dashed border-line-strong opacity-70")}>
            {editing === r.id ? <RuleForm rule={r} onDone={() => setEditing(null)} /> : (
              <>
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <p className="font-semibold"><span className="mr-2 font-mono text-xs text-muted">R{i + 1}</span>{r.title}</p>
                  <p className="text-xs text-muted">
                    {[r.min_level && `mínimo ${LEVEL[r.min_level]}`, r.contract_types || "todos os contratos", !r.active && "desativada"].filter(Boolean).join(", ")}
                  </p>
                </div>
                <p className="mt-1 leading-7">{r.instruction}</p>
                {canEdit ? (
                  <div className="mt-2 flex gap-4 text-sm">
                    <button type="button" onClick={() => setEditing(r.id)} className="text-accent underline underline-offset-4">Editar</button>
                    <button type="button" disabled={pending} onClick={() => act(() => togglePlaybookRule(r.id, !r.active, r))}
                      className="text-muted underline underline-offset-4">{r.active ? "Desativar" : "Ativar"}</button>
                    <button type="button" disabled={pending}
                      onClick={() => window.confirm(`Excluir a regra “${r.title}”?`) && act(() => deletePlaybookRule(r.id))}
                      className="text-muted underline underline-offset-4 hover:text-danger">Excluir</button>
                  </div>
                ) : null}
              </>
            )}
          </li>
        ))}
        {!rules.length ? <li className="text-muted">Nenhuma regra cadastrada.</li> : null}
      </ol>

      {canEdit ? (
        <section className="rounded border border-line bg-surface p-5">
          <h2 className="font-serif text-lg font-semibold">Nova regra</h2>
          <div className="mt-2 flex flex-wrap gap-2">
            <span className="text-sm text-muted">Começar de um exemplo:</span>
            {PRESETS.map((p) => (
              <button key={p.title} type="button" onClick={() => setPreset(p)}
                className="rounded border border-line-strong px-2 py-0.5 text-xs hover:bg-paper">{p.title}</button>
            ))}
          </div>
          <div className="mt-4"><RuleForm rule={preset} key={preset?.title ?? "blank"} /></div>
        </section>
      ) : null}
    </div>
  );
}
