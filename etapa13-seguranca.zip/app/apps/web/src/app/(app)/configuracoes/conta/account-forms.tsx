"use client";

import { useActionState } from "react";
import { changeEmail, changePassword, deleteAccount, signOutEverywhere, updateNotificationPrefs, updateProfile } from "@/server/actions/account";
import { Field } from "@/components/ui/field";
import { FormMessage } from "@/components/ui/alert";
import { Button, SubmitButton } from "@/components/ui/button";
import type { FormState } from "@/lib/errors";

const section = "rounded border border-line bg-surface p-5";

export function ProfileForm({ initial }: { initial: { fullName: string; phone: string; oabNumber: string } }) {
  const [state, action] = useActionState<FormState, FormData>(updateProfile, {});
  const v = state.values ?? initial;
  const e = state.fieldErrors ?? {};
  return (
    <form action={action} className={`${section} space-y-4`} noValidate>
      <h2 className="font-serif text-lg font-semibold">Dados pessoais</h2>
      <FormMessage state={state} />
      <Field label="Nome completo" name="fullName" required defaultValue={v.fullName} error={e.fullName} autoComplete="name" />
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Telefone" name="phone" defaultValue={v.phone} error={e.phone} autoComplete="tel" />
        <Field label="Número da OAB" name="oabNumber" defaultValue={v.oabNumber} error={e.oabNumber}
          placeholder="Ex.: SP 123.456" hint="Usado nas minutas como {{advogado_oab}}." />
      </div>
      <SubmitButton pendingLabel="Salvando…">Salvar dados</SubmitButton>
    </form>
  );
}

export function EmailForm({ email }: { email: string }) {
  const [state, action] = useActionState<FormState, FormData>(changeEmail, {});
  return (
    <form action={action} className={`${section} space-y-4`} noValidate>
      <h2 className="font-serif text-lg font-semibold">E-mail de acesso</h2>
      <p className="text-sm text-muted">Atual: <span className="font-medium text-ink">{email}</span></p>
      <FormMessage state={state} />
      <Field label="Novo e-mail" name="email" type="email" required autoComplete="email" error={state.fieldErrors?.email} />
      <SubmitButton pendingLabel="Enviando…">Alterar e-mail</SubmitButton>
    </form>
  );
}

export function PasswordForm() {
  const [state, action] = useActionState<FormState, FormData>(changePassword, {});
  const e = state.fieldErrors ?? {};
  return (
    <form action={action} className={`${section} space-y-4`} noValidate>
      <h2 className="font-serif text-lg font-semibold">Senha</h2>
      <FormMessage state={state} />
      <Field label="Senha atual" name="current" type="password" required autoComplete="current-password" error={e.current} />
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Nova senha" name="password" type="password" required autoComplete="new-password"
          hint="Pelo menos 8 caracteres, com maiúsculas, minúsculas e números." error={e.password} />
        <Field label="Repita a nova senha" name="confirm" type="password" required autoComplete="new-password" error={e.confirm} />
      </div>
      <SubmitButton pendingLabel="Alterando…">Alterar senha</SubmitButton>
    </form>
  );
}

export function SessionsSection() {
  return (
    <form action={signOutEverywhere} className={`${section} space-y-3`}
      onSubmit={(ev) => { if (!window.confirm("Sair de todos os dispositivos, inclusive deste?")) ev.preventDefault(); }}>
      <h2 className="font-serif text-lg font-semibold">Sessões</h2>
      <p className="text-sm text-muted">
        Encerra o acesso em todos os computadores e celulares onde você entrou. Use se perdeu um aparelho ou
        suspeita de acesso indevido.
      </p>
      <Button type="submit" variant="secondary">Sair de todos os dispositivos</Button>
    </form>
  );
}

export function DeleteAccountSection({ isOwner }: { isOwner: boolean }) {
  const [state, action] = useActionState<FormState, FormData>(deleteAccount, {});
  return (
    <form action={action} className="space-y-3 rounded border border-danger/30 bg-surface p-5"
      onSubmit={(ev) => { if (!window.confirm("Excluir sua conta definitivamente? Esta ação não pode ser desfeita.")) ev.preventDefault(); }}>
      <h2 className="font-serif text-lg font-semibold text-danger">Excluir minha conta</h2>
      <p className="text-sm leading-6 text-muted">
        {isOwner
          ? "Como titular, você precisa transferir a titularidade (em Membros) antes de excluir sua conta. Se for o único membro, exclua o escritório em Escritório."
          : "Sua conta e seus dados pessoais são apagados. Os documentos que você enviou continuam com o escritório."}
      </p>
      <FormMessage state={state} />
      {!isOwner ? (
        <>
          <Field label="Confirme com sua senha" name="password" type="password" required autoComplete="current-password" />
          <SubmitButton variant="danger" pendingLabel="Excluindo…">Excluir minha conta</SubmitButton>
        </>
      ) : null}
    </form>
  );
}

export function NotificationPrefsForm({ analysisDone, quota, deadlines, isAdmin }: {
  analysisDone: boolean; quota: boolean; deadlines: boolean; isAdmin: boolean;
}) {
  const [state, action] = useActionState<FormState, FormData>(updateNotificationPrefs, {});
  const box = "mt-0.5 size-4 shrink-0 accent-accent";
  return (
    <form action={action} className={`${section} space-y-4`}>
      <h2 className="font-serif text-lg font-semibold">Avisos por e-mail</h2>
      <FormMessage state={state} />
      <label className="flex items-start gap-3 text-sm leading-5">
        <input type="checkbox" name="analysisDone" defaultChecked={analysisDone} className={box} />
        <span>Quando a análise de um documento que enviei terminar</span>
      </label>
      <label className="flex items-start gap-3 text-sm leading-5">
        <input type="checkbox" name="deadlines" defaultChecked={deadlines} className={box} />
        <span>Lembretes de prazos (30, 7 e 1 dia antes e no dia){isAdmin ? "" : " dos documentos que enviei"}</span>
      </label>
      {isAdmin ? (
        <label className="flex items-start gap-3 text-sm leading-5">
          <input type="checkbox" name="quota" defaultChecked={quota} className={box} />
          <span>Quando o escritório usar 80% e 100% dos documentos do plano</span>
        </label>
      ) : null}
      <p className="text-xs text-muted">
        {isAdmin
          ? "Avisos de pagamento recusado e de contrato perto do vencimento são sempre enviados ao titular e aos administradores."
          : "Avisos de cota e cobrança vão para o titular e os administradores do escritório."}
      </p>
      <SubmitButton variant="secondary" pendingLabel="Salvando…">Salvar preferências</SubmitButton>
    </form>
  );
}
