import { PageHeader } from "@/components/shell/page-header";
import { NavLink } from "@/components/shell/nav-link";

export default function SettingsLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="max-w-5xl">
      <PageHeader title="Configurações" />
      <div className="mt-8 md:grid md:grid-cols-[180px_1fr] md:gap-10">
        <nav aria-label="Configurações" className="mb-8 flex gap-1 md:mb-0 md:flex-col">
          <NavLink href="/configuracoes/conta">Minha conta</NavLink>
          <NavLink href="/configuracoes/escritorio">Escritório</NavLink>
          <NavLink href="/configuracoes/membros">Membros</NavLink>
          <NavLink href="/configuracoes/playbook">Playbook</NavLink>
        </nav>
        <div className="min-w-0">{children}</div>
      </div>
    </div>
  );
}
