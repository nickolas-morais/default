import type { Metadata } from "next";
import { formatCnpj } from "@app/shared";
import { getSessionContext } from "@/lib/auth/context";
import { createClient } from "@/lib/supabase/server";
import { OfficeForm } from "./office-form";
import { DangerZone } from "./danger-zone";

export const metadata: Metadata = { title: "Escritório" };

export default async function OfficeSettingsPage() {
  const ctx = await getSessionContext();
  const supabase = await createClient();
  const { data: office, error } = await supabase
    .from("offices")
    .select("name, cnpj, address, phone, contact_email, oab_registration, deletion_scheduled_for")
    .eq("id", ctx.office.id)
    .single();
  if (error) throw error;

  return (
    <section className="max-w-2xl">
      <h2 className="font-serif text-xl font-semibold">Dados do escritório</h2>
      <p className="mt-1 text-sm text-muted">
        {ctx.isAdmin
          ? "Aparecem nas minutas e no cabeçalho do app."
          : "Somente o titular e os administradores podem alterar estes dados."}
      </p>
      <OfficeForm
        canEdit={ctx.isAdmin}
        initial={{
          name: office.name, cnpj: office.cnpj ? formatCnpj(office.cnpj) : "", address: office.address ?? "",
          phone: office.phone ?? "", contactEmail: office.contact_email ?? "", oabRegistration: office.oab_registration ?? "",
        }}
      />
      {ctx.role === "owner" ? <DangerZone officeName={office.name} scheduledFor={office.deletion_scheduled_for} /> : null}
    </section>
  );
}
