"use client";

import { useActionState } from "react";
import { cancelOfficeDeletion, requestOfficeDeletion } from "@/server/actions/office";
import { Field } from "@/components/ui/field";
import { FormMessage } from "@/components/ui/alert";
import { SubmitButton } from "@/components/ui/button";
import type { FormState } from "@/lib/errors";

export function DangerZone({ officeName, scheduledFor }: { officeName: string; scheduledFor: string | null }) {
  const [delState, delAction] = useActionState<FormState, FormData>(requestOfficeDeletion, {});
  const [cancelState, cancelAction] = useActionState<FormState>(cancelOfficeDeletion, {});

  return (
    <section className="mt-12 space-y-6 rounded border border-danger/30 bg-surface p-5">
      <h2 className="font-serif text-xl font-semibold text-danger">Zona de risco</h2>

      <div className="space-y-2">
        <h3 className="font-semibold">Exportar dados do escritório</h3>
        <p className="text-sm leading-6 text-muted">
          Arquivo JSON com membros, documentos, dados extraídos, riscos, resumos, modelos e registros de acesso. Os
          arquivos originais podem ser baixados na página de cada documento.
        </p>
        <a href="/api/escritorio/exportar"
          className="inline-flex h-10 items-center rounded border border-line-strong bg-surface px-4 text-sm font-medium hover:bg-paper">
          Exportar dados
        </a>
      </div>

      <div className="space-y-3 border-t border-line pt-6">
        <h3 className="font-semibold">Excluir o escritório</h3>
        {scheduledFor ? (
          <form action={cancelAction} className="space-y-3">
            <p className="text-sm leading-6 text-danger">
              Exclusão agendada para {new Intl.DateTimeFormat("pt-BR", { dateStyle: "long", timeStyle: "short", timeZone: "America/Sao_Paulo" }).format(new Date(scheduledFor))}.
              Até lá, é possível desistir.
            </p>
            <FormMessage state={cancelState} />
            <SubmitButton variant="secondary" pendingLabel="Cancelando…">Cancelar a exclusão</SubmitButton>
          </form>
        ) : (
          <form action={delAction} className="space-y-3" noValidate>
            <p className="text-sm leading-6 text-muted">
              Apaga definitivamente todos os documentos, análises, minutas registradas, modelos, membros e contas dos
              membros, 7 dias após a confirmação. Durante o prazo, novos envios ficam bloqueados e você pode desistir.
              Cancele antes a assinatura em Plano, se houver.
            </p>
            <FormMessage state={delState} />
            <Field label={`Para confirmar, digite o nome do escritório: ${officeName}`} name="confirm" required autoComplete="off" />
            <SubmitButton variant="danger" pendingLabel="Agendando…">Agendar exclusão do escritório</SubmitButton>
          </form>
        )}
      </div>
    </section>
  );
}
