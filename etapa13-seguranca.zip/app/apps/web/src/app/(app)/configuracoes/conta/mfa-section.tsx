"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { messageFor } from "@app/shared";
import { createClient } from "@/lib/supabase/browser";
import { Alert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";

type Enrolling = { factorId: string; qr: string; secret: string };

/** Ativar/desativar verificação em duas etapas (aplicativo autenticador, TOTP). */
export function MfaSection({ required }: { required: boolean }) {
  const router = useRouter();
  const [factorId, setFactorId] = useState<string | null | undefined>(undefined);
  const [enrolling, setEnrolling] = useState<Enrolling | null>(null);
  const [code, setCode] = useState("");
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, setPending] = useState(false);
  const supabase = createClient();

  async function load() {
    const { data } = await supabase.auth.mfa.listFactors();
    setFactorId(data?.totp?.[0]?.id ?? null);
  }
  useEffect(() => { void load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  async function start() {
    setMessage(null);
    // Remove tentativa anterior não concluída, se houver.
    const { data: all } = await supabase.auth.mfa.listFactors();
    for (const f of all?.all ?? []) if (f.status === "unverified") await supabase.auth.mfa.unenroll({ factorId: f.id });
    const { data, error } = await supabase.auth.mfa.enroll({ factorType: "totp", friendlyName: `App ${Date.now()}` });
    if (error || !data) return setMessage({ ok: false, text: messageFor("UNEXPECTED") });
    setEnrolling({ factorId: data.id, qr: data.totp.qr_code, secret: data.totp.secret });
  }

  async function confirm(e: React.FormEvent) {
    e.preventDefault();
    if (!enrolling) return;
    setPending(true);
    const { error } = await supabase.auth.mfa.challengeAndVerify({ factorId: enrolling.factorId, code: code.replace(/\s/g, "") });
    setPending(false);
    if (error) return setMessage({ ok: false, text: messageFor("MFA_INVALID_CODE") });
    setEnrolling(null);
    setCode("");
    setMessage({ ok: true, text: "Verificação em duas etapas ativada. Nos próximos acessos, o código será pedido após a senha." });
    await load();
    router.refresh();
  }

  async function disable() {
    if (!factorId || !window.confirm("Desativar a verificação em duas etapas?")) return;
    const { error } = await supabase.auth.mfa.unenroll({ factorId });
    if (error) return setMessage({ ok: false, text: "Para desativar, entre de novo concluindo a verificação em duas etapas." });
    setMessage({ ok: true, text: "Verificação em duas etapas desativada." });
    await load();
    router.refresh();
  }

  return (
    <section className="space-y-4 rounded border border-line bg-surface p-5">
      <h2 className="font-serif text-lg font-semibold">Verificação em duas etapas</h2>
      <p className="text-sm leading-6 text-muted">
        Além da senha, pede um código de um aplicativo autenticador (Google Authenticator, Microsoft Authenticator,
        1Password). Recomendado para quem lida com contratos de clientes.
        {required ? " Obrigatória para o painel da plataforma." : ""}
      </p>
      {message ? <Alert tone={message.ok ? "success" : "error"}>{message.text}</Alert> : null}

      {factorId === undefined ? null : factorId && !enrolling ? (
        <div className="flex flex-wrap items-center gap-3">
          <p className="text-sm font-medium text-accent-strong">Ativada</p>
          {!required ? <Button variant="secondary" onClick={disable}>Desativar</Button> : null}
        </div>
      ) : enrolling ? (
        <form onSubmit={confirm} className="space-y-4">
          <ol className="list-decimal space-y-2 pl-5 text-sm leading-6">
            <li>No aplicativo autenticador, adicione uma conta lendo o QR code abaixo.</li>
            <li>Digite o código de 6 dígitos que aparecer.</li>
          </ol>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={enrolling.qr} alt="QR code para o aplicativo autenticador" className="size-44 rounded border border-line bg-white p-2" />
          <p className="text-xs text-muted">
            Sem câmera? Digite a chave: <span className="select-all font-mono">{enrolling.secret}</span>
          </p>
          <div className="flex flex-wrap items-end gap-3">
            <div className="space-y-1.5">
              <label htmlFor="mfa-code" className="block text-sm font-medium">Código</label>
              <input id="mfa-code" value={code} onChange={(e) => setCode(e.target.value)} inputMode="numeric"
                autoComplete="one-time-code" maxLength={8}
                className="block h-10 w-40 rounded border border-line-strong bg-surface px-3 font-mono tracking-widest" />
            </div>
            <Button type="submit" disabled={pending || code.replace(/\s/g, "").length < 6}>
              {pending ? "Verificando…" : "Ativar"}
            </Button>
            <Button type="button" variant="ghost" onClick={() => setEnrolling(null)}>Cancelar</Button>
          </div>
        </form>
      ) : (
        <Button variant="secondary" onClick={start}>Ativar verificação em duas etapas</Button>
      )}
    </section>
  );
}
