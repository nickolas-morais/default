import type { Metadata } from "next";
import { getSessionContext } from "@/lib/auth/context";
import { createClient } from "@/lib/supabase/server";
import { MfaSection } from "./mfa-section";
import { NotificationPrefsForm, DeleteAccountSection, EmailForm, PasswordForm, ProfileForm, SessionsSection } from "./account-forms";

export const metadata: Metadata = { title: "Minha conta" };

export default async function AccountPage() {
  const ctx = await getSessionContext();
  const supabase = await createClient();
  const [{ data: profile, error }, { data: adminStatus }] = await Promise.all([
    supabase.from("profiles").select("full_name, phone, oab_number, notify_analysis_done, notify_quota, notify_deadlines").eq("id", ctx.userId).single(),
    supabase.rpc("platform_admin_status"),
  ]);
  if (error) throw error;

  return (
    <div className="max-w-2xl space-y-6">
      <ProfileForm initial={{ fullName: profile.full_name, phone: profile.phone ?? "", oabNumber: profile.oab_number ?? "" }} />
      <EmailForm email={ctx.email} />
      <PasswordForm />
      <NotificationPrefsForm analysisDone={profile.notify_analysis_done} quota={profile.notify_quota}
        deadlines={profile.notify_deadlines} isAdmin={ctx.isAdmin} />
      <MfaSection required={adminStatus !== "none" && adminStatus !== null} />
      <SessionsSection />
      <DeleteAccountSection isOwner={ctx.role === "owner"} />
    </div>
  );
}
