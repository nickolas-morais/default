import type { Metadata } from "next";
import { signOut } from "@/server/actions/auth";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = { title: "Sem acesso" };

export default function NoAccessPage() {
  return (
    <main className="mx-auto max-w-md px-6 py-24">
      <h1 className="font-serif text-2xl font-semibold">Sua conta não está vinculada a um escritório</h1>
      <p className="mt-3 leading-7">
        Isso acontece quando um administrador remove você do escritório. Para voltar a acessar, peça um
        novo convite e abra o link enquanto estiver com esta conta aberta.
      </p>
      <form action={signOut} className="mt-8">
        <Button type="submit" variant="secondary">Sair</Button>
      </form>
    </main>
  );
}
