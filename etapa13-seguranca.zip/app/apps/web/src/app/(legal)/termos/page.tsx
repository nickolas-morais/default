import type { Metadata } from "next";
import { LegalDocument } from "@/content/legal/legal-document";
import { TERMS_SECTIONS } from "@/content/legal/terms";
import { LEGAL_VERSIONS } from "@/content/legal/versions";

export const metadata: Metadata = { title: "Termos de uso" };

export default function TermsPage() {
  return <LegalDocument title="Termos de uso" version={LEGAL_VERSIONS.terms} sections={TERMS_SECTIONS} />;
}
