import type { Metadata } from "next";
import { LegalDocument } from "@/content/legal/legal-document";
import { PRIVACY_SECTIONS } from "@/content/legal/privacy";
import { LEGAL_VERSIONS } from "@/content/legal/versions";

export const metadata: Metadata = { title: "Política de privacidade" };

export default function PrivacyPage() {
  return (
    <LegalDocument title="Política de privacidade" version={LEGAL_VERSIONS.privacy} sections={PRIVACY_SECTIONS} />
  );
}
