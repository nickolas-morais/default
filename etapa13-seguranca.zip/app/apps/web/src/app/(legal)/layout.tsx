import Link from "next/link";

export default function LegalLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-dvh bg-surface">
      <header className="border-b border-line">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-6 py-4">
          <Link href="/" className="font-serif text-lg font-semibold">App</Link>
          <nav className="flex gap-6 text-sm">
            <Link href="/termos" className="text-muted hover:text-ink">Termos de uso</Link>
            <Link href="/privacidade" className="text-muted hover:text-ink">Privacidade</Link>
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-3xl px-6 py-12">{children}</main>
    </div>
  );
}
