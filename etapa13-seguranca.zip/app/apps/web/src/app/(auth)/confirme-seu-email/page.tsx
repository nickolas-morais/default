import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = { title: "Confirme seu e-mail" };

export default async function ConfirmEmailPage({ searchParams }: { searchParams: Promise<{ convite?: string }> }) {
  const { convite } = await searchParams;
  return (
    <>
      <h1 className="font-serif text-2xl font-semibold">Confirme seu e-mail</h1>
      <p className="mt-3 leading-7">
        Enviamos um link de confirmação para o e-mail informado. Abra a mensagem e clique em
        <strong className="font-semibold"> Confirmar e-mail</strong> para acessar o escritório.
      </p>
      <p className="mt-3 text-sm leading-6 text-muted">
        Não chegou em alguns minutos? Confira a caixa de spam.
        {convite
          ? " Se você já tinha uma conta com este e-mail, entre com sua senha e abra o link do convite novamente."
          : " Se este e-mail já tiver uma conta, entre com sua senha ou use a recuperação de senha."}
      </p>
      <Link href="/entrar" className="mt-8 inline-block font-medium text-accent underline underline-offset-4">
        Ir para a tela de entrada
      </Link>
    </>
  );
}
