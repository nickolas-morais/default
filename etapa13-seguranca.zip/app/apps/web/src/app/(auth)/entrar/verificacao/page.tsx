"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { messageFor } from "@app/shared";
import { createClient } from "@/lib/supabase/browser";
import { safeNextPath } from "@/lib/safe-redirect";
import { Alert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";

/** Segunda etapa do login: código do aplicativo autenticador (TOTP). */
export default function MfaVerifyPage() {
  return (
    <Suspense>
      <MfaVerify />
    </Suspense>
  );
}

function MfaVerify() {
  const router = useRouter();
  const params = useSearchParams();
  const [factorId, setFactorId] = useState<string | null>(null);
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  useEffect(() => {
    createClient().auth.mfa.listFactors().then(({ data }) => {
      const totp = data?.totp?.[0];
      if (totp) setFactorId(totp.id);
      else router.replace("/documentos");
    });
  }, [router]);

  async function verify(e: React.FormEvent) {
    e.preventDefault();
    if (!factorId) return;
    setPending(true);
    setError(null);
    const { error: err } = await createClient().auth.mfa.challengeAndVerify({ factorId, code: code.replace(/\s/g, "") });
    setPending(false);
    if (err) return setError(messageFor("MFA_INVALID_CODE"));
    router.replace(safeNextPath(params.get("next")));
    router.refresh();
  }

  return (
    <>
      <h1 className="font-serif text-2xl font-semibold">Verificação em duas etapas</h1>
      <p className="mt-2 text-muted">Digite o código de 6 dígitos do seu aplicativo autenticador.</p>
      <form onSubmit={verify} className="mt-8 space-y-5">
        {error ? <Alert tone="error">{error}</Alert> : null}
        <div className="space-y-1.5">
          <label htmlFor="code" className="block text-sm font-medium">Código</label>
          <input id="code" value={code} onChange={(e) => setCode(e.target.value)} inputMode="numeric"
            autoComplete="one-time-code" maxLength={8} autoFocus
            className="block h-12 w-full rounded border border-line-strong bg-surface px-3 text-center font-mono text-2xl tracking-[0.4em] focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20" />
        </div>
        <Button type="submit" className="w-full" disabled={pending || !factorId || code.replace(/\s/g, "").length < 6}>
          {pending ? "Verificando…" : "Verificar"}
        </Button>
      </form>
    </>
  );
}
