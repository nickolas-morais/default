import type { Metadata } from "next";
import Link from "next/link";
import { Alert } from "@/components/ui/alert";
import { SignInForm } from "./sign-in-form";

export const metadata: Metadata = { title: "Entrar" };

export default async function SignInPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string; erro?: string; conta?: string }>;
}) {
  const { next, erro, conta } = await searchParams;
  return (
    <>
      <h1 className="font-serif text-2xl font-semibold">Entrar</h1>
      <p className="mt-2 text-muted">Acesse com o e-mail e a senha da sua conta.</p>
      {erro === "link" ? (
        <Alert tone="error" className="mt-6">
          Este link é inválido ou expirou. Entre com sua senha ou solicite um novo link.
        </Alert>
      ) : null}
      {conta === "excluida" ? <Alert tone="success" className="mt-6">Sua conta foi excluída.</Alert> : null}
      <SignInForm next={next} />
      <p className="mt-8 text-sm text-muted">
        Escritório novo por aqui?{" "}
        <Link href="/cadastro" className="font-medium text-accent underline underline-offset-4">
          Criar conta
        </Link>
      </p>
    </>
  );
}
