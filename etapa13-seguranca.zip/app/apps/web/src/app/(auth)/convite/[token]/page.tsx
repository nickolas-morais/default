import type { Metadata } from "next";
import Link from "next/link";
import { messageFor } from "@app/shared";
import { createClient } from "@/lib/supabase/server";
import { Alert } from "@/components/ui/alert";
import { AcceptInviteForm, InviteSignUpForm } from "./invite-forms";

export const metadata: Metadata = { title: "Convite" };

const ROLE_LABEL = { owner: "titular", admin: "administrador", member: "membro" } as const;

export default async function InvitePage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const supabase = await createClient();

  const [{ data: preview }, { data: claims }] = await Promise.all([
    supabase.rpc("get_invitation_preview", { p_token: token }),
    supabase.auth.getClaims(),
  ]);
  const invite = preview?.[0];

  if (!invite || invite.status !== "valid") {
    const code = !invite
      ? "INVITE_INVALID"
      : invite.status === "expired"
        ? "INVITE_EXPIRED"
        : invite.status === "used"
          ? "INVITE_USED"
          : "INVITE_REVOKED";
    return (
      <>
        <h1 className="font-serif text-2xl font-semibold">Convite indisponível</h1>
        <Alert tone="error" className="mt-6">{messageFor(code)}</Alert>
        <Link href="/entrar" className="mt-8 inline-block font-medium text-accent underline underline-offset-4">
          Ir para a tela de entrada
        </Link>
      </>
    );
  }

  const header = (
    <>
      <h1 className="font-serif text-2xl font-semibold">Convite para {invite.office_name}</h1>
      <p className="mt-2 text-muted">
        Você foi convidado como {ROLE_LABEL[invite.role]} usando o e-mail{" "}
        <span className="font-medium text-ink">{invite.email}</span>.
      </p>
    </>
  );

  // Usuário logado: aceita com a conta atual (se ainda não tiver escritório).
  if (claims?.claims?.sub) {
    const { data: membership } = await supabase.rpc("current_membership");
    const current = membership?.[0];
    return (
      <>
        {header}
        {current ? (
          <Alert tone="warning" className="mt-6">
            Sua conta já pertence ao escritório {current.office_name}. Cada conta participa de um único
            escritório; para aceitar este convite, peça que ele seja enviado para outro e-mail.
          </Alert>
        ) : (
          <AcceptInviteForm token={token} />
        )}
      </>
    );
  }

  return (
    <>
      {header}
      <InviteSignUpForm token={token} email={invite.email} />
      <p className="mt-8 text-sm text-muted">
        Já tem conta com este e-mail?{" "}
        <Link
          href={`/entrar?next=${encodeURIComponent(`/convite/${token}`)}`}
          className="font-medium text-accent underline underline-offset-4"
        >
          Entre para aceitar
        </Link>
      </p>
    </>
  );
}
