"use client";

import { useActionState } from "react";
import { signUp } from "@/server/actions/auth";
import { Field } from "@/components/ui/field";
import { FormMessage } from "@/components/ui/alert";
import { SubmitButton } from "@/components/ui/button";
import { LegalCheckbox } from "@/components/ui/legal-checkbox";
import type { FormState } from "@/lib/errors";

export function SignUpForm() {
  const [state, action] = useActionState<FormState, FormData>(signUp, {});
  const v = state.values ?? {};
  const e = state.fieldErrors ?? {};
  return (
    <form action={action} className="mt-8 space-y-5" noValidate>
      <FormMessage state={state} />
      <Field label="Seu nome completo" name="fullName" autoComplete="name" required defaultValue={v.fullName} error={e.fullName} />
      <Field
        label="Nome do escritório"
        name="officeName"
        autoComplete="organization"
        required
        defaultValue={v.officeName}
        error={e.officeName}
      />
      <Field label="E-mail" name="email" type="email" autoComplete="email" required defaultValue={v.email} error={e.email} />
      <Field
        label="Senha"
        name="password"
        type="password"
        autoComplete="new-password"
        required
        minLength={8}
        hint="Pelo menos 8 caracteres, com maiúsculas, minúsculas e números."
        error={e.password}
      />
      <LegalCheckbox error={e.acceptLegal} />
      <SubmitButton className="w-full" pendingLabel="Criando conta…">Criar conta</SubmitButton>
    </form>
  );
}
