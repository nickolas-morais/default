import type { Metadata } from "next";
import Link from "next/link";
import { SignUpForm } from "./sign-up-form";

export const metadata: Metadata = { title: "Criar conta" };

export default function SignUpPage() {
  return (
    <>
      <h1 className="font-serif text-2xl font-semibold">Criar conta do escritório</h1>
      <p className="mt-2 text-muted">
        Você será o titular da conta e poderá convidar os colegas depois.
      </p>
      <SignUpForm />
      <p className="mt-8 text-sm text-muted">
        Já tem conta?{" "}
        <Link href="/entrar" className="font-medium text-accent underline underline-offset-4">
          Entrar
        </Link>
      </p>
    </>
  );
}
