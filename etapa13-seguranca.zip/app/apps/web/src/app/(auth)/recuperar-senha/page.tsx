"use client";

import Link from "next/link";
import { useActionState } from "react";
import { requestPasswordReset } from "@/server/actions/auth";
import { Field } from "@/components/ui/field";
import { FormMessage } from "@/components/ui/alert";
import { SubmitButton } from "@/components/ui/button";
import type { FormState } from "@/lib/errors";

export default function RecoverPasswordPage() {
  const [state, action] = useActionState<FormState, FormData>(requestPasswordReset, {});
  return (
    <>
      <h1 className="font-serif text-2xl font-semibold">Recuperar senha</h1>
      <p className="mt-2 text-muted">Informe o e-mail da conta. Enviaremos um link para criar uma nova senha.</p>
      <form action={action} className="mt-8 space-y-5" noValidate>
        <FormMessage state={state} />
        <Field
          label="E-mail"
          name="email"
          type="email"
          autoComplete="email"
          required
          defaultValue={state.values?.email}
          error={state.fieldErrors?.email}
        />
        <SubmitButton className="w-full" pendingLabel="Enviando…">Enviar link</SubmitButton>
      </form>
      <Link href="/entrar" className="mt-8 inline-block text-sm font-medium text-accent underline underline-offset-4">
        Voltar para a entrada
      </Link>
    </>
  );
}
