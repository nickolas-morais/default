export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-dvh md:grid md:grid-cols-[minmax(320px,2fr)_3fr]">
      <aside className="flex flex-col justify-between bg-accent px-8 py-6 text-white md:px-12 md:py-12">
        <p className="font-serif text-xl font-semibold tracking-tight">App</p>
        <div className="hidden max-w-sm md:block">
          <p className="font-serif text-3xl leading-tight">
            Contratos lidos, dados extraídos e riscos apontados antes da primeira reunião.
          </p>
          <p className="mt-4 text-sm leading-6 text-white/75">
            Feito para escritórios de advocacia. Cada escritório só acessa os próprios documentos.
          </p>
        </div>
      </aside>
      <main className="flex items-start justify-center px-6 py-12 md:items-center md:py-16">
        <div className="w-full max-w-sm">{children}</div>
      </main>
    </div>
  );
}
