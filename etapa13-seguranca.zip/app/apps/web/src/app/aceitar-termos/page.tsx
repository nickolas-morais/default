import type { Metadata } from "next";
import { AcceptLegalForm } from "./accept-legal-form";
import { signOut } from "@/server/actions/auth";

export const metadata: Metadata = { title: "Termos atualizados" };

export default function AcceptLegalPage() {
  return (
    <main className="mx-auto max-w-md px-6 py-24">
      <h1 className="font-serif text-2xl font-semibold">Termos atualizados</h1>
      <p className="mt-3 leading-7">
        Os termos de uso e a política de privacidade mudaram desde o seu último acesso. Leia as novas
        versões e confirme o aceite para continuar.
      </p>
      <AcceptLegalForm />
      <form action={signOut} className="mt-4">
        <button type="submit" className="text-sm text-muted underline underline-offset-4 hover:text-ink">
          Sair sem aceitar
        </button>
      </form>
    </main>
  );
}
