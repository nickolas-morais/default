"use client";

import { useActionState } from "react";
import { acceptLegal } from "@/server/actions/legal";
import { FormMessage } from "@/components/ui/alert";
import { SubmitButton } from "@/components/ui/button";
import { LegalCheckbox } from "@/components/ui/legal-checkbox";
import type { FormState } from "@/lib/errors";

export function AcceptLegalForm() {
  const [state, action] = useActionState<FormState, FormData>(acceptLegal, {});
  return (
    <form action={action} className="mt-8 space-y-5" noValidate>
      <FormMessage state={state} />
      <LegalCheckbox error={state.fieldErrors?.acceptLegal} />
      <SubmitButton className="w-full" pendingLabel="Registrando…">Aceitar e continuar</SubmitButton>
    </form>
  );
}
