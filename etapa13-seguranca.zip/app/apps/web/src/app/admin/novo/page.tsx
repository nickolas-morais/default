import { createClientOffice } from "@/server/actions/platform";
import { AdminForm } from "@/components/admin/admin-form";
import { Field } from "@/components/ui/field";

export const metadata = { title: "Novo cliente" };

export default function NewClientPage() {
  return (
    <div className="max-w-2xl">
      <h1 className="font-serif text-[28px] font-semibold">Novo cliente</h1>
      <p className="mt-2 leading-7 text-muted">
        Cria o escritório e gera o convite do titular. Pelo link, o titular define nome e senha, aceita os termos e entra
        no escritório já configurado. Depois, registre o contrato (boleto ou nota) na página do escritório, ou deixe o
        cliente assinar pelo Stripe na página Plano.
      </p>
      <div className="mt-8 rounded border border-line bg-surface p-5">
        <AdminForm action={createClientOffice} submitLabel="Criar escritório e gerar convite">
          <Field label="Nome do escritório" name="name" required />
          <Field label="E-mail do titular" name="email" type="email" required hint="O convite só funciona com este e-mail." />
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Dias de avaliação" name="trialDays" type="number" min={0} defaultValue="14"
              hint="0 = sem avaliação (use com contrato)." />
            <Field label="Documentos na avaliação" name="trialDocs" type="number" min={1} defaultValue="5" />
          </div>
        </AdminForm>
      </div>
    </div>
  );
}
