import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { dateTimeFmt } from "@/lib/format/dates";

export const metadata = { title: "Auditoria" };

const ACTION_LABEL: Record<string, string> = {
  "office.create": "Criou escritório", "office.owner_invite": "Gerou convite de titular", "office.trial": "Alterou avaliação",
  "office.suspend": "Suspendeu", "office.unsuspend": "Reativou", "office.failure_limit": "Alterou limite de falhas",
  "contract.create": "Registrou contrato", "contract.cancel": "Cancelou contrato",
};

export default async function AuditPage() {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("admin_audit_log", { p_limit: 200 });
  if (error) throw error;
  return (
    <>
      <h1 className="font-serif text-[28px] font-semibold">Auditoria</h1>
      <p className="mt-1 text-sm text-muted">Todas as ações feitas no painel da plataforma. Registros não podem ser alterados.</p>
      <div className="mt-6 overflow-x-auto rounded border border-line bg-surface">
        <table className="w-full min-w-[900px] text-left text-sm">
          <thead className="border-b border-line text-muted">
            <tr>{["Quando", "Quem", "Ação", "Escritório", "Detalhes"].map((h) => <th key={h} className="px-4 py-3 font-medium">{h}</th>)}</tr>
          </thead>
          <tbody className="divide-y divide-line">
            {data.map((l, i) => (
              <tr key={i} className="align-top">
                <td className="px-4 py-2.5 tabular-nums">{dateTimeFmt.format(new Date(l.created_at))}</td>
                <td className="px-4 py-2.5">{l.admin_email ?? "—"}</td>
                <td className="px-4 py-2.5">{ACTION_LABEL[l.action] ?? l.action}</td>
                <td className="px-4 py-2.5">
                  {l.office_id ? <Link href={`/admin/escritorios/${l.office_id}`} className="hover:underline">{l.office_name ?? "excluído"}</Link> : "—"}
                </td>
                <td className="max-w-md break-words px-4 py-2.5 font-mono text-xs text-muted">{JSON.stringify(l.details)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {!data.length ? <p className="p-6 text-muted">Nenhuma ação registrada.</p> : null}
      </div>
    </>
  );
}
