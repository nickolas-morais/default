import { createClient } from "@/lib/supabase/server";

export const metadata = { title: "Qualidade" };

const pct = (n: number, d: number) => (d ? `${Math.round((100 * n) / d)}%` : "—");

export default async function QualityPage() {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("admin_quality_stats");
  if (error) throw error;
  return (
    <>
      <h1 className="font-serif text-[28px] font-semibold">Qualidade da análise</h1>
      <p className="mt-1 max-w-[75ch] text-sm leading-6 text-muted">
        Avaliações dos advogados sobre os riscos apontados, por versão do prompt. Somente contagens: os comentários
        ficam no escritório. Para medir antes de publicar uma nova versão, use <code className="font-mono">pnpm eval</code> (evals/README.md).
      </p>
      <div className="mt-6 overflow-x-auto rounded border border-line bg-surface">
        <table className="w-full min-w-[900px] text-left text-sm">
          <thead className="border-b border-line text-muted">
            <tr>{["Versão do prompt", "Documentos", "Riscos", "Avaliados", "Útil", "Não procede", "Docs com riscos faltando", "Trechos localizados"]
              .map((h) => <th key={h} className="px-4 py-3 font-medium">{h}</th>)}</tr>
          </thead>
          <tbody className="divide-y divide-line tabular-nums">
            {data.map((r) => (
              <tr key={r.prompt_version ?? "sem"}>
                <td className="px-4 py-2.5 font-mono">{r.prompt_version ?? "—"}</td>
                <td className="px-4 py-2.5">{r.documents}</td>
                <td className="px-4 py-2.5">{r.risks}</td>
                <td className="px-4 py-2.5">{r.rated} ({pct(r.rated, r.risks)})</td>
                <td className="px-4 py-2.5">{pct(r.useful, r.rated)}</td>
                <td className="px-4 py-2.5">{pct(r.not_applicable, r.rated)}</td>
                <td className="px-4 py-2.5">{r.documents_with_missing} ({pct(r.documents_with_missing, r.documents)})</td>
                <td className="px-4 py-2.5">{r.located_pct === null ? "—" : `${r.located_pct}%`}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {!data.length ? <p className="p-6 text-muted">Nenhum documento analisado ainda.</p> : null}
      </div>
    </>
  );
}
