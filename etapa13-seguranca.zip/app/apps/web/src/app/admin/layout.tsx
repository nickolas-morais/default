import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { NavLink } from "@/components/shell/nav-link";

export const dynamic = "force-dynamic";
export const metadata = { title: { default: "Painel da plataforma", template: "%s · Painel" } };

/**
 * Painel da plataforma. Fora do layout dos escritórios: não depende de ser
 * membro de nenhum. O banco confere admin + 2FA em cada consulta; aqui só se
 * decide o que mostrar.
 */
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const { data: claims } = await supabase.auth.getClaims();
  if (!claims?.claims?.sub) redirect("/entrar?next=/admin");

  const { data: status } = await supabase.rpc("platform_admin_status");
  if (status === "none" || !status) notFound(); // não revela que o painel existe

  if (status === "needs_mfa") {
    const { data: factors } = await supabase.auth.mfa.listFactors();
    const hasFactor = Boolean(factors?.totp?.length);
    return (
      <main className="mx-auto max-w-lg px-6 py-24">
        <h1 className="font-serif text-2xl font-semibold">Verificação em duas etapas obrigatória</h1>
        <p className="mt-3 leading-7">
          {hasFactor
            ? "Conclua a verificação em duas etapas para acessar o painel da plataforma."
            : "O painel da plataforma exige verificação em duas etapas. Ative-a em Minha conta e volte aqui."}
        </p>
        <Link href={hasFactor ? "/entrar/verificacao?next=/admin" : "/configuracoes/conta"}
          className="mt-6 inline-flex h-10 items-center rounded bg-accent px-4 text-sm font-medium text-white">
          {hasFactor ? "Verificar agora" : "Ir para Minha conta"}
        </Link>
      </main>
    );
  }

  return (
    <div className="min-h-dvh">
      <header className="border-b border-line bg-ink text-white">
        <div className="mx-auto flex max-w-[1400px] flex-wrap items-center justify-between gap-4 px-6 py-3">
          <p className="font-serif text-lg font-semibold">Painel da plataforma</p>
          <Link href="/documentos" className="text-sm text-white/70 underline underline-offset-4 hover:text-white">
            Voltar ao app
          </Link>
        </div>
      </header>
      <div className="mx-auto max-w-[1400px] px-6 py-8">
        <nav aria-label="Painel" className="mb-8 flex flex-wrap gap-1">
          <NavLink href="/admin/escritorios">Escritórios</NavLink>
          <NavLink href="/admin/novo">Novo cliente</NavLink>
          <NavLink href="/admin/qualidade">Qualidade</NavLink>
          <NavLink href="/admin/auditoria">Auditoria</NavLink>
        </nav>
        {children}
      </div>
    </div>
  );
}
