import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { dateFmt } from "@/lib/format/dates";
import { cn } from "@/components/ui/cn";

export const metadata = { title: "Escritórios" };

const DAY = 86_400_000;
const SOURCE_LABEL: Record<string, string> = {
  contract: "Contrato", subscription: "Stripe", trial: "Avaliação", none: "Sem plano",
};
const FILTERS = [
  { id: "", label: "Todos" },
  { id: "vencendo", label: "Vencendo em 15 dias" },
  { id: "avaliacao", label: "Em avaliação" },
  { id: "sem_plano", label: "Sem plano" },
  { id: "suspensos", label: "Suspensos" },
] as const;
const usd = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });

export default async function OfficesPage({ searchParams }: { searchParams: Promise<{ q?: string; filtro?: string }> }) {
  const { q = "", filtro = "" } = await searchParams;
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("admin_list_offices", { p_query: q || null });
  if (error) throw error;

  const now = Date.now();
  const rows = data.filter((o) => {
    const ends = o.valid_until ? new Date(o.valid_until).getTime() : null;
    if (filtro === "vencendo") return ends !== null && ends - now <= 15 * DAY && o.source !== "subscription";
    if (filtro === "avaliacao") return o.source === "trial";
    if (filtro === "sem_plano") return o.source === "none";
    if (filtro === "suspensos") return o.suspended;
    return true;
  });
  const total30d = data.reduce((s, o) => s + Number(o.ai_cost_30d), 0);

  return (
    <>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-serif text-[28px] font-semibold">Escritórios</h1>
          <p className="mt-1 text-sm text-muted">
            {data.length} escritórios. Custo de IA nos últimos 30 dias: {usd.format(total30d)}.
          </p>
        </div>
        <form className="flex gap-2" role="search">
          {filtro ? <input type="hidden" name="filtro" value={filtro} /> : null}
          <input name="q" defaultValue={q} placeholder="Nome ou e-mail do titular" aria-label="Buscar"
            className="h-10 w-72 rounded border border-line-strong bg-surface px-3" />
          <button className="h-10 rounded border border-line-strong bg-surface px-4 text-sm font-medium">Buscar</button>
        </form>
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <Link key={f.id} href={`/admin/escritorios?${new URLSearchParams({ ...(q ? { q } : {}), ...(f.id ? { filtro: f.id } : {}) })}`}
            className={cn("rounded px-3 py-1 text-sm", filtro === f.id ? "bg-ink text-white" : "border border-line-strong bg-surface")}>
            {f.label}
          </Link>
        ))}
      </div>

      <div className="mt-4 overflow-x-auto rounded border border-line bg-surface">
        <table className="w-full min-w-[1100px] text-left text-sm">
          <thead className="border-b border-line text-muted">
            <tr>
              {["Escritório", "Titular", "Plano", "Uso no período", "Vigência", "IA 30 dias", "Documentos", "Última atividade"].map((h) => (
                <th key={h} scope="col" className="px-4 py-3 font-medium">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {rows.map((o) => {
              const ends = o.valid_until ? new Date(o.valid_until) : null;
              const soon = ends && ends.getTime() - now <= 15 * DAY && o.source !== "subscription";
              return (
                <tr key={o.office_id} className="align-top hover:bg-paper/60">
                  <td className="px-4 py-3">
                    <Link href={`/admin/escritorios/${o.office_id}`} className="font-medium hover:underline">{o.name}</Link>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {o.suspended ? <span className="rounded bg-danger-soft px-1.5 text-xs text-danger">Suspenso</span> : null}
                      {o.deletion_scheduled_for ? <span className="rounded bg-danger-soft px-1.5 text-xs text-danger">Exclusão agendada</span> : null}
                      {o.created_by_platform ? <span className="rounded bg-paper px-1.5 text-xs text-muted">Venda assistida</span> : null}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    {o.owner_email ? <>{o.owner_name}<p className="text-muted">{o.owner_email}</p></> : <span className="text-warning">Convite pendente</span>}
                  </td>
                  <td className="px-4 py-3">
                    {SOURCE_LABEL[o.source] ?? o.source}
                    {o.plan_name && o.source !== "trial" ? <p className="text-muted">{o.plan_name}</p> : null}
                    {o.subscription_status === "past_due" ? <p className="text-warning">Pagamento em atraso</p> : null}
                  </td>
                  <td className="px-4 py-3 tabular-nums">{o.source === "none" ? "—" : `${o.used} de ${o.doc_limit}`}</td>
                  <td className={cn("px-4 py-3 tabular-nums", soon ? "font-medium text-warning" : "text-muted")}>
                    {ends ? dateFmt.format(ends) : "—"}
                  </td>
                  <td className="px-4 py-3 tabular-nums">{usd.format(Number(o.ai_cost_30d))}</td>
                  <td className="px-4 py-3 tabular-nums">{o.documents_total}</td>
                  <td className="px-4 py-3 tabular-nums text-muted">{o.last_activity ? dateFmt.format(new Date(o.last_activity)) : "—"}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {!rows.length ? <p className="p-6 text-muted">Nenhum escritório encontrado.</p> : null}
      </div>
    </>
  );
}
