import Link from "next/link";
import { notFound } from "next/navigation";
import { codeFromDbError } from "@app/shared";
import { createClient } from "@/lib/supabase/server";
import { dateFmt, dateTimeFmt } from "@/lib/format/dates";
import { AdminForm } from "@/components/admin/admin-form";
import { Field } from "@/components/ui/field";
import {
  cancelContract, createContract, resendOwnerInvite, setFailureLimit, setSuspension, setTrial,
} from "@/server/actions/platform";

export const metadata = { title: "Escritório" };

type Detail = {
  office: {
    id: string; name: string; cnpj: string | null; created_at: string; trial_ends_at: string | null;
    trial_doc_limit: number | null; daily_failure_limit: number; suspended_at: string | null;
    suspended_reason: string | null; deletion_scheduled_for: string | null; stripe_customer_id: string | null;
  };
  entitlement: {
    source: string; plan_name: string | null; doc_limit: number; used: number | null; reserved: number | null;
    period_start: string | null; period_end: string | null; valid_until: string | null; subscription_status: string | null;
  };
  members: { full_name: string; email: string; role: string; created_at: string }[];
  pending_invites: { id: string; email: string; role: string; expires_at: string }[];
  contracts: {
    id: string; plan_id: string | null; doc_limit: number; starts_at: string; ends_at: string;
    billing_method: string; notes: string; cancelled_at: string | null;
  }[];
  subscription: { plan_id: string | null; status: string; current_period_end: string | null; cancel_at_period_end: boolean } | null;
  usage_by_month: { period_start: string; documents_processed: number }[];
  ai_cost_by_month: { month: string; cost_usd: number; documents: number }[];
  failures_24h: number;
  documents_by_status: Record<string, number>;
  audit: { action: string; details: unknown; created_at: string; admin_email: string | null }[];
};

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const ROLE: Record<string, string> = { owner: "Titular", admin: "Administrador", member: "Membro" };
const BILLING: Record<string, string> = { boleto: "Boleto", nota_fiscal: "Nota fiscal", transferencia: "Transferência", outro: "Outro" };
const SOURCE: Record<string, string> = { contract: "Contrato manual", subscription: "Assinatura Stripe", trial: "Avaliação", none: "Sem plano" };
const usd = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });
const card = "rounded border border-line bg-surface p-5";
const select = "block h-10 w-full rounded border border-line-strong bg-surface px-3";
const isoDate = (v: string | null) => (v ? new Date(v).toISOString().slice(0, 10) : "");

export default async function AdminOfficePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!UUID_RE.test(id)) notFound();
  const supabase = await createClient();
  const [{ data, error }, { data: plans }] = await Promise.all([
    supabase.rpc("admin_office_detail", { p_office_id: id }),
    supabase.from("plans").select("id, name, monthly_doc_limit").order("sort_order"),
  ]);
  if (error) {
    if (codeFromDbError(error) === "OFFICE_NOT_FOUND") notFound();
    throw error;
  }
  const d = data as unknown as Detail;
  const o = d.office;
  const e = d.entitlement;
  const hasOwner = d.members.some((m) => m.role === "owner");
  const ownerInvite = d.pending_invites.find((i) => i.role === "owner");
  const today = new Date().toISOString().slice(0, 10);
  const inAYear = new Date(Date.now() + 365 * 86_400_000).toISOString().slice(0, 10);

  return (
    <div className="space-y-8">
      <div>
        <Link href="/admin/escritorios" className="text-sm text-muted underline underline-offset-4">Voltar para escritórios</Link>
        <h1 className="mt-3 font-serif text-[28px] font-semibold">{o.name}</h1>
        <p className="mt-1 text-sm text-muted">
          Criado em {dateFmt.format(new Date(o.created_at))}
          {o.cnpj ? `, CNPJ ${o.cnpj}` : ""}
          {o.stripe_customer_id ? `, cliente Stripe ${o.stripe_customer_id}` : ""}
        </p>
        {o.suspended_at ? <p className="mt-2 text-sm font-medium text-danger">Suspenso desde {dateFmt.format(new Date(o.suspended_at))}: {o.suspended_reason ?? "sem motivo informado"}</p> : null}
        {o.deletion_scheduled_for ? <p className="mt-2 text-sm font-medium text-danger">Exclusão agendada pelo titular para {dateFmt.format(new Date(o.deletion_scheduled_for))}.</p> : null}
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <div className={card}>
          <p className="text-sm text-muted">Direito de uso</p>
          <p className="mt-1 font-semibold">{SOURCE[e.source] ?? e.source}</p>
          {e.plan_name ? <p className="text-sm text-muted">{e.plan_name}</p> : null}
        </div>
        <div className={card}>
          <p className="text-sm text-muted">Uso no período</p>
          <p className="mt-1 text-2xl font-semibold tabular-nums">{e.source === "none" ? "—" : `${e.used ?? 0} de ${e.doc_limit}`}</p>
          {e.reserved ? <p className="text-sm text-muted">{e.reserved} em processamento</p> : null}
        </div>
        <div className={card}>
          <p className="text-sm text-muted">Vigência</p>
          <p className="mt-1 font-semibold tabular-nums">{e.valid_until ? dateFmt.format(new Date(e.valid_until)) : "—"}</p>
          {e.subscription_status === "past_due" ? <p className="text-sm text-warning">Pagamento em atraso</p> : null}
        </div>
        <div className={card}>
          <p className="text-sm text-muted">Custo de IA (mês atual)</p>
          <p className="mt-1 text-2xl font-semibold tabular-nums">{usd.format(Number(d.ai_cost_by_month[0]?.cost_usd ?? 0))}</p>
          <p className="text-sm text-muted">{d.failures_24h} falhas nas últimas 24 h</p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className={card}>
          <h2 className="font-serif text-lg font-semibold">Membros</h2>
          <ul className="mt-3 divide-y divide-line text-sm">
            {d.members.map((m) => (
              <li key={m.email} className="flex justify-between gap-3 py-2">
                <span>{m.full_name}<span className="block text-muted">{m.email}</span></span>
                <span className="text-muted">{ROLE[m.role]}</span>
              </li>
            ))}
            {!d.members.length ? <li className="py-2 text-warning">Ainda sem membros.</li> : null}
          </ul>
          {!hasOwner ? (
            <div className="mt-4 border-t border-line pt-4">
              <h3 className="font-semibold">Convite do titular</h3>
              {ownerInvite ? <p className="mt-1 text-sm text-muted">Pendente para {ownerInvite.email}, expira em {dateFmt.format(new Date(ownerInvite.expires_at))}. Gerar outro cancela o atual.</p> : null}
              <AdminForm action={resendOwnerInvite} submitLabel="Gerar novo convite" variant="secondary" className="mt-3 space-y-3">
                <input type="hidden" name="officeId" value={o.id} />
                <Field label="E-mail do titular" name="email" type="email" required defaultValue={ownerInvite?.email} />
              </AdminForm>
            </div>
          ) : null}
        </section>

        <section className={card}>
          <h2 className="font-serif text-lg font-semibold">Uso e custo por mês</h2>
          <table className="mt-3 w-full text-sm">
            <thead className="text-muted"><tr><th className="py-1 text-left font-medium">Mês</th><th className="py-1 text-right font-medium">Na cota</th><th className="py-1 text-right font-medium">Custo IA</th></tr></thead>
            <tbody className="divide-y divide-line">
              {d.ai_cost_by_month.map((c) => (
                <tr key={c.month}>
                  <td className="py-1.5">{c.month.slice(0, 7)}</td>
                  <td className="py-1.5 text-right tabular-nums">{d.usage_by_month.find((u) => u.period_start.slice(0, 7) === c.month.slice(0, 7))?.documents_processed ?? 0}</td>
                  <td className="py-1.5 text-right tabular-nums">{usd.format(Number(c.cost_usd))}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!d.ai_cost_by_month.length ? <p className="mt-2 text-sm text-muted">Nenhum documento processado.</p> : null}
          <p className="mt-3 text-xs text-muted">
            Documentos por situação: {Object.entries(d.documents_by_status).map(([k, v]) => `${k} ${v}`).join(", ") || "nenhum"}.
            O conteúdo dos documentos não é acessível pelo painel.
          </p>
        </section>
      </div>

      <section className={card}>
        <h2 className="font-serif text-lg font-semibold">Contratos fora do Stripe</h2>
        <p className="mt-1 text-sm text-muted">Boleto, nota fiscal ou transferência. Enquanto vigente, o contrato vale sobre a assinatura e a avaliação; a cota renova a cada mês a partir do início.</p>
        {d.contracts.length ? (
          <ul className="mt-4 divide-y divide-line text-sm">
            {d.contracts.map((c) => (
              <li key={c.id} className="flex flex-wrap items-start justify-between gap-3 py-3">
                <div>
                  <p className="font-medium">
                    {plans?.find((p) => p.id === c.plan_id)?.name ?? "Personalizado"}, {c.doc_limit} documentos/mês, {BILLING[c.billing_method]}
                  </p>
                  <p className="text-muted">
                    {dateFmt.format(new Date(c.starts_at))} a {dateFmt.format(new Date(c.ends_at))}
                    {c.cancelled_at ? `, cancelado em ${dateFmt.format(new Date(c.cancelled_at))}` : ""}
                  </p>
                  {c.notes ? <p className="mt-1 text-muted">{c.notes}</p> : null}
                </div>
                {!c.cancelled_at && new Date(c.ends_at) > new Date() ? (
                  <AdminForm action={cancelContract} submitLabel="Cancelar" variant="danger" className="flex flex-col items-end gap-1"
                    confirmText="Cancelar este contrato? O escritório volta para a assinatura Stripe, a avaliação ou fica sem plano.">
                    <input type="hidden" name="contractId" value={c.id} />
                    <input type="hidden" name="officeId" value={o.id} />
                  </AdminForm>
                ) : null}
              </li>
            ))}
          </ul>
        ) : null}
        <AdminForm action={createContract} submitLabel="Registrar contrato" className="mt-4 grid gap-4 border-t border-line pt-4 md:grid-cols-3">
          <input type="hidden" name="officeId" value={o.id} />
          <div className="space-y-1.5">
            <label htmlFor="planId" className="block text-sm font-medium">Plano</label>
            <select id="planId" name="planId" className={select} defaultValue="">
              <option value="">Personalizado (use o limite ao lado)</option>
              {plans?.map((p) => <option key={p.id} value={p.id}>{p.name} ({p.monthly_doc_limit}/mês)</option>)}
            </select>
          </div>
          <Field label="Documentos por mês" name="docLimit" type="number" min={1} hint="Vazio = limite do plano escolhido." />
          <div className="space-y-1.5">
            <label htmlFor="billing" className="block text-sm font-medium">Cobrança</label>
            <select id="billing" name="billing" className={select} defaultValue="boleto">
              {Object.entries(BILLING).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </div>
          <Field label="Início" name="startsAt" type="date" required defaultValue={today} />
          <Field label="Fim" name="endsAt" type="date" required defaultValue={inAYear} />
          <Field label="Observações internas" name="notes" placeholder="Ex.: NF 123, anual, vencimento dia 10" />
        </AdminForm>
      </section>

      <div className="grid gap-6 lg:grid-cols-3">
        <section className={card}>
          <h2 className="font-serif text-lg font-semibold">Avaliação</h2>
          <AdminForm action={setTrial} submitLabel="Salvar avaliação" variant="secondary" className="mt-3 space-y-3">
            <input type="hidden" name="officeId" value={o.id} />
            <Field label="Termina em" name="endsAt" type="date" defaultValue={isoDate(o.trial_ends_at)} hint="Vazio = 14 dias após a criação." />
            <Field label="Documentos" name="docLimit" type="number" min={1} defaultValue={o.trial_doc_limit ? String(o.trial_doc_limit) : ""} hint="Vazio = 5." />
          </AdminForm>
        </section>
        <section className={card}>
          <h2 className="font-serif text-lg font-semibold">Suspensão</h2>
          <p className="mt-1 text-sm text-muted">Bloqueia novos envios; documentos, análises e exportação continuam acessíveis.</p>
          <AdminForm action={setSuspension} submitLabel={o.suspended_at ? "Reativar" : "Suspender"} variant={o.suspended_at ? "secondary" : "danger"}
            className="mt-3 space-y-3" confirmText={o.suspended_at ? undefined : "Suspender novos envios deste escritório?"}>
            <input type="hidden" name="officeId" value={o.id} />
            <input type="hidden" name="suspend" value={o.suspended_at ? "0" : "1"} />
            {!o.suspended_at ? <Field label="Motivo (interno)" name="reason" placeholder="Ex.: boleto vencido" /> : null}
          </AdminForm>
        </section>
        <section className={card}>
          <h2 className="font-serif text-lg font-semibold">Limite de falhas</h2>
          <AdminForm action={setFailureLimit} submitLabel="Salvar limite" variant="secondary" className="mt-3 space-y-3">
            <input type="hidden" name="officeId" value={o.id} />
            <Field label="Envios com erro por 24 h" name="limit" type="number" min={1} max={1000} defaultValue={String(o.daily_failure_limit)} />
          </AdminForm>
        </section>
      </div>

      <section className={card}>
        <h2 className="font-serif text-lg font-semibold">Ações neste escritório</h2>
        <ul className="mt-3 divide-y divide-line text-sm">
          {d.audit.map((a, i) => (
            <li key={i} className="flex flex-wrap justify-between gap-2 py-2">
              <span>{a.action} <span className="font-mono text-xs text-muted">{JSON.stringify(a.details)}</span></span>
              <span className="text-muted">{a.admin_email}, {dateTimeFmt.format(new Date(a.created_at))}</span>
            </li>
          ))}
          {!d.audit.length ? <li className="py-2 text-muted">Nenhuma ação registrada.</li> : null}
        </ul>
      </section>
    </div>
  );
}
