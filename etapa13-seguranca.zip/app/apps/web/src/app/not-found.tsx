import Link from "next/link";

export default function NotFound() {
  return (
    <main className="mx-auto max-w-lg px-6 py-24">
      <h1 className="font-serif text-2xl font-semibold">Página não encontrada</h1>
      <p className="mt-3 text-muted">O endereço pode estar incorreto ou o conteúdo foi removido.</p>
      <Link href="/documentos" className="mt-6 inline-block font-medium text-accent underline underline-offset-4">
        Ir para documentos
      </Link>
    </main>
  );
}
