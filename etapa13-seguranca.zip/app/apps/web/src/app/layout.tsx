import type { Metadata } from "next";
import { connection } from "next/server";
import { publicSans, sourceSerif } from "./fonts";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "App", template: "%s · App" },
  description: "Análise de contratos para escritórios de advocacia.",
  robots: { index: false, follow: false },
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  // Renderização por requisição: necessária para o nonce da CSP (src/proxy.ts).
  await connection();
  return (
    <html lang="pt-BR" className={`${publicSans.variable} ${sourceSerif.variable}`}>
      <body>{children}</body>
    </html>
  );
}
