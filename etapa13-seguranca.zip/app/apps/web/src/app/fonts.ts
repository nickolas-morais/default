import { Public_Sans, Source_Serif_4 } from "next/font/google";

// Public Sans: sóbria e muito legível em formulários densos.
// Source Serif 4: títulos com a textura de peça jurídica, sem ser decorativa.
export const publicSans = Public_Sans({ subsets: ["latin"], variable: "--font-public-sans", display: "swap" });
export const sourceSerif = Source_Serif_4({ subsets: ["latin"], variable: "--font-source-serif", display: "swap" });
