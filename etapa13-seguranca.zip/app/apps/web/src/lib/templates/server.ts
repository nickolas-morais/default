import "server-only";
import { inspectTemplate } from "@app/shared/docx-template";
import type { ParsedTemplate } from "@app/shared/template-vars";
import { createAdminClient, DOCUMENTS_BUCKET } from "@/lib/supabase/admin";

export const MAX_TEMPLATE_BYTES = 4 * 1024 * 1024;

/** Variáveis gravadas no banco: simples como estão; laços com prefixo "#". */
export function toStoredVariables(parsed: ParsedTemplate): string[] {
  return [...parsed.variables, ...parsed.loops.map((l) => `#${l.name}`)];
}

export function fromStoredVariables(stored: string[]): ParsedTemplate {
  return {
    variables: stored.filter((v) => !v.startsWith("#")),
    loops: stored.filter((v) => v.startsWith("#")).map((v) => ({ name: v.slice(1), fields: [] })),
  };
}

/** Baixa o modelo do Storage (chamar só depois de confirmar o acesso pela RLS). */
export async function loadTemplateFile(storagePath: string) {
  const { data, error } = await createAdminClient().storage.from(DOCUMENTS_BUCKET).download(storagePath);
  if (error || !data) return null;
  const bytes = new Uint8Array(await data.arrayBuffer());
  const inspected = inspectTemplate(bytes);
  return inspected.ok ? { bytes, parsed: inspected.parsed } : null;
}
