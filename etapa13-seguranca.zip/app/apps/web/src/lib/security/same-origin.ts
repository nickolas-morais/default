import { NextResponse, type NextRequest } from "next/server";
import { env } from "@/lib/env";
import { isAllowedOrigin } from "./origin";

/**
 * Defesa contra CSRF nas rotas POST com sessão (além do SameSite=Lax dos
 * cookies): só aceita requisições vindas do próprio app.
 * Server Actions já têm essa checagem embutida no Next.js.
 */
export function rejectCrossOrigin(request: NextRequest): NextResponse | null {
  const allowed = [request.nextUrl.origin, new URL(env.siteUrl).origin];
  if (isAllowedOrigin(request.headers.get("origin"), request.headers.get("referer"), allowed)) return null;
  return NextResponse.json({ error: "FORBIDDEN" }, { status: 403 });
}
