import { test } from "node:test";
import assert from "node:assert/strict";
import { buildCsp, newNonce } from "./csp.ts";

test("CSP de produção: nonce, sem unsafe-eval, Supabase e Sentry liberados", () => {
  const csp = buildCsp("abc123", {
    NODE_ENV: "production",
    NEXT_PUBLIC_SUPABASE_URL: "https://xyz.supabase.co",
    NEXT_PUBLIC_SENTRY_DSN: "https://chave@o123.ingest.us.sentry.io/456",
  });
  assert.match(csp, /script-src 'self' 'nonce-abc123' 'strict-dynamic' 'wasm-unsafe-eval';/);
  assert.ok(!csp.includes("'unsafe-eval'"));
  assert.ok(!/script-src[^;]*'unsafe-inline'/.test(csp));
  assert.match(csp, /connect-src 'self' https:\/\/xyz\.supabase\.co https:\/\/o123\.ingest\.us\.sentry\.io;/);
  assert.match(csp, /frame-src 'self' https:\/\/xyz\.supabase\.co/);
  assert.match(csp, /frame-ancestors 'none'/);
  assert.match(csp, /object-src 'none'/);
  assert.match(csp, /upgrade-insecure-requests/);
  assert.ok(!csp.includes("chave"), "a chave do DSN não vai no cabeçalho");
});

test("nonce muda a cada requisição", () => {
  assert.notEqual(newNonce(), newNonce());
  assert.ok(newNonce().length >= 22);
});
