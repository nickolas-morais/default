/**
 * Content Security Policy com nonce por requisição.
 *
 * - script-src: só scripts com o nonce desta resposta ('strict-dynamic' deixa
 *   os scripts carregados por eles rodarem). Bloqueia script injetado (XSS).
 * - connect-src / frame-src: o próprio app e o Supabase (envio direto ao
 *   Storage, URL assinada do PDF), e o Sentry quando configurado.
 * - worker-src: o worker do pdf.js é servido pelo próprio app.
 * - frame-ancestors 'none': ninguém incorpora o app num iframe (clickjacking).
 */
function originOf(url: string | undefined): string | null {
  if (!url) return null;
  try {
    return new URL(url).origin;
  } catch {
    return null;
  }
}

export function buildCsp(nonce: string, env: Record<string, string | undefined> = process.env): string {
  const dev = env.NODE_ENV !== "production";
  const supabase = originOf(env.NEXT_PUBLIC_SUPABASE_URL);
  const sentry = originOf(env.NEXT_PUBLIC_SENTRY_DSN?.replace(/\/\/[^@]+@/, "//"));
  const connect = ["'self'", supabase, sentry, dev ? "ws:" : null].filter(Boolean).join(" ");

  return [
    "default-src 'self'",
    `script-src 'self' 'nonce-${nonce}' 'strict-dynamic' 'wasm-unsafe-eval'${dev ? " 'unsafe-eval'" : ""}`,
    `style-src 'self' 'nonce-${nonce}'${dev ? " 'unsafe-inline'" : ""}`,
    "style-src-attr 'unsafe-inline'",
    "img-src 'self' blob: data:",
    "font-src 'self' data:",
    `connect-src ${connect}`,
    `frame-src 'self'${supabase ? ` ${supabase}` : ""}`,
    "worker-src 'self' blob:",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
    ...(dev ? [] : ["upgrade-insecure-requests"]),
  ].join("; ");
}

export function newNonce(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return btoa(String.fromCharCode(...bytes));
}
