/** A requisição vem de uma das origens permitidas? (Origin, ou Referer se não houver Origin.) */
export function isAllowedOrigin(origin: string | null, referer: string | null, allowed: string[]): boolean {
  const set = new Set(allowed);
  if (origin) return set.has(origin);
  if (!referer) return false;
  try {
    return set.has(new URL(referer).origin);
  } catch {
    return false;
  }
}
