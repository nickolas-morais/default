import { test } from "node:test";
import assert from "node:assert/strict";
import { isAllowedOrigin } from "./origin.ts";

const app = ["https://app.vercel.app"];

test("CSRF: só aceita POST do próprio app", () => {
  assert.equal(isAllowedOrigin("https://app.vercel.app", null, app), true);
  assert.equal(isAllowedOrigin("https://evil.com", "https://app.vercel.app/x", app), false, "Origin manda, mesmo com Referer do app");
  assert.equal(isAllowedOrigin("https://app.vercel.app.evil.com", null, app), false);
  assert.equal(isAllowedOrigin("null", null, app), false, "iframe sandbox ou arquivo local");
  assert.equal(isAllowedOrigin(null, "https://app.vercel.app/documentos", app), true);
  assert.equal(isAllowedOrigin(null, "https://evil.com/?https://app.vercel.app", app), false);
  assert.equal(isAllowedOrigin(null, null, app), false, "sem Origin nem Referer");
});
