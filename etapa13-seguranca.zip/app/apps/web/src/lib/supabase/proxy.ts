import { NextResponse, type NextRequest } from "next/server";
import { createServerClient } from "@supabase/ssr";
import { env, sessionCookieOptions } from "@/lib/env";
import type { Database } from "@/types/database";

/** Rotas acessíveis sem login. Todo o resto exige sessão. */
const PUBLIC_PREFIXES = [
  "/entrar",
  "/cadastro",
  "/confirme-seu-email",
  "/recuperar-senha",
  "/convite",
  "/termos",
  "/privacidade",
  "/auth/confirm",
  "/api/stripe/webhook", // chamado pelo Stripe, autenticado pela assinatura do evento
  "/api/prazos/feed", // lido pelo Google/Outlook, autenticado pelo token secreto do endereço
];

function isPublic(pathname: string) {
  return PUBLIC_PREFIXES.some((p) => pathname === p || pathname.startsWith(`${p}/`));
}

/**
 * Renova a sessão a cada requisição e barra rotas privadas sem login.
 * A autorização de verdade (qual escritório, qual papel) fica na RLS e nos
 * layouts; aqui é só a primeira barreira.
 */
export async function updateSession(request: NextRequest) {
  let response = NextResponse.next({ request });

  const supabase = createServerClient<Database>(env.supabaseUrl, env.supabaseKey, {
    cookieOptions: sessionCookieOptions,
    cookies: {
      getAll() {
        return request.cookies.getAll();
      },
      setAll(cookiesToSet, headers) {
        cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
        response = NextResponse.next({ request });
        cookiesToSet.forEach(({ name, value, options }) => response.cookies.set(name, value, options));
        Object.entries(headers).forEach(([key, value]) => response.headers.set(key, value));
      },
    },
  });

  // Não coloque código entre createServerClient e getClaims.
  const { data } = await supabase.auth.getClaims();
  const isLoggedIn = Boolean(data?.claims?.sub);
  const { pathname, search } = request.nextUrl;

  if (!isLoggedIn && !isPublic(pathname)) {
    const url = request.nextUrl.clone();
    url.pathname = "/entrar";
    url.search = pathname === "/" ? "" : `?next=${encodeURIComponent(pathname + search)}`;
    return NextResponse.redirect(url);
  }

  if (isLoggedIn && (pathname === "/entrar" || pathname === "/cadastro")) {
    const url = request.nextUrl.clone();
    url.pathname = "/documentos";
    url.search = "";
    return NextResponse.redirect(url);
  }

  return response;
}
