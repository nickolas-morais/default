import { createBrowserClient } from "@supabase/ssr";
import { env, sessionCookieOptions } from "@/lib/env";
import type { Database } from "@/types/database";

export function createClient() {
  return createBrowserClient<Database>(env.supabaseUrl, env.supabaseKey, { cookieOptions: sessionCookieOptions });
}
