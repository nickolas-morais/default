import "server-only";
import { createClient } from "@supabase/supabase-js";
import { env } from "@/lib/env";
import { serverEnv } from "@/lib/env.server";
import type { Database } from "@/types/database";

/**
 * Cliente com a secret key: ignora a RLS.
 *
 * Regras de uso (revisar em todo PR que importe este arquivo):
 *  1. Só depois de confirmar a permissão com o cliente do usuário
 *     (lib/supabase/server.ts), por exemplo lendo o documento via RLS.
 *  2. Sempre filtrar por um id já autorizado; nunca listar tabelas inteiras.
 *  3. Usos permitidos: Storage (baixar para validar, assinar URL, remover) e as
 *     funções restritas a service_role (mark_document_queued, fail_document).
 */
export function createAdminClient() {
  return createClient<Database>(env.supabaseUrl, serverEnv.supabaseSecretKey, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  });
}

export const DOCUMENTS_BUCKET = "documents";
