const TZ = "America/Sao_Paulo";

export const dateTimeFmt = new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short", timeZone: TZ });
export const dateFmt = new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeZone: TZ });

/** "AAAA-MM-DD" (input date) → início do dia em Brasília, em ISO. Null se inválido. */
export function startOfDayBrt(value: string | undefined): string | null {
  if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const d = new Date(`${value}T00:00:00-03:00`);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

export function endOfDayBrt(value: string | undefined): string | null {
  const start = startOfDayBrt(value);
  return start ? new Date(new Date(start).getTime() + 24 * 60 * 60 * 1000).toISOString() : null;
}
