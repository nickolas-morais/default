import "server-only";
import { headers } from "next/headers";

/** IP e user agent da requisição, para o registro de aceite dos termos. */
export async function getRequestMeta() {
  const h = await headers();
  const forwarded = h.get("x-forwarded-for")?.split(",")[0]?.trim();
  const ip = forwarded || h.get("x-real-ip") || null;
  const userAgent = h.get("user-agent")?.slice(0, 512) ?? null;
  return { ip, userAgent };
}
