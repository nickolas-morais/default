import { test } from "node:test";
import assert from "node:assert/strict";
import { safeNextPath } from "./safe-redirect.ts";

test("redirecionamento só para caminhos internos", () => {
  const attacks = [
    "https://evil.com", "//evil.com", "/\\evil.com", "\\\\evil.com", "javascript:alert(1)", " //evil.com",
    "http:/evil.com", "/\t/evil.com", "/\n/evil.com", "/\r\n/evil.com", "/%09/evil.com", "data:text/html,x",
  ];
  for (const evil of attacks) {
    const r = safeNextPath(evil);
    assert.equal(new URL(r, "https://app.com.br").origin, "https://app.com.br", `${JSON.stringify(evil)} -> ${r}`);
  }
  assert.equal(safeNextPath("/documentos?x=1#a"), "/documentos?x=1#a");
  assert.equal(safeNextPath("/redefinir-senha"), "/redefinir-senha");
  assert.equal(safeNextPath(undefined), "/documentos");
});
