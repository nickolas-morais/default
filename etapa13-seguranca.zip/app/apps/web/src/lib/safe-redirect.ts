/**
 * Aceita apenas caminhos do próprio app (evita open redirect).
 * O navegador descarta tabulações e quebras de linha ao ler uma URL
 * ("/\t/evil.com" vira "//evil.com"), então a checagem resolve a URL como
 * ele faria e confere a origem, além de recusar caracteres de controle.
 */
const BASE = "https://interno.invalid";

export function safeNextPath(value: unknown, fallback = "/documentos"): string {
  if (typeof value !== "string" || value.length > 2000) return fallback;
  if (/[\u0000-\u001f\u007f\s\\]/.test(value)) return fallback;
  if (!value.startsWith("/") || value.startsWith("//")) return fallback;
  try {
    const url = new URL(value, BASE);
    if (url.origin !== BASE) return fallback;
    return `${url.pathname}${url.search}${url.hash}`;
  } catch {
    return fallback;
  }
}
