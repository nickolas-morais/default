import { z } from "zod";
import { isValidCnpj, normalizeCnpj } from "@app/shared";

export const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .pipe(z.email({ error: "Informe um e-mail válido." }));

export const passwordSchema = z
  .string()
  .min(8, { error: "A senha precisa ter pelo menos 8 caracteres." })
  .max(72, { error: "A senha pode ter no máximo 72 caracteres." })
  // Mesma regra configurada no Supabase Auth (password_requirements).
  .refine((v) => /[a-z]/.test(v) && /[A-Z]/.test(v) && /\d/.test(v), {
    error: "Use letras maiúsculas, minúsculas e números.",
  });

const nameSchema = (label: string) =>
  z.string().trim().min(2, { error: `Informe ${label}.` }).max(160, { error: `${label} muito longo.` });

const acceptSchema = z.literal("on", {
  error: "Para continuar, aceite os termos de uso e a política de privacidade.",
});

export const signInSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, { error: "Informe a senha." }),
});

export const signUpSchema = z.object({
  fullName: nameSchema("seu nome completo"),
  officeName: nameSchema("o nome do escritório"),
  email: emailSchema,
  password: passwordSchema,
  acceptLegal: acceptSchema,
});

export const inviteSignUpSchema = z.object({
  fullName: nameSchema("seu nome completo"),
  password: passwordSchema,
  acceptLegal: acceptSchema,
});

export const acceptLegalSchema = z.object({ acceptLegal: acceptSchema });

export const recoverSchema = z.object({ email: emailSchema });

export const resetPasswordSchema = z
  .object({ password: passwordSchema, confirm: z.string() })
  .refine((v) => v.password === v.confirm, { error: "As senhas não coincidem.", path: ["confirm"] });

const optionalText = (max: number) =>
  z.string().trim().max(max, { error: `Máximo de ${max} caracteres.` }).transform((v) => v || null);

export const profileSchema = z.object({
  fullName: nameSchema("seu nome completo"),
  phone: optionalText(30),
  oabNumber: optionalText(30),
});

export const changeEmailSchema = z.object({ email: emailSchema });

export const changePasswordSchema = z
  .object({ current: z.string().min(1, { error: "Informe a senha atual." }), password: passwordSchema, confirm: z.string() })
  .refine((v) => v.password === v.confirm, { error: "As senhas não coincidem.", path: ["confirm"] });

export const officeSchema = z.object({
  address: optionalText(300),
  phone: optionalText(30),
  contactEmail: z.string().trim().max(200).transform((v) => v || null)
    .refine((v) => v === null || z.email().safeParse(v).success, { error: "Informe um e-mail válido." }),
  oabRegistration: optionalText(60),
  name: nameSchema("o nome do escritório"),
  cnpj: z
    .string()
    .trim()
    .transform((v) => (v ? normalizeCnpj(v) : null))
    .refine((v) => v === null || isValidCnpj(v), { error: "CNPJ inválido. Confira os dígitos." }),
});

export const inviteSchema = z.object({
  email: emailSchema,
  role: z.enum(["member", "admin"], { error: "Escolha um papel." }),
});

/** Converte FormData em objeto simples (apenas strings). */
export function formToObject(formData: FormData): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [key, value] of formData.entries()) {
    if (typeof value === "string") out[key] = value;
  }
  return out;
}

/** Primeiro erro de cada campo, no formato esperado pelos formulários. */
export function fieldErrorsOf(error: z.ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = issue.path.join(".") || "_";
    out[key] ??= issue.message;
  }
  return out;
}
