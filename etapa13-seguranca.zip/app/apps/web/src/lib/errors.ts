import { messageFor, type ErrorCode } from "@app/shared";

type AuthLikeError = { code?: string; status?: number; message?: string } | null | undefined;

/** Traduz erros do Supabase Auth para códigos do domínio. */
export function codeFromAuthError(error: AuthLikeError): ErrorCode {
  switch (error?.code) {
    case "invalid_credentials":
      return "INVALID_CREDENTIALS";
    case "email_not_confirmed":
      return "EMAIL_NOT_CONFIRMED";
    case "weak_password":
      return "WEAK_PASSWORD";
    case "over_request_rate_limit":
    case "over_email_send_rate_limit":
      return "RATE_LIMITED";
    case "otp_expired":
    case "flow_state_expired":
    case "flow_state_not_found":
      return "LINK_INVALID";
    case "email_address_invalid":
      return "INVALID_EMAIL";
    case "unexpected_failure":
      // Falha no trigger de cadastro: a server action valida antes, então
      // chegar aqui é raro (ex.: convite consumido entre a prévia e o envio).
      return "SIGNUP_FAILED";
    default:
      return error?.status === 429 ? "RATE_LIMITED" : "UNEXPECTED";
  }
}

/** Estado padrão devolvido pelas server actions para os formulários. */
export type FormState = {
  ok?: boolean;
  message?: string;
  fieldErrors?: Record<string, string>;
  values?: Record<string, string>;
};

export function formError(code: ErrorCode, extra?: Partial<FormState>): FormState {
  return { ok: false, message: messageFor(code), ...extra };
}
