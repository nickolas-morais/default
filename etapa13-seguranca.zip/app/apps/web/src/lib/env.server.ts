import "server-only";

const secretKey = process.env.SUPABASE_SECRET_KEY;

export const serverEnv = {
  get supabaseSecretKey(): string {
    if (!secretKey) throw new Error("Variável de ambiente ausente: SUPABASE_SECRET_KEY. Veja apps/web/.env.example.");
    return secretKey;
  },
};
