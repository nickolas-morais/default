import "server-only";
import Stripe from "stripe";

let client: Stripe | null | undefined;

/** Cliente do Stripe, ou null se STRIPE_SECRET_KEY não estiver configurada. */
export function getStripe(): Stripe | null {
  if (client === undefined) {
    const key = process.env.STRIPE_SECRET_KEY;
    client = key && !key.includes("cole-aqui") ? new Stripe(key, { maxNetworkRetries: 2, appInfo: { name: "app" } }) : null;
  }
  return client;
}

export type PlanPrice = { lookupKey: string; priceId: string; amount: number | null; currency: string; interval: string };

/** Preços ativos no Stripe por lookup_key (fonte única dos valores cobrados). */
export async function getPlanPrices(lookupKeys: string[]): Promise<Map<string, PlanPrice>> {
  const stripe = getStripe();
  const map = new Map<string, PlanPrice>();
  if (!stripe || !lookupKeys.length) return map;
  const prices = await stripe.prices.list({ lookup_keys: lookupKeys, active: true, limit: 100 });
  for (const p of prices.data) {
    if (!p.lookup_key) continue;
    map.set(p.lookup_key, {
      lookupKey: p.lookup_key,
      priceId: p.id,
      amount: p.unit_amount,
      currency: p.currency,
      interval: p.recurring?.interval ?? "month",
    });
  }
  return map;
}
