import { test } from "node:test";
import assert from "node:assert/strict";
import { subscriptionToUpsert } from "./sync.ts";

test("usa o período do item da assinatura (API atual do Stripe)", () => {
  const r = subscriptionToUpsert({
    id: "sub_1", status: "active", customer: "cus_1", cancel_at_period_end: false,
    items: { data: [{ current_period_start: 1790000000, current_period_end: 1792592000,
      price: { id: "price_1", lookup_key: "essencial_mensal" } }] },
  });
  assert.equal(r.p_customer_id, "cus_1");
  assert.equal(r.p_price_lookup_key, "essencial_mensal");
  assert.equal(r.p_period_start, new Date(1790000000 * 1000).toISOString());
});

test("aceita cliente expandido e período na assinatura (APIs antigas)", () => {
  const r = subscriptionToUpsert({
    id: "sub_2", status: "canceled", customer: { id: "cus_2" }, cancel_at_period_end: true,
    current_period_start: 1790000000, current_period_end: 1792592000,
    items: { data: [{ price: { id: "price_2", lookup_key: null } }] },
  });
  assert.equal(r.p_customer_id, "cus_2");
  assert.equal(r.p_price_lookup_key, "");
  assert.equal(r.p_period_end, new Date(1792592000 * 1000).toISOString());
  assert.equal(r.p_cancel_at_period_end, true);
});
