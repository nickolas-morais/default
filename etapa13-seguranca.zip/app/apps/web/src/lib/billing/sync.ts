/**
 * Converte uma assinatura do Stripe nos argumentos de
 * public.stripe_upsert_subscription. Função pura (testável sem o Stripe).
 *
 * Na API atual do Stripe (2025-03-31.basil em diante), o período de cobrança
 * fica em cada item da assinatura, não mais na assinatura.
 */
export type SubscriptionLike = {
  id: string;
  status: string;
  customer: string | { id: string };
  cancel_at_period_end: boolean;
  current_period_start?: number | null;
  current_period_end?: number | null;
  items: {
    data: Array<{
      current_period_start?: number | null;
      current_period_end?: number | null;
      price: { id: string; lookup_key: string | null };
    }>;
  };
};

const iso = (seconds: number | null | undefined) => (seconds ? new Date(seconds * 1000).toISOString() : null);

export function subscriptionToUpsert(sub: SubscriptionLike) {
  const item = sub.items.data[0];
  return {
    p_customer_id: typeof sub.customer === "string" ? sub.customer : sub.customer.id,
    p_subscription_id: sub.id,
    p_price_lookup_key: item?.price.lookup_key ?? "",
    p_price_id: item?.price.id ?? "",
    p_status: sub.status,
    p_period_start: iso(item?.current_period_start ?? sub.current_period_start),
    p_period_end: iso(item?.current_period_end ?? sub.current_period_end),
    p_cancel_at_period_end: sub.cancel_at_period_end,
  };
}

/** Eventos que mudam o estado da assinatura. */
export const SUBSCRIPTION_EVENTS = new Set([
  "checkout.session.completed",
  "customer.subscription.created",
  "customer.subscription.updated",
  "customer.subscription.deleted",
  "customer.subscription.paused",
  "customer.subscription.resumed",
  "invoice.paid",
  "invoice.payment_failed",
]);
