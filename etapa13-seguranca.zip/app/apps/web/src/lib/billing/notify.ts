import "server-only";
import { sendEmail } from "@app/shared/email";
import { paymentFailedEmail } from "@app/shared/email-templates";
import { createAdminClient } from "@/lib/supabase/admin";
import { env } from "@/lib/env";

/** Aviso de pagamento recusado (uma vez por fatura), para titular e administradores. */
export async function notifyPaymentFailed(invoiceId: string, customerId: string) {
  const admin = createAdminClient();
  const { data: office } = await admin.from("offices").select("id").eq("stripe_customer_id", customerId).maybeSingle();
  if (!office) return;
  const key = `payment_failed:${invoiceId}`;
  const { data: claimed } = await admin.rpc("notify_claim", { p_key: key, p_kind: "payment_failed" });
  if (!claimed) return;
  const { data: admins } = await admin.rpc("notify_office_admins", { p_office_id: office.id, p_only_quota_optin: false });
  const result = await sendEmail({
    to: (admins ?? []).map((a) => a.email),
    ...paymentFailedEmail({ officeName: admins?.[0]?.office_name ?? "", url: `${env.siteUrl}/plano` }),
  });
  if (!result.ok) await admin.rpc("notify_release", { p_key: key });
}
