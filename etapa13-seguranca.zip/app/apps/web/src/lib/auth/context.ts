import "server-only";
import { cache } from "react";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { OfficeRoleEnum } from "@/types/database";

export type SessionContext = {
  userId: string;
  email: string;
  fullName: string;
  office: { id: string; name: string };
  role: OfficeRoleEnum;
  isAdmin: boolean;
};

/**
 * Resolve usuário, escritório ativo e papel. Memoizado por requisição.
 * O escritório vem de current_membership() no banco, que usa
 * current_office_id(): a aplicação nunca presume "um escritório por usuário".
 *
 * Redireciona quando falta sessão, aceite dos termos vigentes ou escritório.
 */
export const getSessionContext = cache(async (): Promise<SessionContext> => {
  const supabase = await createClient();

  const { data: claimsData } = await supabase.auth.getClaims();
  const userId = claimsData?.claims?.sub;
  if (!userId) redirect("/entrar");

  // Quem ativou a verificação em duas etapas precisa concluí-la em cada sessão.
  const { data: aal } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
  if (aal?.nextLevel === "aal2" && aal.currentLevel !== "aal2") redirect("/entrar/verificacao");

  const [legal, membership, profile] = await Promise.all([
    supabase.rpc("has_accepted_current_legal"),
    supabase.rpc("current_membership"),
    supabase.from("profiles").select("full_name, email").eq("id", userId).maybeSingle(),
  ]);

  if (legal.error || membership.error || profile.error) {
    throw new Error("Falha ao carregar a sessão.");
  }
  if (!legal.data) redirect("/aceitar-termos");

  const current = membership.data?.[0];
  if (!current || !profile.data) redirect("/sem-acesso");

  return {
    userId,
    email: profile.data.email,
    fullName: profile.data.full_name,
    office: { id: current.office_id, name: current.office_name },
    role: current.role,
    isAdmin: current.role === "owner" || current.role === "admin",
  };
});

export async function requireAdmin(): Promise<SessionContext> {
  const ctx = await getSessionContext();
  if (!ctx.isAdmin) redirect("/documentos");
  return ctx;
}
