// Cria (ou confere) no Stripe os produtos e preços mensais dos planos, com os
// lookup_keys usados em public.plans. Idempotente: pode rodar várias vezes.
//   STRIPE_SECRET_KEY=sk_test_... pnpm stripe:setup
// Valores em centavos de real: ajuste antes de rodar em produção.
import Stripe from "stripe";

const PLANS = [
  { lookupKey: "essencial_mensal", name: "Essencial", docs: 30, amount: 19700 },
  { lookupKey: "profissional_mensal", name: "Profissional", docs: 100, amount: 49700 },
  { lookupKey: "escritorio_mensal", name: "Escritório", docs: 300, amount: 119700 },
];

const key = process.env.STRIPE_SECRET_KEY;
if (!key) {
  console.error("Defina STRIPE_SECRET_KEY (use a chave de teste sk_test_...).");
  process.exit(1);
}
const stripe = new Stripe(key);
const existing = await stripe.prices.list({ lookup_keys: PLANS.map((p) => p.lookupKey), limit: 100 });

for (const plan of PLANS) {
  const found = existing.data.find((p) => p.lookup_key === plan.lookupKey);
  if (found) {
    console.log(`ok       ${plan.lookupKey} (${found.id})`);
    continue;
  }
  const product = await stripe.products.create({
    name: `Plano ${plan.name}`,
    description: `${plan.docs} documentos analisados por mês`,
    metadata: { plan_lookup_key: plan.lookupKey },
  });
  const price = await stripe.prices.create({
    product: product.id,
    currency: "brl",
    unit_amount: plan.amount,
    recurring: { interval: "month" },
    lookup_key: plan.lookupKey,
  });
  console.log(`criado   ${plan.lookupKey} (${price.id})`);
}
console.log("\nConfigure também o portal do cliente: https://dashboard.stripe.com/test/settings/billing/portal");
