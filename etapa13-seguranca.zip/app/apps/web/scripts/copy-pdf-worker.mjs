// Copia o worker do PDF.js (mesma versão usada pelo react-pdf) para public/,
// servido como /pdf.worker.min.mjs. Roda após cada `pnpm install`.
import { copyFileSync, mkdirSync } from "node:fs";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const reactPdf = require.resolve("react-pdf/package.json");
const pdfjs = createRequire(reactPdf).resolve("pdfjs-dist/build/pdf.worker.min.mjs");
mkdirSync(new URL("../public/", import.meta.url), { recursive: true });
copyFileSync(pdfjs, new URL("../public/pdf.worker.min.mjs", import.meta.url));
