-- =============================================================================
-- Etapa 11 · Comparação de versões
-- =============================================================================
-- Uma nova versão é um documento novo, ligado ao anterior (parent). Herda
-- cliente, responsável e perspectiva. Ao concluir a análise, o worker compara
-- texto e riscos com a versão anterior e grava em document_comparisons; riscos
-- mantidos herdam a situação marcada na versão anterior (aceito, em
-- negociação...), para o advogado não refazer o trabalho.
-- A nova versão é analisada por inteiro e conta na cota como um documento.
-- =============================================================================

alter table public.documents
  add column parent_document_id uuid references public.documents (id) on delete set null,
  add column version_number     integer not null default 1 check (version_number >= 1);

-- Histórico linear: cada versão tem no máximo uma versão seguinte.
create unique index documents_one_child on public.documents (parent_document_id) where parent_document_id is not null;

create table public.document_comparisons (
  document_id           uuid primary key references public.documents (id) on delete cascade,
  previous_document_id  uuid references public.documents (id) on delete set null,
  office_id             uuid not null references public.offices (id) on delete cascade,
  text_changes          jsonb not null,
  risk_changes          jsonb not null,
  stats                 jsonb not null,
  created_at            timestamptz not null default now()
);

alter table public.document_comparisons enable row level security;
revoke all on public.document_comparisons from anon, authenticated;
grant select on public.document_comparisons to authenticated;
create policy document_comparisons_select on public.document_comparisons for select to authenticated
  using (office_id = (select public.current_office_id()));

-- Liga o documento recém-criado (ainda 'uploading') à versão anterior.
create or replace function public.set_document_parent(p_document_id uuid, p_parent_id uuid)
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid := public.current_office_id();
  v_doc    public.documents%rowtype;
  v_parent public.documents%rowtype;
begin
  select * into v_doc from public.documents where id = p_document_id and office_id = v_office for update;
  select * into v_parent from public.documents where id = p_parent_id and office_id = v_office;
  if v_doc.id is null or v_parent.id is null then
    raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001';
  end if;
  if v_doc.status <> 'uploading' or v_doc.uploaded_by is distinct from auth.uid() or v_doc.parent_document_id is not null then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;
  if v_parent.status <> 'ready' then
    raise exception 'DOCUMENT_NOT_READY' using errcode = 'P0001';
  end if;
  if exists (select 1 from public.documents c where c.parent_document_id = p_parent_id) then
    raise exception 'VERSION_EXISTS' using errcode = 'P0001';
  end if;

  update public.documents set
    parent_document_id = p_parent_id,
    version_number = v_parent.version_number + 1,
    client_id = coalesce(client_id, v_parent.client_id),
    assignee_id = coalesce(v_parent.assignee_id, assignee_id),
    client_party_name = v_parent.client_party_name,
    client_party_role = v_parent.client_party_role,
    review_status = 'em_revisao'
  where id = p_document_id;

  return v_parent.version_number + 1;
end;
$$;

-- Todas as versões da mesma cadeia, da primeira à última.
create or replace function public.document_versions(p_document_id uuid)
returns table (id uuid, version_number integer, file_name text, status public.document_status, created_at timestamptz,
               review_status public.review_status, has_comparison boolean)
language sql
stable
security definer
set search_path = ''
as $$
  with recursive up as (
    select d.id, d.parent_document_id from public.documents d
    where d.id = p_document_id and d.office_id = public.current_office_id()
    union all
    select p.id, p.parent_document_id from public.documents p join up on p.id = up.parent_document_id
  ), root as (
    select id from up where parent_document_id is null
  ), down as (
    select d.id from public.documents d join root on d.id = root.id
    union all
    select c.id from public.documents c join down on c.parent_document_id = down.id
  )
  select d.id, d.version_number, d.file_name, d.status, d.created_at, d.review_status,
         exists (select 1 from public.document_comparisons dc where dc.document_id = d.id)
  from public.documents d join down on down.id = d.id
  where d.office_id = public.current_office_id()
  order by d.version_number
$$;

-- -----------------------------------------------------------------------------
-- Worker
-- -----------------------------------------------------------------------------
-- Entradas da comparação; null se o documento não tem versão anterior pronta.
create or replace function public.worker_comparison_inputs(p_document_id uuid)
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select jsonb_build_object(
    'previous_id', p.id,
    'old_pages', (select coalesce(jsonb_agg(jsonb_build_object('page', pg.page_number, 'text', pg.text) order by pg.page_number), '[]')
                  from public.document_pages pg where pg.document_id = p.id),
    'new_pages', (select coalesce(jsonb_agg(jsonb_build_object('page', pg.page_number, 'text', pg.text) order by pg.page_number), '[]')
                  from public.document_pages pg where pg.document_id = d.id),
    'old_risks', (select coalesce(jsonb_agg(jsonb_build_object('id', r.id, 'title', r.title, 'excerpt', r.excerpt, 'level', r.level,
                    'resolution', r.resolution, 'note', r.resolution_note) order by r.position), '[]')
                  from public.risks r where r.document_id = p.id),
    'new_risks', (select coalesce(jsonb_agg(jsonb_build_object('id', r.id, 'title', r.title, 'excerpt', r.excerpt, 'level', r.level)
                    order by r.position), '[]')
                  from public.risks r where r.document_id = d.id)
  )
  from public.documents d
  join public.documents p on p.id = d.parent_document_id
  where d.id = p_document_id and p.status = 'ready'
$$;

-- Grava a comparação e herda a situação dos riscos mantidos.
-- p_inherit: [{"new_risk_id": "...", "resolution": "negociado", "note": "..."}]
create or replace function public.worker_save_comparison(
  p_document_id uuid,
  p_previous_id uuid,
  p_text        jsonb,
  p_risks       jsonb,
  p_stats       jsonb,
  p_inherit     jsonb
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid;
begin
  select office_id into v_office from public.documents where id = p_document_id;
  if v_office is null then return; end if;

  insert into public.document_comparisons (document_id, previous_document_id, office_id, text_changes, risk_changes, stats)
  values (p_document_id, p_previous_id, v_office, p_text, p_risks, p_stats)
  on conflict (document_id) do update
    set previous_document_id = excluded.previous_document_id, text_changes = excluded.text_changes,
        risk_changes = excluded.risk_changes, stats = excluded.stats, created_at = now();

  update public.risks r
  set resolution = (x ->> 'resolution')::public.risk_resolution,
      resolution_note = left(coalesce(x ->> 'note', ''), 1000),
      resolved_at = now()
  from jsonb_array_elements(coalesce(p_inherit, '[]'::jsonb)) x
  where r.id = (x ->> 'new_risk_id')::uuid and r.document_id = p_document_id
    and r.resolution = 'aberto' and (x ->> 'resolution') in ('aceito', 'negociado', 'resolvido');
end;
$$;

revoke execute on function public.set_document_parent(uuid, uuid) from public, anon;
revoke execute on function public.document_versions(uuid) from public, anon;
grant execute on function public.set_document_parent(uuid, uuid) to authenticated;
grant execute on function public.document_versions(uuid) to authenticated;
revoke execute on function public.worker_comparison_inputs(uuid) from public, anon, authenticated;
revoke execute on function public.worker_save_comparison(uuid, uuid, jsonb, jsonb, jsonb, jsonb) from public, anon, authenticated;
grant execute on function public.worker_comparison_inputs(uuid) to service_role;
grant execute on function public.worker_save_comparison(uuid, uuid, jsonb, jsonb, jsonb, jsonb) to service_role;
