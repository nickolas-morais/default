-- =============================================================================
-- Etapa 6 · Parte 2 · Painel da plataforma, venda assistida e contratos manuais
-- =============================================================================
-- Administradores da plataforma (você e sua equipe) NÃO são um papel dentro dos
-- escritórios. Eles acessam /admin por funções security definer que:
--   1. conferem platform_admins E sessão com verificação em duas etapas (aal2);
--   2. nunca devolvem conteúdo de documentos, análises ou resumos (sigilo
--      profissional e LGPD): só metadados, uso, plano e custo;
--   3. registram toda alteração em platform_audit_logs.
-- O primeiro administrador é cadastrado por SQL (ver README); não há tela para
-- alguém se promover.
--
-- Direito de uso, por prioridade: contrato manual vigente > assinatura Stripe
-- > avaliação (padrão 14 dias/5 documentos, ajustável por escritório) > nenhum.
-- =============================================================================

create table public.platform_admins (
  user_id     uuid primary key references auth.users (id) on delete cascade,
  created_at  timestamptz not null default now()
);

create table public.platform_audit_logs (
  id          bigint generated always as identity primary key,
  admin_id    uuid references auth.users (id) on delete set null,
  action      text not null,
  office_id   uuid,               -- sem FK: o registro sobrevive à exclusão
  details     jsonb not null default '{}',
  created_at  timestamptz not null default now()
);
create index platform_audit_logs_office_idx on public.platform_audit_logs (office_id, created_at desc);

create type public.contract_billing as enum ('boleto', 'nota_fiscal', 'transferencia', 'outro');

create table public.manual_contracts (
  id              uuid primary key default gen_random_uuid(),
  office_id       uuid not null references public.offices (id) on delete cascade,
  plan_id         text references public.plans (id),
  doc_limit       integer not null check (doc_limit > 0),     -- documentos por mês
  starts_at       timestamptz not null,
  ends_at         timestamptz not null,
  billing_method  public.contract_billing not null,
  notes           text not null default '' check (char_length(notes) <= 1000),
  created_by      uuid references auth.users (id) on delete set null,
  created_at      timestamptz not null default now(),
  cancelled_at    timestamptz,
  check (ends_at > starts_at)
);
create index manual_contracts_office_idx on public.manual_contracts (office_id, ends_at desc);

alter table public.offices
  add column trial_ends_at    timestamptz,     -- null = padrão (criação + 14 dias)
  add column trial_doc_limit  integer check (trial_doc_limit > 0),
  add column suspended_at     timestamptz,
  add column suspended_reason text check (char_length(suspended_reason) <= 300),
  add column created_by_platform boolean not null default false;

alter table public.platform_admins     enable row level security;
alter table public.platform_audit_logs enable row level security;
alter table public.manual_contracts    enable row level security;
revoke all on public.platform_admins, public.platform_audit_logs, public.manual_contracts from anon, authenticated;
-- O escritório vê os próprios contratos (vigência e limite), não as notas internas.
grant select (id, office_id, plan_id, doc_limit, starts_at, ends_at, cancelled_at) on public.manual_contracts to authenticated;
create policy manual_contracts_select on public.manual_contracts for select to authenticated
  using (office_id = (select public.current_office_id()));

-- -----------------------------------------------------------------------------
-- Convite de titular (escritório criado pela plataforma, ainda sem titular)
-- -----------------------------------------------------------------------------
alter table public.office_invitations drop constraint office_invitations_role_check;
alter table public.office_invitations add constraint office_invitations_owner_only_platform
  check (role <> 'owner' or invited_by is null);

create or replace function private.consume_invitation(p_token text, p_user_id uuid, p_email text)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_inv public.office_invitations%rowtype;
begin
  select * into v_inv from public.office_invitations
  where token_hash = private.hash_token(p_token) for update;

  if not found then
    raise exception 'INVITE_INVALID' using errcode = 'P0001';
  elsif v_inv.revoked_at is not null then
    raise exception 'INVITE_REVOKED' using errcode = 'P0001';
  elsif v_inv.accepted_at is not null then
    raise exception 'INVITE_USED' using errcode = 'P0001';
  elsif v_inv.expires_at <= now() then
    raise exception 'INVITE_EXPIRED' using errcode = 'P0001';
  elsif v_inv.email <> lower(btrim(p_email)) then
    raise exception 'INVITE_EMAIL_MISMATCH' using errcode = 'P0001';
  elsif v_inv.role = 'owner' and exists (
    select 1 from public.office_members m where m.office_id = v_inv.office_id and m.role = 'owner'
  ) then
    raise exception 'INVITE_INVALID' using errcode = 'P0001';
  end if;

  begin
    insert into public.office_members (office_id, user_id, role) values (v_inv.office_id, p_user_id, v_inv.role);
  exception when unique_violation then
    raise exception 'ALREADY_HAS_OFFICE' using errcode = 'P0001';
  end;

  update public.office_invitations set accepted_at = now(), accepted_by = p_user_id where id = v_inv.id;
  return v_inv.office_id;
end;
$$;

-- -----------------------------------------------------------------------------
-- Direito de uso (substitui a versão da etapa 5)
-- -----------------------------------------------------------------------------
drop function public.current_entitlement();
drop function private.office_entitlement(uuid);

create function private.office_entitlement(p_office_id uuid)
returns table (
  plan_id text, plan_name text, doc_limit integer, period_start timestamptz, period_end timestamptz,
  source text,           -- 'contract' | 'subscription' | 'trial' | 'none'
  subscription_status text, cancel_at_period_end boolean, valid_until timestamptz
)
language plpgsql
stable
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_contract public.manual_contracts%rowtype;
  v_sub      public.subscriptions%rowtype;
  v_plan     public.plans%rowtype;
  v_office   public.offices%rowtype;
  v_months   integer;
  v_start    timestamptz;
  v_trial_end timestamptz;
begin
  -- 1. Contrato manual vigente: ciclos mensais a partir do início do contrato.
  select * into v_contract from public.manual_contracts c
  where c.office_id = p_office_id and c.cancelled_at is null and c.starts_at <= now() and c.ends_at > now()
  order by c.ends_at desc limit 1;
  if found then
    v_months := (extract(year from age(now(), v_contract.starts_at)) * 12
               + extract(month from age(now(), v_contract.starts_at)))::integer;
    v_start := v_contract.starts_at + make_interval(months => v_months);
    select * into v_plan from public.plans p where p.id = v_contract.plan_id;
    return query select v_contract.plan_id, coalesce(v_plan.name, 'Contrato personalizado'), v_contract.doc_limit,
      v_start, least(v_start + interval '1 month', v_contract.ends_at), 'contract'::text, null::text,
      false, v_contract.ends_at;
    return;
  end if;

  -- 2. Assinatura Stripe.
  select * into v_sub from public.subscriptions s where s.office_id = p_office_id;
  if found and v_sub.status in ('active', 'trialing', 'past_due') and v_sub.plan_id is not null then
    select * into v_plan from public.plans p where p.id = v_sub.plan_id;
    return query select v_plan.id, v_plan.name, v_plan.monthly_doc_limit,
      coalesce(v_sub.current_period_start, date_trunc('month', now())),
      coalesce(v_sub.current_period_end, date_trunc('month', now()) + interval '1 month'),
      'subscription'::text, v_sub.status, v_sub.cancel_at_period_end, v_sub.current_period_end;
    return;
  end if;

  -- 3. Avaliação (padrão 14 dias/5 documentos; ajustável pelo painel).
  select * into v_office from public.offices o where o.id = p_office_id;
  v_trial_end := coalesce(v_office.trial_ends_at, v_office.created_at + interval '14 days');
  if now() < v_trial_end then
    return query select 'avaliacao'::text, 'Avaliação gratuita'::text, coalesce(v_office.trial_doc_limit, 5),
      v_office.created_at, v_trial_end, 'trial'::text, v_sub.status, false, v_trial_end;
    return;
  end if;

  return query select null::text, null::text, 0, null::timestamptz, null::timestamptz, 'none'::text,
    v_sub.status, false, null::timestamptz;
end;
$$;

create function public.current_entitlement()
returns table (
  plan_id text, plan_name text, doc_limit integer, period_start timestamptz, period_end timestamptz,
  source text, subscription_status text, cancel_at_period_end boolean, used integer, reserved integer,
  valid_until timestamptz, suspended boolean
)
language sql
stable
security definer
set search_path = ''
as $$
  select e.plan_id, e.plan_name, e.doc_limit, e.period_start, e.period_end, e.source,
         e.subscription_status, e.cancel_at_period_end, coalesce(u.used, 0), coalesce(u.reserved, 0),
         e.valid_until, (o.suspended_at is not null)
  from private.office_entitlement(public.current_office_id()) e
  join public.offices o on o.id = public.current_office_id()
  left join lateral private.office_usage(public.current_office_id(), e.period_start, e.period_end) u on true
$$;
revoke execute on function public.current_entitlement() from public, anon;
grant execute on function public.current_entitlement() to authenticated;

create or replace function private.assert_quota(p_office_id uuid)
returns void
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_ent record;
  v_use record;
begin
  if exists (select 1 from public.offices o where o.id = p_office_id and o.suspended_at is not null) then
    raise exception 'OFFICE_SUSPENDED' using errcode = 'P0001';
  end if;
  if exists (select 1 from public.offices o where o.id = p_office_id and o.deletion_scheduled_for is not null) then
    raise exception 'OFFICE_DELETION_PENDING' using errcode = 'P0001';
  end if;
  select * into v_ent from private.office_entitlement(p_office_id);
  if v_ent.source = 'none' then
    raise exception 'NO_ACTIVE_PLAN' using errcode = 'P0001';
  end if;
  select * into v_use from private.office_usage(p_office_id, v_ent.period_start, v_ent.period_end);
  if v_use.used + v_use.reserved >= v_ent.doc_limit then
    raise exception 'QUOTA_EXCEEDED' using errcode = 'P0001';
  end if;
end;
$$;

-- -----------------------------------------------------------------------------
-- Acesso ao painel
-- -----------------------------------------------------------------------------
-- 'none' | 'needs_mfa' (é admin, mas a sessão não passou pela 2ª etapa) | 'ok'
create or replace function public.platform_admin_status()
returns text
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when not exists (select 1 from public.platform_admins a where a.user_id = auth.uid()) then 'none'
    when coalesce(auth.jwt() ->> 'aal', 'aal1') <> 'aal2' then 'needs_mfa'
    else 'ok'
  end
$$;
grant execute on function public.platform_admin_status() to authenticated;

create or replace function private.require_platform_admin()
returns void
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if public.platform_admin_status() <> 'ok' then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;
end;
$$;

create or replace function private.audit(p_action text, p_office uuid, p_details jsonb)
returns void
language sql
security definer
set search_path = ''
as $$
  insert into public.platform_audit_logs (admin_id, action, office_id, details)
  values (auth.uid(), p_action, p_office, coalesce(p_details, '{}'))
$$;

-- -----------------------------------------------------------------------------
-- Consultas do painel (somente metadados)
-- -----------------------------------------------------------------------------
create or replace function public.admin_list_offices(p_query text default null)
returns table (
  office_id uuid, name text, created_at timestamptz, owner_name text, owner_email text, members integer,
  source text, plan_name text, doc_limit integer, used integer, valid_until timestamptz,
  subscription_status text, ai_cost_30d numeric, documents_total integer, last_activity timestamptz,
  suspended boolean, deletion_scheduled_for timestamptz, created_by_platform boolean
)
language plpgsql
stable
security definer
set search_path = ''
as $$
#variable_conflict use_column
begin
  perform private.require_platform_admin();
  return query
  select o.id, o.name, o.created_at, ow.full_name, ow.email,
    (select count(*)::integer from public.office_members m where m.office_id = o.id),
    e.source, e.plan_name, e.doc_limit, coalesce(u.used, 0), e.valid_until, e.subscription_status,
    coalesce((select round(sum(a.cost_usd), 2) from public.ai_usage a
              where a.office_id = o.id and a.created_at > now() - interval '30 days'), 0),
    (select count(*)::integer from public.documents d where d.office_id = o.id),
    (select max(l.created_at) from public.document_access_logs l where l.office_id = o.id),
    o.suspended_at is not null, o.deletion_scheduled_for, o.created_by_platform
  from public.offices o
  left join lateral (
    select p.full_name, p.email from public.office_members m join public.profiles p on p.id = m.user_id
    where m.office_id = o.id and m.role = 'owner' limit 1
  ) ow on true
  cross join lateral private.office_entitlement(o.id) e
  left join lateral private.office_usage(o.id, e.period_start, e.period_end) u on true
  where p_query is null or btrim(p_query) = ''
     or o.name ilike '%' || btrim(p_query) || '%'
     or ow.email ilike '%' || btrim(p_query) || '%'
  order by o.created_at desc
  limit 500;
end;
$$;

create or replace function public.admin_office_detail(p_office_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v jsonb;
begin
  perform private.require_platform_admin();
  select jsonb_build_object(
    'office', (select to_jsonb(x) from (
        select o.id, o.name, o.cnpj, o.created_at, o.trial_ends_at, o.trial_doc_limit, o.daily_failure_limit,
               o.suspended_at, o.suspended_reason, o.deletion_scheduled_for, o.created_by_platform, o.stripe_customer_id
        from public.offices o where o.id = p_office_id) x),
    'entitlement', (select to_jsonb(x) from (
        select e.*, u.used, u.reserved from private.office_entitlement(p_office_id) e
        left join lateral private.office_usage(p_office_id, e.period_start, e.period_end) u on true) x),
    'members', coalesce((select jsonb_agg(x order by x.created_at) from (
        select p.full_name, p.email, m.role, m.created_at from public.office_members m
        join public.profiles p on p.id = m.user_id where m.office_id = p_office_id) x), '[]'),
    'pending_invites', coalesce((select jsonb_agg(x) from (
        select i.id, i.email, i.role, i.expires_at from public.office_invitations i
        where i.office_id = p_office_id and i.accepted_at is null and i.revoked_at is null and i.expires_at > now()) x), '[]'),
    'contracts', coalesce((select jsonb_agg(x order by x.starts_at desc) from (
        select c.id, c.plan_id, c.doc_limit, c.starts_at, c.ends_at, c.billing_method, c.notes, c.cancelled_at, c.created_at
        from public.manual_contracts c where c.office_id = p_office_id) x), '[]'),
    'subscription', (select to_jsonb(x) from (
        select s.plan_id, s.status, s.current_period_end, s.cancel_at_period_end from public.subscriptions s
        where s.office_id = p_office_id) x),
    'usage_by_month', coalesce((select jsonb_agg(x order by x.period_start desc) from (
        select c.period_start, c.documents_processed from public.usage_counters c
        where c.office_id = p_office_id order by c.period_start desc limit 12) x), '[]'),
    'ai_cost_by_month', coalesce((select jsonb_agg(x order by x.month desc) from (
        select date_trunc('month', a.created_at at time zone 'America/Sao_Paulo')::date as month,
               round(sum(a.cost_usd), 2) as cost_usd, count(distinct a.document_id) as documents
        from public.ai_usage a where a.office_id = p_office_id group by 1 order by 1 desc limit 12) x), '[]'),
    'failures_24h', (select count(*) from public.document_failures f
        where f.office_id = p_office_id and f.created_at > now() - interval '24 hours'),
    'documents_by_status', coalesce((select jsonb_object_agg(status, n) from (
        select d.status, count(*) n from public.documents d where d.office_id = p_office_id group by d.status) x), '{}'),
    'audit', coalesce((select jsonb_agg(x order by x.created_at desc) from (
        select l.action, l.details, l.created_at, p.email as admin_email from public.platform_audit_logs l
        left join public.profiles p on p.id = l.admin_id
        where l.office_id = p_office_id order by l.created_at desc limit 30) x), '[]')
  ) into v;
  if v -> 'office' is null or v -> 'office' = 'null'::jsonb then
    raise exception 'OFFICE_NOT_FOUND' using errcode = 'P0001';
  end if;
  return v;
end;
$$;

create or replace function public.admin_audit_log(p_limit integer default 100)
returns table (action text, office_id uuid, office_name text, admin_email text, details jsonb, created_at timestamptz)
language plpgsql
stable
security definer
set search_path = ''
as $$
#variable_conflict use_column
begin
  perform private.require_platform_admin();
  return query
  select l.action, l.office_id, o.name, p.email, l.details, l.created_at
  from public.platform_audit_logs l
  left join public.offices o on o.id = l.office_id
  left join public.profiles p on p.id = l.admin_id
  order by l.created_at desc limit least(greatest(p_limit, 1), 500);
end;
$$;

-- -----------------------------------------------------------------------------
-- Ações do painel (todas auditadas)
-- -----------------------------------------------------------------------------
create or replace function private.new_owner_invite(p_office_id uuid, p_email text)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_email text := lower(btrim(p_email));
  v_token text := rtrim(translate(encode(extensions.gen_random_bytes(32), 'base64'), '+/', '-_'), '=');
begin
  if v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then
    raise exception 'INVALID_EMAIL' using errcode = 'P0001';
  end if;
  if exists (select 1 from public.office_members m where m.office_id = p_office_id and m.role = 'owner') then
    raise exception 'OFFICE_HAS_OWNER' using errcode = 'P0001';
  end if;
  update public.office_invitations set revoked_at = now()
  where office_id = p_office_id and role = 'owner' and accepted_at is null and revoked_at is null;
  insert into public.office_invitations (office_id, email, role, token_hash, invited_by, expires_at)
  values (p_office_id, v_email, 'owner', private.hash_token(v_token), null, now() + interval '14 days');
  return v_token;
end;
$$;

create or replace function public.admin_create_office(
  p_name        text,
  p_owner_email text,
  p_trial_days  integer default 14,
  p_trial_docs  integer default 5
)
returns table (office_id uuid, invite_token text)
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_id    uuid;
  v_token text;
begin
  perform private.require_platform_admin();
  if char_length(btrim(coalesce(p_name, ''))) < 2 then
    raise exception 'VALIDATION' using errcode = 'P0001';
  end if;
  insert into public.offices (name, created_by_platform, trial_ends_at, trial_doc_limit)
  values (btrim(p_name), true, now() + make_interval(days => greatest(coalesce(p_trial_days, 14), 0)),
          greatest(coalesce(p_trial_docs, 5), 1))
  returning id into v_id;
  v_token := private.new_owner_invite(v_id, p_owner_email);
  perform private.audit('office.create', v_id,
    jsonb_build_object('name', btrim(p_name), 'owner_email', lower(btrim(p_owner_email)),
                       'trial_days', p_trial_days, 'trial_docs', p_trial_docs));
  return query select v_id, v_token;
end;
$$;

create or replace function public.admin_resend_owner_invite(p_office_id uuid, p_email text)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_token text;
begin
  perform private.require_platform_admin();
  v_token := private.new_owner_invite(p_office_id, p_email);
  perform private.audit('office.owner_invite', p_office_id, jsonb_build_object('email', lower(btrim(p_email))));
  return v_token;
end;
$$;

create or replace function public.admin_set_trial(p_office_id uuid, p_ends_at timestamptz, p_doc_limit integer)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform private.require_platform_admin();
  if p_doc_limit is not null and p_doc_limit < 1 then
    raise exception 'VALIDATION' using errcode = 'P0001';
  end if;
  update public.offices set trial_ends_at = p_ends_at, trial_doc_limit = p_doc_limit where id = p_office_id;
  if not found then raise exception 'OFFICE_NOT_FOUND' using errcode = 'P0001'; end if;
  perform private.audit('office.trial', p_office_id, jsonb_build_object('ends_at', p_ends_at, 'doc_limit', p_doc_limit));
end;
$$;

create or replace function public.admin_create_contract(
  p_office_id      uuid,
  p_plan_id        text,
  p_doc_limit      integer,
  p_starts_at      timestamptz,
  p_ends_at        timestamptz,
  p_billing_method public.contract_billing,
  p_notes          text default ''
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_id    uuid;
  v_limit integer := p_doc_limit;
begin
  perform private.require_platform_admin();
  if v_limit is null and p_plan_id is not null then
    select monthly_doc_limit into v_limit from public.plans where id = p_plan_id;
  end if;
  if v_limit is null or v_limit < 1 or p_ends_at <= p_starts_at then
    raise exception 'VALIDATION' using errcode = 'P0001';
  end if;
  if exists (select 1 from public.manual_contracts c where c.office_id = p_office_id and c.cancelled_at is null
             and tstzrange(c.starts_at, c.ends_at) && tstzrange(p_starts_at, p_ends_at)) then
    raise exception 'CONTRACT_OVERLAP' using errcode = 'P0001';
  end if;
  insert into public.manual_contracts (office_id, plan_id, doc_limit, starts_at, ends_at, billing_method, notes, created_by)
  values (p_office_id, p_plan_id, v_limit, p_starts_at, p_ends_at, p_billing_method, left(coalesce(p_notes, ''), 1000), auth.uid())
  returning id into v_id;
  perform private.audit('contract.create', p_office_id, jsonb_build_object(
    'contract_id', v_id, 'plan_id', p_plan_id, 'doc_limit', v_limit, 'starts_at', p_starts_at,
    'ends_at', p_ends_at, 'billing_method', p_billing_method));
  return v_id;
end;
$$;

create or replace function public.admin_cancel_contract(p_contract_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid;
begin
  perform private.require_platform_admin();
  update public.manual_contracts set cancelled_at = now()
  where id = p_contract_id and cancelled_at is null returning office_id into v_office;
  if v_office is null then raise exception 'CONTRACT_NOT_FOUND' using errcode = 'P0001'; end if;
  perform private.audit('contract.cancel', v_office, jsonb_build_object('contract_id', p_contract_id));
end;
$$;

create or replace function public.admin_set_suspension(p_office_id uuid, p_suspended boolean, p_reason text default null)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform private.require_platform_admin();
  update public.offices
  set suspended_at = case when p_suspended then coalesce(suspended_at, now()) end,
      suspended_reason = case when p_suspended then left(p_reason, 300) end
  where id = p_office_id;
  if not found then raise exception 'OFFICE_NOT_FOUND' using errcode = 'P0001'; end if;
  perform private.audit(case when p_suspended then 'office.suspend' else 'office.unsuspend' end, p_office_id,
    jsonb_build_object('reason', p_reason));
end;
$$;

create or replace function public.admin_set_failure_limit(p_office_id uuid, p_limit integer)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform private.require_platform_admin();
  update public.offices set daily_failure_limit = p_limit where id = p_office_id;
  if not found then raise exception 'OFFICE_NOT_FOUND' using errcode = 'P0001'; end if;
  perform private.audit('office.failure_limit', p_office_id, jsonb_build_object('limit', p_limit));
end;
$$;

do $$
declare
  f text;
begin
  foreach f in array array[
    'public.admin_list_offices(text)',
    'public.admin_office_detail(uuid)',
    'public.admin_audit_log(integer)',
    'public.admin_create_office(text, text, integer, integer)',
    'public.admin_resend_owner_invite(uuid, text)',
    'public.admin_set_trial(uuid, timestamptz, integer)',
    'public.admin_create_contract(uuid, text, integer, timestamptz, timestamptz, public.contract_billing, text)',
    'public.admin_cancel_contract(uuid)',
    'public.admin_set_suspension(uuid, boolean, text)',
    'public.admin_set_failure_limit(uuid, integer)'
  ] loop
    execute format('revoke execute on function %s from public, anon', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end;
$$;
