-- =============================================================================
-- Etapa 5 · Planos e pagamentos (Stripe)
-- =============================================================================
-- Direito de uso ("entitlement") do escritório, calculado em um só lugar,
-- private.office_entitlement():
--   - assinatura ativa (active, trialing ou past_due): limite do plano no
--     período de cobrança atual do Stripe;
--   - sem assinatura: avaliação gratuita de 14 dias desde a criação do
--     escritório, com 5 documentos;
--   - avaliação vencida ou assinatura cancelada: sem direito a novos envios.
-- Uso no período = documentos que entraram na cota no período + documentos em
-- andamento que ainda vão entrar (reserva, para envios simultâneos não
-- estourarem o limite). Reprocessar documento já contado não consome.
-- Preços ficam no Stripe (lookup_key); aqui só o limite de documentos.
-- =============================================================================

create table public.plans (
  id                  text primary key,                 -- 'essencial', 'profissional'...
  name                text not null,
  monthly_doc_limit   integer not null check (monthly_doc_limit > 0),
  stripe_lookup_key   text not null unique,             -- lookup_key do Price no Stripe
  description         text not null default '',
  sort_order          integer not null default 0,
  active              boolean not null default true
);

-- Valores iniciais. Ajuste limites e crie os preços correspondentes no Stripe
-- (pnpm stripe:setup cria produtos e preços de teste com estes lookup_keys).
insert into public.plans (id, name, monthly_doc_limit, stripe_lookup_key, description, sort_order) values
  ('essencial',    'Essencial',    30,  'essencial_mensal',    'Para advogados autônomos e escritórios pequenos.', 1),
  ('profissional', 'Profissional', 100, 'profissional_mensal', 'Para escritórios com volume constante de contratos.', 2),
  ('escritorio',   'Escritório',   300, 'escritorio_mensal',   'Para equipes com alto volume de análise.', 3);

alter table public.offices add column stripe_customer_id text unique;

create table public.subscriptions (
  office_id               uuid primary key references public.offices (id) on delete cascade,
  plan_id                 text references public.plans (id),
  stripe_subscription_id  text not null unique,
  stripe_price_id         text,
  status                  text not null,     -- status do Stripe
  current_period_start    timestamptz,
  current_period_end      timestamptz,
  cancel_at_period_end    boolean not null default false,
  updated_at              timestamptz not null default now()
);

-- Idempotência dos webhooks (o Stripe pode reenviar o mesmo evento).
create table public.stripe_events (
  id            text primary key,
  type          text not null,
  received_at   timestamptz not null default now()
);

alter table public.plans         enable row level security;
alter table public.subscriptions enable row level security;
alter table public.stripe_events enable row level security;
revoke all on public.plans, public.subscriptions, public.stripe_events from anon, authenticated;
grant select on public.plans to authenticated;
grant select on public.subscriptions to authenticated;

create policy plans_select on public.plans for select to authenticated using (active);
create policy subscriptions_select on public.subscriptions for select to authenticated
  using (office_id = (select public.current_office_id()));
-- stripe_events: somente service_role.

-- -----------------------------------------------------------------------------
-- Direito de uso e cota
-- -----------------------------------------------------------------------------
create or replace function private.office_entitlement(p_office_id uuid)
returns table (
  plan_id text, plan_name text, doc_limit integer, period_start timestamptz, period_end timestamptz,
  source text,           -- 'subscription' | 'trial' | 'none'
  subscription_status text, cancel_at_period_end boolean
)
language plpgsql
stable
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_sub   public.subscriptions%rowtype;
  v_plan  public.plans%rowtype;
  v_created timestamptz;
  -- Avaliação gratuita: altere aqui.
  c_trial_days constant integer := 14;
  c_trial_docs constant integer := 5;
begin
  select * into v_sub from public.subscriptions s where s.office_id = p_office_id;
  if found and v_sub.status in ('active', 'trialing', 'past_due') and v_sub.plan_id is not null then
    select * into v_plan from public.plans p where p.id = v_sub.plan_id;
    return query select v_plan.id, v_plan.name, v_plan.monthly_doc_limit,
      coalesce(v_sub.current_period_start, date_trunc('month', now())),
      coalesce(v_sub.current_period_end, date_trunc('month', now()) + interval '1 month'),
      'subscription'::text, v_sub.status, v_sub.cancel_at_period_end;
    return;
  end if;

  select o.created_at into v_created from public.offices o where o.id = p_office_id;
  if now() < v_created + make_interval(days => c_trial_days) then
    return query select 'avaliacao'::text, 'Avaliação gratuita'::text, c_trial_docs,
      v_created, v_created + make_interval(days => c_trial_days), 'trial'::text, v_sub.status, false;
  else
    return query select null::text, null::text, 0, null::timestamptz, null::timestamptz,
      'none'::text, v_sub.status, false;
  end if;
end;
$$;

-- Documentos que contam no período atual (concluídos + reservados em andamento).
create or replace function private.office_usage(p_office_id uuid, p_period_start timestamptz, p_period_end timestamptz)
returns table (used integer, reserved integer)
language sql
stable
security definer
set search_path = ''
as $$
  select
    (select count(*)::integer from public.documents d
      where d.office_id = p_office_id and d.usage_counted_at >= p_period_start and d.usage_counted_at < p_period_end),
    (select count(*)::integer from public.documents d
      where d.office_id = p_office_id and d.usage_counted_at is null
        and d.status in ('uploading', 'queued', 'preprocessing', 'analyzing')
        and d.file_deleted_at is null)
$$;

-- Para a interface (planos e uso).
create or replace function public.current_entitlement()
returns table (
  plan_id text, plan_name text, doc_limit integer, period_start timestamptz, period_end timestamptz,
  source text, subscription_status text, cancel_at_period_end boolean, used integer, reserved integer
)
language sql
stable
security definer
set search_path = ''
as $$
  select e.plan_id, e.plan_name, e.doc_limit, e.period_start, e.period_end, e.source,
         e.subscription_status, e.cancel_at_period_end, coalesce(u.used, 0), coalesce(u.reserved, 0)
  from private.office_entitlement(public.current_office_id()) e
  left join lateral private.office_usage(public.current_office_id(), e.period_start, e.period_end) u on true
  where public.current_office_id() is not null
$$;

revoke execute on function public.current_entitlement() from public, anon;
grant execute on function public.current_entitlement() to authenticated;

-- Verificação usada por upload e reprocessamento.
create or replace function private.assert_quota(p_office_id uuid)
returns void
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_ent record;
  v_use record;
begin
  select * into v_ent from private.office_entitlement(p_office_id);
  if v_ent.source = 'none' then
    raise exception 'NO_ACTIVE_PLAN' using errcode = 'P0001';
  end if;
  select * into v_use from private.office_usage(p_office_id, v_ent.period_start, v_ent.period_end);
  if v_use.used + v_use.reserved >= v_ent.doc_limit then
    raise exception 'QUOTA_EXCEEDED' using errcode = 'P0001';
  end if;
end;
$$;

-- -----------------------------------------------------------------------------
-- Aplicação da cota no upload e no reprocessamento
-- -----------------------------------------------------------------------------
-- Redefine create_document_upload (etapa 2) com a verificação da cota.
create or replace function public.create_document_upload(
  p_file_name  text,
  p_size_bytes bigint,
  p_ip         text default null,
  p_user_agent text default null
)
returns table (document_id uuid, storage_path text)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office  uuid := public.current_office_id();
  v_name    text := btrim(p_file_name);
  v_ext     text := lower(substring(btrim(p_file_name) from '\.([A-Za-z0-9]+)$'));
  v_type    public.document_file_type;
  v_id      uuid := gen_random_uuid();
  v_path    text;
  v_limit   integer;
  v_failures integer;
begin
  if v_office is null then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;

  if v_name is null or char_length(v_name) not between 1 and 255 then
    raise exception 'FILE_NAME_INVALID' using errcode = 'P0001';
  end if;

  if v_ext = 'pdf' then
    v_type := 'pdf';
  elsif v_ext = 'docx' then
    v_type := 'docx';
  else
    raise exception 'UNSUPPORTED_TYPE' using errcode = 'P0001';
  end if;

  if p_size_bytes is null or p_size_bytes <= 0 then
    raise exception 'FILE_EMPTY' using errcode = 'P0001';
  elsif p_size_bytes > 25 * 1024 * 1024 then
    raise exception 'FILE_TOO_LARGE' using errcode = 'P0001';
  end if;

  select o.daily_failure_limit into v_limit from public.offices o where o.id = v_office;
  select count(*) into v_failures
  from public.document_failures f
  where f.office_id = v_office and f.created_at > now() - interval '24 hours';
  if v_failures >= v_limit then
    raise exception 'FAILED_ATTEMPTS_LIMIT' using errcode = 'P0001';
  end if;

  if (select count(*) from public.documents d
      where d.office_id = v_office and d.status = 'uploading'
        and d.created_at > now() - interval '1 hour') >= 20 then
    raise exception 'TOO_MANY_PENDING_UPLOADS' using errcode = 'P0001';
  end if;

  -- Etapa 5: cota do plano (concluídos + em andamento).
  perform private.assert_quota(v_office);

  v_path := v_office::text || '/' || v_id::text || '/original.' || v_type::text;

  insert into public.documents (id, office_id, uploaded_by, file_name, file_type, size_bytes, original_path)
  values (v_id, v_office, auth.uid(), v_name, v_type, p_size_bytes, v_path);

  perform private.insert_access_log(v_office, v_id, auth.uid(), 'upload', v_name, p_ip, p_user_agent);

  return query select v_id, v_path;
end;
$$;

-- Reprocessar documento que nunca entrou na cota (falhou antes) exige cota.
create or replace function private.assert_quota_for_reprocess()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.kind = 'reprocess' and exists (
    select 1 from public.documents d where d.id = new.document_id and d.usage_counted_at is null
  ) then
    -- O próprio documento já aparece como reservado (status 'queued'): desconta.
    declare
      v_ent record;
      v_use record;
    begin
      select * into v_ent from private.office_entitlement(new.office_id);
      if v_ent.source = 'none' then
        raise exception 'NO_ACTIVE_PLAN' using errcode = 'P0001';
      end if;
      select * into v_use from private.office_usage(new.office_id, v_ent.period_start, v_ent.period_end);
      if v_use.used + v_use.reserved - 1 >= v_ent.doc_limit then
        raise exception 'QUOTA_EXCEEDED' using errcode = 'P0001';
      end if;
    end;
  end if;
  return new;
end;
$$;

create trigger processing_jobs_quota
  before insert on public.processing_jobs
  for each row execute function private.assert_quota_for_reprocess();

-- -----------------------------------------------------------------------------
-- Sincronização com o Stripe (somente service_role, chamada pelo webhook)
-- -----------------------------------------------------------------------------
create or replace function public.stripe_record_event(p_event_id text, p_type text)
returns boolean     -- false = evento já processado
language sql
security definer
set search_path = ''
as $$
  with ins as (
    insert into public.stripe_events (id, type) values (p_event_id, p_type)
    on conflict (id) do nothing
    returning 1
  )
  select exists (select 1 from ins)
$$;

create or replace function public.stripe_set_customer(p_office_id uuid, p_customer_id text)
returns void
language sql
security definer
set search_path = ''
as $$
  update public.offices set stripe_customer_id = p_customer_id
  where id = p_office_id and (stripe_customer_id is null or stripe_customer_id = p_customer_id)
$$;

create or replace function public.stripe_upsert_subscription(
  p_customer_id          text,
  p_subscription_id      text,
  p_price_lookup_key     text,
  p_price_id             text,
  p_status               text,
  p_period_start         timestamptz,
  p_period_end           timestamptz,
  p_cancel_at_period_end boolean
)
returns boolean     -- false = cliente desconhecido
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid;
  v_plan   text;
begin
  select id into v_office from public.offices where stripe_customer_id = p_customer_id;
  if v_office is null then
    return false;
  end if;
  select id into v_plan from public.plans where stripe_lookup_key = p_price_lookup_key;

  insert into public.subscriptions as s (office_id, plan_id, stripe_subscription_id, stripe_price_id, status,
    current_period_start, current_period_end, cancel_at_period_end, updated_at)
  values (v_office, v_plan, p_subscription_id, p_price_id, p_status, p_period_start, p_period_end,
    coalesce(p_cancel_at_period_end, false), now())
  on conflict (office_id) do update set
    plan_id = excluded.plan_id,
    stripe_subscription_id = excluded.stripe_subscription_id,
    stripe_price_id = excluded.stripe_price_id,
    status = excluded.status,
    current_period_start = excluded.current_period_start,
    current_period_end = excluded.current_period_end,
    cancel_at_period_end = excluded.cancel_at_period_end,
    updated_at = now()
  -- Evento antigo de outra assinatura (ex.: a cancelada, depois de uma nova)
  -- não sobrescreve a assinatura ativa.
  where s.stripe_subscription_id = excluded.stripe_subscription_id
     or s.status not in ('active', 'trialing', 'past_due')
     or excluded.status in ('active', 'trialing', 'past_due');

  return true;
end;
$$;

revoke execute on function public.stripe_record_event(text, text) from public, anon, authenticated;
revoke execute on function public.stripe_set_customer(uuid, text) from public, anon, authenticated;
revoke execute on function public.stripe_upsert_subscription(text, text, text, text, text, timestamptz, timestamptz, boolean) from public, anon, authenticated;
grant execute on function public.stripe_record_event(text, text) to service_role;
grant execute on function public.stripe_set_customer(uuid, text) to service_role;
grant execute on function public.stripe_upsert_subscription(text, text, text, text, text, timestamptz, timestamptz, boolean) to service_role;
