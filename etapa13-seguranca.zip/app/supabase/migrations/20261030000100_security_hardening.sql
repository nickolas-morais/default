-- =============================================================================
-- Segurança · Reforços finais antes do deploy
-- =============================================================================
-- 1. Busca: % e _ digitados pelo usuário viram texto literal (antes, "%"
--    listava tudo e "_" casava qualquer letra; não era injeção de SQL, mas
--    permitia buscas caras).
-- 2. Rate limit por chave (não só por usuário), usado onde não há login.
-- 3. Limite no calendário assinado (endereço público com token) e nas
--    visualizações e downloads de documentos (registro de acesso).
-- 4. Limite para rotas só de leitura (exportação de dados).
-- =============================================================================

create or replace function private.like_contains(p text)
returns text
language sql
immutable
set search_path = ''
as $$
  select '%' || replace(replace(replace(btrim(coalesce(p, '')), '\', '\\'), '%', '\%'), '_', '\_') || '%'
$$;

-- Rate limit por chave arbitrária (o private.rate_limit usa o usuário logado).
create or replace function private.rate_limit_key(p_key text, p_max integer, p_window interval)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_start timestamptz := to_timestamp(floor(extract(epoch from now()) / extract(epoch from p_window)) * extract(epoch from p_window));
  v_hits  integer;
begin
  insert into private.rate_limits (key, window_start, hits) values (p_key, v_start, 1)
  on conflict (key, window_start) do update set hits = private.rate_limits.hits + 1
  returning hits into v_hits;
  if v_hits > p_max then
    raise exception 'RATE_LIMITED' using errcode = 'P0001';
  end if;
end;
$$;

-- Rotas só de leitura que custam caro chamam este limite antes de responder.
-- Lista fechada de buckets: o cliente não escolhe o limite.
create or replace function public.hit_rate_limit(p_bucket text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED' using errcode = 'P0001'; end if;
  case p_bucket
    when 'export' then perform private.rate_limit('export', 10, interval '1 day');
    when 'ics' then perform private.rate_limit('ics', 120, interval '1 hour');
    else raise exception 'VALIDATION' using errcode = 'P0001';
  end case;
end;
$$;
revoke execute on function public.hit_rate_limit(text) from public, anon;
grant execute on function public.hit_rate_limit(text) to authenticated;

-- Visualizações, downloads e minutas (cada um grava no registro de acesso).
create trigger rl_access_logs before insert on public.document_access_logs
  for each row execute function private.rate_limit_trigger('access', '1200', '1 hour');

-- Calendário assinado: valida o token e limita a 240 leituras por hora por
-- endereço (as agendas leem algumas vezes por dia; mais que isso é abuso).
drop function public.calendar_feed_info(text);
create function public.calendar_feed_info(p_token text)
returns table (office_name text, include_details boolean)
language plpgsql
volatile
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_user uuid;
  v_name text;
  v_details boolean;
begin
  select f.user_id, o.name, f.include_details into v_user, v_name, v_details
  from public.calendar_feeds f
  join public.office_members m on m.user_id = f.user_id and m.office_id = f.office_id
  join public.offices o on o.id = f.office_id
  where f.token_hash = private.hash_token(p_token);
  if v_user is null then return; end if;
  perform private.rate_limit_key('feed:' || v_user::text, 240, interval '1 hour');
  return query select v_name, v_details;
end;
$$;
grant execute on function public.calendar_feed_info(text) to anon, authenticated;

create or replace function public.list_clients(p_query text default null, p_include_archived boolean default false)
returns table (
  id uuid, name text, document_number text, email text, notes text, archived_at timestamptz, created_at timestamptz,
  documents integer, pending integer, in_review integer, sent integer, approved integer,
  open_high_risks integer, last_document_at timestamptz
)
language sql
stable
security definer
set search_path = ''
as $$
  select c.id, c.name, c.document_number, c.email, c.notes, c.archived_at, c.created_at,
    count(d.id)::integer,
    count(d.id) filter (where d.review_status = 'pendente')::integer,
    count(d.id) filter (where d.review_status = 'em_revisao')::integer,
    count(d.id) filter (where d.review_status = 'enviado')::integer,
    count(d.id) filter (where d.review_status = 'aprovado')::integer,
    coalesce(sum((select count(*) from public.risks r
                  where r.document_id = d.id and r.level = 'alto' and r.resolution = 'aberto')), 0)::integer,
    max(d.created_at)
  from public.clients c
  left join public.documents d on d.client_id = c.id
  where c.office_id = public.current_office_id()
    and (p_include_archived or c.archived_at is null)
    and (nullif(btrim(p_query), '') is null
         or c.name ilike private.like_contains(p_query)
         or c.document_number = nullif(regexp_replace(upper(p_query), '[^A-Z0-9]', '', 'g'), ''))
  group by c.id
  order by c.archived_at nulls first, c.name
$$;


create or replace function public.admin_list_offices(p_query text default null)
returns table (
  office_id uuid, name text, created_at timestamptz, owner_name text, owner_email text, members integer,
  source text, plan_name text, doc_limit integer, used integer, valid_until timestamptz,
  subscription_status text, ai_cost_30d numeric, documents_total integer, last_activity timestamptz,
  suspended boolean, deletion_scheduled_for timestamptz, created_by_platform boolean
)
language plpgsql
stable
security definer
set search_path = ''
as $$
#variable_conflict use_column
begin
  perform private.require_platform_admin();
  return query
  select o.id, o.name, o.created_at, ow.full_name, ow.email,
    (select count(*)::integer from public.office_members m where m.office_id = o.id),
    e.source, e.plan_name, e.doc_limit, coalesce(u.used, 0), e.valid_until, e.subscription_status,
    coalesce((select round(sum(a.cost_usd), 2) from public.ai_usage a
              where a.office_id = o.id and a.created_at > now() - interval '30 days'), 0),
    (select count(*)::integer from public.documents d where d.office_id = o.id),
    (select max(l.created_at) from public.document_access_logs l where l.office_id = o.id),
    o.suspended_at is not null, o.deletion_scheduled_for, o.created_by_platform
  from public.offices o
  left join lateral (
    select p.full_name, p.email from public.office_members m join public.profiles p on p.id = m.user_id
    where m.office_id = o.id and m.role = 'owner' limit 1
  ) ow on true
  cross join lateral private.office_entitlement(o.id) e
  left join lateral private.office_usage(o.id, e.period_start, e.period_end) u on true
  where p_query is null or btrim(p_query) = ''
     or o.name ilike private.like_contains(p_query)
     or ow.email ilike private.like_contains(p_query)
  order by o.created_at desc
  limit 500;
end;
$$;

