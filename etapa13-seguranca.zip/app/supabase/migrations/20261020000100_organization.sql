-- =============================================================================
-- Etapa 10 · Parte 1 · Organização por cliente e status de revisão
-- =============================================================================
-- - clients: clientes finais do escritório (quem contratou o advogado).
-- - documents: cliente, advogado responsável (padrão: quem enviou) e status
--   de revisão: pendente → em_revisao → enviado (ao cliente) → aprovado.
-- - risks: situação de cada risco no trabalho do advogado: aberto, aceito
--   (risco assumido), negociado (em negociação com a outra parte), resolvido.
--   Reanálise substitui os riscos e, com eles, as situações.
-- =============================================================================

create type public.review_status as enum ('pendente', 'em_revisao', 'enviado', 'aprovado');
create type public.risk_resolution as enum ('aberto', 'aceito', 'negociado', 'resolvido');

create table public.clients (
  id               uuid primary key default gen_random_uuid(),
  office_id        uuid not null references public.offices (id) on delete cascade,
  name             text not null check (char_length(btrim(name)) between 2 and 200),
  document_number  text check (char_length(document_number) <= 20),   -- CPF/CNPJ normalizado
  email            text check (char_length(email) <= 200),
  notes            text not null default '' check (char_length(notes) <= 2000),
  archived_at      timestamptz,
  created_by       uuid references public.profiles (id) on delete set null,
  created_at       timestamptz not null default now()
);
create index clients_office_idx on public.clients (office_id, name);
create unique index clients_office_name_active on public.clients (office_id, lower(name)) where archived_at is null;

alter table public.clients enable row level security;
revoke all on public.clients from anon, authenticated;
grant select on public.clients to authenticated;
create policy clients_select on public.clients for select to authenticated
  using (office_id = (select public.current_office_id()));

alter table public.documents
  add column client_id          uuid references public.clients (id) on delete set null,
  add column assignee_id        uuid references public.profiles (id) on delete set null,
  add column review_status      public.review_status not null default 'pendente',
  add column review_updated_at  timestamptz,
  add column review_updated_by  uuid references public.profiles (id) on delete set null;
create index documents_client_idx on public.documents (client_id);
create index documents_assignee_idx on public.documents (office_id, assignee_id);

-- Responsável padrão: quem enviou.
create or replace function private.default_assignee()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.assignee_id := coalesce(new.assignee_id, new.uploaded_by);
  return new;
end;
$$;
create trigger documents_default_assignee before insert on public.documents
  for each row execute function private.default_assignee();
update public.documents set assignee_id = uploaded_by where assignee_id is null;

alter table public.risks
  add column resolution       public.risk_resolution not null default 'aberto',
  add column resolution_note  text not null default '' check (char_length(resolution_note) <= 1000),
  add column resolved_by      uuid references public.profiles (id) on delete set null,
  add column resolved_at      timestamptz;

-- -----------------------------------------------------------------------------
-- Clientes
-- -----------------------------------------------------------------------------
create or replace function public.save_client(
  p_id              uuid,       -- null = novo
  p_name            text,
  p_document_number text default null,
  p_email           text default null,
  p_notes           text default ''
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid := public.current_office_id();
  v_id     uuid;
  v_number text := nullif(regexp_replace(upper(coalesce(p_document_number, '')), '[^A-Z0-9]', '', 'g'), '');
begin
  if v_office is null then raise exception 'FORBIDDEN' using errcode = 'P0001'; end if;
  if char_length(btrim(coalesce(p_name, ''))) < 2 then raise exception 'VALIDATION' using errcode = 'P0001'; end if;
  begin
    if p_id is null then
      insert into public.clients (office_id, name, document_number, email, notes, created_by)
      values (v_office, btrim(p_name), v_number, nullif(lower(btrim(coalesce(p_email, ''))), ''),
              left(coalesce(p_notes, ''), 2000), auth.uid())
      returning id into v_id;
    else
      update public.clients
      set name = btrim(p_name), document_number = v_number, email = nullif(lower(btrim(coalesce(p_email, ''))), ''),
          notes = left(coalesce(p_notes, ''), 2000)
      where id = p_id and office_id = v_office
      returning id into v_id;
      if v_id is null then raise exception 'CLIENT_NOT_FOUND' using errcode = 'P0001'; end if;
    end if;
  exception when unique_violation then
    raise exception 'CLIENT_EXISTS' using errcode = 'P0001';
  end;
  return v_id;
end;
$$;

create or replace function public.archive_client(p_id uuid, p_archived boolean default true)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  update public.clients set archived_at = case when p_archived then now() end
  where id = p_id and office_id = public.current_office_id();
  if not found then raise exception 'CLIENT_NOT_FOUND' using errcode = 'P0001'; end if;
exception when unique_violation then
  raise exception 'CLIENT_EXISTS' using errcode = 'P0001';
end;
$$;

-- -----------------------------------------------------------------------------
-- Organização do documento e situação dos riscos (qualquer membro)
-- -----------------------------------------------------------------------------
-- Campos null não são alterados; p_clear_client / p_clear_assignee removem.
create or replace function public.set_document_organization(
  p_document_id    uuid,
  p_client_id      uuid default null,
  p_assignee_id    uuid default null,
  p_review_status  public.review_status default null,
  p_clear_client   boolean default false,
  p_clear_assignee boolean default false,
  p_ip             text default null,
  p_user_agent     text default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid := public.current_office_id();
  v_doc    public.documents%rowtype;
begin
  select * into v_doc from public.documents where id = p_document_id and office_id = v_office for update;
  if not found then raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001'; end if;

  if p_client_id is not null and not exists (
    select 1 from public.clients c where c.id = p_client_id and c.office_id = v_office and c.archived_at is null
  ) then
    raise exception 'CLIENT_NOT_FOUND' using errcode = 'P0001';
  end if;
  if p_assignee_id is not null and not exists (
    select 1 from public.office_members m where m.user_id = p_assignee_id and m.office_id = v_office
  ) then
    raise exception 'MEMBER_NOT_FOUND' using errcode = 'P0001';
  end if;

  update public.documents set
    client_id = case when p_clear_client then null else coalesce(p_client_id, client_id) end,
    assignee_id = case when p_clear_assignee then null else coalesce(p_assignee_id, assignee_id) end,
    review_status = coalesce(p_review_status, review_status),
    review_updated_at = case when p_review_status is not null and p_review_status <> v_doc.review_status then now() else review_updated_at end,
    review_updated_by = case when p_review_status is not null and p_review_status <> v_doc.review_status then auth.uid() else review_updated_by end
  where id = p_document_id;

  perform private.insert_access_log(v_office, v_doc.id, auth.uid(), 'edit', v_doc.file_name, p_ip, p_user_agent);
end;
$$;

create or replace function public.set_risk_resolution(
  p_risk_id    uuid,
  p_resolution public.risk_resolution,
  p_note       text default ''
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  update public.risks
  set resolution = p_resolution,
      resolution_note = left(coalesce(p_note, ''), 1000),
      resolved_by = case when p_resolution = 'aberto' then null else auth.uid() end,
      resolved_at = case when p_resolution = 'aberto' then null else now() end
  where id = p_risk_id and office_id = public.current_office_id();
  if not found then raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001'; end if;
end;
$$;

-- -----------------------------------------------------------------------------
-- Busca com os novos filtros e colunas (substitui a da etapa 3)
-- -----------------------------------------------------------------------------
drop function public.search_documents(text, timestamptz, timestamptz, integer, integer);

create function public.search_documents(
  p_query         text default null,
  p_from          timestamptz default null,
  p_to            timestamptz default null,
  p_limit         integer default 25,
  p_offset        integer default 0,
  p_client_id     uuid default null,
  p_assignee_id   uuid default null,
  p_review_status public.review_status default null,
  p_no_client     boolean default false
)
returns table (
  id uuid, file_name text, file_type public.document_file_type, size_bytes bigint,
  page_count integer, status public.document_status, created_at timestamptz,
  uploader_name text, parties text, total_count bigint,
  client_id uuid, client_name text, assignee_id uuid, assignee_name text, review_status public.review_status,
  open_high_risks integer
)
language sql
stable
security invoker
set search_path = ''
as $$
  with q as (
    select nullif(btrim(p_query), '') as term,
           '%' || replace(replace(replace(btrim(coalesce(p_query, '')), '\', '\\'), '%', '\%'), '_', '\_') || '%' as pattern,
           nullif(regexp_replace(upper(coalesce(p_query, '')), '[^A-Z0-9]', '', 'g'), '') as number
  )
  select d.id, d.file_name, d.file_type, d.size_bytes, d.page_count, d.status, d.created_at,
         p.full_name,
         (select string_agg(dp.name, '; ' order by dp.id) from public.document_parties dp where dp.document_id = d.id),
         count(*) over (),
         d.client_id, c.name, d.assignee_id, a.full_name, d.review_status,
         (select count(*)::integer from public.risks r where r.document_id = d.id and r.level = 'alto' and r.resolution = 'aberto')
  from public.documents d
  cross join q
  left join public.profiles p on p.id = d.uploaded_by
  left join public.profiles a on a.id = d.assignee_id
  left join public.clients c on c.id = d.client_id
  where (q.term is null
         or d.file_name ilike q.pattern
         or c.name ilike q.pattern
         or exists (
           select 1 from public.document_parties dp
           where dp.document_id = d.id
             and (dp.name ilike q.pattern
                  or (char_length(q.number) >= 11 and dp.document_number = q.number))))
    and (p_from is null or d.created_at >= p_from)
    and (p_to is null or d.created_at < p_to)
    and (p_client_id is null or d.client_id = p_client_id)
    and (not p_no_client or d.client_id is null)
    and (p_assignee_id is null or d.assignee_id = p_assignee_id)
    and (p_review_status is null or d.review_status = p_review_status)
  order by d.created_at desc
  limit least(greatest(p_limit, 1), 100)
  offset greatest(p_offset, 0)
$$;

do $$
declare
  f text;
begin
  foreach f in array array[
    'public.save_client(uuid, text, text, text, text)',
    'public.archive_client(uuid, boolean)',
    'public.set_document_organization(uuid, uuid, uuid, public.review_status, boolean, boolean, text, text)',
    'public.set_risk_resolution(uuid, public.risk_resolution, text)',
    'public.search_documents(text, timestamptz, timestamptz, integer, integer, uuid, uuid, public.review_status, boolean)'
  ] loop
    execute format('revoke execute on function %s from public, anon', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end;
$$;
