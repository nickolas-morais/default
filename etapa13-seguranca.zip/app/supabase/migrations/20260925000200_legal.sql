-- =============================================================================
-- Etapa 1 · LGPD: termos de uso, política de privacidade e registro de aceite
-- =============================================================================
-- Publicar nova versão (após revisão jurídica):
--   1. atualizar o texto em apps/web/src/content/legal/*.tsx e as constantes em
--      apps/web/src/content/legal/versions.ts;
--   2. criar uma migration inserindo a nova linha em legal_documents.
-- Usuários existentes são levados a /aceitar-termos no próximo acesso.
-- =============================================================================

create type public.legal_document_kind as enum ('terms', 'privacy');

create table public.legal_documents (
  kind          public.legal_document_kind not null,
  version       text not null check (char_length(version) between 1 and 40),
  published_at  timestamptz not null default now(),
  primary key (kind, version)
);

create table public.legal_acceptances (
  id           bigint generated always as identity primary key,
  -- ATENÇÃO JURÍDICA: com "on delete cascade", o comprovante de aceite é
  -- apagado junto com a conta. Validar com o advogado se deve ser retido.
  user_id      uuid not null references auth.users (id) on delete cascade,
  kind         public.legal_document_kind not null,
  version      text not null,
  accepted_at  timestamptz not null default now(),
  ip           inet,
  user_agent   text check (char_length(user_agent) <= 512),
  foreign key (kind, version) references public.legal_documents (kind, version),
  unique (user_id, kind, version)
);

alter table public.legal_documents   enable row level security;
alter table public.legal_acceptances enable row level security;

revoke all on public.legal_documents, public.legal_acceptances from anon, authenticated;
grant select on public.legal_documents to anon, authenticated;
grant select on public.legal_acceptances to authenticated;

create policy legal_documents_select on public.legal_documents
  for select to anon, authenticated
  using (true);

create policy legal_acceptances_select_own on public.legal_acceptances
  for select to authenticated
  using (user_id = (select auth.uid()));

-- Versão vigente = a publicada mais recentemente (até agora).
create or replace function public.current_legal_version(p_kind public.legal_document_kind)
returns text
language sql
stable
set search_path = ''
as $$
  select d.version
  from public.legal_documents d
  where d.kind = p_kind and d.published_at <= now()
  order by d.published_at desc
  limit 1
$$;

create or replace function public.has_accepted_current_legal()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select auth.uid() is not null
     and exists (
       select 1 from public.legal_acceptances a
       where a.user_id = auth.uid() and a.kind = 'terms'
         and a.version = public.current_legal_version('terms'))
     and exists (
       select 1 from public.legal_acceptances a
       where a.user_id = auth.uid() and a.kind = 'privacy'
         and a.version = public.current_legal_version('privacy'))
$$;

-- Registra aceite de versões novas (usuários já cadastrados).
-- As versões enviadas precisam ser as vigentes: evita aceite de texto antigo
-- exibido em uma aba aberta há dias.
create or replace function public.accept_current_legal(
  p_terms_version   text,
  p_privacy_version text,
  p_ip              text default null,
  p_user_agent      text default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED' using errcode = 'P0001';
  end if;

  if p_terms_version is distinct from public.current_legal_version('terms')
     or p_privacy_version is distinct from public.current_legal_version('privacy') then
    raise exception 'LEGAL_VERSION_MISMATCH' using errcode = 'P0001';
  end if;

  insert into public.legal_acceptances (user_id, kind, version, ip, user_agent)
  values
    (auth.uid(), 'terms',   p_terms_version,   private.try_inet(p_ip), left(p_user_agent, 512)),
    (auth.uid(), 'privacy', p_privacy_version, private.try_inet(p_ip), left(p_user_agent, 512))
  on conflict (user_id, kind, version) do nothing;
end;
$$;

revoke execute on function public.accept_current_legal(text, text, text, text) from public, anon;
grant execute on function public.accept_current_legal(text, text, text, text) to authenticated;

-- Versões provisórias (texto a ser substituído após revisão jurídica).
insert into public.legal_documents (kind, version, published_at) values
  ('terms',   '2026-09-provisoria', '2026-09-25 00:00:00+00'),
  ('privacy', '2026-09-provisoria', '2026-09-25 00:00:00+00');
