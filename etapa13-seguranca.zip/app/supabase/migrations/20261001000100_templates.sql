-- =============================================================================
-- Etapa 4 · Modelos de minuta
-- =============================================================================
-- O escritório envia um DOCX com variáveis {{assim}}. O servidor valida o
-- arquivo, lista as variáveis e grava o modelo em
--   documents/{office_id}/templates/{template_id}.docx
-- A minuta gerada NÃO é armazenada (minimização): é montada na hora e baixada.
-- Fica registrado apenas quem gerou, de qual documento e com qual modelo.
-- =============================================================================

create table public.templates (
  id            uuid primary key default gen_random_uuid(),
  office_id     uuid not null references public.offices (id) on delete cascade,
  name          text not null check (char_length(btrim(name)) between 2 and 120),
  description   text not null default '' check (char_length(description) <= 500),
  storage_path  text not null unique,
  variables     text[] not null default '{}',
  size_bytes    bigint not null check (size_bytes > 0),
  created_by    uuid references public.profiles (id) on delete set null,
  created_at    timestamptz not null default now(),
  check (storage_path = office_id::text || '/templates/' || id::text || '.docx'),
  check (cardinality(variables) <= 200)
);

create index templates_office_idx on public.templates (office_id, created_at desc);

create table public.draft_exports (
  id           bigint generated always as identity primary key,
  office_id    uuid not null references public.offices (id) on delete cascade,
  document_id  uuid not null references public.documents (id) on delete cascade,
  template_id  uuid references public.templates (id) on delete set null,
  created_by   uuid references public.profiles (id) on delete set null,
  created_at   timestamptz not null default now()
);

create index draft_exports_document_idx on public.draft_exports (document_id, created_at desc);

alter table public.templates     enable row level security;
alter table public.draft_exports enable row level security;
revoke all on public.templates, public.draft_exports from anon, authenticated;
grant select on public.templates, public.draft_exports to authenticated;

create policy templates_select on public.templates for select to authenticated
  using (office_id = (select public.current_office_id()));
create policy draft_exports_select on public.draft_exports for select to authenticated
  using (office_id = (select public.current_office_id()));

-- Somente titular e administradores gerenciam modelos; todos os membros usam.
create or replace function public.create_template(
  p_name        text,
  p_description text,
  p_variables   text[],
  p_size_bytes  bigint
)
returns table (template_id uuid, storage_path text)
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_office uuid := public.current_office_id();
  v_id     uuid := gen_random_uuid();
  v_path   text;
begin
  if v_office is null or not public.is_office_admin() then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;
  if char_length(btrim(coalesce(p_name, ''))) < 2 then
    raise exception 'VALIDATION' using errcode = 'P0001';
  end if;
  if (select count(*) from public.templates t where t.office_id = v_office) >= 100 then
    raise exception 'TEMPLATE_LIMIT' using errcode = 'P0001';
  end if;

  v_path := v_office::text || '/templates/' || v_id::text || '.docx';
  insert into public.templates (id, office_id, name, description, storage_path, variables, size_bytes, created_by)
  values (v_id, v_office, btrim(p_name), left(btrim(coalesce(p_description, '')), 500), v_path,
          coalesce(p_variables, '{}'), p_size_bytes, auth.uid());

  return query select v_id, v_path;
end;
$$;

-- Devolve o caminho no Storage para o servidor remover o arquivo.
create or replace function public.delete_template(p_template_id uuid)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_path text;
begin
  if not public.is_office_admin() then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;
  delete from public.templates
  where id = p_template_id and office_id = public.current_office_id()
  returning storage_path into v_path;
  if v_path is null then
    raise exception 'TEMPLATE_NOT_FOUND' using errcode = 'P0001';
  end if;
  return v_path;
end;
$$;

-- Registra a geração (chamada antes de devolver o arquivo ao usuário).
create or replace function public.record_draft_export(
  p_document_id uuid,
  p_template_id uuid,
  p_ip          text default null,
  p_user_agent  text default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_doc public.documents%rowtype;
begin
  select * into v_doc from public.documents
  where id = p_document_id and office_id = public.current_office_id();
  if not found then
    raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001';
  end if;
  if v_doc.status <> 'ready' then
    raise exception 'DOCUMENT_NOT_READY' using errcode = 'P0001';
  end if;
  if not exists (select 1 from public.templates t
                 where t.id = p_template_id and t.office_id = v_doc.office_id) then
    raise exception 'TEMPLATE_NOT_FOUND' using errcode = 'P0001';
  end if;

  insert into public.draft_exports (office_id, document_id, template_id, created_by)
  values (v_doc.office_id, v_doc.id, p_template_id, auth.uid());

  perform private.insert_access_log(v_doc.office_id, v_doc.id, auth.uid(), 'export',
                                    v_doc.file_name, p_ip, p_user_agent);
end;
$$;

revoke execute on function public.create_template(text, text, text[], bigint) from public, anon;
revoke execute on function public.delete_template(uuid) from public, anon;
revoke execute on function public.record_draft_export(uuid, uuid, text, text) from public, anon;
grant execute on function public.create_template(text, text, text[], bigint) to authenticated;
grant execute on function public.delete_template(uuid) to authenticated;
grant execute on function public.record_draft_export(uuid, uuid, text, text) to authenticated;
