-- =============================================================================
-- Etapa 7 · Parte 2 · Avisos por e-mail
-- =============================================================================
-- Avisos: análise concluída (quem enviou), cota em 80% e 100% (titular e
-- administradores), pagamento recusado e contrato perto do vencimento (titular
-- e administradores), fila acumulada (administradores da plataforma).
-- notifications_sent garante no máximo um envio por chave (ex.: um aviso de
-- 80% por escritório e período), mesmo com vários workers.
-- Preferências: o usuário desliga "análise concluída" e "cota"; avisos de
-- cobrança e contrato são sempre enviados.
-- =============================================================================

alter table public.profiles
  add column notify_analysis_done boolean not null default true,
  add column notify_quota         boolean not null default true;

grant update (notify_analysis_done, notify_quota) on public.profiles to authenticated;

create table public.notifications_sent (
  key        text primary key,
  kind       text not null,
  created_at timestamptz not null default now()
);
alter table public.notifications_sent enable row level security;
revoke all on public.notifications_sent from anon, authenticated;

-- Reserva a chave antes de enviar; false = já enviado (ou em envio por outro processo).
create or replace function public.notify_claim(p_key text, p_kind text)
returns boolean
language sql
security definer
set search_path = ''
as $$
  with ins as (
    insert into public.notifications_sent (key, kind) values (p_key, p_kind)
    on conflict (key) do nothing returning 1
  )
  select exists (select 1 from ins)
$$;

-- Libera a chave se o envio falhar, para tentar de novo depois.
create or replace function public.notify_release(p_key text)
returns void
language sql
security definer
set search_path = ''
as $$
  delete from public.notifications_sent where key = p_key
$$;

-- Titular e administradores do escritório (opcionalmente só quem aceita avisos de cota).
create or replace function public.notify_office_admins(p_office_id uuid, p_only_quota_optin boolean default false)
returns table (email text, full_name text, office_name text)
language sql
stable
security definer
set search_path = ''
as $$
  select p.email, p.full_name, o.name
  from public.office_members m
  join public.profiles p on p.id = m.user_id
  join public.offices o on o.id = m.office_id
  where m.office_id = p_office_id and m.role in ('owner', 'admin')
    and (not p_only_quota_optin or p.notify_quota)
$$;

-- Quem enviou o documento, se aceita o aviso de análise concluída.
create or replace function public.notify_document_uploader(p_document_id uuid)
returns table (email text, full_name text, file_name text, risks integer, high_risks integer)
language sql
stable
security definer
set search_path = ''
as $$
  select p.email, p.full_name, d.file_name,
    (select count(*)::integer from public.risks r where r.document_id = d.id),
    (select count(*)::integer from public.risks r where r.document_id = d.id and r.level = 'alto')
  from public.documents d
  join public.profiles p on p.id = d.uploaded_by
  where d.id = p_document_id and d.status = 'ready' and p.notify_analysis_done
$$;

-- Uso da cota no período atual (para os avisos de 80% e 100%).
create or replace function public.notify_quota_status(p_office_id uuid)
returns table (source text, plan_name text, doc_limit integer, used integer, period_start timestamptz, period_end timestamptz)
language sql
stable
security definer
set search_path = ''
as $$
  select e.source, e.plan_name, e.doc_limit, coalesce(u.used, 0), e.period_start, e.period_end
  from private.office_entitlement(p_office_id) e
  left join lateral private.office_usage(p_office_id, e.period_start, e.period_end) u on true
$$;

-- Contratos manuais que vencem em até 15 dias (o worker avisa aos 15 e aos 3 dias).
create or replace function public.notify_expiring_contracts()
returns table (contract_id uuid, office_id uuid, ends_at timestamptz, days_left integer)
language sql
stable
security definer
set search_path = ''
as $$
  select c.id, c.office_id, c.ends_at, ceil(extract(epoch from (c.ends_at - now())) / 86400)::integer
  from public.manual_contracts c
  where c.cancelled_at is null and c.ends_at > now() and c.ends_at <= now() + interval '15 days'
    -- Já renovado (contrato seguinte registrado): não avisa.
    and not exists (select 1 from public.manual_contracts n
                    where n.office_id = c.office_id and n.cancelled_at is null and n.starts_at >= c.ends_at - interval '1 day'
                      and n.id <> c.id)
$$;

-- Fila: documentos esperando há mais de p_minutes.
create or replace function public.notify_queue_backlog(p_minutes integer default 15)
returns table (waiting integer, oldest_minutes integer)
language sql
stable
security definer
set search_path = ''
as $$
  select count(*)::integer,
         coalesce(max(extract(epoch from (now() - d.queued_at)) / 60), 0)::integer
  from public.documents d
  where d.status = 'queued' and d.queued_at < now() - make_interval(mins => p_minutes)
$$;

create or replace function public.notify_platform_admins()
returns table (email text)
language sql
stable
security definer
set search_path = ''
as $$
  select u.email from public.platform_admins a join auth.users u on u.id = a.user_id
$$;

do $$
declare
  f text;
begin
  foreach f in array array[
    'public.notify_claim(text, text)',
    'public.notify_release(text)',
    'public.notify_office_admins(uuid, boolean)',
    'public.notify_document_uploader(uuid)',
    'public.notify_quota_status(uuid)',
    'public.notify_expiring_contracts()',
    'public.notify_queue_backlog(integer)',
    'public.notify_platform_admins()'
  ] loop
    execute format('revoke execute on function %s from public, anon, authenticated', f);
    execute format('grant execute on function %s to service_role', f);
  end loop;
end;
$$;
