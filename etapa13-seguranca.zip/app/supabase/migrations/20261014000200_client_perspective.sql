-- =============================================================================
-- Etapa 8 · "Nosso cliente é…": análise do ponto de vista de uma das partes
-- =============================================================================
-- documents.client_party_* guarda a parte representada pelo escritório (null =
-- análise neutra). Trocar a perspectiva cria um job 'perspective', que refaz
-- riscos e resumo mantendo os dados extraídos e as edições. Reprocessamentos
-- mantêm a perspectiva escolhida. Não consome cota; conta no limite de 3
-- reprocessamentos por documento em 24 h (junto com "Reprocessar").
-- =============================================================================

alter table public.documents
  add column client_party_name text check (char_length(client_party_name) between 1 and 200),
  add column client_party_role text check (char_length(client_party_role) <= 120);

-- O worker recebe a perspectiva junto com o job.
drop function public.worker_start_job(uuid);

create function public.worker_start_job(p_job_id uuid)
returns table (
  document_id uuid, office_id uuid, file_type public.document_file_type,
  original_path text, kind public.job_kind, attempts integer,
  client_party_name text, client_party_role text
)
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_job public.processing_jobs%rowtype;
begin
  select * into v_job from public.processing_jobs where id = p_job_id for update;
  if not found or v_job.status in ('succeeded', 'failed') then
    return;
  end if;

  update public.documents d
  set status = 'preprocessing', processing_started_at = now()
  where d.id = v_job.document_id and d.status in ('queued', 'preprocessing', 'analyzing')
    and d.file_deleted_at is null;
  if not found then
    update public.processing_jobs set status = 'failed', error_code = 'DOCUMENT_NOT_FOUND', finished_at = now()
    where id = p_job_id;
    return;
  end if;

  update public.processing_jobs
  set status = 'running', attempts = attempts + 1, started_at = coalesce(started_at, now())
  where id = p_job_id;

  return query
  select d.id, d.office_id, d.file_type, d.original_path, v_job.kind, v_job.attempts + 1,
         d.client_party_name, d.client_party_role
  from public.documents d where d.id = v_job.document_id;
end;
$$;

revoke execute on function public.worker_start_job(uuid) from public, anon, authenticated;
grant execute on function public.worker_start_job(uuid) to service_role;

create or replace function public.worker_complete_job(
  p_job_id         uuid,
  p_result         jsonb,
  p_prompt_version text,
  p_prepare_ms     integer,
  p_ai_ms          integer
)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_job    public.processing_jobs%rowtype;
  v_doc    public.documents%rowtype;
  v_period date := date_trunc('month', now() at time zone 'America/Sao_Paulo')::date;
begin
  select * into v_job from public.processing_jobs where id = p_job_id for update;
  select * into v_doc from public.documents where id = v_job.document_id for update;
  if not found then
    update public.processing_jobs set status = 'failed', error_code = 'DOCUMENT_NOT_FOUND', finished_at = now()
    where id = p_job_id;
    return false;
  end if;

  -- Mudança de perspectiva refaz só riscos e resumo: os dados extraídos (e as
  -- edições do advogado) são mantidos.
  if v_job.kind::text <> 'perspective' then
    insert into public.extractions (document_id, office_id, ai_data)
    values (v_doc.id, v_doc.office_id, p_result -> 'extracao')
    on conflict (document_id) do update
      set ai_data = excluded.ai_data, edited_data = null, edited_by = null, edited_at = null;

    perform private.sync_parties(v_doc.id);
  end if;

  delete from public.risks where document_id = v_doc.id;
  insert into public.risks (document_id, office_id, position, level, title, clause_ref, excerpt,
    explanation, suggestion, affected_party, page_number, match_score)
  select v_doc.id, v_doc.office_id, r.ord::integer, lower(r.item ->> 'nivel')::public.risk_level,
         r.item ->> 'titulo', coalesce(r.item ->> 'clausula', ''), r.item ->> 'trecho_original',
         r.item ->> 'explicacao', r.item ->> 'sugestao_redacao', coalesce(r.item ->> 'parte_prejudicada', ''),
         nullif(r.item ->> 'pagina_localizada', '')::integer, nullif(r.item ->> 'score', '')::real
  from jsonb_array_elements(p_result -> 'riscos') with ordinality as r(item, ord);

  insert into public.summaries (document_id, office_id, ai_content)
  values (v_doc.id, v_doc.office_id, p_result ->> 'resumo')
  on conflict (document_id) do update
    set ai_content = excluded.ai_content, edited_content = null, edited_by = null, edited_at = null;

  update public.documents
  set status = 'ready', processed_at = now(), prompt_version = p_prompt_version,
      error_code = null, failed_at = null,
      usage_counted_at = coalesce(usage_counted_at, now())
  where id = v_doc.id;

  -- Cota: só na primeira conclusão do documento.
  if v_doc.usage_counted_at is null then
    insert into public.usage_counters (office_id, period_start, documents_processed)
    values (v_doc.office_id, v_period, 1)
    on conflict (office_id, period_start)
      do update set documents_processed = public.usage_counters.documents_processed + 1;
  end if;

  update public.processing_jobs
  set status = 'succeeded', finished_at = now(), prepare_ms = p_prepare_ms, ai_ms = p_ai_ms,
      duration_ms = (extract(epoch from (now() - started_at)) * 1000)::integer, error_code = null
  where id = p_job_id;

  return true;
end;
$$;


create or replace function public.request_document_reprocess(
  p_document_id uuid,
  p_ip          text default null,
  p_user_agent  text default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_doc      public.documents%rowtype;
  v_limit    integer;
  v_failures integer;
begin
  if not public.can_delete_document(p_document_id) then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;

  select * into v_doc from public.documents where id = p_document_id for update;

  if v_doc.status not in ('ready', 'failed') or v_doc.file_deleted_at is not null then
    raise exception 'DOCUMENT_NOT_READY' using errcode = 'P0001';
  end if;

  if (select count(*) from public.processing_jobs j
      where j.document_id = p_document_id and j.kind::text in ('reprocess', 'perspective')
        and j.created_at > now() - interval '24 hours') >= 3 then
    raise exception 'REPROCESS_LIMIT' using errcode = 'P0001';
  end if;

  select o.daily_failure_limit into v_limit from public.offices o where o.id = v_doc.office_id;
  select count(*) into v_failures from public.document_failures f
  where f.office_id = v_doc.office_id and f.created_at > now() - interval '24 hours';
  if v_failures >= v_limit then
    raise exception 'FAILED_ATTEMPTS_LIMIT' using errcode = 'P0001';
  end if;

  update public.documents
  set status = 'queued', error_code = null, failed_at = null, queued_at = now()
  where id = p_document_id;

  perform private.enqueue_document(p_document_id, 'reprocess', auth.uid());
  perform private.insert_access_log(v_doc.office_id, v_doc.id, auth.uid(), 'reprocess',
                                    v_doc.file_name, p_ip, p_user_agent);
end;
$$;


-- Qualquer membro do escritório escolhe a perspectiva (decisão de trabalho,
-- não administrativa). p_name null = voltar à análise neutra.
create or replace function public.request_document_perspective(
  p_document_id uuid,
  p_name        text,
  p_role        text default null,
  p_ip          text default null,
  p_user_agent  text default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_doc  public.documents%rowtype;
  v_name text := nullif(left(btrim(coalesce(p_name, '')), 200), '');
  v_role text := nullif(left(btrim(coalesce(p_role, '')), 120), '');
begin
  select * into v_doc from public.documents
  where id = p_document_id and office_id = public.current_office_id() for update;
  if not found then
    raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001';
  end if;
  if v_doc.status <> 'ready' or v_doc.file_deleted_at is not null then
    raise exception 'DOCUMENT_NOT_READY' using errcode = 'P0001';
  end if;
  if v_doc.client_party_name is not distinct from v_name and v_doc.client_party_role is not distinct from v_role then
    raise exception 'PERSPECTIVE_UNCHANGED' using errcode = 'P0001';
  end if;
  if (select count(*) from public.processing_jobs j
      where j.document_id = p_document_id and j.kind::text in ('reprocess', 'perspective')
        and j.created_at > now() - interval '24 hours') >= 3 then
    raise exception 'REPROCESS_LIMIT' using errcode = 'P0001';
  end if;
  if exists (select 1 from public.offices o where o.id = v_doc.office_id
             and (o.suspended_at is not null or o.deletion_scheduled_for is not null)) then
    raise exception 'OFFICE_SUSPENDED' using errcode = 'P0001';
  end if;

  update public.documents
  set client_party_name = v_name, client_party_role = case when v_name is null then null else v_role end,
      status = 'queued', queued_at = now()
  where id = p_document_id;

  perform private.enqueue_document(p_document_id, 'perspective'::text::public.job_kind, auth.uid());
  perform private.insert_access_log(v_doc.office_id, v_doc.id, auth.uid(), 'reprocess',
                                    v_doc.file_name, p_ip, p_user_agent);
end;
$$;

revoke execute on function public.request_document_perspective(uuid, text, text, text, text) from public, anon;
grant execute on function public.request_document_perspective(uuid, text, text, text, text) to authenticated;
