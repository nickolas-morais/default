-- =============================================================================
-- Etapa 7 · Parte 1 · Feedback sobre a qualidade da análise
-- =============================================================================
-- Cada advogado marca um risco como "útil" ou "não procede" e pode informar,
-- por documento, riscos que a análise deixou de apontar.
-- O painel da plataforma vê SOMENTE contagens por versão do prompt; os
-- comentários ficam no escritório (podem conter trechos do contrato).
-- =============================================================================

create type public.risk_verdict as enum ('util', 'nao_procede');

create table public.risk_feedback (
  risk_id      uuid not null references public.risks (id) on delete cascade,
  user_id      uuid not null references public.profiles (id) on delete cascade,
  document_id  uuid not null references public.documents (id) on delete cascade,
  office_id    uuid not null references public.offices (id) on delete cascade,
  verdict      public.risk_verdict not null,
  comment      text not null default '' check (char_length(comment) <= 1000),
  created_at   timestamptz not null default now(),
  primary key (risk_id, user_id)
);

create table public.document_feedback (
  document_id    uuid not null references public.documents (id) on delete cascade,
  user_id        uuid not null references public.profiles (id) on delete cascade,
  office_id      uuid not null references public.offices (id) on delete cascade,
  missing_risks  text not null check (char_length(missing_risks) between 1 and 3000),
  created_at     timestamptz not null default now(),
  primary key (document_id, user_id)
);

alter table public.risk_feedback     enable row level security;
alter table public.document_feedback enable row level security;
revoke all on public.risk_feedback, public.document_feedback from anon, authenticated;
grant select on public.risk_feedback, public.document_feedback to authenticated;

create policy risk_feedback_select on public.risk_feedback for select to authenticated
  using (office_id = (select public.current_office_id()));
create policy document_feedback_select on public.document_feedback for select to authenticated
  using (office_id = (select public.current_office_id()));

-- p_verdict null = retirar a avaliação.
create or replace function public.set_risk_feedback(p_risk_id uuid, p_verdict public.risk_verdict, p_comment text default '')
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_risk public.risks%rowtype;
begin
  select * into v_risk from public.risks where id = p_risk_id and office_id = public.current_office_id();
  if not found then
    raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001';
  end if;
  if p_verdict is null then
    delete from public.risk_feedback where risk_id = p_risk_id and user_id = auth.uid();
    return;
  end if;
  insert into public.risk_feedback (risk_id, user_id, document_id, office_id, verdict, comment)
  values (p_risk_id, auth.uid(), v_risk.document_id, v_risk.office_id, p_verdict, left(coalesce(p_comment, ''), 1000))
  on conflict (risk_id, user_id) do update
    set verdict = excluded.verdict, comment = excluded.comment, created_at = now();
end;
$$;

create or replace function public.set_document_feedback(p_document_id uuid, p_missing_risks text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_doc public.documents%rowtype;
begin
  select * into v_doc from public.documents where id = p_document_id and office_id = public.current_office_id();
  if not found then
    raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001';
  end if;
  if nullif(btrim(p_missing_risks), '') is null then
    delete from public.document_feedback where document_id = p_document_id and user_id = auth.uid();
    return;
  end if;
  insert into public.document_feedback (document_id, user_id, office_id, missing_risks)
  values (p_document_id, auth.uid(), v_doc.office_id, left(btrim(p_missing_risks), 3000))
  on conflict (document_id, user_id) do update set missing_risks = excluded.missing_risks, created_at = now();
end;
$$;

-- Painel da plataforma: qualidade por versão do prompt (somente contagens).
create or replace function public.admin_quality_stats()
returns table (
  prompt_version text, documents integer, risks integer, rated integer, useful integer,
  not_applicable integer, documents_with_missing integer, located_pct numeric
)
language plpgsql
stable
security definer
set search_path = ''
as $$
#variable_conflict use_column
begin
  perform private.require_platform_admin();
  return query
  select d.prompt_version,
    count(distinct d.id)::integer,
    count(r.id)::integer,
    count(distinct f.risk_id)::integer,
    count(distinct f.risk_id) filter (where f.verdict = 'util')::integer,
    count(distinct f.risk_id) filter (where f.verdict = 'nao_procede')::integer,
    (select count(distinct df.document_id)::integer from public.document_feedback df
      join public.documents d2 on d2.id = df.document_id where d2.prompt_version is not distinct from d.prompt_version),
    round(100.0 * count(r.id) filter (where r.page_number is not null) / nullif(count(r.id), 0), 1)
  from public.documents d
  left join public.risks r on r.document_id = d.id
  left join public.risk_feedback f on f.risk_id = r.id
  where d.status = 'ready'
  group by d.prompt_version
  order by d.prompt_version desc nulls last;
end;
$$;

revoke execute on function public.set_risk_feedback(uuid, public.risk_verdict, text) from public, anon;
revoke execute on function public.set_document_feedback(uuid, text) from public, anon;
revoke execute on function public.admin_quality_stats() from public, anon;
grant execute on function public.set_risk_feedback(uuid, public.risk_verdict, text) to authenticated;
grant execute on function public.set_document_feedback(uuid, text) to authenticated;
grant execute on function public.admin_quality_stats() to authenticated;
