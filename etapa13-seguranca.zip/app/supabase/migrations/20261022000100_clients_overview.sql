-- =============================================================================
-- Etapa 10 · Parte 2 · Clientes e acompanhamento da equipe
-- =============================================================================

-- Clientes com indicadores (documentos, revisão, riscos altos em aberto).
create or replace function public.list_clients(p_query text default null, p_include_archived boolean default false)
returns table (
  id uuid, name text, document_number text, email text, notes text, archived_at timestamptz, created_at timestamptz,
  documents integer, pending integer, in_review integer, sent integer, approved integer,
  open_high_risks integer, last_document_at timestamptz
)
language sql
stable
security definer
set search_path = ''
as $$
  select c.id, c.name, c.document_number, c.email, c.notes, c.archived_at, c.created_at,
    count(d.id)::integer,
    count(d.id) filter (where d.review_status = 'pendente')::integer,
    count(d.id) filter (where d.review_status = 'em_revisao')::integer,
    count(d.id) filter (where d.review_status = 'enviado')::integer,
    count(d.id) filter (where d.review_status = 'aprovado')::integer,
    coalesce(sum((select count(*) from public.risks r
                  where r.document_id = d.id and r.level = 'alto' and r.resolution = 'aberto')), 0)::integer,
    max(d.created_at)
  from public.clients c
  left join public.documents d on d.client_id = c.id
  where c.office_id = public.current_office_id()
    and (p_include_archived or c.archived_at is null)
    and (nullif(btrim(p_query), '') is null
         or c.name ilike '%' || btrim(p_query) || '%'
         or c.document_number = nullif(regexp_replace(upper(p_query), '[^A-Z0-9]', '', 'g'), ''))
  group by c.id
  order by c.archived_at nulls first, c.name
$$;

-- Carga de trabalho por responsável (titular e administradores).
create or replace function public.team_overview()
returns table (
  assignee_id uuid, assignee_name text, pending integer, in_review integer, sent integer, approved integer,
  processing integer, open_high_risks integer, overdue_deadlines integer, deadlines_7d integer
)
language plpgsql
stable
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_office uuid := public.current_office_id();
begin
  if not public.is_office_admin() then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;
  return query
  with docs as (
    select d.* from public.documents d where d.office_id = v_office and d.status <> 'uploading'
  ), dl as (
    select d.assignee_id, private.deadline_due(x) as due
    from public.document_deadlines x join docs d on d.id = x.document_id
  )
  select p.user_id, pr.full_name,
    (select count(*)::integer from docs where docs.assignee_id is not distinct from p.user_id and docs.status = 'ready' and docs.review_status = 'pendente'),
    (select count(*)::integer from docs where docs.assignee_id is not distinct from p.user_id and docs.status = 'ready' and docs.review_status = 'em_revisao'),
    (select count(*)::integer from docs where docs.assignee_id is not distinct from p.user_id and docs.status = 'ready' and docs.review_status = 'enviado'),
    (select count(*)::integer from docs where docs.assignee_id is not distinct from p.user_id and docs.status = 'ready' and docs.review_status = 'aprovado'),
    (select count(*)::integer from docs where docs.assignee_id is not distinct from p.user_id and docs.status in ('queued', 'preprocessing', 'analyzing')),
    (select count(*)::integer from public.risks r join docs on docs.id = r.document_id
      where docs.assignee_id is not distinct from p.user_id and r.level = 'alto' and r.resolution = 'aberto'
        and docs.review_status <> 'aprovado'),
    (select count(*)::integer from dl where dl.assignee_id is not distinct from p.user_id and dl.due < current_date and dl.due >= current_date - 365),
    (select count(*)::integer from dl where dl.assignee_id is not distinct from p.user_id and dl.due between current_date and current_date + 7)
  from (select m.user_id from public.office_members m where m.office_id = v_office
        union select null::uuid) p
  left join public.profiles pr on pr.id = p.user_id
  order by pr.full_name nulls last;
end;
$$;

revoke execute on function public.list_clients(text, boolean) from public, anon;
revoke execute on function public.team_overview() from public, anon;
grant execute on function public.list_clients(text, boolean) to authenticated;
grant execute on function public.team_overview() to authenticated;
