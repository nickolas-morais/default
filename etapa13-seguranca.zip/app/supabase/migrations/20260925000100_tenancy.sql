-- =============================================================================
-- Etapa 1 · Multi-tenant: escritórios, perfis, membros e RLS
-- =============================================================================
-- Princípio: toda tabela de negócio tem office_id e toda policy compara com
-- public.current_office_id(). Nenhuma policy consulta office_members por conta
-- própria para descobrir o escritório do usuário.
--
-- REGRA DO MVP (um escritório por usuário) vive em apenas dois lugares:
--   1. constraint office_members_one_office_per_user (UNIQUE(user_id));
--   2. função public.current_office_id().
-- Para suportar vários escritórios: remover a constraint, adicionar
-- profiles.active_office_id e fazer current_office_id() lê-lo (validando que o
-- usuário é membro). Nenhuma policy precisa mudar.
-- =============================================================================

create extension if not exists pgcrypto with schema extensions;

-- Schema para funções internas: não é exposto pela API REST do Supabase.
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;

-- -----------------------------------------------------------------------------
-- Utilitários
-- -----------------------------------------------------------------------------
create or replace function private.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

-- Converte texto em inet sem falhar (cabeçalhos de IP podem vir malformados).
create or replace function private.try_inet(p_value text)
returns inet
language plpgsql
immutable
set search_path = ''
as $$
begin
  return nullif(btrim(p_value), '')::inet;
exception when others then
  return null;
end;
$$;

-- -----------------------------------------------------------------------------
-- Tabelas
-- -----------------------------------------------------------------------------
create type public.office_role as enum ('owner', 'admin', 'member');

create table public.offices (
  id          uuid primary key default gen_random_uuid(),
  name        text not null check (char_length(btrim(name)) between 2 and 160),
  -- CNPJ normalizado (sem pontuação). Aceita o formato alfanumérico (vigente
  -- desde jul/2026): 12 caracteres [A-Z0-9] + 2 dígitos verificadores.
  -- A validação dos dígitos é feita na aplicação (packages/shared/br-docs.ts).
  cnpj        text check (cnpj ~ '^[A-Z0-9]{12}[0-9]{2}$'),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table public.profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  full_name   text not null check (char_length(btrim(full_name)) between 2 and 160),
  email       text not null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table public.office_members (
  office_id   uuid not null references public.offices (id) on delete cascade,
  user_id     uuid not null references public.profiles (id) on delete cascade,
  role        public.office_role not null default 'member',
  created_at  timestamptz not null default now(),
  primary key (office_id, user_id),
  -- REGRA DO MVP: um escritório por usuário (ver cabeçalho).
  constraint office_members_one_office_per_user unique (user_id)
);

-- No máximo um owner por escritório.
create unique index office_members_single_owner
  on public.office_members (office_id) where role = 'owner';

create trigger offices_set_updated_at before update on public.offices
  for each row execute function private.set_updated_at();
create trigger profiles_set_updated_at before update on public.profiles
  for each row execute function private.set_updated_at();

-- -----------------------------------------------------------------------------
-- Resolução do escritório ativo
-- -----------------------------------------------------------------------------
-- ÚNICO ponto que decide "qual escritório o usuário está usando agora".
-- security definer: lê office_members sem passar pela RLS (evita recursão).
create or replace function public.current_office_id()
returns uuid
language sql
stable
security definer
set search_path = ''
as $$
  select m.office_id
  from public.office_members m
  where m.user_id = auth.uid()
  limit 1
$$;

create or replace function public.current_office_role()
returns public.office_role
language sql
stable
security definer
set search_path = ''
as $$
  select m.role
  from public.office_members m
  where m.user_id = auth.uid()
    and m.office_id = public.current_office_id()
$$;

create or replace function public.is_office_admin()
returns boolean
language sql
stable
set search_path = ''
as $$
  select coalesce(public.current_office_role() in ('owner', 'admin'), false)
$$;

-- Contexto da sessão para a aplicação (escritório + papel), em uma chamada.
create or replace function public.current_membership()
returns table (office_id uuid, office_name text, role public.office_role)
language sql
stable
security definer
set search_path = ''
as $$
  select o.id, o.name, m.role
  from public.offices o
  join public.office_members m on m.office_id = o.id
  where o.id = public.current_office_id()
    and m.user_id = auth.uid()
$$;

-- -----------------------------------------------------------------------------
-- Row Level Security
-- -----------------------------------------------------------------------------
alter table public.offices        enable row level security;
alter table public.profiles       enable row level security;
alter table public.office_members enable row level security;

-- Privilégios explícitos: nada para anon; o mínimo para authenticated.
revoke all on public.offices, public.profiles, public.office_members from anon, authenticated;

grant select on public.offices to authenticated;
grant update (name, cnpj) on public.offices to authenticated;

grant select on public.profiles to authenticated;
grant update (full_name) on public.profiles to authenticated;

grant select on public.office_members to authenticated;
-- Inserções e alterações em office_members só acontecem por funções
-- security definer (cadastro, convites, remoção).

create policy offices_select on public.offices
  for select to authenticated
  using (id = (select public.current_office_id()));

create policy offices_update on public.offices
  for update to authenticated
  using (id = (select public.current_office_id()) and (select public.is_office_admin()))
  with check (id = (select public.current_office_id()));

create policy profiles_select on public.profiles
  for select to authenticated
  using (
    id = (select auth.uid())
    or id in (
      select m.user_id from public.office_members m
      where m.office_id = (select public.current_office_id())
    )
  );

create policy profiles_update_self on public.profiles
  for update to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

create policy office_members_select on public.office_members
  for select to authenticated
  using (office_id = (select public.current_office_id()));

-- -----------------------------------------------------------------------------
-- Gestão de membros
-- -----------------------------------------------------------------------------
-- Owner remove qualquer um (exceto a si mesmo); admin remove apenas membros.
create or replace function public.remove_office_member(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid := public.current_office_id();
  v_actor_role public.office_role := public.current_office_role();
  v_target_role public.office_role;
begin
  if v_office is null or v_actor_role not in ('owner', 'admin') then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;

  if p_user_id = auth.uid() then
    raise exception 'CANNOT_REMOVE_SELF' using errcode = 'P0001';
  end if;

  select role into v_target_role
  from public.office_members
  where office_id = v_office and user_id = p_user_id;

  if not found then
    raise exception 'MEMBER_NOT_FOUND' using errcode = 'P0001';
  end if;

  if v_target_role = 'owner' or (v_actor_role = 'admin' and v_target_role = 'admin') then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;

  delete from public.office_members
  where office_id = v_office and user_id = p_user_id;
end;
$$;

revoke execute on function public.remove_office_member(uuid) from public, anon;
grant execute on function public.remove_office_member(uuid) to authenticated;

-- Mantém profiles.email sincronizado com auth.users.
create or replace function private.handle_user_email_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  update public.profiles set email = lower(new.email) where id = new.id;
  return new;
end;
$$;

create trigger on_auth_user_email_changed
  after update of email on auth.users
  for each row
  when (old.email is distinct from new.email)
  execute function private.handle_user_email_change();
