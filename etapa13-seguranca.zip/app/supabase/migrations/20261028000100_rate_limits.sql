-- =============================================================================
-- Segurança · Limite de frequência (rate limit) no banco
-- =============================================================================
-- Aplicado por gatilhos, para valer em qualquer caminho (app, API do Supabase
-- chamada direto com a chave pública, scripts). Só vale para usuários
-- autenticados: o worker e o webhook (service_role) não têm auth.uid().
-- Login, cadastro e envio de e-mails já são limitados pelo Supabase Auth.
-- Janela fixa por hora ou por dia; excedeu → RATE_LIMITED.
-- =============================================================================

create table private.rate_limits (
  key           text not null,
  window_start  timestamptz not null,
  hits          integer not null default 0,
  primary key (key, window_start)
);

create or replace function private.rate_limit(p_bucket text, p_max integer, p_window interval)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid   uuid := auth.uid();
  v_start timestamptz;
  v_hits  integer;
begin
  if v_uid is null then return; end if;   -- worker, webhook, migrations
  v_start := to_timestamp(floor(extract(epoch from now()) / extract(epoch from p_window)) * extract(epoch from p_window));
  insert into private.rate_limits (key, window_start, hits)
  values (p_bucket || ':' || v_uid::text, v_start, 1)
  on conflict (key, window_start) do update set hits = private.rate_limits.hits + 1
  returning hits into v_hits;
  if v_hits > p_max then
    raise exception 'RATE_LIMITED' using errcode = 'P0001';
  end if;
  -- Limpeza ocasional das janelas antigas.
  if random() < 0.01 then
    delete from private.rate_limits where window_start < now() - interval '2 days';
  end if;
end;
$$;

-- Um gatilho genérico: TG_ARGV = (bucket, máximo, janela)
create or replace function private.rate_limit_trigger()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform private.rate_limit(tg_argv[0], tg_argv[1]::integer, tg_argv[2]::interval);
  return coalesce(new, old);
end;
$$;

-- Envio de documentos (inclui novas versões): 120 por hora por usuário.
create trigger rl_documents before insert on public.documents
  for each row execute function private.rate_limit_trigger('upload', '120', '1 hour');
-- Convites: 50 por dia por usuário.
create trigger rl_invitations before insert on public.office_invitations
  for each row execute function private.rate_limit_trigger('invite', '50', '1 day');
-- Clientes: 300 por hora.
create trigger rl_clients before insert on public.clients
  for each row execute function private.rate_limit_trigger('client', '300', '1 hour');
-- Modelos de minuta: 50 por dia.
create trigger rl_templates before insert on public.templates
  for each row execute function private.rate_limit_trigger('template', '50', '1 day');
-- Minutas geradas: 300 por hora.
create trigger rl_drafts before insert on public.draft_exports
  for each row execute function private.rate_limit_trigger('draft', '300', '1 hour');
-- Edição de dados extraídos e resumo: 600 por hora.
create trigger rl_extractions before update on public.extractions
  for each row execute function private.rate_limit_trigger('edit', '600', '1 hour');
create trigger rl_summaries before update on public.summaries
  for each row execute function private.rate_limit_trigger('edit', '600', '1 hour');
-- Endereço do calendário: 20 por dia.
create trigger rl_calendar before insert or update on public.calendar_feeds
  for each row execute function private.rate_limit_trigger('calendar', '20', '1 day');
-- Regras do Playbook e prazos: 300 por hora.
create trigger rl_playbook before insert or update on public.office_playbook_rules
  for each row execute function private.rate_limit_trigger('playbook', '300', '1 hour');
create trigger rl_deadlines before insert or update on public.document_deadlines
  for each row execute function private.rate_limit_trigger('deadline', '600', '1 hour');
-- Avaliações e situação de riscos: 2000 por hora (cliques frequentes).
create trigger rl_risk_feedback before insert or update on public.risk_feedback
  for each row execute function private.rate_limit_trigger('feedback', '2000', '1 hour');

-- =============================================================================
-- Menor privilégio: sem login, só o que o fluxo público precisa
-- (termos vigentes, prévia de convite e calendário por token).
-- =============================================================================
do $$
declare
  f text;
begin
  foreach f in array array['public.current_membership()', 'public.current_office_id()', 'public.current_office_role()',
    'public.is_office_admin()', 'public.has_accepted_current_legal()', 'public.platform_admin_status()'] loop
    execute format('revoke execute on function %s from public, anon', f);
    execute format('grant execute on function %s to authenticated, service_role', f);
  end loop;
end;
$$;
