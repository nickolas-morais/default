-- =============================================================================
-- Etapa 1 · Cadastro atômico e convites
-- =============================================================================
-- Todo usuário nasce vinculado a um escritório, no mesmo INSERT em auth.users:
--   - sem convite: cria o escritório e o usuário vira owner;
--   - com convite: entra no escritório do convite com o papel definido.
-- O aceite dos termos vigentes é obrigatório e verificado no banco. Chamadas
-- diretas à API de Auth sem os metadados corretos falham.
-- Consequência: criar usuário pelo painel do Supabase também falha (proposital).
-- =============================================================================

create table public.office_invitations (
  id           uuid primary key default gen_random_uuid(),
  office_id    uuid not null references public.offices (id) on delete cascade,
  email        text not null check (email = lower(btrim(email)) and email like '_%@_%'),
  role         public.office_role not null default 'member' check (role <> 'owner'),
  token_hash   bytea not null unique,
  invited_by   uuid references public.profiles (id) on delete set null,
  created_at   timestamptz not null default now(),
  expires_at   timestamptz not null default now() + interval '7 days',
  accepted_at  timestamptz,
  accepted_by  uuid references public.profiles (id) on delete set null,
  revoked_at   timestamptz
);

-- Um convite pendente por e-mail em cada escritório.
create unique index office_invitations_one_pending
  on public.office_invitations (office_id, email)
  where accepted_at is null and revoked_at is null;

alter table public.office_invitations enable row level security;
revoke all on public.office_invitations from anon, authenticated;

-- token_hash nunca é legível pela API.
grant select (id, office_id, email, role, invited_by, created_at, expires_at,
              accepted_at, accepted_by, revoked_at)
  on public.office_invitations to authenticated;

create policy office_invitations_select_admin on public.office_invitations
  for select to authenticated
  using (office_id = (select public.current_office_id()) and (select public.is_office_admin()));

-- -----------------------------------------------------------------------------
-- Tokens
-- -----------------------------------------------------------------------------
create or replace function private.hash_token(p_token text)
returns bytea
language sql
immutable
set search_path = ''
as $$
  select extensions.digest(p_token, 'sha256')
$$;

-- Valida e consome um convite, criando a associação. Usado pelo cadastro
-- (trigger) e pelo aceite de usuário já logado sem escritório.
create or replace function private.consume_invitation(
  p_token   text,
  p_user_id uuid,
  p_email   text
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_inv public.office_invitations%rowtype;
begin
  select * into v_inv
  from public.office_invitations
  where token_hash = private.hash_token(p_token)
  for update;

  if not found then
    raise exception 'INVITE_INVALID' using errcode = 'P0001';
  elsif v_inv.revoked_at is not null then
    raise exception 'INVITE_REVOKED' using errcode = 'P0001';
  elsif v_inv.accepted_at is not null then
    raise exception 'INVITE_USED' using errcode = 'P0001';
  elsif v_inv.expires_at <= now() then
    raise exception 'INVITE_EXPIRED' using errcode = 'P0001';
  elsif v_inv.email <> lower(btrim(p_email)) then
    raise exception 'INVITE_EMAIL_MISMATCH' using errcode = 'P0001';
  end if;

  begin
    insert into public.office_members (office_id, user_id, role)
    values (v_inv.office_id, p_user_id, v_inv.role);
  exception when unique_violation then
    raise exception 'ALREADY_HAS_OFFICE' using errcode = 'P0001';
  end;

  update public.office_invitations
  set accepted_at = now(), accepted_by = p_user_id
  where id = v_inv.id;

  return v_inv.office_id;
end;
$$;

-- -----------------------------------------------------------------------------
-- RPCs de convite
-- -----------------------------------------------------------------------------
-- Cria convite e devolve o token em claro (única vez em que ele existe).
-- Owner convida admin ou member; admin convida apenas member.
create or replace function public.create_office_invitation(
  p_email text,
  p_role  public.office_role default 'member'
)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid := public.current_office_id();
  v_actor_role public.office_role := public.current_office_role();
  v_email text := lower(btrim(p_email));
  v_token text;
begin
  if v_office is null or v_actor_role not in ('owner', 'admin') then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;

  if p_role = 'owner' or (p_role = 'admin' and v_actor_role <> 'owner') then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;

  if v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then
    raise exception 'INVALID_EMAIL' using errcode = 'P0001';
  end if;

  -- Só revela se o e-mail já é membro DESTE escritório (nunca de outro).
  if exists (
    select 1 from public.office_members m
    join public.profiles p on p.id = m.user_id
    where m.office_id = v_office and p.email = v_email
  ) then
    raise exception 'ALREADY_MEMBER' using errcode = 'P0001';
  end if;

  -- Reenvio: revoga o convite pendente anterior para o mesmo e-mail.
  update public.office_invitations
  set revoked_at = now()
  where office_id = v_office and email = v_email
    and accepted_at is null and revoked_at is null;

  v_token := rtrim(translate(encode(extensions.gen_random_bytes(32), 'base64'), '+/', '-_'), '=');

  insert into public.office_invitations (office_id, email, role, token_hash, invited_by)
  values (v_office, v_email, p_role, private.hash_token(v_token), auth.uid());

  return v_token;
end;
$$;

create or replace function public.revoke_office_invitation(p_invitation_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.is_office_admin() then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;

  update public.office_invitations
  set revoked_at = now()
  where id = p_invitation_id
    and office_id = public.current_office_id()
    and accepted_at is null and revoked_at is null;

  if not found then
    raise exception 'INVITE_INVALID' using errcode = 'P0001';
  end if;
end;
$$;

-- Prévia pública do convite (para a página /convite/[token]).
-- Quem tem o token vê o nome do escritório e o e-mail convidado.
create or replace function public.get_invitation_preview(p_token text)
returns table (office_name text, email text, role public.office_role, status text)
language sql
stable
security definer
set search_path = ''
as $$
  select o.name, i.email, i.role,
    case
      when i.revoked_at is not null then 'revoked'
      when i.accepted_at is not null then 'used'
      when i.expires_at <= now() then 'expired'
      else 'valid'
    end
  from public.office_invitations i
  join public.offices o on o.id = i.office_id
  where i.token_hash = private.hash_token(p_token)
$$;

-- Usuário já logado e sem escritório (ex.: removido de um escritório) aceita
-- um novo convite.
create or replace function public.accept_office_invitation(p_token text)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_email text;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED' using errcode = 'P0001';
  end if;

  select u.email into v_email from auth.users u where u.id = auth.uid();
  return private.consume_invitation(p_token, auth.uid(), v_email);
end;
$$;

revoke execute on function public.create_office_invitation(text, public.office_role) from public, anon;
revoke execute on function public.revoke_office_invitation(uuid) from public, anon;
revoke execute on function public.accept_office_invitation(text) from public, anon;
grant execute on function public.create_office_invitation(text, public.office_role) to authenticated;
grant execute on function public.revoke_office_invitation(uuid) to authenticated;
grant execute on function public.accept_office_invitation(text) to authenticated;
grant execute on function public.get_invitation_preview(text) to anon, authenticated;

-- -----------------------------------------------------------------------------
-- Trigger de cadastro
-- -----------------------------------------------------------------------------
-- Metadados esperados em raw_user_meta_data (enviados pela server action):
--   full_name, terms_version, privacy_version, signup_ip, signup_user_agent
--   e office_name (novo escritório) OU invite_token (convite).
create or replace function private.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_meta        jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
  v_full_name   text  := btrim(v_meta ->> 'full_name');
  v_office_name text  := btrim(v_meta ->> 'office_name');
  v_invite      text  := nullif(btrim(v_meta ->> 'invite_token'), '');
  v_office_id   uuid;
begin
  if new.email is null then
    raise exception 'EMAIL_REQUIRED' using errcode = 'P0001';
  end if;

  if v_full_name is null or char_length(v_full_name) < 2 then
    raise exception 'FULL_NAME_REQUIRED' using errcode = 'P0001';
  end if;

  if (v_meta ->> 'terms_version') is distinct from public.current_legal_version('terms')
     or (v_meta ->> 'privacy_version') is distinct from public.current_legal_version('privacy') then
    raise exception 'LEGAL_ACCEPTANCE_REQUIRED' using errcode = 'P0001';
  end if;

  insert into public.profiles (id, full_name, email)
  values (new.id, v_full_name, lower(new.email));

  if v_invite is not null then
    perform private.consume_invitation(v_invite, new.id, new.email);
  else
    if v_office_name is null or char_length(v_office_name) < 2 then
      raise exception 'OFFICE_NAME_REQUIRED' using errcode = 'P0001';
    end if;

    insert into public.offices (name) values (v_office_name)
    returning id into v_office_id;

    insert into public.office_members (office_id, user_id, role)
    values (v_office_id, new.id, 'owner');
  end if;

  insert into public.legal_acceptances (user_id, kind, version, ip, user_agent)
  values
    (new.id, 'terms',   v_meta ->> 'terms_version',
      private.try_inet(v_meta ->> 'signup_ip'), left(v_meta ->> 'signup_user_agent', 512)),
    (new.id, 'privacy', v_meta ->> 'privacy_version',
      private.try_inet(v_meta ->> 'signup_ip'), left(v_meta ->> 'signup_user_agent', 512));

  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function private.handle_new_user();
