-- =============================================================================
-- Etapa 9 · Parte 1 · Prazos e alertas
-- =============================================================================
-- Prazos por documento, extraídos pela IA ou cadastrados à mão. A data de um
-- prazo relativo (ex.: 180 dias antes do fim) é calculada na hora a partir dos
-- dados extraídos (editados, se houver): corrigir a data de término no
-- formulário corrige o prazo. Prazos recorrentes (reajuste anual) mostram a
-- próxima ocorrência. Lembretes por e-mail 30, 7 e 1 dia antes e no dia.
-- =============================================================================

alter table public.profiles add column notify_deadlines boolean not null default true;
grant update (notify_deadlines) on public.profiles to authenticated;

create table public.document_deadlines (
  id            uuid primary key default gen_random_uuid(),
  document_id   uuid not null references public.documents (id) on delete cascade,
  office_id     uuid not null references public.offices (id) on delete cascade,
  source        text not null check (source in ('ai', 'manual')),
  kind          text not null default 'outro'
                check (kind in ('fim_vigencia', 'aviso_nao_renovacao', 'reajuste', 'pagamento', 'garantia', 'outro')),
  title         text not null check (char_length(title) between 1 and 200),
  base          text not null check (base in ('fixed', 'data_inicio', 'data_fim')),
  fixed_date    date,
  offset_days   integer not null default 0 check (offset_days between -3650 and 3650),
  recurrence    text not null default 'none' check (recurrence in ('none', 'yearly', 'monthly')),
  clause_ref    text not null default '',
  excerpt       text not null default '',
  done_until    date,            -- ocorrências até esta data estão concluídas
  created_by    uuid references public.profiles (id) on delete set null,
  created_at    timestamptz not null default now(),
  check (base <> 'fixed' or fixed_date is not null)
);
create index document_deadlines_document_idx on public.document_deadlines (document_id);
create index document_deadlines_office_idx on public.document_deadlines (office_id);

alter table public.document_deadlines enable row level security;
revoke all on public.document_deadlines from anon, authenticated;
grant select on public.document_deadlines to authenticated;
create policy document_deadlines_select on public.document_deadlines for select to authenticated
  using (office_id = (select public.current_office_id()));

create or replace function private.try_date(p text)
returns date
language plpgsql
immutable
set search_path = ''
as $$
begin
  return case when p ~ '^\d{4}-\d{2}-\d{2}$' then p::date end;
exception when others then
  return null;
end;
$$;

-- Próxima ocorrência em aberto (null = sem data calculável ou concluído).
create or replace function private.deadline_due(p public.document_deadlines)
returns date
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_data jsonb;
  v_date date;
  v_from date;
  i integer := 0;
begin
  if p.base = 'fixed' then
    v_date := p.fixed_date;
  else
    -- Valor editado pelo advogado, se o campo existir na edição; senão, o da IA.
    select case when e.edited_data ? p.base then e.edited_data else e.ai_data end into v_data
    from public.extractions e where e.document_id = p.document_id;
    v_date := private.try_date(v_data ->> p.base) + p.offset_days;
  end if;
  if v_date is null then return null; end if;

  if p.recurrence = 'none' then
    return case when p.done_until is not null and v_date <= p.done_until then null else v_date end;
  end if;

  -- Recorrente: primeira ocorrência a partir de hoje (ou depois da última concluída).
  v_from := greatest(current_date, coalesce(p.done_until + 1, current_date));
  while v_date < v_from and i < 1200 loop
    v_date := v_date + case p.recurrence when 'yearly' then interval '1 year' else interval '1 month' end;
    i := i + 1;
  end loop;
  return v_date;
end;
$$;

create or replace function public.list_deadlines(
  p_from        date default null,
  p_to          date default null,
  p_document_id uuid default null
)
returns table (
  id uuid, document_id uuid, file_name text, title text, kind text, due_date date, recurrence text,
  source text, clause_ref text, excerpt text, base text, offset_days integer, days_left integer
)
language sql
stable
security definer
set search_path = ''
as $$
  select * from (
    select d.id, d.document_id, doc.file_name, d.title, d.kind, private.deadline_due(d) as due_date, d.recurrence,
      d.source, d.clause_ref, d.excerpt, d.base, d.offset_days, (private.deadline_due(d) - current_date)
    from public.document_deadlines d
    join public.documents doc on doc.id = d.document_id
    where d.office_id = public.current_office_id()
      and (p_document_id is null or d.document_id = p_document_id)
  ) x
  where (p_document_id is not null or x.due_date is not null)
    and (p_from is null or x.due_date >= p_from)
    and (p_to is null or x.due_date <= p_to)
  order by x.due_date nulls last, x.title
$$;

create or replace function public.save_deadline(
  p_id          uuid,          -- null = novo
  p_document_id uuid,
  p_title       text,
  p_due_date    date,
  p_recurrence  text default 'none'
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid := public.current_office_id();
  v_id     uuid;
begin
  if not exists (select 1 from public.documents where id = p_document_id and office_id = v_office) then
    raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001';
  end if;
  if char_length(btrim(coalesce(p_title, ''))) < 2 or p_due_date is null
     or p_recurrence not in ('none', 'yearly', 'monthly') then
    raise exception 'VALIDATION' using errcode = 'P0001';
  end if;
  if p_id is null then
    insert into public.document_deadlines (document_id, office_id, source, title, base, fixed_date, recurrence, created_by)
    values (p_document_id, v_office, 'manual', btrim(p_title), 'fixed', p_due_date, p_recurrence, auth.uid())
    returning id into v_id;
  else
    -- Editar um prazo da IA o torna manual: a nova data não é sobrescrita numa reanálise.
    update public.document_deadlines
    set title = btrim(p_title), base = 'fixed', fixed_date = p_due_date, offset_days = 0, recurrence = p_recurrence,
        source = 'manual', done_until = null
    where id = p_id and document_id = p_document_id and office_id = v_office
    returning id into v_id;
    if v_id is null then raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001'; end if;
  end if;
  return v_id;
end;
$$;

-- Concluir a ocorrência atual (recorrente passa para a próxima) ou reabrir.
create or replace function public.complete_deadline(p_id uuid, p_done boolean default true)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v public.document_deadlines%rowtype;
begin
  select * into v from public.document_deadlines where id = p_id and office_id = public.current_office_id() for update;
  if not found then raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001'; end if;
  update public.document_deadlines
  set done_until = case when p_done then private.deadline_due(v) else null end
  where id = p_id;
end;
$$;

create or replace function public.delete_deadline(p_id uuid)
returns void
language sql
security definer
set search_path = ''
as $$
  delete from public.document_deadlines where id = p_id and office_id = public.current_office_id()
$$;

-- Worker: prazos que vencem hoje ou em 1, 7 ou 30 dias.
create or replace function public.notify_due_deadlines()
returns table (deadline_id uuid, document_id uuid, office_id uuid, file_name text, title text, due_date date, days_left integer)
language sql
stable
security definer
set search_path = ''
as $$
  select x.id, x.document_id, x.office_id, x.file_name, x.title, x.due, x.due - current_date
  from (
    select d.id, d.document_id, d.office_id, doc.file_name, d.title, private.deadline_due(d) as due
    from public.document_deadlines d join public.documents doc on doc.id = d.document_id
    where doc.status = 'ready'
  ) x
  where x.due - current_date in (0, 1, 7, 30)
$$;

-- Destinatários do lembrete: quem enviou o documento e titular/administradores.
create or replace function public.notify_deadline_recipients(p_document_id uuid)
returns table (email text)
language sql
stable
security definer
set search_path = ''
as $$
  select distinct p.email
  from public.documents d
  join public.office_members m on m.office_id = d.office_id
  join public.profiles p on p.id = m.user_id
  where d.id = p_document_id and p.notify_deadlines
    and (m.role in ('owner', 'admin') or m.user_id = d.uploaded_by)
$$;

create or replace function public.worker_complete_job(
  p_job_id         uuid,
  p_result         jsonb,
  p_prompt_version text,
  p_prepare_ms     integer,
  p_ai_ms          integer
)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_job    public.processing_jobs%rowtype;
  v_doc    public.documents%rowtype;
  v_period date := date_trunc('month', now() at time zone 'America/Sao_Paulo')::date;
begin
  select * into v_job from public.processing_jobs where id = p_job_id for update;
  select * into v_doc from public.documents where id = v_job.document_id for update;
  if not found then
    update public.processing_jobs set status = 'failed', error_code = 'DOCUMENT_NOT_FOUND', finished_at = now()
    where id = p_job_id;
    return false;
  end if;

  -- Mudança de perspectiva refaz só riscos e resumo: os dados extraídos (e as
  -- edições do advogado) são mantidos.
  if v_job.kind::text <> 'perspective' then
    insert into public.extractions (document_id, office_id, ai_data)
    values (v_doc.id, v_doc.office_id, p_result -> 'extracao')
    on conflict (document_id) do update
      set ai_data = excluded.ai_data, edited_data = null, edited_by = null, edited_at = null;

    perform private.sync_parties(v_doc.id);

    -- Prazos extraídos pela IA: substitui os anteriores da IA; os manuais ficam.
    delete from public.document_deadlines where document_id = v_doc.id and source = 'ai';
    insert into public.document_deadlines (document_id, office_id, source, kind, title, base, fixed_date,
      offset_days, recurrence, clause_ref, excerpt)
    select v_doc.id, v_doc.office_id, 'ai', lower(x.item ->> 'tipo'), left(x.item ->> 'titulo', 200),
      case when (x.item ->> 'data') ~ '^\d{4}-\d{2}-\d{2}$' then 'fixed'
           when lower(x.item ->> 'referencia') in ('data_inicio', 'data_fim') then lower(x.item ->> 'referencia')
           else 'fixed' end,
      case when (x.item ->> 'data') ~ '^\d{4}-\d{2}-\d{2}$' then private.try_date(x.item ->> 'data') end,
      coalesce((x.item ->> 'deslocamento_dias')::integer, 0),
      case lower(x.item ->> 'recorrencia') when 'anual' then 'yearly' when 'mensal' then 'monthly' else 'none' end,
      coalesce(x.item ->> 'clausula', ''), left(coalesce(x.item ->> 'trecho_original', ''), 1500)
    from jsonb_array_elements(coalesce(p_result -> 'prazos', '[]'::jsonb)) as x(item)
    where (x.item ->> 'data') ~ '^\d{4}-\d{2}-\d{2}$'
       or lower(x.item ->> 'referencia') in ('data_inicio', 'data_fim');
  end if;

  delete from public.risks where document_id = v_doc.id;
  insert into public.risks (document_id, office_id, position, level, title, clause_ref, excerpt,
    explanation, suggestion, affected_party, page_number, match_score)
  select v_doc.id, v_doc.office_id, r.ord::integer, lower(r.item ->> 'nivel')::public.risk_level,
         r.item ->> 'titulo', coalesce(r.item ->> 'clausula', ''), r.item ->> 'trecho_original',
         r.item ->> 'explicacao', r.item ->> 'sugestao_redacao', coalesce(r.item ->> 'parte_prejudicada', ''),
         nullif(r.item ->> 'pagina_localizada', '')::integer, nullif(r.item ->> 'score', '')::real
  from jsonb_array_elements(p_result -> 'riscos') with ordinality as r(item, ord);

  insert into public.summaries (document_id, office_id, ai_content)
  values (v_doc.id, v_doc.office_id, p_result ->> 'resumo')
  on conflict (document_id) do update
    set ai_content = excluded.ai_content, edited_content = null, edited_by = null, edited_at = null;

  update public.documents
  set status = 'ready', processed_at = now(), prompt_version = p_prompt_version,
      error_code = null, failed_at = null,
      usage_counted_at = coalesce(usage_counted_at, now())
  where id = v_doc.id;

  -- Cota: só na primeira conclusão do documento.
  if v_doc.usage_counted_at is null then
    insert into public.usage_counters (office_id, period_start, documents_processed)
    values (v_doc.office_id, v_period, 1)
    on conflict (office_id, period_start)
      do update set documents_processed = public.usage_counters.documents_processed + 1;
  end if;

  update public.processing_jobs
  set status = 'succeeded', finished_at = now(), prepare_ms = p_prepare_ms, ai_ms = p_ai_ms,
      duration_ms = (extract(epoch from (now() - started_at)) * 1000)::integer, error_code = null
  where id = p_job_id;

  return true;
end;
$$;


do $$
declare
  f text;
begin
  foreach f in array array['public.list_deadlines(date, date, uuid)', 'public.save_deadline(uuid, uuid, text, date, text)',
                           'public.complete_deadline(uuid, boolean)', 'public.delete_deadline(uuid)'] loop
    execute format('revoke execute on function %s from public, anon', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
  foreach f in array array['public.notify_due_deadlines()', 'public.notify_deadline_recipients(uuid)'] loop
    execute format('revoke execute on function %s from public, anon, authenticated', f);
    execute format('grant execute on function %s to service_role', f);
  end loop;
end;
$$;
