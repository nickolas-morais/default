-- Etapa 8 · Novo tipo de job (arquivo separado: valor novo de enum precisa ser
-- confirmado antes de ser usado pela migration seguinte).
alter type public.job_kind add value if not exists 'perspective';
