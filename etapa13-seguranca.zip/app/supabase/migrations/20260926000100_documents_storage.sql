-- =============================================================================
-- Etapa 2 · Upload e armazenamento
-- =============================================================================
-- Fluxo:
--   1. create_document_upload()    → linha em documents (status 'uploading')
--   2. navegador envia o arquivo    → storage, liberado pela policy só para
--                                     essa linha, esse usuário e esse caminho
--   3. servidor valida o arquivo    → mark_document_queued() ou fail_document()
--                                     (ambas só para service_role)
-- Leitura de arquivos: nunca direta. O servidor confere a permissão pela RLS
-- de documents, registra o acesso e gera uma URL assinada de curta duração.
-- =============================================================================

create extension if not exists pg_trgm with schema extensions;

-- Limite de tentativas com falha por escritório (janela móvel de 24 h).
-- Não editável pelo cliente (o grant de update em offices cobre só name, cnpj).
alter table public.offices
  add column daily_failure_limit integer not null default 20
  check (daily_failure_limit between 1 and 1000);

create type public.document_status as enum
  ('uploading', 'queued', 'preprocessing', 'analyzing', 'ready', 'failed');

create type public.document_file_type as enum ('pdf', 'docx');

create table public.documents (
  id             uuid primary key default gen_random_uuid(),
  office_id      uuid not null references public.offices (id) on delete cascade,
  uploaded_by    uuid references public.profiles (id) on delete set null,
  file_name      text not null check (char_length(file_name) between 1 and 255),
  file_type      public.document_file_type not null,
  size_bytes     bigint not null check (size_bytes > 0),
  page_count     integer check (page_count > 0),
  -- Caminho no bucket: {office_id}/{document_id}/original.{pdf|docx}
  original_path  text not null unique,
  status         public.document_status not null default 'uploading',
  error_code     text,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  queued_at      timestamptz,
  failed_at      timestamptz,
  check (original_path = office_id::text || '/' || id::text || '/original.' || file_type::text),
  check ((status = 'failed') = (error_code is not null))
);

create index documents_office_created_idx on public.documents (office_id, created_at desc);
create index documents_file_name_trgm_idx on public.documents
  using gin (file_name extensions.gin_trgm_ops);

create trigger documents_set_updated_at before update on public.documents
  for each row execute function private.set_updated_at();

-- Registro de falhas: sobrevive à exclusão do documento (sem FK), para que
-- apagar documentos com erro não zere o contador de abuso.
create table public.document_failures (
  id           bigint generated always as identity primary key,
  office_id    uuid not null references public.offices (id) on delete cascade,
  document_id  uuid not null,
  error_code   text not null,
  created_at   timestamptz not null default now()
);

create index document_failures_office_created_idx
  on public.document_failures (office_id, created_at desc);

-- Log de acesso: somente inserção (por função) e leitura por administradores.
create type public.document_access_action as enum
  ('upload', 'view', 'download', 'delete', 'edit', 'export', 'reprocess');

create table public.document_access_logs (
  id           bigint generated always as identity primary key,
  office_id    uuid not null references public.offices (id) on delete cascade,
  document_id  uuid not null,              -- sem FK: o log sobrevive à exclusão
  user_id      uuid references public.profiles (id) on delete set null,
  action       public.document_access_action not null,
  -- Nome no momento do acesso, para o log continuar legível após a exclusão.
  -- Nome de arquivo pode conter dado pessoal: avaliar com o jurídico.
  file_name    text,
  ip           inet,
  user_agent   text check (char_length(user_agent) <= 512),
  created_at   timestamptz not null default now()
);

create index document_access_logs_document_idx
  on public.document_access_logs (document_id, created_at desc);
create index document_access_logs_office_idx
  on public.document_access_logs (office_id, created_at desc);

-- -----------------------------------------------------------------------------
-- RLS e privilégios
-- -----------------------------------------------------------------------------
alter table public.documents            enable row level security;
alter table public.document_failures    enable row level security;
alter table public.document_access_logs enable row level security;

revoke all on public.documents, public.document_failures, public.document_access_logs
  from anon, authenticated;

grant select on public.documents to authenticated;
grant select on public.document_failures to authenticated;
grant select on public.document_access_logs to authenticated;

create policy documents_select on public.documents
  for select to authenticated
  using (office_id = (select public.current_office_id()));

create policy document_failures_select on public.document_failures
  for select to authenticated
  using (office_id = (select public.current_office_id()));

create policy document_access_logs_select_admin on public.document_access_logs
  for select to authenticated
  using (office_id = (select public.current_office_id()) and (select public.is_office_admin()));

-- -----------------------------------------------------------------------------
-- Funções chamadas pelo usuário
-- -----------------------------------------------------------------------------
create or replace function private.insert_access_log(
  p_office_id   uuid,
  p_document_id uuid,
  p_user_id     uuid,
  p_action      public.document_access_action,
  p_file_name   text,
  p_ip          text,
  p_user_agent  text
)
returns void
language sql
security definer
set search_path = ''
as $$
  insert into public.document_access_logs
    (office_id, document_id, user_id, action, file_name, ip, user_agent)
  values
    (p_office_id, p_document_id, p_user_id, p_action, p_file_name,
     private.try_inet(p_ip), left(p_user_agent, 512))
$$;

-- Cria o registro do documento e devolve o caminho de upload autorizado.
create or replace function public.create_document_upload(
  p_file_name  text,
  p_size_bytes bigint,
  p_ip         text default null,
  p_user_agent text default null
)
returns table (document_id uuid, storage_path text)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office  uuid := public.current_office_id();
  v_name    text := btrim(p_file_name);
  v_ext     text := lower(substring(btrim(p_file_name) from '\.([A-Za-z0-9]+)$'));
  v_type    public.document_file_type;
  v_id      uuid := gen_random_uuid();
  v_path    text;
  v_limit   integer;
  v_failures integer;
begin
  if v_office is null then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;

  if v_name is null or char_length(v_name) not between 1 and 255 then
    raise exception 'FILE_NAME_INVALID' using errcode = 'P0001';
  end if;

  if v_ext = 'pdf' then
    v_type := 'pdf';
  elsif v_ext = 'docx' then
    v_type := 'docx';
  else
    raise exception 'UNSUPPORTED_TYPE' using errcode = 'P0001';
  end if;

  -- Mantenha em sincronia com packages/shared/src/limits.ts (MAX_FILE_BYTES).
  if p_size_bytes is null or p_size_bytes <= 0 then
    raise exception 'FILE_EMPTY' using errcode = 'P0001';
  elsif p_size_bytes > 25 * 1024 * 1024 then
    raise exception 'FILE_TOO_LARGE' using errcode = 'P0001';
  end if;

  -- Limite de tentativas com falha nas últimas 24 h.
  select o.daily_failure_limit into v_limit from public.offices o where o.id = v_office;
  select count(*) into v_failures
  from public.document_failures f
  where f.office_id = v_office and f.created_at > now() - interval '24 hours';
  if v_failures >= v_limit then
    raise exception 'FAILED_ATTEMPTS_LIMIT' using errcode = 'P0001';
  end if;

  -- Evita acúmulo de envios abertos e nunca concluídos.
  if (select count(*) from public.documents d
      where d.office_id = v_office and d.status = 'uploading'
        and d.created_at > now() - interval '1 hour') >= 20 then
    raise exception 'TOO_MANY_PENDING_UPLOADS' using errcode = 'P0001';
  end if;

  -- Etapa 5: verificar aqui a cota do plano (documentos concluídos no período).

  v_path := v_office::text || '/' || v_id::text || '/original.' || v_type::text;

  insert into public.documents (id, office_id, uploaded_by, file_name, file_type, size_bytes, original_path)
  values (v_id, v_office, auth.uid(), v_name, v_type, p_size_bytes, v_path);

  perform private.insert_access_log(v_office, v_id, auth.uid(), 'upload', v_name, p_ip, p_user_agent);

  return query select v_id, v_path;
end;
$$;

-- Registra visualização ou download (chamado antes de gerar a URL assinada).
create or replace function public.log_document_access(
  p_document_id uuid,
  p_action      public.document_access_action,
  p_ip          text default null,
  p_user_agent  text default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_doc public.documents%rowtype;
begin
  if p_action not in ('view', 'download', 'export') then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;

  select * into v_doc from public.documents
  where id = p_document_id and office_id = public.current_office_id();
  if not found then
    raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001';
  end if;

  perform private.insert_access_log(v_doc.office_id, v_doc.id, auth.uid(), p_action,
                                    v_doc.file_name, p_ip, p_user_agent);
end;
$$;

-- Quem pode excluir: administradores ou quem enviou o documento.
create or replace function public.can_delete_document(p_document_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.documents d
    where d.id = p_document_id
      and d.office_id = public.current_office_id()
      and (public.is_office_admin() or d.uploaded_by = auth.uid())
  )
$$;

-- Exclusão definitiva do registro (os arquivos são removidos antes, pela
-- Storage API, no servidor). Tabelas filhas das próximas etapas usam cascade.
create or replace function public.delete_document(
  p_document_id uuid,
  p_ip          text default null,
  p_user_agent  text default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_doc public.documents%rowtype;
begin
  if not public.can_delete_document(p_document_id) then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;

  select * into v_doc from public.documents where id = p_document_id;

  perform private.insert_access_log(v_doc.office_id, v_doc.id, auth.uid(), 'delete',
                                    v_doc.file_name, p_ip, p_user_agent);

  delete from public.documents where id = p_document_id;
end;
$$;

-- Envio interrompido no navegador: remove o registro sem contar como falha.
create or replace function public.cancel_document_upload(p_document_id uuid)
returns void
language sql
security definer
set search_path = ''
as $$
  delete from public.documents
  where id = p_document_id
    and office_id = public.current_office_id()
    and uploaded_by = auth.uid()
    and status = 'uploading'
$$;

revoke execute on function public.create_document_upload(text, bigint, text, text) from public, anon;
revoke execute on function public.log_document_access(uuid, public.document_access_action, text, text) from public, anon;
revoke execute on function public.can_delete_document(uuid) from public, anon;
revoke execute on function public.delete_document(uuid, text, text) from public, anon;
revoke execute on function public.cancel_document_upload(uuid) from public, anon;
grant execute on function public.create_document_upload(text, bigint, text, text) to authenticated;
grant execute on function public.log_document_access(uuid, public.document_access_action, text, text) to authenticated;
grant execute on function public.can_delete_document(uuid) to authenticated;
grant execute on function public.delete_document(uuid, text, text) to authenticated;
grant execute on function public.cancel_document_upload(uuid) to authenticated;

-- -----------------------------------------------------------------------------
-- Transições de status confiáveis: somente service_role (servidor e worker)
-- -----------------------------------------------------------------------------
create or replace function public.mark_document_queued(
  p_document_id uuid,
  p_size_bytes  bigint,
  p_page_count  integer
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  update public.documents
  set status = 'queued', size_bytes = p_size_bytes, page_count = p_page_count, queued_at = now()
  where id = p_document_id and status = 'uploading';

  if not found then
    raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001';
  end if;
end;
$$;

create or replace function public.fail_document(p_document_id uuid, p_error_code text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid;
begin
  update public.documents
  set status = 'failed', error_code = p_error_code, failed_at = now()
  where id = p_document_id and status <> 'ready'
  returning office_id into v_office;

  if v_office is null then
    raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001';
  end if;

  insert into public.document_failures (office_id, document_id, error_code)
  values (v_office, p_document_id, p_error_code);
end;
$$;

revoke execute on function public.mark_document_queued(uuid, bigint, integer) from public, anon, authenticated;
revoke execute on function public.fail_document(uuid, text) from public, anon, authenticated;
grant execute on function public.mark_document_queued(uuid, bigint, integer) to service_role;
grant execute on function public.fail_document(uuid, text) to service_role;

-- -----------------------------------------------------------------------------
-- Storage: bucket privado
-- -----------------------------------------------------------------------------
-- Criptografia em repouso (AES-256) é feita pelo Supabase Storage.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'documents', 'documents', false, 26214400,
  array['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
)
on conflict (id) do update
  set public = false,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

-- Upload: só no caminho exato de um documento 'uploading' do próprio usuário.
-- Não há policies de select/update/delete: leitura apenas por URL assinada
-- gerada no servidor; remoção apenas pela Storage API com service_role.
create policy documents_bucket_insert on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'documents'
    and exists (
      select 1 from public.documents d
      where d.original_path = objects.name
        and d.office_id = (select public.current_office_id())
        and d.uploaded_by = (select auth.uid())
        and d.status = 'uploading'
    )
  );
