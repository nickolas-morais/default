-- =============================================================================
-- Etapa 6 · Parte 1 · Configurações de conta e do escritório
-- =============================================================================
-- - Perfil: telefone e OAB do usuário (também usados nas minutas).
-- - Escritório: endereço, telefone, e-mail de contato e registro na OAB.
-- - Papéis: titular promove/rebaixa administradores e transfere a titularidade.
-- - Exclusão do escritório com prazo de arrependimento de 7 dias; executada
--   pelo worker (arquivos, usuários e dados). Exige assinatura já cancelada.
-- - Exclusão da própria conta (a remoção em auth.users é feita no servidor).
-- =============================================================================

alter table public.profiles
  add column phone      text check (char_length(phone) <= 30),
  add column oab_number text check (char_length(oab_number) <= 30);

alter table public.offices
  add column address                text check (char_length(address) <= 300),
  add column phone                  text check (char_length(phone) <= 30),
  add column contact_email          text check (char_length(contact_email) <= 200),
  add column oab_registration       text check (char_length(oab_registration) <= 60),
  add column deletion_scheduled_for timestamptz,
  add column deletion_requested_by  uuid references public.profiles (id) on delete set null;

grant update (full_name, phone, oab_number) on public.profiles to authenticated;
grant update (name, cnpj, address, phone, contact_email, oab_registration) on public.offices to authenticated;

-- -----------------------------------------------------------------------------
-- Papéis e titularidade (somente o titular)
-- -----------------------------------------------------------------------------
create or replace function public.set_member_role(p_user_id uuid, p_role public.office_role)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid := public.current_office_id();
begin
  if public.current_office_role() is distinct from 'owner' then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;
  if p_role not in ('admin', 'member') or p_user_id = auth.uid() then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;
  update public.office_members set role = p_role
  where office_id = v_office and user_id = p_user_id and role <> 'owner';
  if not found then
    raise exception 'MEMBER_NOT_FOUND' using errcode = 'P0001';
  end if;
end;
$$;

-- O titular atual passa a administrador.
create or replace function public.transfer_ownership(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid := public.current_office_id();
begin
  if public.current_office_role() is distinct from 'owner' or p_user_id = auth.uid() then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;
  if not exists (select 1 from public.office_members where office_id = v_office and user_id = p_user_id) then
    raise exception 'MEMBER_NOT_FOUND' using errcode = 'P0001';
  end if;
  update public.office_members set role = 'admin' where office_id = v_office and user_id = auth.uid();
  update public.office_members set role = 'owner' where office_id = v_office and user_id = p_user_id;
end;
$$;

-- -----------------------------------------------------------------------------
-- Exclusão da própria conta
-- -----------------------------------------------------------------------------
-- Chamada pelo servidor antes de remover o usuário em auth.users.
-- Titular com colegas precisa transferir a titularidade; titular sozinho
-- exclui o escritório inteiro (fluxo com prazo de 7 dias).
create or replace function public.check_account_deletion()
returns void
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_office uuid := public.current_office_id();
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED' using errcode = 'P0001';
  end if;
  if public.current_office_role() = 'owner' then
    if exists (select 1 from public.office_members where office_id = v_office and user_id <> auth.uid()) then
      raise exception 'OWNER_MUST_TRANSFER' using errcode = 'P0001';
    end if;
    raise exception 'OWNER_MUST_DELETE_OFFICE' using errcode = 'P0001';
  end if;
end;
$$;

-- -----------------------------------------------------------------------------
-- Exclusão do escritório (prazo de arrependimento)
-- -----------------------------------------------------------------------------
create or replace function public.request_office_deletion()
returns timestamptz
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid := public.current_office_id();
  v_when   timestamptz := now() + interval '7 days';
begin
  if public.current_office_role() is distinct from 'owner' then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;
  -- Assinatura que ainda vai renovar precisa ser cancelada antes (portal do Stripe).
  if exists (select 1 from public.subscriptions s
             where s.office_id = v_office and s.status in ('active', 'trialing', 'past_due')
               and not s.cancel_at_period_end) then
    raise exception 'ACTIVE_SUBSCRIPTION' using errcode = 'P0001';
  end if;
  update public.offices
  set deletion_scheduled_for = v_when, deletion_requested_by = auth.uid()
  where id = v_office;
  return v_when;
end;
$$;

create or replace function public.cancel_office_deletion()
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if public.current_office_role() is distinct from 'owner' then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;
  update public.offices set deletion_scheduled_for = null, deletion_requested_by = null
  where id = public.current_office_id();
end;
$$;

-- Com exclusão agendada, nada de novos envios ou reprocessamentos.
create or replace function private.assert_quota(p_office_id uuid)
returns void
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_ent record;
  v_use record;
begin
  if exists (select 1 from public.offices o where o.id = p_office_id and o.deletion_scheduled_for is not null) then
    raise exception 'OFFICE_DELETION_PENDING' using errcode = 'P0001';
  end if;
  select * into v_ent from private.office_entitlement(p_office_id);
  if v_ent.source = 'none' then
    raise exception 'NO_ACTIVE_PLAN' using errcode = 'P0001';
  end if;
  select * into v_use from private.office_usage(p_office_id, v_ent.period_start, v_ent.period_end);
  if v_use.used + v_use.reserved >= v_ent.doc_limit then
    raise exception 'QUOTA_EXCEEDED' using errcode = 'P0001';
  end if;
end;
$$;

-- Worker: escritórios com prazo vencido e os usuários a remover.
create or replace function public.worker_offices_due_for_deletion()
returns table (office_id uuid, member_ids uuid[])
language sql
security definer
set search_path = ''
as $$
  select o.id, coalesce(array_agg(m.user_id) filter (where m.user_id is not null), '{}')
  from public.offices o
  left join public.office_members m on m.office_id = o.id
  where o.deletion_scheduled_for is not null and o.deletion_scheduled_for <= now()
  group by o.id
  limit 20
$$;

-- Apaga o escritório (cascade: documentos, análises, modelos, membros, logs).
-- Arquivos e usuários são removidos pelo worker antes/depois, pelas APIs.
create or replace function public.worker_delete_office(p_office_id uuid)
returns void
language sql
security definer
set search_path = ''
as $$
  delete from public.offices
  where id = p_office_id and deletion_scheduled_for is not null and deletion_scheduled_for <= now()
$$;

do $$
declare
  f text;
begin
  foreach f in array array[
    'public.set_member_role(uuid, public.office_role)',
    'public.transfer_ownership(uuid)',
    'public.check_account_deletion()',
    'public.request_office_deletion()',
    'public.cancel_office_deletion()'
  ] loop
    execute format('revoke execute on function %s from public, anon', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
  foreach f in array array[
    'public.worker_offices_due_for_deletion()',
    'public.worker_delete_office(uuid)'
  ] loop
    execute format('revoke execute on function %s from public, anon, authenticated', f);
    execute format('grant execute on function %s to service_role', f);
  end loop;
end;
$$;
