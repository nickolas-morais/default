-- =============================================================================
-- Etapa 9 · Parte 2 · Assinatura do calendário (Google Agenda, Outlook, Apple)
-- =============================================================================
-- Cada usuário pode ter um endereço secreto (token de 256 bits; o banco guarda
-- só o hash) que o Google/Microsoft consultam periodicamente, sem login.
-- - Gerar de novo revoga o anterior; revogar desliga na hora.
-- - Quem sai do escritório perde o acesso: o feed confere a associação atual.
-- - Privacidade: por padrão, o feed mostra só o tipo do prazo, sem nome do
--   documento nem trecho do contrato (os servidores da agenda leem o conteúdo).
--   O usuário pode optar por incluir o nome do documento e a cláusula.
-- =============================================================================

create table public.calendar_feeds (
  user_id           uuid primary key references public.profiles (id) on delete cascade,
  office_id         uuid not null references public.offices (id) on delete cascade,
  token_hash        bytea not null unique,
  include_details   boolean not null default false,
  created_at        timestamptz not null default now(),
  last_accessed_at  timestamptz
);

alter table public.calendar_feeds enable row level security;
revoke all on public.calendar_feeds from anon, authenticated;
grant select (user_id, office_id, include_details, created_at, last_accessed_at) on public.calendar_feeds to authenticated;
create policy calendar_feeds_select_own on public.calendar_feeds for select to authenticated
  using (user_id = (select auth.uid()));

-- Gera (ou substitui) o endereço do usuário e devolve o token em claro, uma vez.
create or replace function public.create_calendar_feed(p_include_details boolean default false)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid := public.current_office_id();
  v_token  text := rtrim(translate(encode(extensions.gen_random_bytes(32), 'base64'), '+/', '-_'), '=');
begin
  if v_office is null then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;
  insert into public.calendar_feeds (user_id, office_id, token_hash, include_details)
  values (auth.uid(), v_office, private.hash_token(v_token), coalesce(p_include_details, false))
  on conflict (user_id) do update
    set office_id = excluded.office_id, token_hash = excluded.token_hash,
        include_details = excluded.include_details, created_at = now(), last_accessed_at = null;
  return v_token;
end;
$$;

create or replace function public.revoke_calendar_feed()
returns void
language sql
security definer
set search_path = ''
as $$
  delete from public.calendar_feeds where user_id = auth.uid()
$$;

-- Chamado sem login pelo endpoint público do feed. Sem token válido ou sem
-- associação atual ao escritório, não devolve nada.
create or replace function public.calendar_feed_events(p_token text)
returns table (
  office_name text, include_details boolean, deadline_id uuid, document_id uuid, file_name text,
  title text, kind text, due_date date, recurrence text, clause_ref text
)
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_feed public.calendar_feeds%rowtype;
begin
  select * into v_feed from public.calendar_feeds f where f.token_hash = private.hash_token(p_token);
  if not found then return; end if;
  if not exists (select 1 from public.office_members m where m.user_id = v_feed.user_id and m.office_id = v_feed.office_id) then
    return;
  end if;

  update public.calendar_feeds set last_accessed_at = now() where user_id = v_feed.user_id;

  return query
  select o.name, v_feed.include_details, x.id, x.document_id, x.file_name, x.title, x.kind, x.due, x.recurrence, x.clause_ref
  from public.offices o
  cross join lateral (
    select d.id, d.document_id, doc.file_name, d.title, d.kind, private.deadline_due(d) as due, d.recurrence, d.clause_ref
    from public.document_deadlines d join public.documents doc on doc.id = d.document_id
    where d.office_id = v_feed.office_id
  ) x
  where o.id = v_feed.office_id
    and x.due is not null
    and x.due between current_date - 30 and current_date + 730
  order by x.due;
end;
$$;

-- Validade do endereço (para devolver calendário vazio, e não erro, quando não há prazos).
create or replace function public.calendar_feed_info(p_token text)
returns table (office_name text, include_details boolean)
language sql
stable
security definer
set search_path = ''
as $$
  select o.name, f.include_details
  from public.calendar_feeds f
  join public.office_members m on m.user_id = f.user_id and m.office_id = f.office_id
  join public.offices o on o.id = f.office_id
  where f.token_hash = private.hash_token(p_token)
$$;
grant execute on function public.calendar_feed_info(text) to anon, authenticated;

revoke execute on function public.create_calendar_feed(boolean) from public, anon;
revoke execute on function public.revoke_calendar_feed() from public, anon;
grant execute on function public.create_calendar_feed(boolean) to authenticated;
grant execute on function public.revoke_calendar_feed() to authenticated;
grant execute on function public.calendar_feed_events(text) to anon, authenticated;
