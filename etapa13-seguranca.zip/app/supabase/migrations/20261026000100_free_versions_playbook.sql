-- =============================================================================
-- Etapa 12 · Versões gratuitas e Playbook do escritório
-- =============================================================================
-- Versões: até 3 novas versões gratuitas por contrato (v2 a v4); da v5 em
-- diante, conta na cota. O worker recusa, antes da IA, arquivos que não
-- parecem versão do anterior (VERSION_UNRELATED), fechando a brecha de enviar
-- qualquer contrato como "versão".
-- Playbook: regras próprias do escritório aplicadas em todas as análises
-- (planos Profissional e Escritório, contratos manuais e avaliação).
-- =============================================================================

alter table public.documents
  add column billing text not null default 'normal' check (billing in ('normal', 'free_version'));

create or replace function private.office_usage(p_office_id uuid, p_period_start timestamptz, p_period_end timestamptz)
returns table (used integer, reserved integer)
language sql
stable
security definer
set search_path = ''
as $$
  select
    (select count(*)::integer from public.documents d
      where d.office_id = p_office_id and d.usage_counted_at >= p_period_start and d.usage_counted_at < p_period_end
        and d.billing <> 'free_version'),
    (select count(*)::integer from public.documents d
      where d.office_id = p_office_id and d.usage_counted_at is null
        and d.status in ('uploading', 'queued', 'preprocessing', 'analyzing')
        and d.file_deleted_at is null and d.billing <> 'free_version')
$$;


-- Validações comuns do envio (as mesmas de create_document_upload).
create or replace function private.check_upload(p_office uuid, p_name text, p_size bigint)
returns public.document_file_type
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_ext text := lower(substring(btrim(p_name) from '\.([A-Za-z0-9]+)$'));
  v_limit integer;
  v_failures integer;
begin
  if p_office is null then raise exception 'FORBIDDEN' using errcode = 'P0001'; end if;
  if btrim(coalesce(p_name, '')) = '' or char_length(btrim(p_name)) > 255 then
    raise exception 'FILE_NAME_INVALID' using errcode = 'P0001';
  end if;
  if v_ext not in ('pdf', 'docx') or v_ext is null then raise exception 'UNSUPPORTED_TYPE' using errcode = 'P0001'; end if;
  if p_size is null or p_size <= 0 then raise exception 'FILE_EMPTY' using errcode = 'P0001'; end if;
  if p_size > 25 * 1024 * 1024 then raise exception 'FILE_TOO_LARGE' using errcode = 'P0001'; end if;
  select o.daily_failure_limit into v_limit from public.offices o where o.id = p_office;
  select count(*) into v_failures from public.document_failures f
  where f.office_id = p_office and f.created_at > now() - interval '24 hours';
  if v_failures >= v_limit then raise exception 'FAILED_ATTEMPTS_LIMIT' using errcode = 'P0001'; end if;
  if exists (select 1 from public.offices o where o.id = p_office and (o.suspended_at is not null)) then
    raise exception 'OFFICE_SUSPENDED' using errcode = 'P0001';
  end if;
  if exists (select 1 from public.offices o where o.id = p_office and o.deletion_scheduled_for is not null) then
    raise exception 'OFFICE_DELETION_PENDING' using errcode = 'P0001';
  end if;
  return v_ext::public.document_file_type;
end;
$$;

-- Envio de nova versão: cria o documento já ligado à versão anterior.
create or replace function public.create_version_upload(
  p_parent_id  uuid,
  p_file_name  text,
  p_size_bytes bigint,
  p_ip         text default null,
  p_user_agent text default null
)
returns table (document_id uuid, storage_path text, version_number integer, free boolean)
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_office uuid := public.current_office_id();
  v_parent public.documents%rowtype;
  v_type   public.document_file_type;
  v_id     uuid := gen_random_uuid();
  v_path   text;
  v_free   boolean;
  c_free_versions constant integer := 3;
begin
  v_type := private.check_upload(v_office, p_file_name, p_size_bytes);

  select * into v_parent from public.documents d where d.id = p_parent_id and d.office_id = v_office;
  if not found then raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001'; end if;
  if v_parent.status <> 'ready' then raise exception 'DOCUMENT_NOT_READY' using errcode = 'P0001'; end if;
  if exists (select 1 from public.documents c where c.parent_document_id = p_parent_id) then
    raise exception 'VERSION_EXISTS' using errcode = 'P0001';
  end if;

  -- Versões gratuitas já usadas neste contrato (cadeia até a v1).
  with recursive chain as (
    select d.id, d.parent_document_id, d.billing from public.documents d where d.id = p_parent_id
    union all
    select p.id, p.parent_document_id, p.billing from public.documents p join chain on p.id = chain.parent_document_id
  )
  select count(*) filter (where chain.billing = 'free_version') < c_free_versions into v_free from chain;

  if not v_free then
    perform private.assert_quota(v_office);
  end if;

  v_path := v_office::text || '/' || v_id::text || '/original.' || v_type::text;
  insert into public.documents (id, office_id, uploaded_by, file_name, file_type, size_bytes, original_path,
    parent_document_id, version_number, client_id, assignee_id, client_party_name, client_party_role, review_status, billing)
  values (v_id, v_office, auth.uid(), btrim(p_file_name), v_type, p_size_bytes, v_path,
    p_parent_id, v_parent.version_number + 1, v_parent.client_id, coalesce(v_parent.assignee_id, auth.uid()),
    v_parent.client_party_name, v_parent.client_party_role, 'em_revisao',
    case when v_free then 'free_version' else 'normal' end);

  perform private.insert_access_log(v_office, v_id, auth.uid(), 'upload', btrim(p_file_name), p_ip, p_user_agent);
  return query select v_id, v_path, v_parent.version_number + 1, v_free;
exception when unique_violation then
  raise exception 'VERSION_EXISTS' using errcode = 'P0001';
end;
$$;

-- Texto da versão anterior (o worker confere se o arquivo é mesmo uma versão).
create or replace function public.worker_previous_pages(p_document_id uuid)
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce(jsonb_agg(jsonb_build_object('page', pg.page_number, 'text', pg.text) order by pg.page_number), '[]')
  from public.documents d
  join public.document_pages pg on pg.document_id = d.parent_document_id
  where d.id = p_document_id
  having count(*) > 0
$$;

-- -----------------------------------------------------------------------------
-- Playbook do escritório
-- -----------------------------------------------------------------------------
alter table public.plans add column playbook boolean not null default false;
update public.plans set playbook = true where id in ('profissional', 'escritorio');

create table public.office_playbook_rules (
  id           uuid primary key default gen_random_uuid(),
  office_id    uuid not null references public.offices (id) on delete cascade,
  title        text not null check (char_length(btrim(title)) between 3 and 120),
  instruction  text not null check (char_length(btrim(instruction)) between 10 and 600),
  min_level    public.risk_level,                -- nível mínimo quando a regra é violada
  contract_types text not null default '' check (char_length(contract_types) <= 120),  -- vazio = todos
  active       boolean not null default true,
  position     integer not null default 0,
  created_by   uuid references public.profiles (id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index office_playbook_rules_office_idx on public.office_playbook_rules (office_id, position);

alter table public.office_playbook_rules enable row level security;
revoke all on public.office_playbook_rules from anon, authenticated;
grant select on public.office_playbook_rules to authenticated;
create policy office_playbook_rules_select on public.office_playbook_rules for select to authenticated
  using (office_id = (select public.current_office_id()));

alter table public.risks add column playbook_rule_id uuid references public.office_playbook_rules (id) on delete set null;

create or replace function private.office_has_playbook(p_office_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select case e.source
    when 'contract' then true
    when 'trial' then true
    when 'subscription' then coalesce((select p.playbook from public.plans p where p.id = e.plan_id), false)
    else false end
  from private.office_entitlement(p_office_id) e
$$;

create or replace function public.current_features()
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select jsonb_build_object('playbook', coalesce(private.office_has_playbook(public.current_office_id()), false))
$$;

create or replace function public.save_playbook_rule(
  p_id uuid, p_title text, p_instruction text, p_min_level public.risk_level default null,
  p_contract_types text default '', p_active boolean default true
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid := public.current_office_id();
  v_id uuid;
begin
  if not public.is_office_admin() then raise exception 'FORBIDDEN' using errcode = 'P0001'; end if;
  if char_length(btrim(coalesce(p_title, ''))) < 3 or char_length(btrim(coalesce(p_instruction, ''))) < 10 then
    raise exception 'VALIDATION' using errcode = 'P0001';
  end if;
  if p_id is null then
    if (select count(*) from public.office_playbook_rules r where r.office_id = v_office) >= 30 then
      raise exception 'PLAYBOOK_LIMIT' using errcode = 'P0001';
    end if;
    insert into public.office_playbook_rules (office_id, title, instruction, min_level, contract_types, active, position, created_by)
    values (v_office, btrim(p_title), left(btrim(p_instruction), 600), p_min_level, left(btrim(coalesce(p_contract_types, '')), 120),
            coalesce(p_active, true),
            coalesce((select max(position) + 1 from public.office_playbook_rules r where r.office_id = v_office), 0), auth.uid())
    returning id into v_id;
  else
    update public.office_playbook_rules
    set title = btrim(p_title), instruction = left(btrim(p_instruction), 600), min_level = p_min_level,
        contract_types = left(btrim(coalesce(p_contract_types, '')), 120), active = coalesce(p_active, true), updated_at = now()
    where id = p_id and office_id = v_office
    returning id into v_id;
    if v_id is null then raise exception 'VALIDATION' using errcode = 'P0001'; end if;
  end if;
  return v_id;
end;
$$;

create or replace function public.delete_playbook_rule(p_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.is_office_admin() then raise exception 'FORBIDDEN' using errcode = 'P0001'; end if;
  delete from public.office_playbook_rules where id = p_id and office_id = public.current_office_id();
end;
$$;

-- Worker: regras ativas do escritório (vazio se o plano não inclui o Playbook).
create or replace function public.worker_playbook_rules(p_office_id uuid)
returns table (id uuid, title text, instruction text, min_level public.risk_level, contract_types text)
language sql
stable
security definer
set search_path = ''
as $$
  select r.id, r.title, r.instruction, r.min_level, r.contract_types
  from public.office_playbook_rules r
  where r.office_id = p_office_id and r.active and private.office_has_playbook(p_office_id)
  order by r.position, r.created_at
  limit 30
$$;

create or replace function public.worker_complete_job(
  p_job_id         uuid,
  p_result         jsonb,
  p_prompt_version text,
  p_prepare_ms     integer,
  p_ai_ms          integer
)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_job    public.processing_jobs%rowtype;
  v_doc    public.documents%rowtype;
  v_period date := date_trunc('month', now() at time zone 'America/Sao_Paulo')::date;
begin
  select * into v_job from public.processing_jobs where id = p_job_id for update;
  select * into v_doc from public.documents where id = v_job.document_id for update;
  if not found then
    update public.processing_jobs set status = 'failed', error_code = 'DOCUMENT_NOT_FOUND', finished_at = now()
    where id = p_job_id;
    return false;
  end if;

  -- Mudança de perspectiva refaz só riscos e resumo: os dados extraídos (e as
  -- edições do advogado) são mantidos.
  if v_job.kind::text <> 'perspective' then
    insert into public.extractions (document_id, office_id, ai_data)
    values (v_doc.id, v_doc.office_id, p_result -> 'extracao')
    on conflict (document_id) do update
      set ai_data = excluded.ai_data, edited_data = null, edited_by = null, edited_at = null;

    perform private.sync_parties(v_doc.id);

    -- Prazos extraídos pela IA: substitui os anteriores da IA; os manuais ficam.
    delete from public.document_deadlines where document_id = v_doc.id and source = 'ai';
    insert into public.document_deadlines (document_id, office_id, source, kind, title, base, fixed_date,
      offset_days, recurrence, clause_ref, excerpt)
    select v_doc.id, v_doc.office_id, 'ai', lower(x.item ->> 'tipo'), left(x.item ->> 'titulo', 200),
      case when (x.item ->> 'data') ~ '^\d{4}-\d{2}-\d{2}$' then 'fixed'
           when lower(x.item ->> 'referencia') in ('data_inicio', 'data_fim') then lower(x.item ->> 'referencia')
           else 'fixed' end,
      case when (x.item ->> 'data') ~ '^\d{4}-\d{2}-\d{2}$' then private.try_date(x.item ->> 'data') end,
      coalesce((x.item ->> 'deslocamento_dias')::integer, 0),
      case lower(x.item ->> 'recorrencia') when 'anual' then 'yearly' when 'mensal' then 'monthly' else 'none' end,
      coalesce(x.item ->> 'clausula', ''), left(coalesce(x.item ->> 'trecho_original', ''), 1500)
    from jsonb_array_elements(coalesce(p_result -> 'prazos', '[]'::jsonb)) as x(item)
    where (x.item ->> 'data') ~ '^\d{4}-\d{2}-\d{2}$'
       or lower(x.item ->> 'referencia') in ('data_inicio', 'data_fim');
  end if;

  delete from public.risks where document_id = v_doc.id;
  insert into public.risks (document_id, office_id, position, level, title, clause_ref, excerpt,
    explanation, suggestion, affected_party, page_number, match_score, playbook_rule_id)
  select v_doc.id, v_doc.office_id, r.ord::integer, lower(r.item ->> 'nivel')::public.risk_level,
         r.item ->> 'titulo', coalesce(r.item ->> 'clausula', ''), r.item ->> 'trecho_original',
         r.item ->> 'explicacao', r.item ->> 'sugestao_redacao', coalesce(r.item ->> 'parte_prejudicada', ''),
         nullif(r.item ->> 'pagina_localizada', '')::integer, nullif(r.item ->> 'score', '')::real,
         (select pr.id from public.office_playbook_rules pr
           where pr.id::text = r.item ->> 'playbook_rule_id' and pr.office_id = v_doc.office_id)
  from jsonb_array_elements(p_result -> 'riscos') with ordinality as r(item, ord);

  insert into public.summaries (document_id, office_id, ai_content)
  values (v_doc.id, v_doc.office_id, p_result ->> 'resumo')
  on conflict (document_id) do update
    set ai_content = excluded.ai_content, edited_content = null, edited_by = null, edited_at = null;

  update public.documents
  set status = 'ready', processed_at = now(), prompt_version = p_prompt_version,
      error_code = null, failed_at = null,
      usage_counted_at = coalesce(usage_counted_at, now())
  where id = v_doc.id;

  -- Cota: só na primeira conclusão do documento.
  -- Versões gratuitas (até 3 por contrato) não entram na cota.
  if v_doc.usage_counted_at is null and v_doc.billing <> 'free_version' then
    insert into public.usage_counters (office_id, period_start, documents_processed)
    values (v_doc.office_id, v_period, 1)
    on conflict (office_id, period_start)
      do update set documents_processed = public.usage_counters.documents_processed + 1;
  end if;

  update public.processing_jobs
  set status = 'succeeded', finished_at = now(), prepare_ms = p_prepare_ms, ai_ms = p_ai_ms,
      duration_ms = (extract(epoch from (now() - started_at)) * 1000)::integer, error_code = null
  where id = p_job_id;

  return true;
end;
$$;


do $$
declare
  f text;
begin
  foreach f in array array['public.create_version_upload(uuid, text, bigint, text, text)', 'public.current_features()',
    'public.save_playbook_rule(uuid, text, text, public.risk_level, text, boolean)', 'public.delete_playbook_rule(uuid)'] loop
    execute format('revoke execute on function %s from public, anon', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
  foreach f in array array['public.worker_previous_pages(uuid)', 'public.worker_playbook_rules(uuid)'] loop
    execute format('revoke execute on function %s from public, anon, authenticated', f);
    execute format('grant execute on function %s to service_role', f);
  end loop;
end;
$$;
