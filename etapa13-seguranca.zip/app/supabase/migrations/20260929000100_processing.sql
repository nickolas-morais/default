-- =============================================================================
-- Etapa 3 · Processamento: fila, resultados da IA, telemetria e cota
-- =============================================================================
-- Fluxo:
--   documents.status 'uploading' → 'queued'  (trigger cria processing_job e
--   publica na fila pgmq 'document_processing')
--   worker: worker_start_job → 'preprocessing' → worker_set_stage('analyzing')
--           → worker_complete_job (tudo numa transação) → 'ready'
--   falha:  worker_retry_job (volta para 'queued') ou worker_fail_job
--
-- Cota (etapa 5 usa usage_counters): conta um documento UMA única vez, na
-- primeira conclusão (documents.usage_counted_at). Reprocessar não conta.
-- Telemetria de custo (ai_usage, processing_jobs): uso interno, sem acesso
-- pela API para usuários dos escritórios.
-- =============================================================================

create extension if not exists pgmq;
select pgmq.create('document_processing');

-- -----------------------------------------------------------------------------
-- Ajustes em documents
-- -----------------------------------------------------------------------------
alter table public.documents
  add column viewer_path           text,          -- PDF exibido (convertido/OCR); null = original
  add column is_scanned            boolean,
  add column file_deleted_at       timestamptz,   -- arquivo descartado (falha permanente)
  add column processing_started_at timestamptz,
  add column processed_at          timestamptz,
  add column usage_counted_at      timestamptz,   -- entrada na cota (uma vez só)
  add column prompt_version        text;

-- Falhas de validação da etapa 2 já tinham o arquivo removido.
update public.documents set file_deleted_at = failed_at where status = 'failed';

-- fail_document ganha o parâmetro p_file_deleted.
drop function public.fail_document(uuid, text);

create or replace function public.fail_document(
  p_document_id  uuid,
  p_error_code   text,
  p_file_deleted boolean default false
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid;
begin
  update public.documents
  set status = 'failed', error_code = p_error_code, failed_at = now(),
      file_deleted_at = case when p_file_deleted then now() else file_deleted_at end,
      viewer_path = case when p_file_deleted then null else viewer_path end
  where id = p_document_id and status <> 'ready'
  returning office_id into v_office;

  if v_office is null then
    raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001';
  end if;

  insert into public.document_failures (office_id, document_id, error_code)
  values (v_office, p_document_id, p_error_code);
end;
$$;

revoke execute on function public.fail_document(uuid, text, boolean) from public, anon, authenticated;
grant execute on function public.fail_document(uuid, text, boolean) to service_role;

-- -----------------------------------------------------------------------------
-- Resultados da análise
-- -----------------------------------------------------------------------------
create type public.risk_level as enum ('alto', 'medio', 'baixo');

-- Texto por página (entrada da IA e base para localizar trechos). Sem acesso
-- pela API: o navegador usa a camada de texto do próprio PDF.
create table public.document_pages (
  document_id  uuid not null references public.documents (id) on delete cascade,
  office_id    uuid not null references public.offices (id) on delete cascade,
  page_number  integer not null check (page_number > 0),
  text         text not null,
  primary key (document_id, page_number)
);

create table public.extractions (
  document_id    uuid primary key references public.documents (id) on delete cascade,
  office_id      uuid not null references public.offices (id) on delete cascade,
  ai_data        jsonb not null,
  edited_data    jsonb,
  edited_by      uuid references public.profiles (id) on delete set null,
  edited_at      timestamptz,
  created_at     timestamptz not null default now()
);

-- Partes normalizadas para a busca da lista de documentos.
create table public.document_parties (
  id               bigint generated always as identity primary key,
  document_id      uuid not null references public.documents (id) on delete cascade,
  office_id        uuid not null references public.offices (id) on delete cascade,
  name             text not null,
  document_number  text,           -- CPF/CNPJ só com [A-Z0-9]
  role             text
);

create index document_parties_document_idx on public.document_parties (document_id);
create index document_parties_name_trgm_idx on public.document_parties
  using gin (name extensions.gin_trgm_ops);
create index document_parties_number_idx on public.document_parties (office_id, document_number);

create table public.risks (
  id               uuid primary key default gen_random_uuid(),
  document_id      uuid not null references public.documents (id) on delete cascade,
  office_id        uuid not null references public.offices (id) on delete cascade,
  position         integer not null,
  level            public.risk_level not null,
  title            text not null,
  clause_ref       text not null default '',
  excerpt          text not null,
  explanation      text not null,
  suggestion       text not null,
  affected_party   text not null default '',
  page_number      integer,          -- null = trecho não localizado no texto
  match_score      real,
  unique (document_id, position)
);

create table public.summaries (
  document_id     uuid primary key references public.documents (id) on delete cascade,
  office_id       uuid not null references public.offices (id) on delete cascade,
  ai_content      text not null,
  edited_content  text,
  edited_by       uuid references public.profiles (id) on delete set null,
  edited_at       timestamptz,
  created_at      timestamptz not null default now()
);

-- -----------------------------------------------------------------------------
-- Jobs, telemetria de custo e cota
-- -----------------------------------------------------------------------------
create type public.job_kind as enum ('initial', 'reprocess');
create type public.job_status as enum ('queued', 'running', 'retrying', 'succeeded', 'failed');

-- Sem FK para documents: o histórico de custo sobrevive à exclusão.
create table public.processing_jobs (
  id             uuid primary key default gen_random_uuid(),
  document_id    uuid not null,
  office_id      uuid not null references public.offices (id) on delete cascade,
  kind           public.job_kind not null,
  status         public.job_status not null default 'queued',
  attempts       integer not null default 0,
  error_code     text,
  requested_by   uuid references public.profiles (id) on delete set null,
  page_count     integer,
  is_scanned     boolean,
  prepare_ms     integer,
  ai_ms          integer,
  duration_ms    integer,
  created_at     timestamptz not null default now(),
  started_at     timestamptz,
  finished_at    timestamptz
);

create index processing_jobs_document_idx on public.processing_jobs (document_id, created_at desc);
create index processing_jobs_office_idx on public.processing_jobs (office_id, created_at desc);

-- Preços por modelo (USD por milhão de tokens). Atualize com uma nova linha
-- (effective_from) quando a Anthropic mudar os preços.
create table public.ai_model_prices (
  model                 text not null,
  effective_from        date not null,
  input_per_mtok        numeric(10,4) not null,
  output_per_mtok       numeric(10,4) not null,
  cache_write_per_mtok  numeric(10,4) not null,
  cache_read_per_mtok   numeric(10,4) not null,
  primary key (model, effective_from)
);

-- Fonte: https://platform.claude.com/docs/en/about-claude/pricing (consulta em 29/09/2026).
-- cache_write = escrita de cache de 5 minutos.
insert into public.ai_model_prices values
  ('claude-sonnet-5-5',         '2026-09-01', 2.00, 10.00, 2.50, 0.20),
  ('claude-opus-5-5',           '2026-09-01', 4.00, 20.00, 5.00, 0.20),
  ('claude-haiku-4-5-20251001', '2026-09-01', 1.00,  5.00, 1.25, 0.10);

create table public.ai_usage (
  id                     bigint generated always as identity primary key,
  job_id                 uuid not null,
  document_id            uuid not null,
  office_id              uuid not null,
  model                  text not null,
  input_tokens           integer not null default 0,
  output_tokens          integer not null default 0,
  thinking_tokens        integer not null default 0,
  cache_creation_tokens  integer not null default 0,
  cache_read_tokens      integer not null default 0,
  cost_usd               numeric(12,6),    -- null se o modelo não tiver preço cadastrado
  duration_ms            integer,
  stop_reason            text,
  created_at             timestamptz not null default now()
);

create index ai_usage_job_idx on public.ai_usage (job_id);
create index ai_usage_created_idx on public.ai_usage (created_at);

create table public.usage_counters (
  office_id            uuid not null references public.offices (id) on delete cascade,
  period_start         date not null,
  documents_processed  integer not null default 0,
  primary key (office_id, period_start)
);

-- -----------------------------------------------------------------------------
-- RLS e privilégios
-- -----------------------------------------------------------------------------
alter table public.document_pages   enable row level security;
alter table public.extractions      enable row level security;
alter table public.document_parties enable row level security;
alter table public.risks            enable row level security;
alter table public.summaries        enable row level security;
alter table public.processing_jobs  enable row level security;
alter table public.ai_model_prices  enable row level security;
alter table public.ai_usage         enable row level security;
alter table public.usage_counters   enable row level security;

revoke all on public.document_pages, public.extractions, public.document_parties, public.risks,
  public.summaries, public.processing_jobs, public.ai_model_prices, public.ai_usage,
  public.usage_counters from anon, authenticated;

grant select on public.extractions, public.document_parties, public.risks, public.summaries,
  public.usage_counters to authenticated;
-- processing_jobs: sem colunas de custo/tempo para o usuário.
grant select (id, document_id, office_id, kind, status, attempts, error_code, created_at, finished_at)
  on public.processing_jobs to authenticated;

create policy extractions_select on public.extractions for select to authenticated
  using (office_id = (select public.current_office_id()));
create policy document_parties_select on public.document_parties for select to authenticated
  using (office_id = (select public.current_office_id()));
create policy risks_select on public.risks for select to authenticated
  using (office_id = (select public.current_office_id()));
create policy summaries_select on public.summaries for select to authenticated
  using (office_id = (select public.current_office_id()));
create policy processing_jobs_select on public.processing_jobs for select to authenticated
  using (office_id = (select public.current_office_id()));
create policy usage_counters_select on public.usage_counters for select to authenticated
  using (office_id = (select public.current_office_id()));
-- document_pages, ai_usage, ai_model_prices: sem policies (somente service_role).

-- -----------------------------------------------------------------------------
-- Enfileiramento
-- -----------------------------------------------------------------------------
create or replace function private.enqueue_document(
  p_document_id  uuid,
  p_kind         public.job_kind,
  p_requested_by uuid
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid;
  v_job    uuid;
begin
  select office_id into v_office from public.documents where id = p_document_id;

  insert into public.processing_jobs (document_id, office_id, kind, requested_by)
  values (p_document_id, v_office, p_kind, p_requested_by)
  returning id into v_job;

  perform pgmq.send('document_processing',
    jsonb_build_object('job_id', v_job, 'document_id', p_document_id));

  return v_job;
end;
$$;

create or replace function private.on_document_queued()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform private.enqueue_document(new.id, 'initial', new.uploaded_by);
  return new;
end;
$$;

create trigger on_document_queued
  after update of status on public.documents
  for each row
  when (old.status = 'uploading' and new.status = 'queued')
  execute function private.on_document_queued();

-- Documentos que ficaram na fila na etapa 2 (antes do worker existir).
select private.enqueue_document(id, 'initial', uploaded_by)
from public.documents where status = 'queued';

-- -----------------------------------------------------------------------------
-- Reprocessamento (usuário)
-- -----------------------------------------------------------------------------
-- Admin ou quem enviou. Não consome cota (usage_counted_at já preenchido).
-- Limites: 3 reprocessamentos por documento em 24 h e o limite diário de
-- falhas do escritório. Edições feitas nos dados e no resumo são descartadas.
create or replace function public.request_document_reprocess(
  p_document_id uuid,
  p_ip          text default null,
  p_user_agent  text default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_doc      public.documents%rowtype;
  v_limit    integer;
  v_failures integer;
begin
  if not public.can_delete_document(p_document_id) then
    raise exception 'FORBIDDEN' using errcode = 'P0001';
  end if;

  select * into v_doc from public.documents where id = p_document_id for update;

  if v_doc.status not in ('ready', 'failed') or v_doc.file_deleted_at is not null then
    raise exception 'DOCUMENT_NOT_READY' using errcode = 'P0001';
  end if;

  if (select count(*) from public.processing_jobs j
      where j.document_id = p_document_id and j.kind = 'reprocess'
        and j.created_at > now() - interval '24 hours') >= 3 then
    raise exception 'REPROCESS_LIMIT' using errcode = 'P0001';
  end if;

  select o.daily_failure_limit into v_limit from public.offices o where o.id = v_doc.office_id;
  select count(*) into v_failures from public.document_failures f
  where f.office_id = v_doc.office_id and f.created_at > now() - interval '24 hours';
  if v_failures >= v_limit then
    raise exception 'FAILED_ATTEMPTS_LIMIT' using errcode = 'P0001';
  end if;

  update public.documents
  set status = 'queued', error_code = null, failed_at = null, queued_at = now()
  where id = p_document_id;

  perform private.enqueue_document(p_document_id, 'reprocess', auth.uid());
  perform private.insert_access_log(v_doc.office_id, v_doc.id, auth.uid(), 'reprocess',
                                    v_doc.file_name, p_ip, p_user_agent);
end;
$$;

revoke execute on function public.request_document_reprocess(uuid, text, text) from public, anon;
grant execute on function public.request_document_reprocess(uuid, text, text) to authenticated;

-- -----------------------------------------------------------------------------
-- Edição pelo advogado
-- -----------------------------------------------------------------------------
create or replace function private.sync_parties(p_document_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_office uuid;
  v_data   jsonb;
begin
  select e.office_id, coalesce(e.edited_data, e.ai_data) into v_office, v_data
  from public.extractions e where e.document_id = p_document_id;

  delete from public.document_parties where document_id = p_document_id;

  if v_data is null or jsonb_typeof(v_data -> 'partes') <> 'array' then
    return;
  end if;

  insert into public.document_parties (document_id, office_id, name, document_number, role)
  select p_document_id, v_office,
         left(btrim(p ->> 'nome'), 300),
         nullif(regexp_replace(upper(coalesce(p ->> 'documento', '')), '[^A-Z0-9]', '', 'g'), ''),
         left(btrim(coalesce(p ->> 'papel', '')), 120)
  from jsonb_array_elements(v_data -> 'partes') p
  where btrim(coalesce(p ->> 'nome', '')) <> '';
end;
$$;

-- p_data null = descartar edições e voltar aos dados da IA.
-- O formato de p_data é validado na aplicação (Zod); aqui, só tamanho e tipo.
create or replace function public.save_extraction(
  p_document_id uuid,
  p_data        jsonb,
  p_ip          text default null,
  p_user_agent  text default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_doc public.documents%rowtype;
begin
  select * into v_doc from public.documents
  where id = p_document_id and office_id = public.current_office_id();
  if not found then
    raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001';
  end if;
  if v_doc.status <> 'ready' then
    raise exception 'DOCUMENT_NOT_READY' using errcode = 'P0001';
  end if;
  if p_data is not null and (jsonb_typeof(p_data) <> 'object' or octet_length(p_data::text) > 65536) then
    raise exception 'VALIDATION' using errcode = 'P0001';
  end if;

  update public.extractions
  set edited_data = p_data,
      edited_by = case when p_data is null then null else auth.uid() end,
      edited_at = case when p_data is null then null else now() end
  where document_id = p_document_id;

  perform private.sync_parties(p_document_id);
  perform private.insert_access_log(v_doc.office_id, v_doc.id, auth.uid(), 'edit',
                                    v_doc.file_name, p_ip, p_user_agent);
end;
$$;

create or replace function public.save_summary(
  p_document_id uuid,
  p_content     text,
  p_ip          text default null,
  p_user_agent  text default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_doc public.documents%rowtype;
begin
  select * into v_doc from public.documents
  where id = p_document_id and office_id = public.current_office_id();
  if not found then
    raise exception 'DOCUMENT_NOT_FOUND' using errcode = 'P0001';
  end if;
  if v_doc.status <> 'ready' then
    raise exception 'DOCUMENT_NOT_READY' using errcode = 'P0001';
  end if;
  if p_content is not null and char_length(p_content) > 20000 then
    raise exception 'VALIDATION' using errcode = 'P0001';
  end if;

  update public.summaries
  set edited_content = nullif(btrim(p_content), ''),
      edited_by = case when nullif(btrim(p_content), '') is null then null else auth.uid() end,
      edited_at = case when nullif(btrim(p_content), '') is null then null else now() end
  where document_id = p_document_id;

  perform private.insert_access_log(v_doc.office_id, v_doc.id, auth.uid(), 'edit',
                                    v_doc.file_name, p_ip, p_user_agent);
end;
$$;

revoke execute on function public.save_extraction(uuid, jsonb, text, text) from public, anon;
revoke execute on function public.save_summary(uuid, text, text, text) from public, anon;
grant execute on function public.save_extraction(uuid, jsonb, text, text) to authenticated;
grant execute on function public.save_summary(uuid, text, text, text) to authenticated;

-- -----------------------------------------------------------------------------
-- Busca de documentos (nome do arquivo, parte ou CPF/CNPJ, período)
-- -----------------------------------------------------------------------------
-- security invoker: a RLS de cada tabela se aplica normalmente.
create or replace function public.search_documents(
  p_query  text default null,
  p_from   timestamptz default null,
  p_to     timestamptz default null,
  p_limit  integer default 25,
  p_offset integer default 0
)
returns table (
  id uuid, file_name text, file_type public.document_file_type, size_bytes bigint,
  page_count integer, status public.document_status, created_at timestamptz,
  uploader_name text, parties text, total_count bigint
)
language sql
stable
security invoker
set search_path = ''
as $$
  with q as (
    select nullif(btrim(p_query), '') as term,
           '%' || replace(replace(replace(btrim(coalesce(p_query, '')), '\', '\\'), '%', '\%'), '_', '\_') || '%' as pattern,
           nullif(regexp_replace(upper(coalesce(p_query, '')), '[^A-Z0-9]', '', 'g'), '') as number
  )
  select d.id, d.file_name, d.file_type, d.size_bytes, d.page_count, d.status, d.created_at,
         p.full_name,
         (select string_agg(dp.name, '; ' order by dp.id)
            from public.document_parties dp where dp.document_id = d.id),
         count(*) over ()
  from public.documents d
  cross join q
  left join public.profiles p on p.id = d.uploaded_by
  where (q.term is null
         or d.file_name ilike q.pattern
         or exists (
           select 1 from public.document_parties dp
           where dp.document_id = d.id
             and (dp.name ilike q.pattern
                  or (char_length(q.number) >= 11 and dp.document_number = q.number))))
    and (p_from is null or d.created_at >= p_from)
    and (p_to is null or d.created_at < p_to)
  order by d.created_at desc
  limit least(greatest(p_limit, 1), 100)
  offset greatest(p_offset, 0)
$$;

revoke execute on function public.search_documents(text, timestamptz, timestamptz, integer, integer) from public, anon;
grant execute on function public.search_documents(text, timestamptz, timestamptz, integer, integer) to authenticated;

-- -----------------------------------------------------------------------------
-- Funções do worker (somente service_role)
-- -----------------------------------------------------------------------------
create or replace function public.worker_read_jobs(p_vt_seconds integer, p_qty integer)
returns table (msg_id bigint, read_ct integer, message jsonb)
language sql
security definer
set search_path = ''
as $$
  select r.msg_id, r.read_ct, r.message
  from pgmq.read('document_processing', p_vt_seconds, p_qty) r
$$;

create or replace function public.worker_ack(p_msg_id bigint, p_archive boolean default false)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if p_archive then
    perform pgmq.archive('document_processing', p_msg_id);
  else
    perform pgmq.delete('document_processing', p_msg_id);
  end if;
end;
$$;

create or replace function public.worker_delay(p_msg_id bigint, p_seconds integer)
returns void
language sql
security definer
set search_path = ''
as $$
  select null from pgmq.set_vt('document_processing', p_msg_id, p_seconds)
$$;

-- Inicia o job. Devolve null se o documento foi excluído ou o job já terminou.
create or replace function public.worker_start_job(p_job_id uuid)
returns table (
  document_id uuid, office_id uuid, file_type public.document_file_type,
  original_path text, kind public.job_kind, attempts integer
)
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_job public.processing_jobs%rowtype;
begin
  select * into v_job from public.processing_jobs where id = p_job_id for update;
  if not found or v_job.status in ('succeeded', 'failed') then
    return;
  end if;

  update public.documents d
  set status = 'preprocessing', processing_started_at = now()
  where d.id = v_job.document_id and d.status in ('queued', 'preprocessing', 'analyzing')
    and d.file_deleted_at is null;
  if not found then
    update public.processing_jobs set status = 'failed', error_code = 'DOCUMENT_NOT_FOUND', finished_at = now()
    where id = p_job_id;
    return;
  end if;

  update public.processing_jobs
  set status = 'running', attempts = attempts + 1, started_at = coalesce(started_at, now())
  where id = p_job_id;

  return query
  select d.id, d.office_id, d.file_type, d.original_path, v_job.kind, v_job.attempts + 1
  from public.documents d where d.id = v_job.document_id;
end;
$$;

create or replace function public.worker_set_stage(p_job_id uuid, p_status public.document_status)
returns void
language sql
security definer
set search_path = ''
as $$
  update public.documents d set status = p_status
  from public.processing_jobs j
  where j.id = p_job_id and d.id = j.document_id and p_status in ('preprocessing', 'analyzing')
$$;

-- Grava páginas extraídas e o PDF de visualização (substitui em reprocessos).
create or replace function public.worker_save_pages(
  p_job_id      uuid,
  p_pages       jsonb,       -- [{"page": 1, "text": "..."}]
  p_viewer_path text,
  p_is_scanned  boolean,
  p_page_count  integer
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_doc    uuid;
  v_office uuid;
begin
  select j.document_id, j.office_id into v_doc, v_office from public.processing_jobs j where j.id = p_job_id;

  delete from public.document_pages where document_id = v_doc;
  insert into public.document_pages (document_id, office_id, page_number, text)
  select v_doc, v_office, (x ->> 'page')::integer, x ->> 'text'
  from jsonb_array_elements(p_pages) x;

  update public.documents
  set viewer_path = p_viewer_path, is_scanned = p_is_scanned, page_count = p_page_count
  where id = v_doc;

  update public.processing_jobs set page_count = p_page_count, is_scanned = p_is_scanned
  where id = p_job_id;
end;
$$;

create or replace function public.worker_record_ai_usage(
  p_job_id                uuid,
  p_model                 text,
  p_input_tokens          integer,
  p_output_tokens         integer,
  p_thinking_tokens       integer,
  p_cache_creation_tokens integer,
  p_cache_read_tokens     integer,
  p_duration_ms           integer,
  p_stop_reason           text
)
returns numeric
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_job   public.processing_jobs%rowtype;
  v_price public.ai_model_prices%rowtype;
  v_cost  numeric(12,6);
begin
  select * into v_job from public.processing_jobs where id = p_job_id;

  select * into v_price from public.ai_model_prices
  where model = p_model and effective_from <= current_date
  order by effective_from desc limit 1;

  if found then
    v_cost := (coalesce(p_input_tokens, 0) * v_price.input_per_mtok
             + coalesce(p_output_tokens, 0) * v_price.output_per_mtok
             + coalesce(p_cache_creation_tokens, 0) * v_price.cache_write_per_mtok
             + coalesce(p_cache_read_tokens, 0) * v_price.cache_read_per_mtok) / 1000000;
  end if;

  insert into public.ai_usage (job_id, document_id, office_id, model, input_tokens, output_tokens,
    thinking_tokens, cache_creation_tokens, cache_read_tokens, cost_usd, duration_ms, stop_reason)
  values (p_job_id, v_job.document_id, v_job.office_id, p_model, coalesce(p_input_tokens, 0),
    coalesce(p_output_tokens, 0), coalesce(p_thinking_tokens, 0), coalesce(p_cache_creation_tokens, 0),
    coalesce(p_cache_read_tokens, 0), v_cost, p_duration_ms, p_stop_reason);

  return v_cost;
end;
$$;

-- Grava todos os resultados e conclui, numa única transação.
-- p_result: {"extracao": {...}, "riscos": [{...,"pagina_localizada": n|null,
--            "score": x|null}], "resumo": "..."}
-- Devolve false se o documento foi excluído durante o processamento.
create or replace function public.worker_complete_job(
  p_job_id         uuid,
  p_result         jsonb,
  p_prompt_version text,
  p_prepare_ms     integer,
  p_ai_ms          integer
)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_job    public.processing_jobs%rowtype;
  v_doc    public.documents%rowtype;
  v_period date := date_trunc('month', now() at time zone 'America/Sao_Paulo')::date;
begin
  select * into v_job from public.processing_jobs where id = p_job_id for update;
  select * into v_doc from public.documents where id = v_job.document_id for update;
  if not found then
    update public.processing_jobs set status = 'failed', error_code = 'DOCUMENT_NOT_FOUND', finished_at = now()
    where id = p_job_id;
    return false;
  end if;

  insert into public.extractions (document_id, office_id, ai_data)
  values (v_doc.id, v_doc.office_id, p_result -> 'extracao')
  on conflict (document_id) do update
    set ai_data = excluded.ai_data, edited_data = null, edited_by = null, edited_at = null;

  perform private.sync_parties(v_doc.id);

  delete from public.risks where document_id = v_doc.id;
  insert into public.risks (document_id, office_id, position, level, title, clause_ref, excerpt,
    explanation, suggestion, affected_party, page_number, match_score)
  select v_doc.id, v_doc.office_id, r.ord::integer, lower(r.item ->> 'nivel')::public.risk_level,
         r.item ->> 'titulo', coalesce(r.item ->> 'clausula', ''), r.item ->> 'trecho_original',
         r.item ->> 'explicacao', r.item ->> 'sugestao_redacao', coalesce(r.item ->> 'parte_prejudicada', ''),
         nullif(r.item ->> 'pagina_localizada', '')::integer, nullif(r.item ->> 'score', '')::real
  from jsonb_array_elements(p_result -> 'riscos') with ordinality as r(item, ord);

  insert into public.summaries (document_id, office_id, ai_content)
  values (v_doc.id, v_doc.office_id, p_result ->> 'resumo')
  on conflict (document_id) do update
    set ai_content = excluded.ai_content, edited_content = null, edited_by = null, edited_at = null;

  update public.documents
  set status = 'ready', processed_at = now(), prompt_version = p_prompt_version,
      error_code = null, failed_at = null,
      usage_counted_at = coalesce(usage_counted_at, now())
  where id = v_doc.id;

  -- Cota: só na primeira conclusão do documento.
  if v_doc.usage_counted_at is null then
    insert into public.usage_counters (office_id, period_start, documents_processed)
    values (v_doc.office_id, v_period, 1)
    on conflict (office_id, period_start)
      do update set documents_processed = public.usage_counters.documents_processed + 1;
  end if;

  update public.processing_jobs
  set status = 'succeeded', finished_at = now(), prepare_ms = p_prepare_ms, ai_ms = p_ai_ms,
      duration_ms = (extract(epoch from (now() - started_at)) * 1000)::integer, error_code = null
  where id = p_job_id;

  return true;
end;
$$;

create or replace function public.worker_retry_job(p_job_id uuid, p_error_code text)
returns void
language sql
security definer
set search_path = ''
as $$
  update public.processing_jobs set status = 'retrying', error_code = p_error_code where id = p_job_id;
  update public.documents d set status = 'queued'
  from public.processing_jobs j
  where j.id = p_job_id and d.id = j.document_id and d.status in ('preprocessing', 'analyzing');
$$;

create or replace function public.worker_fail_job(
  p_job_id       uuid,
  p_error_code   text,
  p_file_deleted boolean
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_doc uuid;
begin
  update public.processing_jobs
  set status = 'failed', error_code = p_error_code, finished_at = now(),
      duration_ms = (extract(epoch from (now() - coalesce(started_at, now()))) * 1000)::integer
  where id = p_job_id
  returning document_id into v_doc;

  if exists (select 1 from public.documents where id = v_doc) then
    perform public.fail_document(v_doc, p_error_code, p_file_deleted);
  end if;
end;
$$;

-- Envios abandonados (navegador fechado antes da confirmação).
create or replace function public.worker_abandoned_uploads(p_older_than_minutes integer default 120)
returns table (document_id uuid, original_path text)
language sql
security definer
set search_path = ''
as $$
  select d.id, d.original_path from public.documents d
  where d.status = 'uploading' and d.created_at < now() - make_interval(mins => p_older_than_minutes)
  limit 100
$$;

create or replace function public.worker_delete_abandoned(p_document_id uuid)
returns void
language sql
security definer
set search_path = ''
as $$
  delete from public.documents where id = p_document_id and status = 'uploading'
$$;

do $$
declare
  f text;
begin
  foreach f in array array[
    'public.worker_read_jobs(integer, integer)',
    'public.worker_ack(bigint, boolean)',
    'public.worker_delay(bigint, integer)',
    'public.worker_start_job(uuid)',
    'public.worker_set_stage(uuid, public.document_status)',
    'public.worker_save_pages(uuid, jsonb, text, boolean, integer)',
    'public.worker_record_ai_usage(uuid, text, integer, integer, integer, integer, integer, integer, text)',
    'public.worker_complete_job(uuid, jsonb, text, integer, integer)',
    'public.worker_retry_job(uuid, text)',
    'public.worker_fail_job(uuid, text, boolean)',
    'public.worker_abandoned_uploads(integer)',
    'public.worker_delete_abandoned(uuid)'
  ] loop
    execute format('revoke execute on function %s from public, anon, authenticated', f);
    execute format('grant execute on function %s to service_role', f);
  end loop;
end;
$$;
