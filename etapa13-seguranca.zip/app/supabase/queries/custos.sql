-- Relatórios de custo e desempenho (uso interno). Rode no SQL Editor do
-- Supabase (usuário postgres). Custos em USD, calculados com ai_model_prices.

-- 1. Custo e tempo por documento concluído, do mais recente para o mais antigo.
select j.document_id,
       j.kind,
       j.page_count,
       j.is_scanned,
       round(sum(u.cost_usd), 4)          as custo_usd,
       sum(u.input_tokens)                as tokens_entrada,
       sum(u.output_tokens)               as tokens_saida,
       sum(u.thinking_tokens)             as tokens_raciocinio,
       round(j.prepare_ms / 1000.0, 1)    as preparo_s,
       round(j.ai_ms / 1000.0, 1)         as ia_s,
       round(j.duration_ms / 1000.0, 1)   as total_s,
       j.finished_at
from public.processing_jobs j
join public.ai_usage u on u.job_id = j.id
where j.status = 'succeeded'
group by j.id
order by j.finished_at desc
limit 100;

-- 2. Base para precificar os planos: médias e percentis dos últimos 30 dias.
with por_job as (
  select j.id, j.page_count, j.is_scanned, j.duration_ms, sum(u.cost_usd) as custo
  from public.processing_jobs j
  join public.ai_usage u on u.job_id = j.id
  where j.status = 'succeeded' and j.finished_at > now() - interval '30 days'
  group by j.id
)
select count(*)                                                                  as documentos,
       round(avg(custo), 4)                                                      as custo_medio_usd,
       round((percentile_cont(0.5) within group (order by custo))::numeric, 4)   as custo_mediano_usd,
       round((percentile_cont(0.9) within group (order by custo))::numeric, 4)   as custo_p90_usd,
       round(max(custo), 4)                                                      as custo_max_usd,
       round(avg(custo / nullif(page_count, 0)), 5)                              as custo_medio_por_pagina_usd,
       round(avg(page_count), 1)                                                 as paginas_media,
       round(100.0 * avg(case when is_scanned then 1 else 0 end), 1)             as pct_escaneados,
       round((percentile_cont(0.9) within group (order by duration_ms) / 1000)::numeric, 1) as tempo_p90_s
from por_job;

-- 3. Custo total por escritório e mês, incluindo reprocessamentos e falhas
-- (tokens gastos em tentativas que falharam também são cobrados pela Anthropic).
select u.office_id,
       date_trunc('month', u.created_at at time zone 'America/Sao_Paulo')::date as mes,
       count(distinct u.document_id)                                            as documentos,
       round(sum(u.cost_usd), 2)                                                as custo_usd,
       coalesce(max(c.documents_processed), 0)                                  as documentos_na_cota
from public.ai_usage u
left join public.usage_counters c
  on c.office_id = u.office_id
 and c.period_start = date_trunc('month', u.created_at at time zone 'America/Sao_Paulo')::date
group by 1, 2
order by 2 desc, 4 desc;

-- 4. Custo desperdiçado: chamadas de jobs que terminaram em falha.
select j.error_code, count(distinct j.id) as jobs, round(sum(u.cost_usd), 4) as custo_usd
from public.processing_jobs j
join public.ai_usage u on u.job_id = j.id
where j.status = 'failed'
group by j.error_code
order by custo_usd desc;
