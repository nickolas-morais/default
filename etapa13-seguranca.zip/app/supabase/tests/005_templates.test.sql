-- Modelos de minuta: permissões, isolamento e registro de minutas geradas.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(14);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}'),
  ('22222222-2222-2222-2222-222222222222', 'bruno@escritorio-b.com.br',
   '{"full_name":"Bruno Lima","office_name":"Escritório B","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');

set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select public.create_office_invitation('carla@exemplo.com', 'member') as token_carla \gset
reset role;
insert into auth.users (id, email, raw_user_meta_data) values
  ('33333333-3333-3333-3333-333333333333', 'carla@exemplo.com', jsonb_build_object(
    'full_name','Carla Dias','invite_token', :'token_carla',
    'terms_version','2026-09-provisoria','privacy_version','2026-09-provisoria'));

-- Documento pronto no escritório A.
set local role authenticated;
select document_id as doc from public.create_document_upload('Locação.pdf', 5000) \gset
reset role;
set local role service_role;
select public.mark_document_queued(:'doc', 5000, 3);
select message ->> 'job_id' as job from public.worker_read_jobs(60, 1) \gset
select public.worker_start_job(:'job');
select public.worker_complete_job(:'job', '{"extracao":{"partes":[]},"riscos":[],"resumo":"r"}', 'v1', 1, 1);
reset role;

-- Ana (owner) cria modelo --------------------------------------------------------
set local role authenticated;
select template_id as tpl, storage_path as tpl_path
from public.create_template('Notificação de rescisão', 'Modelo padrão', array['locatario','valor','cidade'], 12000) \gset

select is(:'tpl_path', public.current_office_id()::text || '/templates/' || :'tpl' || '.docx',
  'modelo fica na pasta de modelos do escritório');
select is((select variables from public.templates where id = :'tpl'), array['locatario','valor','cidade'],
  'variáveis gravadas');
select throws_ok($$select * from public.create_template('x', '', '{}', 10)$$, 'P0001', 'VALIDATION',
  'nome curto demais');
select throws_ok($$insert into public.templates (office_id, name, storage_path, size_bytes) values (gen_random_uuid(), 'x', 'y', 1)$$,
  '42501', null, 'cliente não insere modelos diretamente');

-- Carla (member) usa, mas não gerencia ------------------------------------------
set local request.jwt.claims = '{"sub":"33333333-3333-3333-3333-333333333333","role":"authenticated"}';
select is((select count(*)::int from public.templates), 1, 'membro vê os modelos do escritório');
select throws_ok($$select * from public.create_template('Outro modelo', '', '{}', 10)$$, 'P0001', 'FORBIDDEN',
  'membro não cria modelos');
select throws_ok(format($$select public.delete_template(%L)$$, :'tpl'), 'P0001', 'FORBIDDEN',
  'membro não exclui modelos');
select lives_ok(format($$select public.record_draft_export(%L, %L)$$, :'doc', :'tpl'),
  'membro gera minuta');
select is((select count(*)::int from public.document_access_logs where document_id = :'doc' and action = 'export'),
  0, 'membro não lê o log (só admin)');

-- Bruno (outro escritório) --------------------------------------------------------
set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated"}';
select is((select count(*)::int from public.templates), 0, 'outro escritório não vê os modelos');
select document_id as doc_b from public.create_document_upload('B.pdf', 5000) \gset
select throws_ok(format($$select public.record_draft_export(%L, %L)$$, :'doc_b', :'tpl'), 'P0001', 'DOCUMENT_NOT_READY',
  'documento ainda não analisado');
select throws_ok(format($$select public.delete_template(%L)$$, :'tpl'), 'P0001', 'TEMPLATE_NOT_FOUND',
  'não exclui modelo de outro escritório');

-- Ana confere o log e exclui o modelo -----------------------------------------------
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select is((select count(*)::int from public.document_access_logs where document_id = :'doc' and action = 'export'),
  1, 'geração de minuta fica no log de acesso');
select is(public.delete_template(:'tpl'), :'tpl_path', 'exclusão devolve o caminho para remover o arquivo');

reset role;
select * from finish();
rollback;
