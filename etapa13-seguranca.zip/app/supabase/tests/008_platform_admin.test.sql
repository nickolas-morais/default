-- Painel da plataforma: acesso com 2FA, venda assistida, contratos manuais,
-- suspensão e auditoria.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(22);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'dono@plataforma.com',
   '{"full_name":"Dono da Plataforma","office_name":"Escritório do Dono","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}'),
  ('22222222-2222-2222-2222-222222222222', 'bruno@escritorio-b.com.br',
   '{"full_name":"Bruno Lima","office_name":"Escritório B","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');

-- Acesso ----------------------------------------------------------------------------
set local role authenticated;
set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated","aal":"aal2"}';
select is(public.platform_admin_status(), 'none', 'usuário comum não é admin da plataforma');
select throws_ok($$select * from public.admin_list_offices()$$, 'P0001', 'FORBIDDEN', 'usuário comum não lista escritórios');
select throws_ok($$select * from public.platform_audit_logs$$, '42501', null, 'auditoria não é legível pela API');
select throws_ok($$insert into public.platform_admins values ('22222222-2222-2222-2222-222222222222')$$, '42501', null,
  'ninguém se promove a admin pela API');
reset role;

insert into public.platform_admins (user_id) values ('11111111-1111-1111-1111-111111111111');
set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated","aal":"aal1"}';
select is(public.platform_admin_status(), 'needs_mfa', 'admin sem 2ª etapa precisa verificar');
select throws_ok($$select * from public.admin_list_offices()$$, 'P0001', 'FORBIDDEN', 'sem 2FA o painel é recusado');

set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated","aal":"aal2"}';
select is(public.platform_admin_status(), 'ok', 'admin com 2FA acessa o painel');
select is((select count(*)::int from public.admin_list_offices()), 2, 'lista todos os escritórios');

-- Venda assistida ---------------------------------------------------------------------
select office_id as novo, invite_token as token from public.admin_create_office('Novo Cliente Advogados', 'Titular@Novo.com', 30, 10) \gset
select is((select count(*)::int from public.admin_audit_log() where action = 'office.create'), 1, 'criação auditada');
reset role;

insert into auth.users (id, email, raw_user_meta_data) values
  ('44444444-4444-4444-4444-444444444444', 'titular@novo.com', jsonb_build_object(
    'full_name','Titular Novo','invite_token', :'token',
    'terms_version','2026-09-provisoria','privacy_version','2026-09-provisoria'));
select is((select role::text || '/' || office_id::text from public.office_members where user_id = '44444444-4444-4444-4444-444444444444'),
  'owner/' || :'novo', 'cliente entra como titular do escritório pré-criado');

set local role authenticated;
set local request.jwt.claims = '{"sub":"44444444-4444-4444-4444-444444444444","role":"authenticated"}';
select is((select source || '/' || doc_limit from public.current_entitlement()), 'trial/10', 'avaliação personalizada (10 documentos)');

set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated","aal":"aal2"}';
select throws_ok(format($$select public.admin_resend_owner_invite(%L, 'outro@novo.com')$$, :'novo'), 'P0001', 'OFFICE_HAS_OWNER',
  'não gera segundo titular');

-- Contrato fora do Stripe --------------------------------------------------------------
select public.admin_create_contract(:'novo', 'profissional', null, now() - interval '40 days', now() + interval '325 days',
  'boleto', 'NF 123, pagamento anual') as contrato \gset
select throws_ok(format($$select public.admin_create_contract(%L, null, 50, now(), now() + interval '30 days', 'nota_fiscal')$$, :'novo'),
  'P0001', 'CONTRACT_OVERLAP', 'contratos não se sobrepõem');

set local request.jwt.claims = '{"sub":"44444444-4444-4444-4444-444444444444","role":"authenticated"}';
select is((select source || '/' || doc_limit from public.current_entitlement()), 'contract/100', 'contrato vale sobre a avaliação');
select ok((select period_start > now() - interval '31 days' and period_end <= now() + interval '31 days' from public.current_entitlement()),
  'cota mensal em ciclos a partir do início do contrato');
select throws_ok('select notes from public.manual_contracts', '42501', null, 'escritório não vê as notas internas do contrato');
select is((select count(*)::int from public.manual_contracts), 1, 'escritório vê a vigência do próprio contrato');

-- Suspensão ---------------------------------------------------------------------------
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated","aal":"aal2"}';
select public.admin_set_suspension(:'novo', true, 'Inadimplência');
set local request.jwt.claims = '{"sub":"44444444-4444-4444-4444-444444444444","role":"authenticated"}';
select throws_ok($$select * from public.create_document_upload('a.pdf', 10)$$, 'P0001', 'OFFICE_SUSPENDED',
  'escritório suspenso não envia documentos');
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated","aal":"aal2"}';
select public.admin_set_suspension(:'novo', false);
select public.admin_cancel_contract(:'contrato');
set local request.jwt.claims = '{"sub":"44444444-4444-4444-4444-444444444444","role":"authenticated"}';
select is((select source from public.current_entitlement()), 'trial', 'contrato cancelado volta à avaliação');
select lives_ok($$select * from public.create_document_upload('a.pdf', 10)$$, 'reativado envia normalmente');

-- Detalhe sem conteúdo de documentos ------------------------------------------------------
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated","aal":"aal2"}';
select is((select jsonb_array_length(public.admin_office_detail(:'novo') -> 'members')), 1, 'detalhe traz os membros');
select ok(not (public.admin_office_detail(:'novo') ?| array['extractions','risks','summaries','documents']),
  'detalhe não expõe conteúdo de documentos');

reset role;
select * from finish();
rollback;
