-- Prazos: extração pela IA, cálculo com dados editados, recorrência,
-- prazos manuais, conclusão, reanálise e lembretes.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(14);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}'),
  ('22222222-2222-2222-2222-222222222222', 'bruno@escritorio-b.com.br',
   '{"full_name":"Bruno Lima","office_name":"Escritório B","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');

set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select document_id as doc from public.create_document_upload('Locação.pdf', 5000) \gset
reset role;

set local role service_role;
select public.mark_document_queued(:'doc', 5000, 3);
select message ->> 'job_id' as job from public.worker_read_jobs(60, 1) \gset
select public.worker_start_job(:'job');
select public.worker_complete_job(:'job', jsonb_build_object(
  'extracao', jsonb_build_object('partes', '[]'::jsonb,
     'data_inicio', to_char(current_date - 400, 'YYYY-MM-DD'), 'data_fim', to_char(current_date + 200, 'YYYY-MM-DD')),
  'riscos', '[]'::jsonb, 'resumo', 'r',
  'prazos', jsonb_build_array(
    jsonb_build_object('tipo','fim_vigencia','titulo','Fim da vigência','data','','referencia','data_fim','deslocamento_dias',0,'recorrencia','nenhuma','clausula','2.1','trecho_original','t'),
    jsonb_build_object('tipo','aviso_nao_renovacao','titulo','Aviso de não renovação','data','','referencia','data_fim','deslocamento_dias',-180,'recorrencia','nenhuma','clausula','2.2','trecho_original','t'),
    jsonb_build_object('tipo','reajuste','titulo','Reajuste anual','data','','referencia','data_inicio','deslocamento_dias',0,'recorrencia','anual','clausula','4.1','trecho_original','t'),
    jsonb_build_object('tipo','garantia','titulo','Entrega da garantia','data', to_char(current_date + 7, 'YYYY-MM-DD'),'referencia','nenhuma','deslocamento_dias',0,'recorrencia','nenhuma','clausula','','trecho_original','t'),
    jsonb_build_object('tipo','outro','titulo','Sem data','data','','referencia','nenhuma','deslocamento_dias',0,'recorrencia','nenhuma','clausula','','trecho_original','t'))
), 'v3', 1, 1);
reset role;

set local role authenticated;
select is((select count(*)::int from public.document_deadlines where document_id = :'doc'), 4, 'prazos sem data calculável são descartados');
select is((select due_date from public.list_deadlines(null, null, :'doc') where title = 'Aviso de não renovação'), current_date + 20,
  'prazo relativo calculado a partir do fim da vigência');
select is((select due_date from public.list_deadlines(null, null, :'doc') where title = 'Reajuste anual'),
  ((current_date - 400) + interval '2 years')::date, 'reajuste anual mostra a próxima ocorrência');

-- Advogada corrige a data de término: os prazos relativos acompanham.
select public.save_extraction(:'doc', jsonb_build_object('partes', '[]'::jsonb, 'data_fim', to_char(current_date + 300, 'YYYY-MM-DD')));
select is((select due_date from public.list_deadlines(null, null, :'doc') where title = 'Aviso de não renovação'), current_date + 120,
  'corrigir a data de término recalcula o prazo');

-- Conclusão
select id as reaj from public.document_deadlines where title = 'Reajuste anual' \gset
select public.complete_deadline(:'reaj');
select is((select due_date from public.list_deadlines(null, null, :'doc') where title = 'Reajuste anual'),
  ((current_date - 400) + interval '3 years')::date, 'concluir recorrente passa para a próxima ocorrência');
select id as fim from public.document_deadlines where title = 'Fim da vigência' \gset
select public.complete_deadline(:'fim');
select is((select due_date from public.list_deadlines(null, null, :'doc') where title = 'Fim da vigência'), null::date,
  'prazo único concluído sai do calendário');
select is((select count(*)::int from public.list_deadlines(null, null, null) where title = 'Fim da vigência'), 0,
  'calendário do escritório não mostra concluídos');
select public.complete_deadline(:'fim', false);

-- Manuais
select public.save_deadline(null, :'doc', 'Vistoria de entrada', current_date + 30) as manual \gset
select is((select source from public.document_deadlines where id = :'manual'), 'manual', 'prazo manual criado');
select public.save_deadline(:'reaj', :'doc', 'Reajuste (ajustado)', current_date + 45, 'yearly');
select is((select source || '/' || base from public.document_deadlines where id = :'reaj'), 'manual/fixed',
  'editar prazo da IA o torna manual');
reset role;

-- Reanálise: prazos da IA substituídos, manuais mantidos.
set local role service_role;
select public.worker_complete_job(:'job', jsonb_build_object('extracao', jsonb_build_object('partes','[]'::jsonb),
  'riscos','[]'::jsonb,'resumo','r','prazos','[]'::jsonb), 'v3', 1, 1);
select is((select count(*)::int from public.document_deadlines where document_id = :'doc'), 2,
  'reanálise mantém só os prazos manuais');
select is((select count(*)::int from public.notify_due_deadlines() where days_left = 30), 1, 'lembrete de 30 dias');
select is((select count(*)::int from public.notify_deadline_recipients(:'doc')), 1, 'titular recebe o lembrete');
reset role;

set local role authenticated;
set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated"}';
select is((select count(*)::int from public.list_deadlines(null, null, null)), 0, 'outro escritório não vê os prazos');
select throws_ok(format($$select public.save_deadline(null, %L, 'Invasão', current_date)$$, :'doc'), 'P0001', 'DOCUMENT_NOT_FOUND',
  'outro escritório não cria prazos');
reset role;

select * from finish();
rollback;
