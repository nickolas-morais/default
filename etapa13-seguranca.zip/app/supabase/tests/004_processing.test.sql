-- Processamento: fila, funções do worker, resultados, cota, reprocessamento,
-- edição, busca e isolamento das tabelas novas.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(50);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}'),
  ('22222222-2222-2222-2222-222222222222', 'bruno@escritorio-b.com.br',
   '{"full_name":"Bruno Lima","office_name":"Escritório B","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');

set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select public.create_office_invitation('carla@exemplo.com', 'member') as token_carla \gset
reset role;
insert into auth.users (id, email, raw_user_meta_data) values
  ('33333333-3333-3333-3333-333333333333', 'carla@exemplo.com', jsonb_build_object(
    'full_name','Carla Dias','invite_token', :'token_carla',
    'terms_version','2026-09-provisoria','privacy_version','2026-09-provisoria'));

-- Upload validado entra na fila ---------------------------------------------------
set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select document_id as doc from public.create_document_upload('Locação Loja Centro.pdf', 5000) \gset
reset role;
set local role service_role;
select public.mark_document_queued(:'doc', 5000, 4);
reset role;

select is((select count(*)::int from public.processing_jobs where document_id = :'doc' and kind = 'initial'), 1,
  'validação cria o job inicial');

set local role service_role;
select msg_id, message ->> 'job_id' as job from public.worker_read_jobs(60, 1) \gset
select is(:'job', (select id::text from public.processing_jobs where document_id = :'doc'),
  'mensagem na fila aponta para o job');

select is((select document_id::text from public.worker_start_job(:'job')), :'doc', 'worker inicia o job');
reset role;
select is((select status::text from public.documents where id = :'doc'), 'preprocessing', 'documento em preparação');
select is((select status::text || '/' || attempts from public.processing_jobs where id = :'job'), 'running/1',
  'job em execução, tentativa 1');

-- Usuário não chama funções do worker.
set local role authenticated;
select throws_ok(format($$select * from public.worker_start_job(%L)$$, :'job'), '42501', null,
  'usuário não inicia jobs');
select throws_ok($$select * from public.worker_read_jobs(1, 1)$$, '42501', null, 'usuário não lê a fila');
select throws_ok(format($$select public.worker_complete_job(%L, '{}', 'x', 1, 1)$$, :'job'), '42501', null,
  'usuário não grava resultados');
reset role;

-- Worker grava páginas, custo e resultados -----------------------------------------
set local role service_role;
select public.worker_set_stage(:'job', 'analyzing');
select public.worker_save_pages(:'job',
  '[{"page":1,"text":"CONTRATO DE LOCAÇÃO"},{"page":2,"text":"Multa de 10 aluguéis"}]', null, false, 2);
select is(public.worker_record_ai_usage(:'job', 'claude-sonnet-5-5', 10000, 2000, 500, 0, 0, 30000, 'end_turn'),
  0.040000::numeric, 'custo calculado pela tabela de preços');
select is(public.worker_record_ai_usage(:'job', 'modelo-sem-preco', 10, 10, 0, 0, 0, 1, 'end_turn'),
  null::numeric, 'modelo sem preço registra tokens com custo nulo');

select ok(public.worker_complete_job(:'job', $json$
{
  "extracao": {
    "partes": [
      {"nome": "Imobiliária Paulista Ltda.", "documento": "11.222.333/0001-81", "papel": "Locadora"},
      {"nome": "Café Aurora ME", "documento": "", "papel": "Locatária"}
    ],
    "objeto": "Locação de loja", "valor": "R$ 8.000,00 mensais", "forma_pagamento": "Boleto",
    "vigencia": "36 meses", "data_inicio": "2026-10-01", "data_fim": "2029-09-30",
    "prazo_rescisao": "30 dias", "multas": [{"descricao": "Rescisão antecipada", "valor": "10 aluguéis"}],
    "foro": "São Paulo/SP", "indice_reajuste": "IGP-M anual"
  },
  "riscos": [
    {"nivel": "Alto", "titulo": "Multa desproporcional", "clausula": "Cláusula 9", "trecho_original": "Multa de 10 aluguéis",
     "pagina": 2, "explicacao": "...", "sugestao_redacao": "...", "parte_prejudicada": "Locatária",
     "pagina_localizada": 2, "score": 1},
    {"nivel": "baixo", "titulo": "Foro", "clausula": "", "trecho_original": "texto que não existe",
     "pagina": 3, "explicacao": "...", "sugestao_redacao": "...", "parte_prejudicada": "",
     "pagina_localizada": null, "score": null}
  ],
  "resumo": "Resumo em linguagem simples."
}$json$::jsonb, '2026-09-v1', 1200, 45000), 'worker conclui o job');
reset role;

select is((select status::text from public.documents where id = :'doc'), 'ready', 'documento pronto');
select is((select count(*)::int from public.risks where document_id = :'doc'), 2, 'riscos gravados');
select is((select level::text from public.risks where document_id = :'doc' and position = 1), 'alto',
  'nível normalizado para minúsculas');
select is((select page_number from public.risks where document_id = :'doc' and position = 2), null::integer,
  'trecho não localizado fica sem página');
select is((select count(*)::int from public.document_parties where document_id = :'doc'), 2, 'partes indexadas');
select is((select document_number from public.document_parties where document_id = :'doc' and role = 'Locadora'),
  '11222333000181', 'CNPJ normalizado para busca');
select is((select documents_processed from public.usage_counters), 1, 'primeira conclusão conta na cota');
select is((select status::text from public.processing_jobs where id = :'job'), 'succeeded', 'job concluído');
select is((select count(*)::int from public.ai_usage where job_id = :'job'), 2, 'uso de IA registrado por chamada');

set local role service_role;
select public.worker_ack(:'msg_id');
reset role;

-- Isolamento e dados internos -------------------------------------------------------
set local role authenticated;
set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated"}';
select is((select count(*)::int from public.risks), 0, 'outro escritório não vê riscos');
select is((select count(*)::int from public.extractions), 0, 'outro escritório não vê extrações');
select is((select count(*)::int from public.summaries), 0, 'outro escritório não vê resumos');
select is((select count(*)::int from public.search_documents('Aurora')), 0, 'busca não atravessa escritórios');
select throws_ok(format($$select public.save_summary(%L, 'invadido')$$, :'doc'), 'P0001', 'DOCUMENT_NOT_FOUND',
  'outro escritório não edita o resumo');

set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select throws_ok('select * from public.ai_usage', '42501', null, 'custo de IA é interno');
select throws_ok('select * from public.document_pages', '42501', null, 'texto das páginas não é exposto');
select throws_ok('select duration_ms from public.processing_jobs', '42501', null, 'tempos do job são internos');
select is((select count(*)::int from public.processing_jobs), 1, 'escritório vê o status dos próprios jobs');

-- Busca -----------------------------------------------------------------------------
select is((select file_name from public.search_documents('aurora')), 'Locação Loja Centro.pdf', 'busca por nome da parte');
select is((select file_name from public.search_documents('11.222.333/0001-81')), 'Locação Loja Centro.pdf', 'busca por CNPJ');
select is((select file_name from public.search_documents('loja centro')), 'Locação Loja Centro.pdf', 'busca por nome do arquivo');
select is((select count(*)::int from public.search_documents('100%')), 0, 'curingas digitados são tratados como texto');
select alike((select parties from public.search_documents(null)), '%Imobiliária Paulista%', 'lista traz as partes');

-- Edição por membro -----------------------------------------------------------------
set local request.jwt.claims = '{"sub":"33333333-3333-3333-3333-333333333333","role":"authenticated"}';
select lives_ok(format($$select public.save_extraction(%L,
  '{"partes":[{"nome":"Café Aurora Comércio Ltda.","documento":"","papel":"Locatária"}]}')$$, :'doc'),
  'membro edita os dados extraídos');
select is((select count(*)::int from public.search_documents('Comércio')), 1, 'busca usa os dados editados');
select throws_ok(format($$select public.request_document_reprocess(%L)$$, :'doc'), 'P0001', 'FORBIDDEN',
  'membro não reprocessa documento de outra pessoa');

-- Reprocessamento não consome cota ---------------------------------------------------
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select lives_ok(format($$select public.request_document_reprocess(%L)$$, :'doc'), 'owner reprocessa');
select throws_ok(format($$select public.request_document_reprocess(%L)$$, :'doc'), 'P0001', 'DOCUMENT_NOT_READY',
  'não reprocessa o que já está na fila');
reset role;

set local role service_role;
select msg_id as msg2, message ->> 'job_id' as job2 from public.worker_read_jobs(60, 1) \gset
select public.worker_start_job(:'job2');
select public.worker_complete_job(:'job2',
  '{"extracao":{"partes":[]},"riscos":[],"resumo":"Novo resumo."}', '2026-09-v1', 10, 10);
reset role;
select is((select documents_processed from public.usage_counters), 1, 'reprocessamento não consome cota');
select is((select edited_data from public.extractions where document_id = :'doc'), null::jsonb,
  'reprocessamento descarta edições');
select is((select count(*)::int from public.document_access_logs where document_id = :'doc' and action = 'reprocess'),
  1, 'reprocessamento fica no log de acesso');

-- Limite de 3 reprocessamentos por dia.
insert into public.processing_jobs (document_id, office_id, kind, status)
select :'doc'::uuid, office_id, 'reprocess'::public.job_kind, 'succeeded'::public.job_status from public.documents where id = :'doc'
union all select :'doc'::uuid, office_id, 'reprocess'::public.job_kind, 'succeeded'::public.job_status from public.documents where id = :'doc';
set local role authenticated;
select throws_ok(format($$select public.request_document_reprocess(%L)$$, :'doc'), 'P0001', 'REPROCESS_LIMIT',
  'limite de reprocessamentos por documento');
reset role;

-- Nova tentativa e falha permanente ----------------------------------------------
set local role authenticated;
select document_id as doc_ruim from public.create_document_upload('escaneado ilegível.pdf', 5000) \gset
reset role;
set local role service_role;
select public.mark_document_queued(:'doc_ruim', 5000, 3);
select message ->> 'job_id' as job3 from public.worker_read_jobs(60, 1) \gset
select public.worker_start_job(:'job3');
select public.worker_retry_job(:'job3', 'AI_UNAVAILABLE');
reset role;
select is((select status::text from public.documents where id = :'doc_ruim'), 'queued', 'falha temporária volta para a fila');

set local role service_role;
select is((select attempts from public.worker_start_job(:'job3')), 2, 'segunda tentativa');
select public.worker_fail_job(:'job3', 'OCR_ILLEGIBLE', true);
reset role;
select is((select status::text || '/' || error_code || '/' || (file_deleted_at is not null)::text
  from public.documents where id = :'doc_ruim'), 'failed/OCR_ILLEGIBLE/true', 'falha permanente descarta o arquivo');

set local role authenticated;
select throws_ok(format($$select public.request_document_reprocess(%L)$$, :'doc_ruim'), 'P0001', 'DOCUMENT_NOT_READY',
  'sem arquivo não há reprocessamento');
reset role;

-- Documento excluído durante o processamento -------------------------------------
set local role authenticated;
select document_id as doc_del from public.create_document_upload('será excluído.pdf', 5000) \gset
reset role;
set local role service_role;
select public.mark_document_queued(:'doc_del', 5000, 1);
select message ->> 'job_id' as job4 from public.worker_read_jobs(60, 1) \gset
select public.worker_start_job(:'job4');
reset role;
set local role authenticated;
select public.delete_document(:'doc_del');
reset role;
set local role service_role;
select ok(not public.worker_complete_job(:'job4', '{"extracao":{},"riscos":[],"resumo":""}', 'v', 1, 1),
  'conclusão de documento excluído devolve false');

-- Envios abandonados --------------------------------------------------------------
reset role;
set local role authenticated;
select document_id as doc_aband from public.create_document_upload('abandonado.pdf', 5000) \gset
reset role;
update public.documents set created_at = now() - interval '3 hours' where id = :'doc_aband';
set local role service_role;
select is((select count(*)::int from public.worker_abandoned_uploads(120) where document_id = :'doc_aband'), 1,
  'worker encontra envio abandonado');
select public.worker_delete_abandoned(:'doc_aband');
reset role;
select is((select count(*)::int from public.documents where id = :'doc_aband'), 0, 'envio abandonado removido');

select * from finish();
rollback;
