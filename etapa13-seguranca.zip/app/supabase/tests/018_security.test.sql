-- Auditoria de segurança: estrutura (RLS, permissões, funções expostas) e
-- ataques simulados (IDOR, adulteração de campos, SQL injection, storage,
-- funções internas, rate limit).
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(50);

-- =============================================================================
-- 1. Estrutura
-- =============================================================================
select is((select count(*)::int from pg_class c join pg_namespace n on n.oid = c.relnamespace
  where n.nspname = 'public' and c.relkind = 'r' and not c.relrowsecurity), 0,
  'RLS ligada em todas as tabelas do schema public');

select is((select count(*)::int from information_schema.role_table_grants
  where table_schema = 'public' and grantee = 'anon' and privilege_type in ('INSERT', 'UPDATE', 'DELETE')), 0,
  'visitante sem login não escreve em nenhuma tabela');

select is((select coalesce(string_agg(p.proname, ', ' order by p.proname), '')
  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
  where n.nspname = 'public' and p.prosecdef
    and not coalesce(array_to_string(p.proconfig, ',') like '%search_path=%', false)), '',
  'toda função security definer fixa o search_path');

select is((select coalesce(string_agg(p.proname, ', ' order by p.proname), '')
  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
  where n.nspname = 'public' and has_function_privilege('anon', p.oid, 'execute')
    and (p.proname like 'worker\_%' or p.proname like 'stripe\_%' or p.proname like 'admin\_%'
         or p.proname like 'notify\_%')), '',
  'funções internas (worker, stripe, admin, avisos) fechadas para visitantes');

select is((select coalesce(string_agg(p.proname, ', ' order by p.proname), '')
  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
  where n.nspname = 'public' and has_function_privilege('authenticated', p.oid, 'execute')
    and (p.proname like 'worker\_%' or p.proname like 'stripe\_%' or p.proname like 'notify\_%')), '',
  'funções do worker, do Stripe e dos avisos fechadas para usuários logados');

select is((select string_agg(p.proname, ', ' order by p.proname)
  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
  where n.nspname = 'public' and has_function_privilege('anon', p.oid, 'execute')),
  'calendar_feed_events, calendar_feed_info, current_legal_version, get_invitation_preview',
  'sem login, só as funções públicas previstas');

select ok(not has_schema_privilege('authenticated', 'private', 'usage'), 'schema private inacessível pela API');
select ok(not has_schema_privilege('anon', 'private', 'usage'), 'schema private inacessível para visitantes');

-- =============================================================================
-- Dados de ataque: escritório A (vítima) e B (atacante)
-- =============================================================================
insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}'),
  ('22222222-2222-2222-2222-222222222222', 'bruno@escritorio-b.com.br',
   '{"full_name":"Bruno Lima","office_name":"Escritório B","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');
select id as office_a from public.offices where name = 'Escritório A' \gset

set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select document_id as doc, storage_path as path from public.create_document_upload('Contrato sigiloso.pdf', 5000) \gset
select public.save_client(null, 'Cliente Sigiloso') as cli \gset
reset role;
set local role service_role;
select public.mark_document_queued(:'doc', 5000, 3);
select message ->> 'job_id' as job from public.worker_read_jobs(60, 1) \gset
select public.worker_start_job(:'job');
select public.worker_complete_job(:'job', '{"extracao":{"partes":[{"nome":"Parte X","documento":"11222333000181","papel":"Locadora"}]},"resumo":"sigiloso","prazos":[],"riscos":[
  {"nivel":"alto","titulo":"Multa","trecho_original":"x","explicacao":"e","sugestao_redacao":"s"}]}', 'v4', 1, 1);
reset role;
select id as risk from public.risks where document_id = :'doc' \gset

-- =============================================================================
-- 2. IDOR: Bruno usa ids do escritório A
-- =============================================================================
set local role authenticated;
set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated"}';

select is((select count(*)::int from public.documents where id = :'doc'), 0, 'IDOR: documento de outro escritório pelo id');
select is((select count(*)::int from public.extractions where document_id = :'doc'), 0, 'IDOR: dados extraídos');
select is((select count(*)::int from public.risks where id = :'risk'), 0, 'IDOR: riscos');
select is((select count(*)::int from public.summaries where document_id = :'doc'), 0, 'IDOR: resumo');
select is((select count(*)::int from public.document_parties), 0, 'IDOR: partes (busca por CNPJ)');
select is((select count(*)::int from public.clients where id = :'cli'), 0, 'IDOR: clientes');
select is((select count(*)::int from public.profiles where id = '11111111-1111-1111-1111-111111111111'), 0, 'IDOR: perfil de outra pessoa');
select is((select count(*)::int from public.document_access_logs), 0, 'IDOR: registro de acesso');
select is((select count(*)::int from public.search_documents('Contrato')), 0, 'IDOR: busca não vaza documentos');
select throws_ok(format($$select public.save_extraction(%L, '{"partes":[]}')$$, :'doc'), 'P0001', null, 'IDOR: editar dados de outro escritório');
select throws_ok(format($$select public.save_summary(%L, 'invadido')$$, :'doc'), 'P0001', null, 'IDOR: editar resumo');
select throws_ok(format($$select public.request_document_reprocess(%L)$$, :'doc'), 'P0001', null, 'IDOR: reprocessar (gastar a IA do outro)');
select throws_ok(format($$select public.set_document_organization(%L, p_review_status => 'aprovado')$$, :'doc'), 'P0001', null, 'IDOR: mudar status de revisão');
select throws_ok(format($$select public.set_risk_resolution(%L, 'resolvido')$$, :'risk'), 'P0001', null, 'IDOR: marcar risco');
select throws_ok(format($$select public.save_deadline(null, %L, 'Prazo falso', current_date)$$, :'doc'), 'P0001', null, 'IDOR: criar prazo');
select throws_ok(format($$select * from public.create_version_upload(%L, 'v2.pdf', 10)$$, :'doc'), 'P0001', null, 'IDOR: criar versão no documento do outro');
select throws_ok(format($$select public.set_document_organization(
  (select id from public.documents limit 1), %L)$$, :'cli'), 'P0001', null, 'IDOR: vincular cliente de outro escritório');

-- =============================================================================
-- 3. Adulteração de campos (mass assignment)
-- =============================================================================
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select throws_ok($$update public.office_members set role = 'owner'$$, '42501', null, 'não troca o próprio papel');
select throws_ok($$update public.offices set daily_failure_limit = 100000$$, '42501', null, 'não aumenta o limite de falhas');
select throws_ok($$update public.offices set trial_doc_limit = 100000$$, '42501', null, 'não aumenta a própria avaliação');
select throws_ok($$update public.offices set suspended_at = null$$, '42501', null, 'não se desbloqueia de uma suspensão');
select throws_ok($$update public.offices set stripe_customer_id = 'cus_outro'$$, '42501', null, 'não troca o cliente do Stripe');
select throws_ok(format($$update public.documents set status = 'ready' where id = %L$$, :'doc'), '42501', null, 'não muda o status do documento');
select throws_ok(format($$update public.documents set billing = 'free_version' where id = %L$$, :'doc'), '42501', null, 'não marca documento como gratuito');
select throws_ok($$insert into public.subscriptions (office_id, plan_id, stripe_subscription_id, status)
  select id, 'escritorio', 'sub_falso', 'active' from public.offices$$, '42501', null, 'não cria assinatura falsa');
select throws_ok($$insert into public.manual_contracts (office_id, doc_limit, starts_at, ends_at, billing_method)
  select id, 99999, now(), now() + interval '10 years', 'outro' from public.offices$$, '42501', null, 'não cria contrato manual');
select throws_ok($$update public.usage_counters set documents_processed = 0$$, '42501', null, 'não zera o uso do período');
select throws_ok(format($$update public.risks set level = 'baixo' where id = %L$$, :'risk'), '42501', null, 'não altera riscos diretamente');
select throws_ok($$update public.profiles set email = 'x@x.com'$$, '42501', null, 'e-mail só muda pelo fluxo de confirmação');
select throws_ok($$select * from public.ai_usage$$, '42501', null, 'custos de IA não legíveis pela API');
select throws_ok($$select token_hash from public.office_invitations$$, '42501', null, 'hash de convites não legível');
select throws_ok($$select public.stripe_upsert_subscription('cus_x', 'sub_x', 'escritorio_mensal', 'price_x', 'active', now(), now() + interval '10 years', false)$$,
  '42501', null, 'webhook do Stripe não pode ser forjado pela API');
select throws_ok($$select public.admin_set_trial((select id from public.offices), now() + interval '10 years', 99999)$$,
  'P0001', 'FORBIDDEN', 'funções do painel recusam usuário comum');

-- =============================================================================
-- 4. SQL injection
-- =============================================================================
select lives_ok($$select * from public.search_documents($q$'; drop table public.documents; --$q$)$$, 'busca com injeção não quebra');
select ok(to_regclass('public.documents') is not null, 'tabela documents continua existindo');
select is((select count(*)::int from public.search_documents($q$' or '1'='1$q$)), 0, 'OR 1=1 não retorna tudo');
select public.save_client(null, $q$Robert'); drop table public.clients; --$q$) as evil \gset
select is((select name from public.clients where id = :'evil'), $q$Robert'); drop table public.clients; --$q$, 'texto malicioso é gravado como texto');
select lives_ok($$select * from public.list_clients($q$%' or 1=1 --$q$)$$, 'busca de clientes com injeção não quebra');

-- =============================================================================
-- 5. Armazenamento
-- =============================================================================
select is((select count(*)::int from storage.objects), 0, 'usuário não lista arquivos (só URL assinada pelo servidor)');
set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated"}';
select throws_ok(format($$insert into storage.objects (bucket_id, name, owner) values ('documents', %L, auth.uid())$$, :'path'),
  '42501', null, 'não grava arquivo no caminho de outro escritório');
reset role;

-- =============================================================================
-- 6. Rate limit
-- =============================================================================
set local role authenticated;
set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated"}';
create function pg_temp.flood() returns text language plpgsql as $$
begin
  for i in 1..301 loop perform public.save_client(null, 'Cliente ' || i); end loop;
  return 'ok';
exception when others then return sqlerrm;
end $$;
select is(pg_temp.flood(), 'RATE_LIMITED', 'cadastro em massa bloqueado pelo limite de frequência');
reset role;
set local role service_role;
select lives_ok(format($$select public.worker_complete_job(%L, '{"extracao":{"partes":[]},"resumo":"r","prazos":[],"riscos":[]}', 'v4', 1, 1)$$, :'job'),
  'limite não afeta o worker');
reset role;

select * from finish();
rollback;
