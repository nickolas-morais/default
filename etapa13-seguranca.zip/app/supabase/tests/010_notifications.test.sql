-- Avisos: deduplicação, destinatários, preferências e fila.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(9);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');
select id as office from public.offices \gset

set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select throws_ok($$select public.notify_claim('x', 'y')$$, '42501', null, 'usuário não usa funções de aviso');
update public.profiles set notify_quota = false;
select document_id as doc from public.create_document_upload('Contrato.pdf', 10) \gset
reset role;

set local role service_role;
select ok(public.notify_claim('quota80:a:2026-10', 'quota'), 'primeira reserva do aviso');
select ok(not public.notify_claim('quota80:a:2026-10', 'quota'), 'aviso repetido é bloqueado');
select public.notify_release('quota80:a:2026-10');
select ok(public.notify_claim('quota80:a:2026-10', 'quota'), 'liberado após falha, pode reenviar');

select is((select count(*)::int from public.notify_office_admins(:'office')), 1, 'titular recebe avisos do escritório');
select is((select count(*)::int from public.notify_office_admins(:'office', true)), 0, 'quem desligou avisos de cota não recebe');
select is((select source || '/' || doc_limit || '/' || used from public.notify_quota_status(:'office')), 'trial/5/0',
  'uso da cota para o aviso');

select public.mark_document_queued(:'doc', 10, 1);
reset role;
update public.documents set queued_at = now() - interval '30 minutes' where id = :'doc';
set local role service_role;
select is((select waiting from public.notify_queue_backlog(15)), 1, 'fila acumulada detectada');
select is((select count(*)::int from public.notify_document_uploader(:'doc')), 0, 'aviso de análise só para documento pronto');
reset role;

select * from finish();
rollback;
