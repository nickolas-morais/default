-- Documentos: criação de upload, storage, transições, limite de falhas,
-- exclusão e log de acesso.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(30);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}'),
  ('22222222-2222-2222-2222-222222222222', 'bruno@escritorio-b.com.br',
   '{"full_name":"Bruno Lima","office_name":"Escritório B","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');

-- Carla entra no escritório A como membro.
set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select public.create_office_invitation('carla@exemplo.com', 'member') as token_carla \gset
reset role;
insert into auth.users (id, email, raw_user_meta_data) values
  ('33333333-3333-3333-3333-333333333333', 'carla@exemplo.com', jsonb_build_object(
    'full_name','Carla Dias','invite_token', :'token_carla',
    'terms_version','2026-09-provisoria','privacy_version','2026-09-provisoria'));

-- Ana cria um upload ------------------------------------------------------------
set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select document_id as doc_ana, storage_path as path_ana
from public.create_document_upload('Contrato de Locação.PDF', 120000, '200.1.1.1', 'pgtap') \gset

select is(:'path_ana', public.current_office_id()::text || '/' || :'doc_ana' || '/original.pdf',
  'caminho segue {escritório}/{documento}/original.pdf');
select is((select status::text from public.documents where id = :'doc_ana'), 'uploading',
  'documento nasce como uploading');
select is((select count(*)::int from public.document_access_logs where document_id = :'doc_ana' and action = 'upload'),
  1, 'upload fica registrado no log de acesso');

select throws_ok($$select * from public.create_document_upload('minuta.doc', 1000)$$,
  'P0001', 'UNSUPPORTED_TYPE', 'recusa .doc');
select throws_ok($$select * from public.create_document_upload('contrato.pdf', 26214401)$$,
  'P0001', 'FILE_TOO_LARGE', 'recusa arquivo acima de 25 MB');
select throws_ok($$select * from public.create_document_upload('contrato.pdf', 0)$$,
  'P0001', 'FILE_EMPTY', 'recusa arquivo vazio');

-- Storage: só o caminho exato do documento 'uploading' do próprio usuário.
select lives_ok(
  format($$insert into storage.objects (bucket_id, name) values ('documents', %L)$$, :'path_ana'),
  'Ana envia o arquivo para o caminho autorizado');
select throws_ok(
  format($$insert into storage.objects (bucket_id, name) values ('documents', %L)$$,
    public.current_office_id()::text || '/' || gen_random_uuid()::text || '/original.pdf'),
  '42501', null, 'caminho sem documento correspondente é recusado');

select throws_ok($$update public.documents set status = 'ready'$$, '42501', null,
  'cliente não altera documents diretamente');
select throws_ok(format($$select public.mark_document_queued(%L, 1, 1)$$, :'doc_ana'), '42501', null,
  'cliente não marca documento como validado');
select throws_ok(format($$select public.fail_document(%L, 'X')$$, :'doc_ana'), '42501', null,
  'cliente não registra falhas');

-- Bruno (escritório B) ------------------------------------------------------------
set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated"}';
select is((select count(*)::int from public.documents), 0, 'outro escritório não vê o documento');
select is((select count(*)::int from public.document_access_logs), 0, 'outro escritório não vê o log');
select throws_ok(
  format($$insert into storage.objects (bucket_id, name) values ('documents', %L)$$, :'path_ana'),
  '42501', null, 'outro escritório não grava na pasta do escritório A');
select throws_ok(format($$select public.log_document_access(%L, 'view')$$, :'doc_ana'),
  'P0001', 'DOCUMENT_NOT_FOUND', 'outro escritório não registra acesso ao documento');
select ok(not public.can_delete_document(:'doc_ana'), 'outro escritório não pode excluir');
select throws_ok(format($$select public.delete_document(%L)$$, :'doc_ana'),
  'P0001', 'FORBIDDEN', 'exclusão por outro escritório é recusada');

-- Servidor valida e enfileira ----------------------------------------------------
reset role;
set local role service_role;
select lives_ok(format($$select public.mark_document_queued(%L, 118000, 12)$$, :'doc_ana'),
  'service_role marca documento como na fila');
reset role;

set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select is((select status::text || '/' || page_count from public.documents where id = :'doc_ana'), 'queued/12',
  'status e páginas atualizados');

-- Permissões de exclusão ----------------------------------------------------------
set local request.jwt.claims = '{"sub":"33333333-3333-3333-3333-333333333333","role":"authenticated"}';
select document_id as doc_carla from public.create_document_upload('Aditivo.docx', 5000) \gset
select ok(not public.can_delete_document(:'doc_ana'), 'membro não exclui documento de outra pessoa');
select ok(public.can_delete_document(:'doc_carla'), 'membro exclui o próprio documento');
select is((select count(*)::int from public.document_access_logs), 0, 'membro não lê o log de acesso');
select lives_ok(format($$select public.log_document_access(%L, 'view')$$, :'doc_ana'),
  'membro registra visualização de documento do escritório');
select throws_ok(format($$select public.log_document_access(%L, 'delete')$$, :'doc_ana'),
  'P0001', 'FORBIDDEN', 'log de exclusão só pela função de exclusão');

set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select lives_ok(format($$select public.delete_document(%L)$$, :'doc_carla'),
  'owner exclui documento de membro');
select is((select count(*)::int from public.document_access_logs where document_id = :'doc_carla' and action = 'delete'),
  1, 'exclusão fica no log mesmo sem o documento');

-- Limite de tentativas com falha --------------------------------------------------
reset role;
update public.offices set daily_failure_limit = 2
where id = (select office_id from public.office_members where user_id = '11111111-1111-1111-1111-111111111111');

set local role authenticated;
select document_id as f1 from public.create_document_upload('ruim1.pdf', 10) \gset
select document_id as f2 from public.create_document_upload('ruim2.pdf', 10) \gset
reset role;
set local role service_role;
select public.fail_document(:'f1', 'FILE_CORRUPTED');
select public.fail_document(:'f2', 'FILE_CORRUPTED');
reset role;

set local role authenticated;
select throws_ok($$select * from public.create_document_upload('mais-um.pdf', 10)$$,
  'P0001', 'FAILED_ATTEMPTS_LIMIT', 'bloqueia após atingir o limite diário de falhas');

select public.delete_document(:'f1');
select public.delete_document(:'f2');
select throws_ok($$select * from public.create_document_upload('mais-um.pdf', 10)$$,
  'P0001', 'FAILED_ATTEMPTS_LIMIT', 'excluir documentos com falha não zera o contador');

-- Cancelamento de envio interrompido ----------------------------------------------
reset role;
update public.offices set daily_failure_limit = 20;
set local role authenticated;
select document_id as doc_cancel from public.create_document_upload('interrompido.pdf', 10) \gset
select public.cancel_document_upload(:'doc_cancel');
select is((select count(*)::int from public.documents where id = :'doc_cancel'), 0,
  'envio interrompido é removido');
select public.cancel_document_upload(:'doc_ana');
select is((select count(*)::int from public.documents where id = :'doc_ana'), 1,
  'cancelamento não remove documento já validado');

reset role;
select * from finish();
rollback;
