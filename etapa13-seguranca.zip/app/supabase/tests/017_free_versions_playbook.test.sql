-- Versões gratuitas (limite, cota) e Playbook (regras, plano, marcação nos riscos).
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(13);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');
select id as office from public.offices \gset

create function pg_temp.finish_doc(p_doc uuid, p_result jsonb) returns void language plpgsql as $$
declare v_job text;
begin
  perform public.mark_document_queued(p_doc, 10, 1);
  select message ->> 'job_id' into v_job from public.worker_read_jobs(60, 1);
  perform public.worker_start_job(v_job::uuid);
  perform public.worker_save_pages(v_job::uuid, '[{"page":1,"text":"contrato"}]', null, false, 1);
  perform public.worker_complete_job(v_job::uuid, p_result, 'v4', 1, 1);
end $$;

set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select document_id as v1 from public.create_document_upload('Contrato v1.pdf', 10) \gset
reset role;
select pg_temp.finish_doc(:'v1', '{"extracao":{"partes":[]},"riscos":[],"resumo":"r","prazos":[]}');

-- Versões 2, 3 e 4 gratuitas; a 5 conta.
set local role authenticated;
select document_id as v2, free as f2 from public.create_version_upload(:'v1', 'Contrato v2.pdf', 10) \gset
select ok(:'f2'::boolean, 'v2 é gratuita');
reset role;
select pg_temp.finish_doc(:'v2', '{"extracao":{"partes":[]},"riscos":[],"resumo":"r","prazos":[]}');
select is((select documents_processed from public.usage_counters), 1, 'versão gratuita não soma no contador');
set local role authenticated;
select is((select used from public.current_entitlement()), 1, 'nem na cota do período');
select document_id as v3 from public.create_version_upload(:'v2', 'Contrato v3.pdf', 10) \gset
reset role;
select pg_temp.finish_doc(:'v3', '{"extracao":{"partes":[]},"riscos":[],"resumo":"r","prazos":[]}');
set local role authenticated;
select document_id as v4 from public.create_version_upload(:'v3', 'Contrato v4.pdf', 10) \gset
reset role;
select pg_temp.finish_doc(:'v4', '{"extracao":{"partes":[]},"riscos":[],"resumo":"r","prazos":[]}');
set local role authenticated;
select document_id as v5, free as f5, version_number as n5 from public.create_version_upload(:'v4', 'Contrato v5.pdf', 10) \gset
select ok(not :'f5'::boolean and :'n5'::int = 5, 'a partir da v5, conta na cota');
select throws_ok(format($$select * from public.create_version_upload(%L, 'outra.pdf', 10)$$, :'v1'), 'P0001', 'VERSION_EXISTS',
  'nova versão só a partir da mais recente');
reset role;

set local role service_role;
select is((select jsonb_array_length(public.worker_previous_pages(:'v2'))), 1, 'worker recebe o texto da versão anterior');
select is(public.worker_previous_pages(:'v1'), null::jsonb, 'primeira versão não tem anterior');
reset role;

-- Playbook
set local role authenticated;
select public.save_playbook_rule(null, 'Foro em São Paulo', 'O foro de eleição deve ser a Comarca de São Paulo/SP.', 'alto') as rule \gset
select is((select current_features() ->> 'playbook'), 'true', 'avaliação inclui o Playbook');
reset role;
set local role service_role;
select is((select count(*)::int from public.worker_playbook_rules(:'office')), 1, 'worker recebe as regras ativas');
reset role;
select pg_temp.finish_doc(:'v5', jsonb_build_object('extracao', '{"partes":[]}'::jsonb, 'resumo', 'r', 'prazos', '[]'::jsonb,
  'riscos', jsonb_build_array(jsonb_build_object('nivel','alto','titulo','Foro fora de SP','trecho_original','x','explicacao','e',
    'sugestao_redacao','s','playbook_rule_id', :'rule'))));
select is((select playbook_rule_id::text from public.risks where document_id = :'v5'), :'rule', 'risco marcado com a regra do escritório');

-- Plano sem Playbook
insert into public.subscriptions (office_id, plan_id, stripe_subscription_id, status, current_period_start, current_period_end)
values (:'office', 'essencial', 'sub_x', 'active', now() - interval '1 day', now() + interval '29 days');
set local role authenticated;
select is((select current_features() ->> 'playbook'), 'false', 'plano Essencial não inclui o Playbook');
reset role;
set local role service_role;
select is((select count(*)::int from public.worker_playbook_rules(:'office')), 0, 'sem o recurso, as regras não entram na análise');
reset role;
update public.subscriptions set plan_id = 'profissional';
set local role authenticated;
select is((select current_features() ->> 'playbook'), 'true', 'plano Profissional inclui o Playbook');
reset role;

select * from finish();
rollback;
