-- Feedback dos advogados sobre os riscos e estatística de qualidade.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(9);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}'),
  ('22222222-2222-2222-2222-222222222222', 'bruno@escritorio-b.com.br',
   '{"full_name":"Bruno Lima","office_name":"Escritório B","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');

set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select document_id as doc from public.create_document_upload('Locação.pdf', 5000) \gset
reset role;
set local role service_role;
select public.mark_document_queued(:'doc', 5000, 3);
select message ->> 'job_id' as job from public.worker_read_jobs(60, 1) \gset
select public.worker_start_job(:'job');
select public.worker_complete_job(:'job', $j$
{"extracao":{"partes":[]},"resumo":"r","riscos":[
 {"nivel":"alto","titulo":"Multa","trecho_original":"a","explicacao":"e","sugestao_redacao":"s","pagina_localizada":2,"score":1},
 {"nivel":"baixo","titulo":"Foro","trecho_original":"b","explicacao":"e","sugestao_redacao":"s","pagina_localizada":null,"score":null}]}
$j$::jsonb, 'v-teste', 1, 1);
reset role;
select id as risk1 from public.risks where document_id = :'doc' and position = 1 \gset
select id as risk2 from public.risks where document_id = :'doc' and position = 2 \gset

set local role authenticated;
select lives_ok(format($$select public.set_risk_feedback(%L, 'util')$$, :'risk1'), 'advogado marca risco como útil');
select lives_ok(format($$select public.set_risk_feedback(%L, 'nao_procede', 'Cláusula é padrão')$$, :'risk2'), 'marca como não procede com comentário');
select lives_ok(format($$select public.set_risk_feedback(%L, 'nao_procede')$$, :'risk1'), 'muda de ideia');
select is((select count(*)::int from public.risk_feedback where verdict = 'nao_procede'), 2, 'uma avaliação por risco e usuário');
select lives_ok(format($$select public.set_document_feedback(%L, 'Faltou a renúncia ao direito de preferência')$$, :'doc'),
  'informa risco não apontado');

set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated"}';
select throws_ok(format($$select public.set_risk_feedback(%L, 'util')$$, :'risk1'), 'P0001', 'DOCUMENT_NOT_FOUND',
  'outro escritório não avalia');
select is((select count(*)::int from public.risk_feedback), 0, 'outro escritório não vê as avaliações');
reset role;

insert into public.platform_admins values ('22222222-2222-2222-2222-222222222222');
set local role authenticated;
set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated","aal":"aal2"}';
select is((select risks || '/' || rated || '/' || not_applicable || '/' || documents_with_missing || '/' || located_pct
  from public.admin_quality_stats() where prompt_version = 'v-teste'), '2/2/2/1/50.0', 'painel vê apenas contagens por versão');
select ok((select not ('comment' = any(proargnames)) from pg_proc where proname = 'admin_quality_stats'),
  'comentários não saem para o painel');
reset role;

select * from finish();
rollback;
