-- "Nosso cliente é…": perspectiva, preservação da extração e limites.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(12);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}'),
  ('22222222-2222-2222-2222-222222222222', 'bruno@escritorio-b.com.br',
   '{"full_name":"Bruno Lima","office_name":"Escritório B","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');

set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select public.create_office_invitation('carla@exemplo.com', 'member') as token_carla \gset
select document_id as doc from public.create_document_upload('Locação.pdf', 5000) \gset
reset role;
insert into auth.users (id, email, raw_user_meta_data) values
  ('33333333-3333-3333-3333-333333333333', 'carla@exemplo.com', jsonb_build_object(
    'full_name','Carla Dias','invite_token', :'token_carla',
    'terms_version','2026-09-provisoria','privacy_version','2026-09-provisoria'));

set local role service_role;
select public.mark_document_queued(:'doc', 5000, 3);
select message ->> 'job_id' as job from public.worker_read_jobs(60, 1) \gset
select public.worker_start_job(:'job');
select public.worker_complete_job(:'job', '{"extracao":{"partes":[{"nome":"Café Aurora","documento":"","papel":"Locatária"}]},"riscos":[{"nivel":"medio","titulo":"Neutro","trecho_original":"x","explicacao":"e","sugestao_redacao":"s"}],"resumo":"neutro"}', 'v1', 1, 1);
reset role;

-- Advogada (membro) edita os dados e escolhe a perspectiva.
set local role authenticated;
set local request.jwt.claims = '{"sub":"33333333-3333-3333-3333-333333333333","role":"authenticated"}';
select public.save_extraction(:'doc', '{"partes":[{"nome":"Café Aurora Ltda.","documento":"","papel":"Locatária"}]}');
select lives_ok(format($$select public.request_document_perspective(%L, 'Café Aurora Ltda.', 'Locatária')$$, :'doc'),
  'membro escolhe a parte representada');
select is((select status::text || '/' || client_party_name || '/' || client_party_role from public.documents where id = :'doc'),
  'queued/Café Aurora Ltda./Locatária', 'documento volta para a fila com a perspectiva');
reset role;

set local role service_role;
select message ->> 'job_id' as job2 from public.worker_read_jobs(60, 1) \gset
select is((select kind::text || '/' || client_party_role from public.worker_start_job(:'job2')), 'perspective/Locatária',
  'worker recebe o tipo e a perspectiva');
select public.worker_complete_job(:'job2', '{"extracao":{"partes":[]},"riscos":[{"nivel":"alto","titulo":"A favor da locatária","trecho_original":"y","explicacao":"e","sugestao_redacao":"s","parte_prejudicada":"Locatária"}],"resumo":"para você"}', 'v2', 1, 1);
reset role;

select is((select edited_data -> 'partes' -> 0 ->> 'nome' from public.extractions where document_id = :'doc'), 'Café Aurora Ltda.',
  'edições nos dados extraídos são mantidas');
select is((select ai_data -> 'partes' -> 0 ->> 'nome' from public.extractions where document_id = :'doc'), 'Café Aurora',
  'extração original da IA não é substituída');
select is((select title from public.risks where document_id = :'doc'), 'A favor da locatária', 'riscos refeitos');
select is((select ai_content from public.summaries where document_id = :'doc'), 'para você', 'resumo refeito');
select is((select documents_processed from public.usage_counters), 1, 'perspectiva não consome cota');

-- Regras
set local role authenticated;
set local request.jwt.claims = '{"sub":"33333333-3333-3333-3333-333333333333","role":"authenticated"}';
select throws_ok(format($$select public.request_document_perspective(%L, 'Café Aurora Ltda.', 'Locatária')$$, :'doc'),
  'P0001', 'PERSPECTIVE_UNCHANGED', 'mesma perspectiva não gera nova análise');
reset role;
insert into public.processing_jobs (document_id, office_id, kind, status)
select :'doc'::uuid, office_id, 'reprocess'::public.job_kind, 'succeeded'::public.job_status from public.documents where id = :'doc'
union all select :'doc'::uuid, office_id, 'reprocess'::public.job_kind, 'succeeded'::public.job_status from public.documents where id = :'doc';
set local role authenticated;
select throws_ok(format($$select public.request_document_perspective(%L, null)$$, :'doc'), 'P0001', 'REPROCESS_LIMIT',
  'perspectiva e reprocessamento dividem o limite de 3 por dia');

set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated"}';
select throws_ok(format($$select public.request_document_perspective(%L, 'x')$$, :'doc'), 'P0001', 'DOCUMENT_NOT_FOUND',
  'outro escritório não altera a perspectiva');
reset role;
select is((select count(*)::int from public.document_access_logs where document_id = :'doc' and action = 'reprocess'), 1,
  'troca de perspectiva fica no log');

select * from finish();
rollback;
