-- Convites, papéis e remoção de membros.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(21);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}'),
  ('22222222-2222-2222-2222-222222222222', 'bruno@escritorio-b.com.br',
   '{"full_name":"Bruno Lima","office_name":"Escritório B","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');

-- Ana convida Carla ---------------------------------------------------------------
set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select public.create_office_invitation('Carla@Exemplo.com ', 'member') as token_carla \gset

select ok(length(:'token_carla') >= 40, 'convite devolve token forte');
select is((select email from public.office_invitations), 'carla@exemplo.com', 'e-mail do convite é normalizado');
select throws_ok('select token_hash from public.office_invitations', '42501', null,
  'hash do token não é legível pela API');

-- Bruno não enxerga convites do escritório A.
set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated"}';
select is((select count(*)::int from public.office_invitations), 0, 'outro escritório não vê o convite');
reset role;

-- Prévia pública ------------------------------------------------------------------
set local role anon;
select results_eq(
  format('select office_name, status from public.get_invitation_preview(%L)', :'token_carla'),
  $$values ('Escritório A'::text, 'valid'::text)$$,
  'prévia do convite funciona sem login');
select is((select count(*)::int from public.get_invitation_preview('token-inexistente')), 0,
  'token inexistente não retorna nada');
reset role;

-- Cadastro pelo convite ---------------------------------------------------------------
select throws_ok(
  format($$insert into auth.users (id, email, raw_user_meta_data) values
    (gen_random_uuid(), 'outra@exemplo.com', jsonb_build_object(
      'full_name','Outra Pessoa','invite_token',%L,
      'terms_version','2026-09-provisoria','privacy_version','2026-09-provisoria'))$$, :'token_carla'),
  'P0001', 'INVITE_EMAIL_MISMATCH', 'convite só vale para o e-mail convidado');

select lives_ok(
  format($$insert into auth.users (id, email, raw_user_meta_data) values
    ('33333333-3333-3333-3333-333333333333', 'carla@exemplo.com', jsonb_build_object(
      'full_name','Carla Dias','invite_token',%L,
      'terms_version','2026-09-provisoria','privacy_version','2026-09-provisoria'))$$, :'token_carla'),
  'Carla se cadastra pelo convite');

select is(
  (select o.name from public.office_members m join public.offices o on o.id = m.office_id
   where m.user_id = '33333333-3333-3333-3333-333333333333'),
  'Escritório A', 'Carla entra no escritório A');

select throws_ok(
  format($$insert into auth.users (id, email, raw_user_meta_data) values
    (gen_random_uuid(), 'carla@exemplo.com', jsonb_build_object(
      'full_name','Carla Dois','invite_token',%L,
      'terms_version','2026-09-provisoria','privacy_version','2026-09-provisoria'))$$, :'token_carla'),
  'P0001', 'INVITE_USED', 'convite não pode ser reutilizado');

-- Carla (member) ------------------------------------------------------------------
set local role authenticated;
set local request.jwt.claims = '{"sub":"33333333-3333-3333-3333-333333333333","role":"authenticated"}';
select is((select count(*)::int from public.profiles), 2, 'membro vê os colegas do escritório');
select throws_ok($$select public.create_office_invitation('x@exemplo.com', 'member')$$,
  'P0001', 'FORBIDDEN', 'member não convida');
select throws_ok($$select public.remove_office_member('11111111-1111-1111-1111-111111111111')$$,
  'P0001', 'FORBIDDEN', 'member não remove ninguém');

-- Ana (owner) --------------------------------------------------------------------
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select throws_ok($$select public.remove_office_member('11111111-1111-1111-1111-111111111111')$$,
  'P0001', 'CANNOT_REMOVE_SELF', 'owner não remove a si mesmo');
select throws_ok($$select public.create_office_invitation('carla@exemplo.com', 'member')$$,
  'P0001', 'ALREADY_MEMBER', 'não convida quem já é membro');
select lives_ok($$select public.remove_office_member('33333333-3333-3333-3333-333333333333')$$,
  'owner remove membro');

-- Carla sem escritório perde acesso a tudo.
set local request.jwt.claims = '{"sub":"33333333-3333-3333-3333-333333333333","role":"authenticated"}';
select is(public.current_office_id(), null::uuid, 'removida fica sem escritório');
select is((select count(*)::int from public.offices), 0, 'removida não vê mais o escritório');

-- Ana convida Carla de novo; Carla (logada) aceita.
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select public.create_office_invitation('carla@exemplo.com', 'member') as token_volta \gset
set local request.jwt.claims = '{"sub":"33333333-3333-3333-3333-333333333333","role":"authenticated"}';
select lives_ok(format('select public.accept_office_invitation(%L)', :'token_volta'),
  'usuária logada sem escritório aceita convite');

-- Bruno convida Ana, que já tem escritório.
set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated"}';
select public.create_office_invitation('ana@escritorio-a.com.br', 'member') as token_ana \gset
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select throws_ok(format('select public.accept_office_invitation(%L)', :'token_ana'),
  'P0001', 'ALREADY_HAS_OFFICE', 'usuário com escritório não entra em outro (regra do MVP)');

-- Bruno não remove membro de outro escritório.
set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated"}';
select throws_ok($$select public.remove_office_member('33333333-3333-3333-3333-333333333333')$$,
  'P0001', 'MEMBER_NOT_FOUND', 'não remove membro de outro escritório');

reset role;
select * from finish();
rollback;
