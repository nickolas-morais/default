-- Clientes com indicadores e visão da equipe.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(8);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');
set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select public.create_office_invitation('carla@exemplo.com', 'member') as token_carla \gset
select document_id as doc from public.create_document_upload('Locação.pdf', 5000) \gset
select public.save_client(null, 'Café Aurora', '12.ABC.345/01DE-35') as cli \gset
select public.save_client(null, 'Cliente Antigo') as old \gset
select public.archive_client(:'old');
reset role;
insert into auth.users (id, email, raw_user_meta_data) values
  ('33333333-3333-3333-3333-333333333333', 'carla@exemplo.com', jsonb_build_object(
    'full_name','Carla Dias','invite_token', :'token_carla',
    'terms_version','2026-09-provisoria','privacy_version','2026-09-provisoria'));
set local role service_role;
select public.mark_document_queued(:'doc', 5000, 3);
select message ->> 'job_id' as job from public.worker_read_jobs(60, 1) \gset
select public.worker_start_job(:'job');
select public.worker_complete_job(:'job', '{"extracao":{"partes":[]},"resumo":"r","prazos":[],"riscos":[
  {"nivel":"alto","titulo":"Multa","trecho_original":"a","explicacao":"e","sugestao_redacao":"s"}]}', 'v3', 1, 1);
reset role;

set local role authenticated;
select public.set_document_organization(:'doc', :'cli', p_review_status => 'em_revisao');
select public.save_deadline(null, :'doc', 'Vencido', current_date - 3);

select is((select documents || '/' || in_review || '/' || open_high_risks from public.list_clients() where id = :'cli'), '1/1/1',
  'cliente com documentos, revisão e riscos em aberto');
select is((select count(*)::int from public.list_clients()), 1, 'arquivados ficam fora por padrão');
select is((select count(*)::int from public.list_clients(null, true)), 2, 'arquivados aparecem quando pedido');
select is((select name from public.list_clients('12.ABC.345/01DE-35')), 'Café Aurora', 'busca pelo CNPJ do cliente');

select is((select in_review || '/' || open_high_risks || '/' || overdue_deadlines from public.team_overview()
  where assignee_id = '11111111-1111-1111-1111-111111111111'), '1/1/1', 'carga da titular: revisão, riscos e prazos vencidos');
select public.set_document_organization(:'doc', p_clear_assignee => true);
select is((select in_review from public.team_overview() where assignee_id is null), 1, 'documentos sem responsável aparecem numa linha própria');
select is((select count(*)::int from public.team_overview()), 3, 'uma linha por membro e uma para "sem responsável"');

set local request.jwt.claims = '{"sub":"33333333-3333-3333-3333-333333333333","role":"authenticated"}';
select throws_ok('select * from public.team_overview()', 'P0001', 'FORBIDDEN', 'membro comum não vê a carga da equipe');
reset role;

select * from finish();
rollback;
