-- Reforços finais: busca com curingas literais e limites sem login.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(7);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');

set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select public.save_client(null, 'Café Aurora');
select public.save_client(null, 'Lima_Souza Advogados');
select is((select count(*)::int from public.list_clients('%')), 0, '"%" é texto literal, não lista todos os clientes');
select is((select count(*)::int from public.list_clients('_')), 1, '"_" é literal: só casa quem tem "_" no nome');
select is((select count(*)::int from public.list_clients('aurora')), 1, 'busca normal continua funcionando');
select throws_ok($$select public.hit_rate_limit('qualquer')$$, 'P0001', 'VALIDATION', 'bucket fora da lista é recusado');
select lives_ok($$select public.hit_rate_limit('export')$$, 'exportação dentro do limite');

select public.create_calendar_feed() as feed \gset
reset role;
insert into private.rate_limits (key, window_start, hits)
select 'feed:11111111-1111-1111-1111-111111111111',
  to_timestamp(floor(extract(epoch from now()) / 3600) * 3600), 240;
set local role anon;
select throws_ok(format($$select * from public.calendar_feed_info(%L)$$, :'feed'), 'P0001', 'RATE_LIMITED',
  'calendário assinado limitado por endereço');
select is((select count(*)::int from public.calendar_feed_info('token-inventado')), 0, 'token inválido não grava nada');
reset role;

select * from finish();
rollback;
