-- Isolamento multi-tenant e validações do cadastro.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(19);

-- Dois escritórios independentes ---------------------------------------------
insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria","signup_ip":"200.10.10.10","signup_user_agent":"pgtap"}'),
  ('22222222-2222-2222-2222-222222222222', 'bruno@escritorio-b.com.br',
   '{"full_name":"Bruno Lima","office_name":"Escritório B","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria","signup_ip":"lixo","signup_user_agent":"pgtap"}');

select is(
  (select role::text from public.office_members where user_id = '11111111-1111-1111-1111-111111111111'),
  'owner', 'quem cria o escritório vira owner');

select is(
  (select count(*)::int from public.legal_acceptances where user_id = '11111111-1111-1111-1111-111111111111'),
  2, 'cadastro registra aceite de termos e privacidade');

select is(
  (select host(ip) from public.legal_acceptances
   where user_id = '11111111-1111-1111-1111-111111111111' and kind = 'terms'),
  '200.10.10.10', 'aceite guarda o IP informado');

select is(
  (select ip from public.legal_acceptances
   where user_id = '22222222-2222-2222-2222-222222222222' and kind = 'terms'),
  null::inet, 'IP malformado vira null sem quebrar o cadastro');

-- Como Ana (escritório A) ------------------------------------------------------
set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';

select results_eq('select name from public.offices', $$values ('Escritório A')$$,
  'Ana vê apenas o próprio escritório');
select is((select count(*)::int from public.profiles), 1, 'Ana vê apenas perfis do próprio escritório');
select is((select count(*)::int from public.office_members), 1, 'Ana vê apenas membros do próprio escritório');
select is((select count(*)::int from public.legal_acceptances), 2, 'Ana vê apenas os próprios aceites');
select ok(public.has_accepted_current_legal(), 'Ana aceitou as versões vigentes');
select is(public.current_office_id(), (select id from public.offices), 'current_office_id() aponta para o escritório A');

-- Tentativa de alterar o escritório B (a RLS filtra: 0 linhas afetadas).
update public.offices set name = 'Invadido' where name = 'Escritório B';

select throws_ok(
  $$insert into public.office_members (office_id, user_id, role)
    select id, '11111111-1111-1111-1111-111111111111', 'member' from public.offices$$,
  '42501', null, 'cliente não insere em office_members diretamente');

select throws_ok(
  $$insert into public.offices (name) values ('Paralelo')$$,
  '42501', null, 'cliente não cria escritórios diretamente');

select throws_ok(
  $$update public.offices set created_at = now()$$,
  '42501', null, 'somente name e cnpj são editáveis');

reset role;
select is((select name from public.offices where id =
  (select office_id from public.office_members where user_id = '22222222-2222-2222-2222-222222222222')),
  'Escritório B', 'escritório B não foi alterado por Ana');

-- Anônimo ------------------------------------------------------------------------
set local role anon;
select throws_ok('select * from public.offices', '42501', null, 'anônimo não lê escritórios');
reset role;

-- Cadastro inválido --------------------------------------------------------------
select throws_ok(
  $$insert into auth.users (id, email, raw_user_meta_data) values
    (gen_random_uuid(), 'x@x.com', '{"full_name":"Sem Aceite","office_name":"Esc"}')$$,
  'P0001', 'LEGAL_ACCEPTANCE_REQUIRED', 'cadastro sem aceite falha');

select throws_ok(
  $$insert into auth.users (id, email, raw_user_meta_data) values
    (gen_random_uuid(), 'x@x.com',
     '{"full_name":"Versão Velha","office_name":"Esc","terms_version":"2025-01","privacy_version":"2026-09-provisoria"}')$$,
  'P0001', 'LEGAL_ACCEPTANCE_REQUIRED', 'cadastro com versão antiga dos termos falha');

select throws_ok(
  $$insert into auth.users (id, email, raw_user_meta_data) values
    (gen_random_uuid(), 'x@x.com',
     '{"full_name":"Sem Escritório","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}')$$,
  'P0001', 'OFFICE_NAME_REQUIRED', 'cadastro sem convite exige nome do escritório');

select throws_ok(
  $$insert into auth.users (id, email, raw_user_meta_data) values
    (gen_random_uuid(), 'x@x.com',
     '{"office_name":"Esc","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}')$$,
  'P0001', 'FULL_NAME_REQUIRED', 'cadastro exige nome completo');

select * from finish();
rollback;
