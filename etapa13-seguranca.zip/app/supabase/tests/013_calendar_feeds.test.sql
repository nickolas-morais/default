-- Assinatura do calendário: token, revogação, saída do escritório e isolamento.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(11);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}'),
  ('22222222-2222-2222-2222-222222222222', 'bruno@escritorio-b.com.br',
   '{"full_name":"Bruno Lima","office_name":"Escritório B","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');

set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select public.create_office_invitation('carla@exemplo.com', 'member') as token_carla \gset
select document_id as doc from public.create_document_upload('Locação Loja Centro.pdf', 5000) \gset
reset role;
insert into auth.users (id, email, raw_user_meta_data) values
  ('33333333-3333-3333-3333-333333333333', 'carla@exemplo.com', jsonb_build_object(
    'full_name','Carla Dias','invite_token', :'token_carla',
    'terms_version','2026-09-provisoria','privacy_version','2026-09-provisoria'));
set local role service_role;
select public.mark_document_queued(:'doc', 5000, 3);
select message ->> 'job_id' as job from public.worker_read_jobs(60, 1) \gset
select public.worker_start_job(:'job');
select public.worker_complete_job(:'job', '{"extracao":{"partes":[]},"riscos":[],"resumo":"r","prazos":[]}', 'v3', 1, 1);
reset role;

-- Carla (membro) cria um prazo e o endereço do calendário.
set local role authenticated;
set local request.jwt.claims = '{"sub":"33333333-3333-3333-3333-333333333333","role":"authenticated"}';
select public.save_deadline(null, :'doc', 'Aviso de não renovação', current_date + 20);
select public.create_calendar_feed() as feed \gset
select ok(length(:'feed') >= 40, 'token forte, entregue uma única vez');
select throws_ok('select token_hash from public.calendar_feeds', '42501', null, 'hash do token não é legível');
select is((select include_details from public.calendar_feeds), false, 'por padrão, sem detalhes do documento');
reset role;

set local role anon;
select is((select count(*)::int from public.calendar_feed_events(:'feed')), 1, 'feed funciona sem login, com o token');
select is((select title || '/' || office_name from public.calendar_feed_events(:'feed')), 'Aviso de não renovação/Escritório A',
  'feed traz os prazos do escritório');
select is((select count(*)::int from public.calendar_feed_events('token-inventado')), 0, 'token inválido não devolve nada');
select is((select office_name from public.calendar_feed_info(:'feed')), 'Escritório A', 'endereço válido é reconhecido mesmo sem prazos');
reset role;

-- Novo endereço revoga o anterior.
set local role authenticated;
select public.create_calendar_feed(true) as feed2 \gset
reset role;
set local role anon;
select is((select count(*)::int from public.calendar_feed_events(:'feed')), 0, 'endereço antigo deixa de funcionar');
reset role;

-- Bruno não enxerga o feed de Carla.
set local role authenticated;
set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated"}';
select is((select count(*)::int from public.calendar_feeds), 0, 'outro usuário não vê o endereço');

-- Carla é removida do escritório: o feed para.
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select public.remove_office_member('33333333-3333-3333-3333-333333333333');
reset role;
set local role anon;
select is((select count(*)::int from public.calendar_feed_events(:'feed2')), 0, 'quem sai do escritório perde o calendário');
reset role;

set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select public.create_calendar_feed() as feed3 \gset
select public.revoke_calendar_feed();
reset role;
set local role anon;
select is((select count(*)::int from public.calendar_feed_events(:'feed3')), 0, 'revogar desliga na hora');
reset role;

select * from finish();
rollback;
