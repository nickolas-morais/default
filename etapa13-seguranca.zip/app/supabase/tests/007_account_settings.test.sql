-- Configurações: perfil, escritório, papéis, titularidade e exclusões.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(20);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');
set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select public.create_office_invitation('carla@exemplo.com', 'member') as token_carla \gset
reset role;
insert into auth.users (id, email, raw_user_meta_data) values
  ('33333333-3333-3333-3333-333333333333', 'carla@exemplo.com', jsonb_build_object(
    'full_name','Carla Dias','invite_token', :'token_carla',
    'terms_version','2026-09-provisoria','privacy_version','2026-09-provisoria'));

-- Perfil e escritório -----------------------------------------------------------------
set local role authenticated;
update public.profiles set phone = '(19) 99999-0000', oab_number = 'SP 123.456'
where id = '11111111-1111-1111-1111-111111111111';
select is((select oab_number from public.profiles where id = '11111111-1111-1111-1111-111111111111'), 'SP 123.456',
  'usuário edita telefone e OAB');
select throws_ok($$update public.profiles set email = 'x@x.com'$$, '42501', null, 'e-mail do perfil não é editável direto');
update public.offices set address = 'Rua A, 1', contact_email = 'contato@a.com.br', oab_registration = 'OAB/SP 9.999';
select is((select oab_registration from public.offices), 'OAB/SP 9.999', 'titular edita dados do escritório');

set local request.jwt.claims = '{"sub":"33333333-3333-3333-3333-333333333333","role":"authenticated"}';
update public.offices set address = 'Invadido';
select is((select address from public.offices), 'Rua A, 1', 'membro não altera o escritório (RLS)');
select throws_ok($$select public.set_member_role('11111111-1111-1111-1111-111111111111', 'member')$$,
  'P0001', 'FORBIDDEN', 'membro não altera papéis');
select throws_ok($$select public.request_office_deletion()$$, 'P0001', 'FORBIDDEN', 'membro não exclui o escritório');
select lives_ok($$select public.check_account_deletion()$$, 'membro pode excluir a própria conta');

-- Papéis e titularidade -----------------------------------------------------------------
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select throws_ok($$select public.check_account_deletion()$$, 'P0001', 'OWNER_MUST_TRANSFER',
  'titular com colegas precisa transferir antes de sair');
select lives_ok($$select public.set_member_role('33333333-3333-3333-3333-333333333333', 'admin')$$, 'titular promove a administradora');
select is((select role::text from public.office_members where user_id = '33333333-3333-3333-3333-333333333333'), 'admin',
  'papel alterado');
select throws_ok($$select public.set_member_role('33333333-3333-3333-3333-333333333333', 'owner')$$,
  'P0001', 'FORBIDDEN', 'titularidade só por transferência');
select lives_ok($$select public.transfer_ownership('33333333-3333-3333-3333-333333333333')$$, 'titular transfere a titularidade');
select is((select string_agg(role::text, ',' order by role) from public.office_members), 'owner,admin',
  'um único titular; o anterior vira administrador');

-- Exclusão do escritório ---------------------------------------------------------------
set local request.jwt.claims = '{"sub":"33333333-3333-3333-3333-333333333333","role":"authenticated"}';
reset role;
insert into public.subscriptions (office_id, plan_id, stripe_subscription_id, status, cancel_at_period_end)
select id, 'essencial', 'sub_x', 'active', false from public.offices;
set local role authenticated;
select throws_ok($$select public.request_office_deletion()$$, 'P0001', 'ACTIVE_SUBSCRIPTION',
  'assinatura ativa precisa ser cancelada antes');
reset role;
update public.subscriptions set cancel_at_period_end = true;
set local role authenticated;
select ok(public.request_office_deletion() > now() + interval '6 days', 'exclusão agendada para daqui a 7 dias');
select throws_ok($$select * from public.create_document_upload('novo.pdf', 10)$$, 'P0001', 'OFFICE_DELETION_PENDING',
  'sem novos envios durante o prazo');
select lives_ok($$select public.cancel_office_deletion()$$, 'titular desiste da exclusão');
select lives_ok($$select * from public.create_document_upload('novo.pdf', 10)$$, 'envios voltam a funcionar');
select public.request_office_deletion();
reset role;

-- Worker executa após o prazo.
update public.offices set deletion_scheduled_for = now() - interval '1 minute';
set local role service_role;
select is((select cardinality(member_ids) from public.worker_offices_due_for_deletion()), 2,
  'worker recebe o escritório e os usuários a remover');
select public.worker_delete_office(office_id) from public.worker_offices_due_for_deletion();
reset role;
select is((select count(*)::int from public.documents), 0, 'documentos apagados junto com o escritório');

select * from finish();
rollback;
