-- Versões: vínculo, herança, histórico, comparação e herança de situação.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(12);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}'),
  ('22222222-2222-2222-2222-222222222222', 'bruno@escritorio-b.com.br',
   '{"full_name":"Bruno Lima","office_name":"Escritório B","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');

set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select document_id as v1 from public.create_document_upload('Locação v1.pdf', 5000) \gset
select public.save_client(null, 'Café Aurora') as cli \gset
reset role;
set local role service_role;
select public.mark_document_queued(:'v1', 5000, 3);
select message ->> 'job_id' as job from public.worker_read_jobs(60, 1) \gset
select public.worker_start_job(:'job');
select public.worker_save_pages(:'job', '[{"page":1,"text":"9.1 multa de 12 alugueis"}]', null, false, 1);
select public.worker_complete_job(:'job', '{"extracao":{"partes":[]},"resumo":"r","prazos":[],"riscos":[
  {"nivel":"alto","titulo":"Multa","trecho_original":"multa de 12 alugueis","explicacao":"e","sugestao_redacao":"s"}]}', 'v3', 1, 1);
reset role;

set local role authenticated;
select public.set_document_organization(:'v1', :'cli');
reset role;
update public.documents set client_party_name = 'Café Aurora', client_party_role = 'Locatária' where id = :'v1';
update public.risks set resolution = 'negociado', resolution_note = 'Proposta de 3 aluguéis' where document_id = :'v1';

set local role authenticated;
select document_id as v2 from public.create_document_upload('Locação v2.pdf', 5000) \gset
select is(public.set_document_parent(:'v2', :'v1'), 2, 'nova versão recebe o número 2');
select is((select (client_id = :'cli')::text || '/' || client_party_role || '/' || review_status from public.documents where id = :'v2'),
  'true/Locatária/em_revisao', 'herda cliente e perspectiva e entra em revisão');
select document_id as v2b from public.create_document_upload('Outra v2.pdf', 5000) \gset
select throws_ok(format($$select public.set_document_parent(%L, %L)$$, :'v2b', :'v1'), 'P0001', 'VERSION_EXISTS',
  'histórico linear: não cria duas versões seguintes');
reset role;

set local role service_role;
select public.mark_document_queued(:'v2', 5000, 3);
select message ->> 'job_id' as job2 from public.worker_read_jobs(60, 1) \gset
select is((select client_party_role from public.worker_start_job(:'job2')), 'Locatária', 'worker analisa a nova versão com a perspectiva herdada');
select public.worker_save_pages(:'job2', '[{"page":1,"text":"9.1 multa de 3 alugueis"}]', null, false, 1);
select public.worker_complete_job(:'job2', '{"extracao":{"partes":[]},"resumo":"r","prazos":[],"riscos":[
  {"nivel":"medio","titulo":"Multa","trecho_original":"multa de 3 alugueis","explicacao":"e","sugestao_redacao":"s"}]}', 'v3', 1, 1);

select is((public.worker_comparison_inputs(:'v2') ->> 'previous_id'), :'v1', 'entradas da comparação apontam a versão anterior');
select is(jsonb_array_length(public.worker_comparison_inputs(:'v2') -> 'old_risks'), 1, 'riscos da versão anterior incluídos');
select is(public.worker_comparison_inputs(:'v1'), null::jsonb, 'primeira versão não tem comparação');
select id as r2 from public.risks where document_id = :'v2' \gset
select public.worker_save_comparison(:'v2', :'v1', '[]', '[]', '{"changed":1}',
  jsonb_build_array(jsonb_build_object('new_risk_id', :'r2', 'resolution', 'negociado', 'note', 'Proposta de 3 aluguéis')));
reset role;

select is((select resolution::text || '/' || resolution_note from public.risks where id = :'r2'), 'negociado/Proposta de 3 aluguéis',
  'risco mantido herda a situação da versão anterior');

set local role authenticated;
select is((select string_agg(version_number::text || ':' || has_comparison::text, ',' order by version_number) from public.document_versions(:'v1')),
  '1:false,2:true', 'histórico completo a partir de qualquer versão');
select is((select stats ->> 'changed' from public.document_comparisons where document_id = :'v2'), '1', 'comparação legível pelo escritório');
set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated"}';
select is((select count(*)::int from public.document_comparisons), 0, 'outro escritório não vê comparações');
select is((select count(*)::int from public.document_versions(:'v1')), 0, 'outro escritório não vê o histórico');
reset role;

select * from finish();
rollback;
