-- Organização: clientes, responsável, status de revisão, situação dos riscos
-- e filtros da busca.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(15);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}'),
  ('22222222-2222-2222-2222-222222222222', 'bruno@escritorio-b.com.br',
   '{"full_name":"Bruno Lima","office_name":"Escritório B","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');

set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select public.create_office_invitation('carla@exemplo.com', 'member') as token_carla \gset
select document_id as doc from public.create_document_upload('Locação Loja Centro.pdf', 5000) \gset
select document_id as doc2 from public.create_document_upload('Prestação de serviços.pdf', 5000) \gset
reset role;
insert into auth.users (id, email, raw_user_meta_data) values
  ('33333333-3333-3333-3333-333333333333', 'carla@exemplo.com', jsonb_build_object(
    'full_name','Carla Dias','invite_token', :'token_carla',
    'terms_version','2026-09-provisoria','privacy_version','2026-09-provisoria'));
set local role service_role;
select public.mark_document_queued(:'doc', 5000, 3);
select message ->> 'job_id' as job from public.worker_read_jobs(60, 1) \gset
select public.worker_start_job(:'job');
select public.worker_complete_job(:'job', '{"extracao":{"partes":[]},"resumo":"r","prazos":[],"riscos":[
  {"nivel":"alto","titulo":"Multa","trecho_original":"a","explicacao":"e","sugestao_redacao":"s"},
  {"nivel":"alto","titulo":"Foro","trecho_original":"b","explicacao":"e","sugestao_redacao":"s"}]}', 'v3', 1, 1);
reset role;

set local role authenticated;
select is((select assignee_id::text from public.documents where id = :'doc'), '11111111-1111-1111-1111-111111111111',
  'responsável padrão é quem enviou');
select is((select review_status::text from public.documents where id = :'doc'), 'pendente', 'status inicial pendente');

-- Clientes
select public.save_client(null, 'Café Aurora Comércio de Alimentos', '12.ABC.345/01DE-35', 'Juridico@Aurora.com') as cli \gset
select is((select document_number || '/' || email from public.clients where id = :'cli'), '12ABC34501DE35/juridico@aurora.com',
  'CNPJ e e-mail normalizados');
select throws_ok($$select public.save_client(null, 'café aurora comércio de alimentos')$$, 'P0001', 'CLIENT_EXISTS',
  'não duplica cliente ativo com o mesmo nome');

-- Organização do documento (por um membro)
set local request.jwt.claims = '{"sub":"33333333-3333-3333-3333-333333333333","role":"authenticated"}';
select lives_ok(format($$select public.set_document_organization(%L, %L, '33333333-3333-3333-3333-333333333333', 'em_revisao')$$,
  :'doc', :'cli'), 'membro define cliente, responsável e status');
select is((select review_status::text || '/' || (review_updated_by = '33333333-3333-3333-3333-333333333333')::text
  from public.documents where id = :'doc'), 'em_revisao/true', 'status registra quem alterou');
select lives_ok(format($$select public.set_document_organization(%L, p_review_status => 'enviado')$$, :'doc'),
  'mudar só o status mantém cliente e responsável');
select is((select (client_id = :'cli')::text || '/' || review_status from public.documents where id = :'doc'), 'true/enviado',
  'demais campos preservados');

-- Situação dos riscos
select id as r1 from public.risks where document_id = :'doc' and title = 'Multa' \gset
select public.set_risk_resolution(:'r1', 'negociado', 'Proposta de redução enviada');
select is((select resolution::text || '/' || resolution_note from public.risks where id = :'r1'), 'negociado/Proposta de redução enviada',
  'risco marcado como negociado');

-- Busca
select is((select client_name || '/' || assignee_name || '/' || open_high_risks from public.search_documents(p_client_id => :'cli')),
  'Café Aurora Comércio de Alimentos/Carla Dias/1', 'busca por cliente com responsável e riscos altos em aberto');
select is((select count(*)::int from public.search_documents(p_assignee_id => '33333333-3333-3333-3333-333333333333')), 1,
  'filtro "meus documentos"');
select is((select count(*)::int from public.search_documents(p_no_client => true)), 1, 'filtro "sem cliente"');
select is((select count(*)::int from public.search_documents('aurora')), 1, 'busca textual inclui o nome do cliente');

-- Isolamento
set local request.jwt.claims = '{"sub":"22222222-2222-2222-2222-222222222222","role":"authenticated"}';
select is((select count(*)::int from public.clients), 0, 'outro escritório não vê clientes');
select throws_ok(format($$select public.set_document_organization(%L, p_review_status => 'aprovado')$$, :'doc'),
  'P0001', 'DOCUMENT_NOT_FOUND', 'outro escritório não altera o documento');
reset role;

select * from finish();
rollback;
