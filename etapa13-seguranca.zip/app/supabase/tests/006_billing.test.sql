-- Planos e cota: avaliação, limite do plano, reserva de documentos em
-- andamento, reprocessamento e sincronização com o Stripe.
-- Rodar com: supabase test db
begin;
create extension if not exists pgtap with schema extensions;
select plan(19);

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'ana@escritorio-a.com.br',
   '{"full_name":"Ana Souza","office_name":"Escritório A","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}'),
  ('22222222-2222-2222-2222-222222222222', 'bruno@escritorio-b.com.br',
   '{"full_name":"Bruno Lima","office_name":"Escritório B","terms_version":"2026-09-provisoria","privacy_version":"2026-09-provisoria"}');

select id as office_a from public.offices where name = 'Escritório A' \gset

-- Avaliação: 5 documentos ------------------------------------------------------------
set local role authenticated;
set local request.jwt.claims = '{"sub":"11111111-1111-1111-1111-111111111111","role":"authenticated"}';
select is((select source || '/' || doc_limit from public.current_entitlement()), 'trial/5', 'escritório novo começa na avaliação');

select document_id as d1 from public.create_document_upload('1.pdf', 10) \gset
select document_id as d2 from public.create_document_upload('2.pdf', 10) \gset
select document_id as d3 from public.create_document_upload('3.pdf', 10) \gset
select document_id as d4 from public.create_document_upload('4.pdf', 10) \gset
select document_id as d5 from public.create_document_upload('5.pdf', 10) \gset
select is((select reserved from public.current_entitlement()), 5, 'envios em andamento reservam cota');
select throws_ok($$select * from public.create_document_upload('6.pdf', 10)$$, 'P0001', 'QUOTA_EXCEEDED',
  'sexto envio simultâneo é bloqueado');

-- Envio interrompido libera a reserva.
select public.cancel_document_upload(:'d5');
select lives_ok($$select * from public.create_document_upload('6.pdf', 10)$$, 'reserva liberada após cancelamento');
reset role;

-- Falha não consome cota.
set local role service_role;
select public.fail_document(:'d4', 'FILE_CORRUPTED', true);
reset role;
set local role authenticated;
select is((select used + reserved from public.current_entitlement()), 4, 'documento com falha sai da conta');
reset role;

-- Avaliação vencida -------------------------------------------------------------------
update public.offices set created_at = now() - interval '15 days' where id = :'office_a';
set local role authenticated;
select is((select source from public.current_entitlement()), 'none', 'avaliação vence em 14 dias');
select throws_ok($$select * from public.create_document_upload('7.pdf', 10)$$, 'P0001', 'NO_ACTIVE_PLAN',
  'sem plano não há novos envios');
reset role;

-- Assinatura via Stripe ---------------------------------------------------------------
set local role authenticated;
select throws_ok(format($$select public.stripe_set_customer(%L, 'cus_x')$$, :'office_a'), '42501', null,
  'usuário não altera dados do Stripe');
select throws_ok($$select public.stripe_upsert_subscription('cus_x','sub_x','essencial_mensal','price_x','active',now(),now(),false)$$,
  '42501', null, 'usuário não grava assinaturas');
reset role;

set local role service_role;
select ok(public.stripe_record_event('evt_1', 'customer.subscription.created'), 'evento novo é processado');
select ok(not public.stripe_record_event('evt_1', 'customer.subscription.created'), 'evento repetido é ignorado');
select public.stripe_set_customer(:'office_a', 'cus_A');
select ok(not public.stripe_upsert_subscription('cus_desconhecido','sub_1','essencial_mensal','price_1','active',now(),now(),false),
  'cliente desconhecido não cria assinatura');
select ok(public.stripe_upsert_subscription('cus_A','sub_A1','essencial_mensal','price_1','active',
  now() - interval '1 day', now() + interval '29 days', false), 'assinatura ativa gravada');
reset role;

set local role authenticated;
select is((select source || '/' || plan_id || '/' || doc_limit from public.current_entitlement()),
  'subscription/essencial/30', 'plano Essencial com 30 documentos');
select is((select used from public.current_entitlement()), 0, 'período do plano começa na data de cobrança do Stripe');
select lives_ok($$select * from public.create_document_upload('8.pdf', 10)$$, 'envio liberado com plano ativo');
reset role;

-- past_due mantém acesso; cancelada bloqueia; evento velho não sobrescreve.
set local role service_role;
select public.stripe_upsert_subscription('cus_A','sub_A1','essencial_mensal','price_1','past_due',
  now() - interval '1 day', now() + interval '29 days', false);
reset role;
set local role authenticated;
select is((select source from public.current_entitlement()), 'subscription', 'pagamento em atraso mantém o acesso (carência do Stripe)');
reset role;

set local role service_role;
select public.stripe_upsert_subscription('cus_A','sub_A2','profissional_mensal','price_2','active',
  now(), now() + interval '30 days', false);
select public.stripe_upsert_subscription('cus_A','sub_A1','essencial_mensal','price_1','canceled',
  now() - interval '1 day', now() + interval '29 days', false);
reset role;
set local role authenticated;
select is((select plan_id from public.current_entitlement()), 'profissional',
  'cancelamento da assinatura antiga não derruba a nova');
reset role;

set local role service_role;
select public.stripe_upsert_subscription('cus_A','sub_A2','profissional_mensal','price_2','canceled',
  now(), now() + interval '30 days', false);
reset role;
set local role authenticated;
select throws_ok($$select * from public.create_document_upload('9.pdf', 10)$$, 'P0001', 'NO_ACTIVE_PLAN',
  'assinatura cancelada bloqueia novos envios');
reset role;

select * from finish();
rollback;
