/**
 * Validação de CPF e CNPJ.
 * CNPJ aceita o formato alfanumérico (IN RFB nº 2.229/2024, vigente desde
 * julho de 2026): 12 caracteres [A-Z0-9] + 2 dígitos verificadores numéricos.
 * Cada caractere vale (código ASCII − 48); para dígitos isso dá o próprio valor.
 */

export function normalizeCpf(value: string): string {
  return value.replace(/\D/g, "");
}

export function normalizeCnpj(value: string): string {
  return value.toUpperCase().replace(/[.\-/\s]/g, "");
}

export function isValidCpf(value: string): boolean {
  const cpf = normalizeCpf(value);
  if (!/^\d{11}$/.test(cpf) || /^(\d)\1{10}$/.test(cpf)) return false;

  const digits = [...cpf].map(Number);
  const dv = (length: number) => {
    let sum = 0;
    for (let i = 0; i < length; i++) sum += digits[i]! * (length + 1 - i);
    const rest = (sum * 10) % 11;
    return rest === 10 ? 0 : rest;
  };
  return dv(9) === digits[9] && dv(10) === digits[10];
}

export function isValidCnpj(value: string): boolean {
  const cnpj = normalizeCnpj(value);
  if (!/^[A-Z0-9]{12}\d{2}$/.test(cnpj) || /^(.)\1{13}$/.test(cnpj)) return false;

  const values = [...cnpj].map((c) => c.charCodeAt(0) - 48);
  const dv = (length: number) => {
    const weights = length === 12
      ? [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
      : [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    const sum = weights.reduce((acc, w, i) => acc + w * values[i]!, 0);
    const rest = sum % 11;
    return rest < 2 ? 0 : 11 - rest;
  };
  return dv(12) === values[12] && dv(13) === values[13];
}

export function formatCpf(value: string): string {
  const d = normalizeCpf(value);
  return d.length === 11 ? `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6, 9)}-${d.slice(9)}` : value;
}

export function formatCnpj(value: string): string {
  const c = normalizeCnpj(value);
  return c.length === 14
    ? `${c.slice(0, 2)}.${c.slice(2, 5)}.${c.slice(5, 8)}/${c.slice(8, 12)}-${c.slice(12)}`
    : value;
}
