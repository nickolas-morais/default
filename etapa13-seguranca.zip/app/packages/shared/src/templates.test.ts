import { test } from "node:test";
import assert from "node:assert/strict";
import { Document, Header, Packer, Paragraph, TextRun } from "docx";
import PizZip from "pizzip";
import { inspectTemplate, renderTemplate } from "./docx-template.ts";
import {
  buildLoopValues, buildRenderData, buildStandardValues, mapVariables, normalizeVarName, parseTemplateTags,
} from "./template-vars.ts";
import type { Extraction } from "./analysis.ts";

const DATA: Extraction = {
  partes: [
    { nome: "Imobiliária Horizonte Paulista Ltda.", documento: "11222333000181", papel: "Locadora" },
    { nome: "Café Aurora Comércio de Alimentos Ltda.", documento: "12.ABC.345/01DE-35", papel: "Locatária" },
    { nome: "João Carlos Ribeiro", documento: "52998224725", papel: "Fiador" },
  ],
  objeto: "Locação da loja 3", valor: "R$ 8.500,00 mensais", forma_pagamento: "Boleto", vigencia: "36 meses",
  data_inicio: "2026-10-01", data_fim: "2029-09-30", prazo_rescisao: "30 dias",
  multas: [{ descricao: "Rescisão antecipada", valor: "12 aluguéis" }], foro: "Manaus/AM", indice_reajuste: "",
};

async function templateDocx(): Promise<Uint8Array> {
  const doc = new Document({
    sections: [{
      headers: { default: new Header({ children: [new Paragraph("{{escritorio}}")] }) },
      children: [
        // O Word costuma dividir a marcação em vários trechos de formatação.
        new Paragraph({ children: [new TextRun("À {{Locat"), new TextRun({ text: "ária}}", bold: true }), new TextRun(", CNPJ {{locataria_cnpj}}")] }),
        new Paragraph("Locador: {{locador}}. Início: {{data_inicio}}. Reajuste: {{indice_reajuste}}."),
        new Paragraph("{{#lista_partes}}"),
        new Paragraph("- {{nome}} ({{Papel}}): {{documento}}"),
        new Paragraph("{{/lista_partes}}"),
        new Paragraph("{{cidade}}, {{data_hoje_extenso}}."),
      ],
    }],
  });
  return new Uint8Array(await Packer.toBuffer(doc));
}

const bodyText = (bytes: Uint8Array) =>
  new PizZip(bytes).file("word/document.xml")!.asText().replace(/<w:p[ >]/g, "\n$&").replace(/<[^>]+>/g, "");

test("normaliza nomes de variáveis", () => {
  assert.equal(normalizeVarName(" Locatário CPF "), "locatario_cpf");
});

test("lê variáveis e laços, inclusive divididos pelo Word e no cabeçalho", async () => {
  const r = inspectTemplate(await templateDocx());
  assert.ok(r.ok);
  if (!r.ok) return;
  assert.deepEqual(r.parsed.variables.sort(),
    ["Locatária", "cidade", "data_hoje_extenso", "data_inicio", "escritorio", "indice_reajuste", "locador", "locataria_cnpj"]);
  assert.deepEqual(r.parsed.loops, [{ name: "lista_partes", fields: ["nome", "Papel", "documento"] }]);
});

test("separa variáveis automáticas e manuais", async () => {
  const r = inspectTemplate(await templateDocx());
  if (!r.ok) throw new Error();
  const m = mapVariables(r.parsed);
  assert.deepEqual(m.manual, ["cidade"]);
  assert.equal(m.automatic.find((a) => a.tag === "Locatária")?.key, "locatario");
  assert.equal(m.automatic.find((a) => a.tag === "locataria_cnpj")?.key, "locatario_documento");
  assert.deepEqual(m.loops, [{ name: "lista_partes", key: "lista_partes", label: "Lista de partes", unknownFields: [] }]);
});

test("preenche o modelo com dados extraídos e manuais", async () => {
  const bytes = await templateDocx();
  const r = inspectTemplate(bytes);
  if (!r.ok) throw new Error();
  const std = buildStandardValues(DATA, { officeName: "Souza Advogados", today: new Date("2026-09-29T15:00:00Z") });
  const data = buildRenderData(r.parsed, std, buildLoopValues(DATA), { cidade: "Campinas" });
  const out = renderTemplate(bytes, data);
  const text = bodyText(out);
  assert.match(text, /À Café Aurora Comércio de Alimentos Ltda\., CNPJ 12\.ABC\.345\/01DE-35/);
  assert.match(text, /Locador: Imobiliária Horizonte Paulista Ltda\.\. Início: 01\/10\/2026/);
  assert.match(text, /Reajuste: __________\./, "campo sem valor vira linha para preencher");
  assert.match(text, /- João Carlos Ribeiro \(Fiador\): 529\.982\.247-25/);
  assert.match(text, /Campinas, 29 de setembro de 2026\./);
  const header = new PizZip(out).file("word/header1.xml")!.asText();
  assert.match(header, /Souza Advogados/);
});

test("erros de sintaxe viram mensagens em português", async () => {
  const doc = new Document({ sections: [{ children: [new Paragraph("{{contratante} e {{#lista_partes}} sem fim")] }] });
  const r = inspectTemplate(new Uint8Array(await Packer.toBuffer(doc)));
  assert.equal(r.ok, false);
  if (r.ok) return;
  assert.ok(r.errors.some((e) => e.includes("sem fechamento")));
  assert.ok(r.errors.some((e) => e.includes("{{/lista_partes}}")));
});

test("parseTemplateTags ignora texto sem marcações", () => {
  assert.deepEqual(parseTemplateTags(["Contrato sem variáveis."]), { variables: [], loops: [] });
});

test("dados do escritório e de quem gera a minuta", () => {
  const v = buildStandardValues(DATA, {
    officeName: "Souza Advogados", today: new Date(),
    office: { cnpj: "11222333000181", address: "Av. Paulista, 1.000" },
    user: { name: "Ana Souza", oab: "SP 123.456" },
  });
  assert.equal(v.escritorio_cnpj, "11.222.333/0001-81");
  assert.equal(v.advogado, "Ana Souza");
  const m = mapVariables({ variables: ["advogado_responsavel", "oab", "escritorio_endereco"], loops: [] });
  assert.deepEqual(m.manual, []);
});
