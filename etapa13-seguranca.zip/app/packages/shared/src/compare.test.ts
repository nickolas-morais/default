import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { compareRisks, compareText, comparisonStats, diffWords, splitBlocks } from "./compare.ts";

const v1Text = readFileSync(new URL("../../../evals/casos/locacao-comercial/contrato.txt", import.meta.url), "utf8");
const pages = (t: string) => t.split("\f").map((text, i) => ({ page: i + 1, text }));

const v2Text = v1Text
  .replace("equivalente a 12 (doze) aluguéis vigentes, independentemente do tempo decorrido do",
           "equivalente a 3 (três) aluguéis, proporcional ao tempo restante do")
  .replace(/CLÁUSULA 11ª[\s\S]*?dação em pagamento\.\n/, "")
  .replace("CLÁUSULA 13ª", "CLÁUSULA 12-A – DA CONFIDENCIALIDADE\n12-A.1. As partes manterão sigilo sobre os termos deste contrato.\nCLÁUSULA 13ª");

test("divide o contrato em cláusulas e itens", () => {
  const blocks = splitBlocks(pages(v1Text));
  assert.ok(blocks.length >= 25, `blocos: ${blocks.length}`);
  assert.ok(blocks.some((b) => b.startsWith("9.1. Em caso de rescisão antecipada")));
});

test("detecta cláusula alterada, removida e incluída", () => {
  const changes = compareText(pages(v1Text), pages(v2Text));
  const altered = changes.find((c) => c.type === "alterado" && c.after.startsWith("9.1."));
  assert.ok(altered && altered.type === "alterado");
  assert.ok(altered.words.some((w) => w.op === "del" && w.text.includes("12")));
  assert.ok(altered.words.some((w) => w.op === "add" && w.text.includes("proporcional")));
  assert.ok(changes.some((c) => c.type === "removido" && c.before.includes("direito de preferência")));
  assert.ok(changes.some((c) => c.type === "incluido" && c.after.includes("sigilo")));
  const stats = comparisonStats(changes, []);
  assert.ok(stats.changed >= 1 && stats.removed >= 1 && stats.added >= 1);
  assert.ok(changes.length <= 8, `mudanças demais: ${changes.length}`);
});

test("diferença palavra a palavra", () => {
  assert.deepEqual(diffWords("multa de 12 aluguéis vigentes", "multa de 3 aluguéis"), [
    { op: "eq", text: "multa de" }, { op: "del", text: "12" }, { op: "add", text: "3" },
    { op: "eq", text: "aluguéis" }, { op: "del", text: "vigentes" },
  ]);
});

test("classifica riscos entre versões", () => {
  const old = [
    { id: "o1", title: "Multa desproporcional", level: "alto" as const, excerpt: "pagará multa equivalente a 12 (doze) aluguéis vigentes, independentemente do tempo decorrido", resolution: "negociado" },
    { id: "o2", title: "Renúncia ao direito de preferência", level: "medio" as const, excerpt: "A LOCATÁRIA renuncia ao direito de preferência na aquisição do imóvel" },
    { id: "o3", title: "Foro distante", level: "medio" as const, excerpt: "Fica eleito o foro da Comarca de Manaus/AM" },
  ];
  const neu = [
    { id: "n1", title: "Foro distante", level: "alto" as const, excerpt: "Fica eleito o foro da Comarca de Manaus/AM para dirimir quaisquer dúvidas" },
    { id: "n2", title: "Confidencialidade sem prazo", level: "baixo" as const, excerpt: "As partes manterão sigilo sobre os termos deste contrato" },
  ];
  const r = compareRisks(old, neu);
  assert.deepEqual(r.filter((x) => x.type === "resolvido").map((x) => x.type === "resolvido" && x.old.id).sort(), ["o1", "o2"]);
  const kept = r.find((x) => x.type === "mantido");
  assert.ok(kept && kept.type === "mantido" && kept.new.id === "n1" && kept.levelChanged);
  assert.ok(r.some((x) => x.type === "novo" && x.new.id === "n2"));
});

test("semelhança distingue nova versão de outro contrato", async () => {
  const { textSimilarity } = await import("./compare.ts");
  const other = pages("CONTRATO DE PRESTAÇÃO DE SERVIÇOS DE CONSULTORIA TRIBUTÁRIA. A CONTRATADA prestará serviços de revisão fiscal mensal à CONTRATANTE, mediante honorários de R$ 4.000,00, pelo prazo de 12 meses, com foro em Curitiba/PR.");
  assert.ok(textSimilarity(pages(v1Text), pages(v2Text)) > 0.6);
  assert.ok(textSimilarity(pages(v1Text), other) < 0.1);
});
