import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { PDFDocument } from "pdf-lib";
import { validateFile } from "./file-validation.ts";

const fixture = (name: string) => new Uint8Array(readFileSync(new URL(`./fixtures/${name}`, import.meta.url)));

async function pdfWithPages(pages: number) {
  const doc = await PDFDocument.create();
  for (let i = 0; i < pages; i++) doc.addPage();
  return doc.save();
}

// ZIP mínimo com as entradas de um DOCX (sem compressão).
function zipWith(names: string[]): Uint8Array {
  const parts: Buffer[] = [];
  for (const name of names) {
    const header = Buffer.alloc(30);
    header.writeUInt32LE(0x04034b50, 0);
    header.writeUInt16LE(Buffer.byteLength(name), 26);
    parts.push(header, Buffer.from(name));
  }
  return new Uint8Array(Buffer.concat(parts));
}

test("PDF válido devolve o número de páginas", async () => {
  assert.deepEqual(await validateFile(await pdfWithPages(3), "pdf"), { ok: true, pageCount: 3 });
});

test("PDF acima de 50 páginas", async () => {
  assert.deepEqual(await validateFile(await pdfWithPages(51), "pdf"), { ok: false, code: "TOO_MANY_PAGES" });
});

test("PDF criptografado segue para o worker decidir (qpdf)", async () => {
  for (const name of ["protegido.pdf", "protegido-sem-senha-abertura.pdf"]) {
    assert.deepEqual(await validateFile(fixture(name), "pdf"), { ok: true, pageCount: null });
  }
});

test("PDF truncado", async () => {
  const bytes = (await pdfWithPages(2)).slice(0, 200);
  assert.deepEqual(await validateFile(bytes, "pdf"), { ok: false, code: "FILE_CORRUPTED" });
});

test("extensão trocada", async () => {
  const docx = zipWith(["[Content_Types].xml", "word/document.xml"]);
  assert.deepEqual(await validateFile(docx, "pdf"), { ok: false, code: "FILE_TYPE_MISMATCH" });
  assert.deepEqual(await validateFile(await pdfWithPages(1), "docx"), { ok: false, code: "FILE_TYPE_MISMATCH" });
});

test("DOCX válido, ZIP qualquer e DOCX protegido", async () => {
  assert.deepEqual(await validateFile(zipWith(["[Content_Types].xml", "word/document.xml"]), "docx"), {
    ok: true,
    pageCount: null,
  });
  assert.deepEqual(await validateFile(zipWith(["a.txt"]), "docx"), { ok: false, code: "FILE_CORRUPTED" });
  const ole = new Uint8Array([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1, 0, 0]);
  assert.deepEqual(await validateFile(ole, "docx"), { ok: false, code: "PASSWORD_PROTECTED" });
});

test("arquivo vazio", async () => {
  assert.deepEqual(await validateFile(new Uint8Array(), "pdf"), { ok: false, code: "FILE_EMPTY" });
});
