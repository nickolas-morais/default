/**
 * Modelos dos avisos por e-mail (HTML + texto). Todo valor dinâmico é escapado.
 * Visual alinhado ao app: fundo claro, texto grafite, botão verde-garrafa.
 */
export type EmailContent = { subject: string; html: string; text: string };

const esc = (s: string | number) =>
  String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const fmtDate = (d: Date | string) =>
  new Intl.DateTimeFormat("pt-BR", { dateStyle: "long", timeZone: "America/Sao_Paulo" }).format(new Date(d));

function layout(o: { title: string; paragraphs: string[]; cta?: { label: string; url: string }; footer?: string }): { html: string; text: string } {
  const body = o.paragraphs.map((p) => `<p style="margin:0 0 16px;font-size:15px;line-height:1.6">${esc(p)}</p>`).join("");
  const button = o.cta
    ? `<p style="margin:8px 0 24px"><a href="${esc(o.cta.url)}" style="display:inline-block;background:#1e5b4f;color:#ffffff;text-decoration:none;padding:12px 20px;border-radius:4px;font-size:15px">${esc(o.cta.label)}</a></p>`
    : "";
  const footer = o.footer ?? "Você recebe este aviso porque participa de um escritório no App. Preferências de aviso: Configurações → Minha conta.";
  const html = `<!doctype html><html lang="pt-BR"><body style="margin:0;padding:32px 16px;background:#f3f5f6;font-family:Arial,Helvetica,sans-serif;color:#1b2430">
<table role="presentation" width="100%" style="max-width:560px;margin:0 auto;background:#ffffff;border:1px solid #dce1e5;border-radius:6px"><tr><td style="padding:32px">
<h1 style="margin:0 0 20px;font-family:Georgia,serif;font-size:21px;font-weight:600">${esc(o.title)}</h1>${body}${button}
<p style="margin:24px 0 0;font-size:12px;line-height:1.5;color:#5b6573">${esc(footer)}</p>
</td></tr></table></body></html>`;
  const text = [o.title, "", ...o.paragraphs, ...(o.cta ? ["", `${o.cta.label}: ${o.cta.url}`] : []), "", footer].join("\n");
  return { html, text };
}

export function analysisDoneEmail(o: { name: string; fileName: string; risks: number; highRisks: number; url: string }): EmailContent {
  const riskLine = o.risks
    ? `Foram apontados ${o.risks} ${o.risks === 1 ? "risco" : "riscos"}${o.highRisks ? `, ${o.highRisks} de nível alto` : ""}.`
    : "Nenhuma cláusula de risco relevante foi apontada.";
  return {
    subject: `Análise concluída: ${o.fileName}`,
    ...layout({
      title: "Análise concluída",
      paragraphs: [`Olá, ${o.name}.`, `A análise de “${o.fileName}” está pronta. ${riskLine}`,
        "Revise os dados extraídos, os riscos e o resumo antes de usar com o cliente."],
      cta: { label: "Abrir análise", url: o.url },
    }),
  };
}

export function quotaEmail(o: { officeName: string; used: number; limit: number; periodEnd: string | null; url: string }): EmailContent {
  const full = o.used >= o.limit;
  const renew = o.periodEnd ? ` A cota renova em ${fmtDate(o.periodEnd)}.` : "";
  return {
    subject: full ? `Cota esgotada: ${o.officeName}` : `Cota em ${Math.round((100 * o.used) / o.limit)}%: ${o.officeName}`,
    ...layout({
      title: full ? "Cota do plano esgotada" : "Cota do plano quase no fim",
      paragraphs: [
        `O escritório ${o.officeName} usou ${o.used} de ${o.limit} documentos do período.${renew}`,
        full ? "Novos envios ficam bloqueados até a renovação ou a mudança de plano." : "Para não interromper o trabalho da equipe, avalie mudar de plano.",
      ],
      cta: { label: "Ver planos", url: o.url },
    }),
  };
}

export function paymentFailedEmail(o: { officeName: string; url: string }): EmailContent {
  return {
    subject: `Pagamento não aprovado: ${o.officeName}`,
    ...layout({
      title: "Pagamento não aprovado",
      paragraphs: [
        `Não conseguimos cobrar a assinatura do escritório ${o.officeName}.`,
        "O acesso continua enquanto o pagamento é tentado de novo automaticamente. Atualize a forma de pagamento para evitar a interrupção dos envios.",
      ],
      cta: { label: "Atualizar pagamento", url: o.url },
      footer: "Aviso de cobrança enviado ao titular e aos administradores do escritório.",
    }),
  };
}

export function contractExpiringEmail(o: { officeName: string; daysLeft: number; endsAt: string }): EmailContent {
  return {
    subject: `Contrato vence em ${o.daysLeft} ${o.daysLeft === 1 ? "dia" : "dias"}: ${o.officeName}`,
    ...layout({
      title: "Contrato perto do vencimento",
      paragraphs: [
        `O contrato do escritório ${o.officeName} vence em ${fmtDate(o.endsAt)}.`,
        "Depois dessa data, novos envios de documentos ficam bloqueados. Os documentos e análises existentes continuam disponíveis. Responda a este e-mail ou fale com o suporte para renovar.",
      ],
      footer: "Aviso de contrato enviado ao titular e aos administradores do escritório.",
    }),
  };
}

export function queueBacklogEmail(o: { waiting: number; oldestMinutes: number; url: string }): EmailContent {
  return {
    subject: `[Plataforma] ${o.waiting} documentos parados na fila`,
    ...layout({
      title: "Fila de processamento acumulada",
      paragraphs: [
        `${o.waiting} documentos estão esperando há mais de 15 minutos (o mais antigo, há ${o.oldestMinutes} minutos).`,
        "Verifique se o worker está rodando e os logs de erro. Este aviso é enviado no máximo uma vez por hora.",
      ],
      cta: { label: "Abrir painel", url: o.url },
      footer: "Enviado aos administradores da plataforma.",
    }),
  };
}

export function deadlineReminderEmail(o: { title: string; fileName: string; dueDate: string; daysLeft: number; url: string }): EmailContent {
  const when = o.daysLeft === 0 ? "vence hoje" : `vence em ${o.daysLeft} ${o.daysLeft === 1 ? "dia" : "dias"}`;
  return {
    subject: `Prazo ${when}: ${o.title}`,
    ...layout({
      title: `Prazo ${when}`,
      paragraphs: [`${o.title}, em ${fmtDate(`${o.dueDate}T12:00:00Z`)}.`, `Documento: ${o.fileName}.`,
        "Se já foi resolvido, marque o prazo como concluído para não receber novos lembretes."],
      cta: { label: "Ver prazos do documento", url: o.url },
    }),
  };
}
