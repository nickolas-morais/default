import { test } from "node:test";
import assert from "node:assert/strict";
import { findBestWindow, locateExcerpt, tokenize } from "./text-match.ts";

test("tokenize normaliza acentos, pontuação e hifenização", () => {
  assert.deepEqual(tokenize("O CONTRA-\nTANTE pagará R$ 1.000,00."), ["o", "contratante", "pagara", "r", "100000"]);
});

const pages = [
  { page: 1, text: "CONTRATO DE LOCAÇÃO NÃO RESIDENCIAL\nCláusula 1ª – Do objeto: loja situada na Rua A." },
  { page: 2, text: "Cláusula 9ª – Em caso de rescisão antecipada, a LOCATÁRIA pagará multa equivalente a\n10 (dez) aluguéis vigentes, independentemente do tempo decorrido." },
  { page: 3, text: "Cláusula 15ª – Fica eleito o foro da Comarca de Manaus/AM." },
];

test("encontra trecho exato", () => {
  assert.deepEqual(locateExcerpt(pages, "Fica eleito o foro da Comarca de Manaus/AM."), { page: 3, score: 1 });
});

test("tolera diferenças de OCR e de citação", () => {
  const r = locateExcerpt(pages, "a LOCATARIA pagara multa equivalente a 10 (dez) alugueis vigentes, independente do tempo decorrido");
  assert.equal(r?.page, 2);
  assert.ok((r?.score ?? 0) >= 0.85);
});

test("trecho que atravessa páginas começa na página certa", () => {
  const r = locateExcerpt(pages, "independentemente do tempo decorrido. Cláusula 15ª – Fica eleito o foro");
  assert.equal(r?.page, 2);
});

test("trecho inventado não é localizado", () => {
  assert.equal(locateExcerpt(pages, "O locador poderá vender o imóvel sem aviso prévio ao inquilino"), null);
});

test("findBestWindow com haystack menor que o trecho", () => {
  assert.equal(findBestWindow(["a", "b"], ["a", "b", "c", "d"]), null);
  assert.deepEqual(findBestWindow(["a", "b"], ["a", "b", "c"], 0.6), { start: 0, end: 2, score: 2 / 3 });
});

test("tokenizeWithOffsets aponta o início de cada palavra no texto original", async () => {
  const { tokenizeWithOffsets } = await import("./text-match.ts");
  const text = "Multa  de\n10 alu-\nguéis";
  assert.deepEqual(tokenizeWithOffsets(text), [
    { word: "multa", start: 0 },
    { word: "de", start: 7 },
    { word: "10", start: 10 },
    { word: "alugueis", start: 13 },
  ]);
});
