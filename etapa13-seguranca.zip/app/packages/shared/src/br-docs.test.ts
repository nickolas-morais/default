import { test } from "node:test";
import assert from "node:assert/strict";
import { isValidCnpj, isValidCpf, formatCnpj } from "./br-docs.ts";

test("CPF", () => {
  assert.equal(isValidCpf("529.982.247-25"), true);
  assert.equal(isValidCpf("52998224724"), false);
  assert.equal(isValidCpf("111.111.111-11"), false);
});

test("CNPJ numérico", () => {
  assert.equal(isValidCnpj("11.222.333/0001-81"), true);
  assert.equal(isValidCnpj("11.222.333/0001-80"), false);
  assert.equal(isValidCnpj("00.000.000/0000-00"), false);
});

test("CNPJ alfanumérico (exemplo oficial da Receita)", () => {
  assert.equal(isValidCnpj("12.ABC.345/01DE-35"), true);
  assert.equal(isValidCnpj("12ABC34501DE34"), false);
  assert.equal(formatCnpj("12abc34501de35"), "12.ABC.345/01DE-35");
});
