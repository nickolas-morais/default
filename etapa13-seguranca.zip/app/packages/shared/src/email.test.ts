import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, readdirSync, readFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { analysisDoneEmail, quotaEmail } from "./email-templates.ts";
import { sendEmail } from "./email.ts";

test("modelos escapam valores dinâmicos", () => {
  const e = analysisDoneEmail({ name: "Ana", fileName: "<script>x</script>.pdf", risks: 3, highRisks: 1, url: "https://app/x" });
  assert.ok(!e.html.includes("<script>"));
  assert.match(e.text, /3 riscos, 1 de nível alto/);
});

test("aviso de cota em 80% e esgotada", () => {
  assert.match(quotaEmail({ officeName: "A", used: 24, limit: 30, periodEnd: null, url: "u" }).subject, /80%/);
  assert.match(quotaEmail({ officeName: "A", used: 30, limit: 30, periodEnd: null, url: "u" }).subject, /esgotada/);
});

test("modo console salva o HTML e não envia", async () => {
  const dir = mkdtempSync(path.join(os.tmpdir(), "outbox-"));
  const r = await sendEmail({ ...quotaEmail({ officeName: "A", used: 1, limit: 2, periodEnd: null, url: "u" }), to: ["a@b.com", "A@B.com"] },
    { EMAIL_MODE: "console", EMAIL_OUTBOX_DIR: dir });
  assert.equal(r.ok, true);
  const files = readdirSync(dir);
  assert.equal(files.length, 1);
  assert.match(readFileSync(path.join(dir, files[0]!), "utf8"), /Cota do plano/);
});

test("sem destinatários não envia", async () => {
  const r = await sendEmail({ subject: "x", html: "", text: "", to: [] }, { EMAIL_MODE: "resend" });
  assert.deepEqual(r, { ok: true, id: "sem-destinatarios" });
});
