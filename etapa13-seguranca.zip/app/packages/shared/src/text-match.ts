/**
 * Localização aproximada de trechos citados pela IA no texto do documento.
 * Usada pelo worker (para achar a página) e pelo navegador (para destacar o
 * trecho na camada de texto do PDF). O mesmo algoritmo nos dois lados evita
 * divergência entre "onde o servidor achou" e "o que a tela destaca".
 *
 * Tolerante a: acentos, maiúsculas, pontuação, quebras de linha, hifenização
 * no fim da linha e pequenos erros de OCR (compara palavras, não caracteres).
 */

export function normalizeWord(word: string): string {
  return word
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
}

export type Token = { word: string; start: number };

/**
 * Palavras normalizadas com a posição (no texto original) onde cada uma começa.
 * Separa por espaços; "R$ 1.000,00" vira ["r", "100000"]. Palavra hifenizada
 * no fim da linha é unida à seguinte ("contra-\ntante" → "contratante").
 */
export function tokenizeWithOffsets(text: string): Token[] {
  const raw = [...text.matchAll(/\S+/g)];
  const out: Token[] = [];
  for (let i = 0; i < raw.length; i++) {
    const m = raw[i]!;
    let piece = m[0];
    const next = raw[i + 1];
    if (next && /\p{L}-$/u.test(piece) && /\n/.test(text.slice(m.index! + piece.length, next.index)) && /^\p{L}/u.test(next[0])) {
      piece = piece.slice(0, -1) + next[0];
      i++;
    }
    const word = normalizeWord(piece);
    if (word) out.push({ word, start: m.index! });
  }
  return out;
}

export function tokenize(text: string): string[] {
  return tokenizeWithOffsets(text).map((t) => t.word);
}

export type WindowMatch = { start: number; end: number; score: number };

/**
 * Melhor janela de `haystack` com o mesmo tamanho de `needle`, pontuada pela
 * sobreposição de palavras (multiconjunto). score 1 = todas as palavras
 * presentes. Devolve null se nada passar de `minScore`.
 * O(n) sobre o haystack, com contagem incremental.
 */
export function findBestWindow(haystack: string[], needle: string[], minScore = 0.75): WindowMatch | null {
  const n = needle.length;
  if (n === 0 || haystack.length === 0) return null;

  // Atalho: correspondência exata da sequência.
  const exact = indexOfSequence(haystack, needle);
  if (exact >= 0) return { start: exact, end: exact + n, score: 1 };

  const size = Math.min(n, haystack.length);
  const want = new Map<string, number>();
  for (const w of needle) want.set(w, (want.get(w) ?? 0) + 1);

  const have = new Map<string, number>();
  let overlap = 0;
  const add = (w: string) => {
    const c = (have.get(w) ?? 0) + 1;
    have.set(w, c);
    if (c <= (want.get(w) ?? 0)) overlap++;
  };
  const remove = (w: string) => {
    const c = have.get(w) ?? 0;
    if (c <= (want.get(w) ?? 0)) overlap--;
    have.set(w, c - 1);
  };

  for (let i = 0; i < size; i++) add(haystack[i]!);
  let best: WindowMatch = { start: 0, end: size, score: overlap / n };

  for (let i = size; i < haystack.length; i++) {
    add(haystack[i]!);
    remove(haystack[i - size]!);
    const score = overlap / n;
    if (score > best.score) best = { start: i - size + 1, end: i + 1, score };
  }

  return best.score >= minScore ? best : null;
}

function indexOfSequence(haystack: string[], needle: string[]): number {
  outer: for (let i = 0; i + needle.length <= haystack.length; i++) {
    for (let j = 0; j < needle.length; j++) if (haystack[i + j] !== needle[j]) continue outer;
    return i;
  }
  return -1;
}

export type PageText = { page: number; text: string };

/** Página (1-based) em que o trecho começa, procurando no documento inteiro. */
export function locateExcerpt(pages: PageText[], excerpt: string): { page: number; score: number } | null {
  const needle = tokenize(excerpt);
  if (needle.length === 0) return null;

  const tokens: string[] = [];
  const pageOf: number[] = [];
  for (const p of pages) {
    for (const t of tokenize(p.text)) {
      tokens.push(t);
      pageOf.push(p.page);
    }
  }

  const match = findBestWindow(tokens, needle);
  if (!match) return null;
  // Janela pode começar em palavras que não pertencem ao trecho: usa a
  // primeira palavra da janela que está no trecho.
  const needleSet = new Set(needle);
  let first = match.start;
  while (first < match.end && !needleSet.has(tokens[first]!)) first++;
  return { page: pageOf[first] ?? pageOf[match.start]!, score: Math.round(match.score * 100) / 100 };
}
