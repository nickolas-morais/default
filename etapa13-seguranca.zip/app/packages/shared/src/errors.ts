/**
 * Códigos de erro do domínio, compartilhados entre web e worker.
 * Os códigos de banco (lançados com RAISE EXCEPTION nas funções SQL) chegam
 * como `error.message` nas chamadas RPC e são traduzidos aqui.
 */
export const ERROR_MESSAGES = {
  // Genéricos
  UNEXPECTED: "Não foi possível concluir a operação. Tente novamente em instantes.",
  NOT_AUTHENTICATED: "Sua sessão expirou. Entre novamente para continuar.",
  FORBIDDEN: "Você não tem permissão para esta ação. Fale com o administrador do escritório.",
  VALIDATION: "Revise os campos destacados.",

  // Cadastro e login
  INVALID_CREDENTIALS: "E-mail ou senha incorretos.",
  EMAIL_NOT_CONFIRMED: "Confirme seu e-mail antes de entrar. Procure a mensagem que enviamos na sua caixa de entrada.",
  WEAK_PASSWORD: "Escolha uma senha mais forte: pelo menos 8 caracteres, com letras maiúsculas, minúsculas e números.",
  RATE_LIMITED: "Muitas tentativas em pouco tempo. Aguarde alguns minutos e tente de novo.",
  LEGAL_ACCEPTANCE_REQUIRED: "Para criar a conta, aceite os termos de uso e a política de privacidade.",
  LEGAL_VERSION_MISMATCH: "Os termos foram atualizados enquanto esta página estava aberta. Recarregue a página e leia a versão atual.",
  FULL_NAME_REQUIRED: "Informe seu nome completo.",
  OFFICE_NAME_REQUIRED: "Informe o nome do escritório.",
  SIGNUP_FAILED: "Não foi possível criar a conta. Confira os dados e tente novamente.",
  LINK_INVALID: "Este link é inválido ou expirou. Solicite um novo.",

  // Convites e membros
  INVALID_EMAIL: "Informe um e-mail válido.",
  INVITE_INVALID: "Convite não encontrado. Peça um novo link ao administrador do escritório.",
  INVITE_REVOKED: "Este convite foi cancelado. Peça um novo link ao administrador do escritório.",
  INVITE_USED: "Este convite já foi utilizado. Se a conta é sua, entre com seu e-mail e senha.",
  INVITE_EXPIRED: "Este convite expirou. Peça um novo link ao administrador do escritório.",
  INVITE_EMAIL_MISMATCH: "Este convite foi enviado para outro e-mail. Use o e-mail que recebeu o convite.",
  ALREADY_HAS_OFFICE: "Este e-mail já está vinculado a outro escritório. Cada conta pertence a um único escritório.",
  ALREADY_MEMBER: "Esta pessoa já faz parte do escritório.",
  MEMBER_NOT_FOUND: "Membro não encontrado neste escritório.",
  CANNOT_REMOVE_SELF: "Você não pode remover a si mesmo do escritório.",

  // Upload e armazenamento
  UNSUPPORTED_TYPE: "Formato não aceito. Envie o contrato em PDF ou DOCX.",
  FILE_EMPTY: "O arquivo está vazio. Confira se ele abre no seu computador e envie novamente.",
  FILE_TOO_LARGE: "O arquivo passa de 25 MB. Comprima o PDF ou divida o documento em partes menores.",
  FILE_NAME_INVALID: "O nome do arquivo é inválido. Renomeie o arquivo (até 255 caracteres) e envie novamente.",
  TOO_MANY_PAGES: "O documento tem mais de 50 páginas. Divida-o em partes de até 50 páginas e envie cada uma.",
  FILE_CORRUPTED: "Não foi possível abrir o arquivo; ele pode estar corrompido. Gere o PDF ou DOCX novamente e reenvie.",
  FILE_TYPE_MISMATCH: "O conteúdo do arquivo não corresponde à extensão. Abra o arquivo no programa original e salve-o de novo como PDF ou DOCX.",
  PASSWORD_PROTECTED: "O arquivo está protegido por senha. Remova a proteção (por exemplo, imprimindo como PDF) e envie novamente.",
  UPLOAD_FAILED: "O envio do arquivo não foi concluído. Verifique sua conexão e tente novamente.",
  FAILED_ATTEMPTS_LIMIT: "O escritório atingiu o limite de envios com erro nas últimas 24 horas. Tente novamente mais tarde ou fale com o suporte.",
  TOO_MANY_PENDING_UPLOADS: "Há muitos envios em andamento. Aguarde a conclusão dos atuais antes de enviar novos arquivos.",
  DOCUMENT_NOT_FOUND: "Documento não encontrado. Ele pode ter sido excluído.",
  STORAGE_UNAVAILABLE: "O armazenamento de arquivos não respondeu. Tente novamente em instantes.",

  // Processamento e IA
  OCR_ILLEGIBLE: "Não foi possível ler o texto do documento digitalizado. Digitalize novamente com mais resolução (300 dpi), sem sombras ou inclinação, e envie de novo.",
  PROCESSING_FAILED: "O processamento do documento falhou. Use “Reprocessar” para tentar novamente.",
  PROCESSING_TIMEOUT: "O processamento demorou mais que o esperado e foi interrompido. Use “Reprocessar” para tentar novamente.",
  AI_UNAVAILABLE: "O serviço de análise está indisponível no momento. Use “Reprocessar” em alguns minutos; este envio não consumiu a cota.",
  AI_INVALID_OUTPUT: "A análise gerou um resultado incompleto. Use “Reprocessar” para tentar novamente; este envio não consumiu a cota.",
  AI_REFUSED: "O serviço de análise não processou este documento. Revise o conteúdo do arquivo ou fale com o suporte.",
  DOCUMENT_NOT_READY: "O documento ainda está em processamento ou não tem arquivo disponível para esta ação.",
  REPROCESS_LIMIT: "Este documento já foi reprocessado 3 vezes nas últimas 24 horas. Tente novamente amanhã.",

  // Modelos de minuta
  TEMPLATE_INVALID: "O modelo tem marcações inválidas. Corrija os pontos indicados no Word e envie de novo.",
  TEMPLATE_NOT_DOCX: "O modelo precisa ser um arquivo DOCX (Word). Salve como .docx e envie de novo.",
  TEMPLATE_TOO_LARGE: "O modelo passa de 4 MB. Remova imagens grandes do arquivo e envie de novo.",
  TEMPLATE_NOT_FOUND: "Modelo não encontrado. Ele pode ter sido excluído.",
  TEMPLATE_LIMIT: "O escritório atingiu o limite de 100 modelos. Exclua modelos que não usa mais.",
  // Planos e pagamentos
  QUOTA_EXCEEDED: "O escritório usou todos os documentos do plano neste período. Mude de plano em “Plano” ou aguarde a renovação.",
  NO_ACTIVE_PLAN: "O escritório não tem um plano ativo. Escolha um plano em “Plano” para enviar novos documentos. Os documentos já analisados continuam disponíveis.",
  BILLING_UNAVAILABLE: "Não foi possível falar com o sistema de pagamentos. Tente novamente em instantes.",
  BILLING_NOT_CONFIGURED: "Os pagamentos ainda não foram configurados neste ambiente.",
  // Conta e escritório
  WRONG_PASSWORD: "A senha atual está incorreta.",
  SAME_EMAIL: "Este já é o e-mail da sua conta.",
  EMAIL_IN_USE: "Este e-mail já está em uso por outra conta.",
  OWNER_MUST_TRANSFER: "Você é o titular do escritório. Transfira a titularidade para outro membro em Membros antes de excluir sua conta.",
  OWNER_MUST_DELETE_OFFICE: "Você é o único membro e titular do escritório. Para sair, exclua o escritório em Escritório → Zona de risco.",
  ACTIVE_SUBSCRIPTION: "Cancele a assinatura em Plano → Gerenciar assinatura antes de excluir o escritório.",
  OFFICE_DELETION_PENDING: "O escritório está com exclusão agendada. O titular pode cancelar a exclusão em Configurações → Escritório.",
  CONFIRMATION_MISMATCH: "O texto de confirmação não confere.",
  // Plataforma
  OFFICE_SUSPENDED: "O acesso do escritório a novos envios está suspenso. Fale com o suporte.",
  OFFICE_HAS_OWNER: "Este escritório já tem titular.",
  OFFICE_NOT_FOUND: "Escritório não encontrado.",
  CONTRACT_OVERLAP: "Já existe um contrato ativo nesse período. Cancele o atual ou ajuste as datas.",
  CONTRACT_NOT_FOUND: "Contrato não encontrado ou já cancelado.",
  MFA_INVALID_CODE: "Código inválido ou expirado. Confira o horário do celular e digite o código atual do aplicativo.",
  PERSPECTIVE_UNCHANGED: "A análise já está desse ponto de vista.",
  CLIENT_EXISTS: "Já existe um cliente ativo com esse nome no escritório.",
  CLIENT_NOT_FOUND: "Cliente não encontrado ou arquivado.",
  VERSION_EXISTS: "Este documento já tem uma versão mais nova. Envie a nova versão a partir da versão mais recente.",
  VERSION_UNRELATED: "O arquivo não parece ser uma nova versão deste contrato (o texto é muito diferente). Envie-o como documento novo, pela lista de documentos.",
  PLAYBOOK_LIMIT: "O Playbook comporta até 30 regras. Desative ou exclua regras que não usa.",
  DRAFT_FAILED: "Não foi possível gerar a minuta com este modelo. Confira as marcações do modelo e tente de novo.",
} as const;

export type ErrorCode = keyof typeof ERROR_MESSAGES;

export function isErrorCode(value: unknown): value is ErrorCode {
  return typeof value === "string" && value in ERROR_MESSAGES;
}

export function messageFor(code: ErrorCode): string {
  return ERROR_MESSAGES[code];
}

/** Extrai um código conhecido de um erro vindo do banco (RPC) ou devolve UNEXPECTED. */
export function codeFromDbError(error: { message?: string } | null | undefined): ErrorCode {
  const raw = error?.message?.trim();
  return isErrorCode(raw) ? raw : "UNEXPECTED";
}
