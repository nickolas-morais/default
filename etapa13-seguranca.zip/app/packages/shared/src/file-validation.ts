/**
 * Validação do conteúdo real de arquivos enviados. Usada pelo servidor web e,
 * na etapa 3, pelo worker. Importar via "@app/shared/file-validation" (fora do
 * índice, para o pdf-lib não entrar no bundle do navegador).
 */
import { EncryptedPDFError, PDFDocument } from "pdf-lib";
import { MAX_FILE_BYTES, MAX_PAGES, type AcceptedFileType, type ErrorCode } from "./index.ts";

export type FileValidation =
  | { ok: true; pageCount: number | null }
  | { ok: false; code: ErrorCode };

const OLE_SIGNATURE = [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]; // Office criptografado ou .doc antigo
const ZIP_SIGNATURE = [0x50, 0x4b, 0x03, 0x04];

function startsWith(bytes: Uint8Array, signature: number[]) {
  return signature.every((b, i) => bytes[i] === b);
}

function containsAscii(bytes: Uint8Array, text: string) {
  return Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength).includes(text, 0, "latin1");
}

async function validatePdf(bytes: Uint8Array): Promise<FileValidation> {
  // A especificação tolera lixo antes do cabeçalho; os leitores olham o 1º KB.
  const head = Buffer.from(bytes.subarray(0, 1024)).toString("latin1");
  if (!head.includes("%PDF-")) {
    return { ok: false, code: startsWith(bytes, ZIP_SIGNATURE) ? "FILE_TYPE_MISMATCH" : "FILE_CORRUPTED" };
  }

  // PDF criptografado: comum em contratos que só restringem impressão/cópia
  // (abrem sem senha). Não dá para distinguir aqui sem decifrar, então segue
  // para o worker, que remove a proteção com qpdf ou recusa com
  // PASSWORD_PROTECTED se houver senha de abertura. O dicionário /Encrypt fica
  // no trailer ou no dicionário do xref stream, que nunca são comprimidos.
  if (containsAscii(bytes, "/Encrypt")) return { ok: true, pageCount: null };

  try {
    const pdf = await PDFDocument.load(bytes, { updateMetadata: false, throwOnInvalidObject: false });
    const pageCount = pdf.getPageCount();
    if (pageCount === 0) return { ok: false, code: "FILE_CORRUPTED" };
    if (pageCount > MAX_PAGES) return { ok: false, code: "TOO_MANY_PAGES" };
    return { ok: true, pageCount };
  } catch (error) {
    if (error instanceof EncryptedPDFError) return { ok: false, code: "PASSWORD_PROTECTED" };
    return { ok: false, code: "FILE_CORRUPTED" };
  }
}

function validateDocx(bytes: Uint8Array): FileValidation {
  if (startsWith(bytes, OLE_SIGNATURE)) {
    // DOCX protegido por senha é gravado como contêiner OLE, não como ZIP.
    return { ok: false, code: "PASSWORD_PROTECTED" };
  }
  if (!startsWith(bytes, ZIP_SIGNATURE)) {
    return { ok: false, code: bytes[0] === 0x25 ? "FILE_TYPE_MISMATCH" : "FILE_CORRUPTED" };
  }
  // Nomes de arquivos do ZIP ficam sem compressão nos cabeçalhos.
  if (!containsAscii(bytes, "word/document.xml")) return { ok: false, code: "FILE_CORRUPTED" };
  // O total de páginas de um DOCX só é conhecido após a conversão para PDF,
  // feita pelo worker (etapa 3), que aplica o limite de 50 páginas.
  return { ok: true, pageCount: null };
}

/** Confere o conteúdo real do arquivo (não confia em extensão nem em MIME). */
export async function validateFile(bytes: Uint8Array, type: AcceptedFileType): Promise<FileValidation> {
  if (bytes.byteLength === 0) return { ok: false, code: "FILE_EMPTY" };
  if (bytes.byteLength > MAX_FILE_BYTES) return { ok: false, code: "FILE_TOO_LARGE" };
  return type === "pdf" ? validatePdf(bytes) : validateDocx(bytes);
}
