/**
 * Comparação entre duas versões de um contrato. Funções puras, usadas pelo
 * worker ao concluir a análise de uma nova versão.
 *
 * 1. Texto: divide em cláusulas/parágrafos, alinha por LCS e, nos trechos
 *    alterados, mostra a diferença palavra a palavra.
 * 2. Riscos: casa os riscos das duas versões pelo trecho citado (o mesmo
 *    algoritmo tolerante do destaque) e classifica em resolvido, mantido, novo
 *    ou nível alterado.
 */
import { findBestWindow, normalizeWord, tokenize, type PageText } from "./text-match.ts";

export type WordOp = { op: "eq" | "add" | "del"; text: string };
export type TextChange =
  | { type: "alterado"; label: string | null; before: string; after: string; words: WordOp[] }
  | { type: "incluido"; label: string | null; after: string }
  | { type: "removido"; label: string | null; before: string };

export type RiskInput = { id: string; title: string; excerpt: string; level: "alto" | "medio" | "baixo"; resolution?: string; note?: string };
export type RiskChange =
  | { type: "resolvido"; old: RiskInput }
  | { type: "novo"; new: RiskInput }
  | { type: "mantido"; old: RiskInput; new: RiskInput; levelChanged: boolean };

// Início de cláusula, parágrafo ou item: "CLÁUSULA 9ª", "9.1.", "Parágrafo único", "I –", "DAS PARTES".
const BLOCK_START = /^(cl[áa]usula\b|par[áa]grafo\b|\d+(-[a-z])?(\.\d+)*[.)ºª]?\s|[ivxlc]+\s*[-–.)]\s|das?\s+[a-zà-ú]|dos?\s+[a-zà-ú])/i;

export function splitBlocks(pages: PageText[]): string[] {
  const lines = pages.flatMap((p) => p.text.split(/\r?\n/)).map((l) => l.trim());
  const blocks: string[] = [];
  let current: string[] = [];
  const flush = () => {
    const text = current.join(" ").replace(/(\p{L})- (\p{L})/gu, "$1$2").replace(/\s+/g, " ").trim();
    if (text) blocks.push(text);
    current = [];
  };
  for (const line of lines) {
    if (!line) { flush(); continue; }
    const heading = BLOCK_START.test(line) || (line.length < 80 && line === line.toUpperCase() && /\p{L}{3}/u.test(line));
    if (heading && current.length) flush();
    current.push(line);
  }
  flush();
  return blocks;
}

const key = (s: string) => tokenize(s).join(" ");

/** Rótulo da cláusula (ex.: "Cláusula 9ª", "9.1"). */
function labelOf(text: string): string | null {
  const m = text.match(/^(cl[áa]usula\s+[\w\-ºª]+|par[áa]grafo\s+(único|[\wºª]+)|\d+(-[a-z])?(\.\d+)+|\d+[ºª]?)/i);
  return m ? m[0] : null;
}

/** LCS genérico sobre chaves; devolve pares de índices iguais em ordem. */
function lcsPairs(a: string[], b: string[]): Array<[number, number]> {
  const n = a.length, m = b.length;
  const dp = Array.from({ length: n + 1 }, () => new Uint32Array(m + 1));
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      dp[i]![j] = a[i] === b[j] ? dp[i + 1]![j + 1]! + 1 : Math.max(dp[i + 1]![j]!, dp[i]![j + 1]!);
    }
  }
  const pairs: Array<[number, number]> = [];
  let i = 0, j = 0;
  while (i < n && j < m) {
    if (a[i] === b[j]) { pairs.push([i, j]); i++; j++; }
    else if (dp[i + 1]![j]! >= dp[i]![j + 1]!) i++;
    else j++;
  }
  return pairs;
}

export function diffWords(before: string, after: string): WordOp[] {
  const a = before.split(/\s+/).filter(Boolean);
  const b = after.split(/\s+/).filter(Boolean);
  if (a.length * b.length > 400_000) {
    return [{ op: "del", text: before }, { op: "add", text: after }];
  }
  const pairs = lcsPairs(a.map(normalizeWord), b.map(normalizeWord));
  const ops: WordOp[] = [];
  const push = (op: WordOp["op"], text: string) => {
    const last = ops[ops.length - 1];
    if (last && last.op === op) last.text += ` ${text}`;
    else ops.push({ op, text });
  };
  let i = 0, j = 0;
  for (const [pi, pj] of [...pairs, [a.length, b.length] as [number, number]]) {
    while (i < pi) push("del", a[i++]!);
    while (j < pj) push("add", b[j++]!);
    if (pi < a.length && pj < b.length) { push("eq", b[pj]!); i++; j++; }
  }
  return ops;
}

function similarity(a: string, b: string): number {
  const ta = new Set(tokenize(a));
  const tb = new Set(tokenize(b));
  if (!ta.size || !tb.size) return 0;
  let common = 0;
  for (const t of ta) if (tb.has(t)) common++;
  return (2 * common) / (ta.size + tb.size);
}

export function compareText(oldPages: PageText[], newPages: PageText[]): TextChange[] {
  const a = splitBlocks(oldPages);
  const b = splitBlocks(newPages);
  const pairs = lcsPairs(a.map(key), b.map(key));
  const changes: TextChange[] = [];

  let i = 0, j = 0;
  for (const [pi, pj] of [...pairs, [a.length, b.length] as [number, number]]) {
    const removed = a.slice(i, pi);
    const added = b.slice(j, pj);
    // Pareia removidos e incluídos parecidos como "alterado".
    const usedAdded = new Set<number>();
    const region: TextChange[] = [];
    for (const r of removed) {
      let best = -1, bestScore = 0.5;
      added.forEach((ad, k) => {
        if (usedAdded.has(k)) return;
        const s = similarity(r, ad);
        if (s > bestScore) { bestScore = s; best = k; }
      });
      if (best >= 0) {
        usedAdded.add(best);
        region.push({ type: "alterado", label: labelOf(added[best]!) ?? labelOf(r), before: r, after: added[best]!, words: diffWords(r, added[best]!) });
      } else {
        region.push({ type: "removido", label: labelOf(r), before: r });
      }
    }
    added.forEach((ad, k) => { if (!usedAdded.has(k)) region.push({ type: "incluido", label: labelOf(ad), after: ad }); });
    changes.push(...region);
    i = pi + 1;
    j = pj + 1;
  }
  return changes;
}

function excerptMatch(a: string, b: string): number {
  const ta = tokenize(a), tb = tokenize(b);
  return Math.max(findBestWindow(ta, tb, 0)?.score ?? 0, findBestWindow(tb, ta, 0)?.score ?? 0);
}

/** Casa riscos antigos e novos pelo trecho citado (e, na dúvida, pelo título). */
export function compareRisks(oldRisks: RiskInput[], newRisks: RiskInput[]): RiskChange[] {
  const candidates: Array<{ o: number; n: number; score: number }> = [];
  oldRisks.forEach((o, oi) => newRisks.forEach((n, ni) => {
    const score = Math.max(excerptMatch(o.excerpt, n.excerpt), similarity(o.title, n.title) >= 0.8 ? 0.7 : 0);
    if (score >= 0.6) candidates.push({ o: oi, n: ni, score });
  }));
  candidates.sort((x, y) => y.score - x.score);

  const usedOld = new Set<number>(), usedNew = new Set<number>();
  const out: RiskChange[] = [];
  for (const c of candidates) {
    if (usedOld.has(c.o) || usedNew.has(c.n)) continue;
    usedOld.add(c.o); usedNew.add(c.n);
    const o = oldRisks[c.o]!, n = newRisks[c.n]!;
    out.push({ type: "mantido", old: o, new: n, levelChanged: o.level !== n.level });
  }
  oldRisks.forEach((o, i) => { if (!usedOld.has(i)) out.push({ type: "resolvido", old: o }); });
  newRisks.forEach((n, i) => { if (!usedNew.has(i)) out.push({ type: "novo", new: n }); });
  return out;
}

export function comparisonStats(text: TextChange[], risks: RiskChange[]) {
  return {
    changed: text.filter((t) => t.type === "alterado").length,
    added: text.filter((t) => t.type === "incluido").length,
    removed: text.filter((t) => t.type === "removido").length,
    risksResolved: risks.filter((r) => r.type === "resolvido").length,
    risksKept: risks.filter((r) => r.type === "mantido").length,
    risksNew: risks.filter((r) => r.type === "novo").length,
    risksLevelChanged: risks.filter((r) => r.type === "mantido" && r.levelChanged).length,
  };
}

/**
 * Semelhança entre dois textos por trincas de palavras (Jaccard). Versões de um
 * mesmo contrato ficam, em geral, acima de 0,5; contratos diferentes, mesmo do
 * mesmo tipo, bem abaixo de 0,3.
 */
export function textSimilarity(a: PageText[], b: PageText[]): number {
  const shingles = (pages: PageText[]) => {
    const t = tokenize(pages.map((p) => p.text).join("\n"));
    const set = new Set<string>();
    for (let i = 0; i + 2 < t.length; i++) set.add(`${t[i]} ${t[i + 1]} ${t[i + 2]}`);
    return set;
  };
  const sa = shingles(a), sb = shingles(b);
  if (!sa.size || !sb.size) return 0;
  let inter = 0;
  for (const s of sa) if (sb.has(s)) inter++;
  return inter / (sa.size + sb.size - inter);
}
