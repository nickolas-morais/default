/**
 * Limites de upload. MAX_FILE_BYTES também está em
 * public.create_document_upload() e no bucket 'documents' (migration da etapa 2).
 */
export const MAX_FILE_BYTES = 25 * 1024 * 1024;
export const MAX_PAGES = 50;

export const ACCEPTED_FILE_TYPES = {
  pdf: "application/pdf",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
} as const;

export type AcceptedFileType = keyof typeof ACCEPTED_FILE_TYPES;

/** Tipo pelo nome do arquivo; null se a extensão não for aceita. */
export function fileTypeFromName(fileName: string): AcceptedFileType | null {
  const ext = fileName.trim().toLowerCase().match(/\.([a-z0-9]+)$/)?.[1];
  return ext === "pdf" || ext === "docx" ? ext : null;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1).replace(".", ",")} MB`;
}
