import { test } from "node:test";
import assert from "node:assert/strict";
import { buildIcs } from "./ics.ts";

test("evento de dia inteiro, com recorrência, alarme e texto escapado", () => {
  const ics = buildIcs({
    name: "Prazos, Escritório A", now: new Date("2026-10-01T12:00:00Z"),
    events: [{ uid: "d1@app", date: "2027-03-31", title: "Aviso de não renovação; Locação", description: "Cláusula 2.2\nLoja Centro",
      recurrence: "yearly", alarmDaysBefore: [7] }],
  });
  assert.match(ics, /DTSTART;VALUE=DATE:20270331\r\nDTEND;VALUE=DATE:20270401/);
  assert.match(ics, /SUMMARY:Aviso de não renovação\\; Locação/);
  assert.match(ics, /DESCRIPTION:Cláusula 2\.2\\nLoja Centro/);
  assert.match(ics, /RRULE:FREQ=YEARLY/);
  assert.match(ics, /TRIGGER:-P7D/);
  assert.match(ics, /X-WR-CALNAME:Prazos\\, Escritório A/);
  assert.ok(ics.endsWith("END:VCALENDAR\r\n"));
});

test("linhas longas são dobradas em até 75 bytes", () => {
  const ics = buildIcs({ name: "x", events: [{ uid: "u", date: "2027-01-01", title: "ção".repeat(60) }] });
  for (const line of ics.split("\r\n")) assert.ok(Buffer.byteLength(line) <= 75, line);
});

test("calendário assinado sugere intervalo de atualização", () => {
  const ics = buildIcs({ name: "x", events: [], refreshHours: 6 });
  assert.match(ics, /REFRESH-INTERVAL;VALUE=DURATION:PT6H/);
  assert.match(ics, /X-PUBLISHED-TTL:PT6H/);
});
