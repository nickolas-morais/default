/**
 * Variáveis de modelos de minuta: nomes padrão reconhecidos automaticamente,
 * leitura das marcações do modelo e montagem dos valores a partir dos dados
 * extraídos. Lógica pura (sem DOCX), usada no servidor e na tela.
 */
import type { Extraction } from "./analysis.ts";
import { formatCnpj, formatCpf, isValidCnpj, isValidCpf, normalizeCnpj } from "./br-docs.ts";

export type VariableGroup = "partes" | "contrato" | "gerais";

export type StandardVariable = {
  key: string;
  label: string;
  description: string;
  example: string;
  group: VariableGroup;
  aliases?: string[];
};

const party = (key: string, label: string, roleHint: string): StandardVariable[] => [
  {
    key, label, group: "partes",
    description: `Nome da parte cujo papel no contrato contém "${roleHint}".`,
    example: "Café Aurora Comércio de Alimentos Ltda.",
  },
  {
    key: `${key}_documento`, label: `CPF/CNPJ (${label.toLowerCase()})`, group: "partes",
    description: `CPF ou CNPJ formatado da parte "${roleHint}".`,
    example: "12.ABC.345/01DE-35",
    aliases: [`${key}_cpf`, `${key}_cnpj`, `cpf_${key}`, `cnpj_${key}`, `cpf_cnpj_${key}`, `documento_${key}`],
  },
];

export const STANDARD_VARIABLES: StandardVariable[] = [
  ...party("contratante", "Contratante", "contratante"),
  ...party("contratada", "Contratada", "contratad"),
  ...party("locador", "Locador(a)", "locador"),
  ...party("locatario", "Locatário(a)", "locatári"),
  ...party("fiador", "Fiador(a)", "fiador"),
  ...party("vendedor", "Vendedor(a)", "vendedor"),
  ...party("comprador", "Comprador(a)", "comprador"),
  {
    key: "partes", label: "Todas as partes", group: "partes",
    description: "Todas as partes, uma por linha, com papel e CPF/CNPJ.",
    example: "Imobiliária Horizonte Paulista Ltda. (Locadora), CNPJ 11.222.333/0001-81",
  },
  { key: "objeto", label: "Objeto", group: "contrato", description: "Objeto do contrato.", example: "Locação da loja 3…" },
  { key: "valor", label: "Valor", group: "contrato", description: "Valor, com moeda e periodicidade.", example: "R$ 8.500,00 mensais", aliases: ["valor_total", "preco"] },
  { key: "forma_pagamento", label: "Forma de pagamento", group: "contrato", description: "Forma e prazo de pagamento.", example: "Boleto, até o dia 5", aliases: ["pagamento"] },
  { key: "vigencia", label: "Vigência", group: "contrato", description: "Prazo de vigência e renovação.", example: "36 meses", aliases: ["prazo"] },
  { key: "data_inicio", label: "Início da vigência", group: "contrato", description: "Data de início (dd/mm/aaaa).", example: "01/10/2026" },
  { key: "data_fim", label: "Término da vigência", group: "contrato", description: "Data de término (dd/mm/aaaa).", example: "30/09/2029", aliases: ["data_termino"] },
  { key: "prazo_rescisao", label: "Rescisão", group: "contrato", description: "Hipóteses e prazos de rescisão.", example: "Aviso prévio de 30 dias", aliases: ["rescisao"] },
  { key: "multas", label: "Multas", group: "contrato", description: "Multas previstas, uma por linha.", example: "Rescisão antecipada: 12 aluguéis", aliases: ["multa"] },
  { key: "foro", label: "Foro", group: "contrato", description: "Foro de eleição.", example: "Comarca de Manaus/AM" },
  { key: "indice_reajuste", label: "Reajuste", group: "contrato", description: "Índice e periodicidade de reajuste.", example: "IGP-M anual", aliases: ["reajuste", "indice"] },
  { key: "escritorio", label: "Escritório", group: "gerais", description: "Nome do escritório.", example: "Souza & Lima Advogados", aliases: ["nome_escritorio"] },
  { key: "escritorio_cnpj", label: "CNPJ do escritório", group: "gerais", description: "CNPJ do escritório (Configurações → Escritório).", example: "11.222.333/0001-81" },
  { key: "escritorio_endereco", label: "Endereço do escritório", group: "gerais", description: "Endereço cadastrado do escritório.", example: "Av. Paulista, 1.000, São Paulo/SP" },
  { key: "escritorio_telefone", label: "Telefone do escritório", group: "gerais", description: "Telefone cadastrado do escritório.", example: "(11) 3000-0000" },
  { key: "escritorio_email", label: "E-mail do escritório", group: "gerais", description: "E-mail de contato do escritório.", example: "contato@souzalima.adv.br" },
  { key: "escritorio_oab", label: "Registro do escritório na OAB", group: "gerais", description: "Registro da sociedade de advogados.", example: "OAB/SP 12.345" },
  { key: "advogado", label: "Advogado(a) que gera a minuta", group: "gerais", description: "Nome de quem gera a minuta (Minha conta).", example: "Ana Souza", aliases: ["advogado_responsavel", "advogada", "advogada_responsavel"] },
  { key: "advogado_oab", label: "OAB do(a) advogado(a)", group: "gerais", description: "Número da OAB de quem gera a minuta (Minha conta).", example: "SP 123.456", aliases: ["oab", "advogada_oab"] },
  { key: "data_hoje", label: "Data de hoje", group: "gerais", description: "Data da geração (dd/mm/aaaa).", example: "29/09/2026", aliases: ["data", "data_atual"] },
  { key: "data_hoje_extenso", label: "Data de hoje por extenso", group: "gerais", description: "Data da geração por extenso.", example: "29 de setembro de 2026", aliases: ["data_extenso"] },
];

export type LoopDefinition = { key: string; label: string; fields: { key: string; description: string }[] };

export const STANDARD_LOOPS: LoopDefinition[] = [
  {
    key: "lista_partes", label: "Lista de partes",
    fields: [
      { key: "nome", description: "Nome ou razão social" },
      { key: "documento", description: "CPF/CNPJ formatado" },
      { key: "papel", description: "Papel no contrato" },
    ],
  },
  {
    key: "lista_multas", label: "Lista de multas",
    fields: [
      { key: "descricao", description: "Hipótese da multa" },
      { key: "valor", description: "Valor ou percentual" },
    ],
  },
];

/** "Locatário CPF" → "locatario_cpf". Usado para reconhecer variações de escrita. */
export function normalizeVarName(tag: string): string {
  return tag
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

const BY_NAME = new Map<string, StandardVariable>();
for (const v of STANDARD_VARIABLES) {
  BY_NAME.set(v.key, v);
  for (const a of v.aliases ?? []) BY_NAME.set(a, v);
}
// Feminino e variações comuns dos papéis.
for (const [alias, key] of [
  ["locadora", "locador"], ["locataria", "locatario"], ["inquilino", "locatario"], ["inquilina", "locatario"],
  ["fiadora", "fiador"], ["vendedora", "vendedor"], ["compradora", "comprador"], ["contratado", "contratada"],
] as const) {
  BY_NAME.set(alias, BY_NAME.get(key)!);
  const doc = BY_NAME.get(`${key}_documento`)!;
  for (const form of [`${alias}_documento`, ...(doc.aliases ?? []).map((a) => a.replace(key, alias))]) {
    BY_NAME.set(form, doc);
  }
}
const LOOPS = new Map(STANDARD_LOOPS.map((l) => [l.key, l]));

export function findStandardVariable(tag: string): StandardVariable | null {
  return BY_NAME.get(normalizeVarName(tag)) ?? null;
}

export type ParsedTemplate = {
  /** Variáveis simples, com o nome exatamente como escrito no modelo. */
  variables: string[];
  loops: { name: string; fields: string[] }[];
};

/**
 * Lê as marcações {{...}} do texto do modelo (o docxtemplater já juntou os
 * pedaços que o Word divide). Variáveis dentro de laços ficam no laço.
 */
export function parseTemplateTags(texts: string[]): ParsedTemplate {
  const variables: string[] = [];
  const loops = new Map<string, Set<string>>();
  const stack: string[] = [];
  for (const text of texts) {
    for (const m of text.matchAll(/\{\{\s*([#/^]?)\s*([^{}]+?)\s*\}\}/g)) {
      const [, prefix, name] = m as unknown as [string, string, string];
      if (prefix === "#" || prefix === "^") {
        stack.push(name);
        if (!loops.has(name)) loops.set(name, new Set());
      } else if (prefix === "/") {
        stack.pop();
      } else if (stack.length) {
        loops.get(stack[stack.length - 1]!)!.add(name);
      } else if (!variables.includes(name)) {
        variables.push(name);
      }
    }
  }
  return { variables, loops: [...loops].map(([name, fields]) => ({ name, fields: [...fields] })) };
}

export type VariableMapping = {
  automatic: { tag: string; key: string; label: string }[];
  manual: string[];
  loops: { name: string; key: string | null; label: string | null; unknownFields: string[] }[];
};

export function mapVariables(parsed: ParsedTemplate): VariableMapping {
  const automatic: VariableMapping["automatic"] = [];
  const manual: string[] = [];
  for (const tag of parsed.variables) {
    const std = findStandardVariable(tag);
    if (std) automatic.push({ tag, key: std.key, label: std.label });
    else manual.push(tag);
  }
  const loops = parsed.loops.map((l) => {
    const def = LOOPS.get(normalizeVarName(l.name)) ?? null;
    const known = new Set(def?.fields.map((f) => f.key));
    return {
      name: l.name,
      key: def?.key ?? null,
      label: def?.label ?? null,
      unknownFields: l.fields.filter((f) => !known.has(normalizeVarName(f))),
    };
  });
  return { automatic, manual, loops };
}

function formatDocument(value: string): string {
  const n = normalizeCnpj(value);
  if (/^\d{11}$/.test(n) && isValidCpf(n)) return formatCpf(n);
  if (n.length === 14 && isValidCnpj(n)) return formatCnpj(n);
  return value.trim();
}

const brDate = (iso: string) => (/^\d{4}-\d{2}-\d{2}$/.test(iso) ? iso.split("-").reverse().join("/") : iso);
const roleWord = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

const ROLE_HINTS: Record<string, string> = {
  contratante: "contratante", contratada: "contratad", locador: "locador", locatario: "locatari",
  fiador: "fiador", vendedor: "vendedor", comprador: "comprador",
};

/** Valores das variáveis padrão a partir dos dados extraídos (editados, se houver). */
export type TemplateContext = {
  officeName: string;
  today: Date;
  office?: { cnpj?: string | null; address?: string | null; phone?: string | null; contactEmail?: string | null; oab?: string | null };
  user?: { name?: string | null; oab?: string | null };
};

export function buildStandardValues(data: Extraction, ctx: TemplateContext): Record<string, string> {
  const values: Record<string, string> = {};
  for (const [key, hint] of Object.entries(ROLE_HINTS)) {
    const matches = data.partes.filter((p) => roleWord(p.papel).includes(hint));
    values[key] = matches.map((p) => p.nome).join(" e ");
    values[`${key}_documento`] = matches.map((p) => formatDocument(p.documento)).filter(Boolean).join(" e ");
  }
  values.partes = data.partes
    .map((p) => [p.nome, p.papel && `(${p.papel})`, p.documento && `, ${/^\d{11}$/.test(normalizeCnpj(p.documento)) ? "CPF" : "CNPJ"} ${formatDocument(p.documento)}`]
      .filter(Boolean).join(" ").replace(" ,", ","))
    .join("\n");
  values.objeto = data.objeto;
  values.valor = data.valor;
  values.forma_pagamento = data.forma_pagamento;
  values.vigencia = data.vigencia;
  values.data_inicio = brDate(data.data_inicio);
  values.data_fim = brDate(data.data_fim);
  values.prazo_rescisao = data.prazo_rescisao;
  values.multas = data.multas.map((m) => `${m.descricao}: ${m.valor}`).join("\n");
  values.foro = data.foro;
  values.indice_reajuste = data.indice_reajuste;
  values.escritorio = ctx.officeName;
  values.escritorio_cnpj = ctx.office?.cnpj ? formatDocument(ctx.office.cnpj) : "";
  values.escritorio_endereco = ctx.office?.address ?? "";
  values.escritorio_telefone = ctx.office?.phone ?? "";
  values.escritorio_email = ctx.office?.contactEmail ?? "";
  values.escritorio_oab = ctx.office?.oab ?? "";
  values.advogado = ctx.user?.name ?? "";
  values.advogado_oab = ctx.user?.oab ?? "";
  const tz = { timeZone: "America/Sao_Paulo" } as const;
  values.data_hoje = new Intl.DateTimeFormat("pt-BR", { ...tz, dateStyle: "short" }).format(ctx.today);
  values.data_hoje_extenso = new Intl.DateTimeFormat("pt-BR", { ...tz, dateStyle: "long" }).format(ctx.today);
  return values;
}

export function buildLoopValues(data: Extraction): Record<string, Record<string, string>[]> {
  return {
    lista_partes: data.partes.map((p) => ({ nome: p.nome, documento: formatDocument(p.documento), papel: p.papel })),
    lista_multas: data.multas.map((m) => ({ descricao: m.descricao, valor: m.valor })),
  };
}

/**
 * Dados para o docxtemplater, com as chaves exatamente como no modelo.
 * `overrides` traz o que o usuário preencheu ou corrigiu na tela (por tag).
 */
export function buildRenderData(
  parsed: ParsedTemplate,
  standard: Record<string, string>,
  loopValues: Record<string, Record<string, string>[]>,
  overrides: Record<string, string>,
): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const tag of parsed.variables) {
    const std = findStandardVariable(tag);
    out[tag] = overrides[tag] ?? (std ? standard[std.key] ?? "" : "");
  }
  for (const loop of parsed.loops) {
    const key = LOOPS.get(normalizeVarName(loop.name))?.key;
    const rows = key ? loopValues[key] ?? [] : [];
    // Campos do laço aceitam variações de escrita ({{Nome}}, {{NOME}}).
    out[loop.name] = rows.map((row) =>
      Object.fromEntries(loop.fields.map((f) => [f, row[normalizeVarName(f)] ?? ""])),
    );
  }
  return out;
}
