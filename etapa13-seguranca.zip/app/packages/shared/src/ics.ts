/**
 * Geração de calendário iCalendar (RFC 5545) com eventos de dia inteiro.
 * Abre no Google Agenda, Outlook e Apple Calendar.
 */
export type IcsEvent = {
  uid: string;
  date: string;              // AAAA-MM-DD
  title: string;
  description?: string;
  url?: string;
  recurrence?: "none" | "yearly" | "monthly";
  alarmDaysBefore?: number[];
};

const escapeText = (s: string) => s.replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");

/** Quebra linhas em 75 octetos, sem partir caracteres UTF-8. */
function fold(line: string): string {
  const out: string[] = [];
  let current = "";
  let bytes = 0;
  for (const ch of line) {
    const size = Buffer.byteLength(ch);
    if (bytes + size > (out.length ? 74 : 75)) {
      out.push(current);
      current = "";
      bytes = 0;
    }
    current += ch;
    bytes += size;
  }
  out.push(current);
  return out.join("\r\n ");
}

const compact = (d: string) => d.replace(/-/g, "");
const nextDay = (d: string) => {
  const x = new Date(`${d}T00:00:00Z`);
  x.setUTCDate(x.getUTCDate() + 1);
  return x.toISOString().slice(0, 10);
};

export function buildIcs(o: { name: string; events: IcsEvent[]; now?: Date; refreshHours?: number }): string {
  const stamp = (o.now ?? new Date()).toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
  const lines = [
    "BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//App//Prazos//PT-BR", "CALSCALE:GREGORIAN", "METHOD:PUBLISH",
    `X-WR-CALNAME:${escapeText(o.name)}`, "X-WR-TIMEZONE:America/Sao_Paulo",
  ];
  // Sugestão de frequência de atualização para calendários assinados.
  if (o.refreshHours) lines.push(`REFRESH-INTERVAL;VALUE=DURATION:PT${o.refreshHours}H`, `X-PUBLISHED-TTL:PT${o.refreshHours}H`);
  for (const e of o.events) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(e.date)) continue;
    lines.push("BEGIN:VEVENT", `UID:${e.uid}`, `DTSTAMP:${stamp}`,
      `DTSTART;VALUE=DATE:${compact(e.date)}`, `DTEND;VALUE=DATE:${compact(nextDay(e.date))}`,
      `SUMMARY:${escapeText(e.title)}`);
    if (e.description) lines.push(`DESCRIPTION:${escapeText(e.description)}`);
    if (e.url) lines.push(`URL:${e.url}`);
    if (e.recurrence === "yearly") lines.push("RRULE:FREQ=YEARLY");
    if (e.recurrence === "monthly") lines.push("RRULE:FREQ=MONTHLY");
    lines.push("TRANSP:TRANSPARENT");
    for (const days of e.alarmDaysBefore ?? []) {
      lines.push("BEGIN:VALARM", "ACTION:DISPLAY", `DESCRIPTION:${escapeText(e.title)}`, `TRIGGER:-P${days}D`, "END:VALARM");
    }
    lines.push("END:VEVENT");
  }
  lines.push("END:VCALENDAR");
  return lines.map(fold).join("\r\n") + "\r\n";
}
