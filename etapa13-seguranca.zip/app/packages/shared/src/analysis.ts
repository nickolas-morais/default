/**
 * Contrato de dados da análise por IA: o que o modelo devolve (JSON Schema
 * enviado em output_config.format) e a validação local (Zod).
 *
 * Regras do schema para saídas estruturadas da API da Anthropic:
 *  - todos os campos obrigatórios e sem uniões (texto ausente = ""), o que
 *    mantém a gramática pequena e a ordem dos campos previsível;
 *  - additionalProperties: false em todo objeto;
 *  - sem restrições de tamanho no schema: os limites ficam no Zod.
 * A ordem importa: extração → riscos → resumo (o resumo é escrito por último,
 * já considerando os riscos).
 */
import { z } from "zod";

export const RISK_LEVELS = ["alto", "medio", "baixo"] as const;
export type RiskLevel = (typeof RISK_LEVELS)[number];

const text = (max: number) => z.string().trim().max(max);

export const PartySchema = z.object({
  nome: text(300),
  documento: text(40),
  papel: text(120),
});

export const FineSchema = z.object({
  descricao: text(1000),
  valor: text(300),
});

export const ExtractionSchema = z.object({
  partes: z.array(PartySchema).max(30),
  objeto: text(4000),
  valor: text(1000),
  forma_pagamento: text(2000),
  vigencia: text(1000),
  data_inicio: text(10),
  data_fim: text(10),
  prazo_rescisao: text(3000),
  multas: z.array(FineSchema).max(30),
  foro: text(500),
  indice_reajuste: text(500),
});

export type Extraction = z.infer<typeof ExtractionSchema>;

export const EMPTY_EXTRACTION: Extraction = {
  partes: [],
  objeto: "",
  valor: "",
  forma_pagamento: "",
  vigencia: "",
  data_inicio: "",
  data_fim: "",
  prazo_rescisao: "",
  multas: [],
  foro: "",
  indice_reajuste: "",
};

export const RiskSchema = z.object({
  nivel: z.string().transform((v) => v.trim().toLowerCase()).pipe(z.enum(RISK_LEVELS)),
  titulo: text(200),
  clausula: text(100),
  trecho_original: text(3000),
  pagina: z.number().int(),
  explicacao: text(3000),
  sugestao_redacao: text(4000),
  parte_prejudicada: text(200),
  // Código da regra do Playbook do escritório (ex.: "R2"); "" se não vier de uma regra.
  regra_playbook: text(10).default(""),
});

export const DEADLINE_KINDS = ["fim_vigencia", "aviso_nao_renovacao", "reajuste", "pagamento", "garantia", "outro"] as const;
export type DeadlineKind = (typeof DEADLINE_KINDS)[number];

const lowerEnum = <T extends readonly [string, ...string[]]>(values: T) =>
  z.string().transform((v) => v.trim().toLowerCase()).pipe(z.enum(values));

export const DeadlineSchema = z.object({
  tipo: lowerEnum(DEADLINE_KINDS),
  titulo: text(200),
  data: text(10),
  referencia: lowerEnum(["nenhuma", "data_inicio", "data_fim"] as const),
  deslocamento_dias: z.number().int().min(-3650).max(3650),
  recorrencia: lowerEnum(["nenhuma", "anual", "mensal"] as const),
  clausula: text(100),
  trecho_original: text(1500),
});
export type Deadline = z.infer<typeof DeadlineSchema>;

export const AnalysisSchema = z.object({
  extracao: ExtractionSchema,
  // Opcional na validação: análises anteriores à versão 2026-10-v3 não têm prazos.
  prazos: z.array(DeadlineSchema).max(20).default([]),
  riscos: z.array(RiskSchema).max(40),
  resumo: text(8000),
});

export type Analysis = z.infer<typeof AnalysisSchema>;
export type Risk = z.infer<typeof RiskSchema>;

const str = (description: string) => ({ type: "string", description }) as const;

/** JSON Schema enviado à API. Mantenha em sincronia com AnalysisSchema (há teste). */
export const ANALYSIS_JSON_SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["extracao", "prazos", "riscos", "resumo"],
  properties: {
    extracao: {
      type: "object",
      additionalProperties: false,
      required: [
        "partes", "objeto", "valor", "forma_pagamento", "vigencia", "data_inicio", "data_fim",
        "prazo_rescisao", "multas", "foro", "indice_reajuste",
      ],
      properties: {
        partes: {
          type: "array",
          items: {
            type: "object",
            additionalProperties: false,
            required: ["nome", "documento", "papel"],
            properties: {
              nome: str("Nome completo ou razão social, como no contrato."),
              documento: str("CPF ou CNPJ exatamente como aparece no contrato; \"\" se ausente."),
              papel: str("Papel no contrato: Contratante, Contratada, Locador, Fiador etc."),
            },
          },
        },
        objeto: str("Objeto do contrato em uma ou duas frases."),
        valor: str("Valor total ou periódico, com moeda e periodicidade."),
        forma_pagamento: str("Forma, prazo e condições de pagamento."),
        vigencia: str("Prazo de vigência e condições de renovação."),
        data_inicio: str("Início da vigência no formato AAAA-MM-DD; \"\" se não houver data explícita."),
        data_fim: str("Término da vigência no formato AAAA-MM-DD; \"\" se não houver data explícita."),
        prazo_rescisao: str("Hipóteses, aviso prévio e prazos de rescisão."),
        multas: {
          type: "array",
          items: {
            type: "object",
            additionalProperties: false,
            required: ["descricao", "valor"],
            properties: {
              descricao: str("Hipótese em que a multa se aplica."),
              valor: str("Valor, percentual ou fórmula da multa."),
            },
          },
        },
        foro: str("Foro de eleição (comarca e estado)."),
        indice_reajuste: str("Índice e periodicidade de reajuste."),
      },
    },
    prazos: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["tipo", "titulo", "data", "referencia", "deslocamento_dias", "recorrencia", "clausula", "trecho_original"],
        properties: {
          tipo: { type: "string", enum: [...DEADLINE_KINDS] },
          titulo: str("Descrição curta do prazo, como \"Aviso de não renovação\"."),
          data: str("Data explícita no contrato, AAAA-MM-DD; \"\" se o prazo for relativo."),
          referencia: { type: "string", enum: ["nenhuma", "data_inicio", "data_fim"] },
          deslocamento_dias: { type: "integer", description: "Dias a partir da referência; negativo = antes. 0 se data explícita." },
          recorrencia: { type: "string", enum: ["nenhuma", "anual", "mensal"] },
          clausula: str("Número da cláusula; \"\" se não numerada."),
          trecho_original: str("Cópia literal do trecho que define o prazo."),
        },
      },
    },
    riscos: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: [
          "nivel", "titulo", "clausula", "trecho_original", "pagina", "explicacao",
          "sugestao_redacao", "parte_prejudicada", "regra_playbook",
        ],
        properties: {
          nivel: { type: "string", enum: [...RISK_LEVELS] },
          titulo: str("Título curto do risco."),
          clausula: str("Número da cláusula, como \"Cláusula 9.2\"; \"\" se não numerada."),
          trecho_original: str("Cópia literal e contínua do trecho do contrato, sem reticências."),
          pagina: { type: "integer", description: "Número da <pagina> onde o trecho começa." },
          explicacao: str("Por que é um risco, com fundamento legal quando houver."),
          sugestao_redacao: str("Redação alternativa completa da cláusula."),
          parte_prejudicada: str("Parte desfavorecida pela cláusula, pelo papel; \"\" se ambas."),
          regra_playbook: str("Código da regra do escritório (ex.: \"R2\") que o risco viola; \"\" se nenhuma."),
        },
      },
    },
    resumo: str("Resumo executivo para o cliente leigo."),
  },
} as const;
