/**
 * Leitura e preenchimento de modelos DOCX (docxtemplater). Somente servidor.
 * Importar via "@app/shared/docx-template".
 */
import PizZip from "pizzip";
import Docxtemplater from "docxtemplater";
import { parseTemplateTags, type ParsedTemplate } from "./template-vars.ts";

const OPTIONS = {
  paragraphLoop: true,
  linebreaks: true,
  delimiters: { start: "{{", end: "}}" },
  errorLogging: false,
} as const;

/** Campo vazio vira uma linha para preenchimento, visível para o advogado. */
const BLANK = "__________";

type TemplateErrorLike = { properties?: { id?: string; xtag?: string; context?: string; errors?: TemplateErrorLike[] } };

function describe(err: TemplateErrorLike): string {
  const p = err.properties ?? {};
  const tag = p.xtag ?? p.context ?? "";
  switch (p.id) {
    case "unclosed_tag":
      return `Marcação sem fechamento perto de “${p.context ?? tag}”. Toda variável precisa terminar com }}.`;
    case "unopened_tag":
      return `Fechamento }} sem abertura perto de “${p.context ?? tag}”.`;
    case "unclosed_loop":
      return `A lista {{#${tag}}} não foi fechada. Adicione {{/${tag}}} no fim do trecho que se repete.`;
    case "unopened_loop":
      return `Encontrado {{/${tag}}} sem o {{#${tag}}} correspondente.`;
    case "closing_tag_does_not_match_opening_tag":
      return `Uma lista foi fechada com um nome diferente do que foi aberta (${tag}).`;
    case "duplicate_open_tag":
    case "duplicate_close_tag":
      return `Chaves duplicadas perto de “${p.context ?? tag}”. Use exatamente {{ e }}.`;
    default:
      return `Marcação inválida perto de “${tag || "?"}”.`;
  }
}

function compile(bytes: Uint8Array): Docxtemplater {
  return new Docxtemplater(new PizZip(bytes), OPTIONS);
}

export type InspectResult = { ok: true; parsed: ParsedTemplate } | { ok: false; errors: string[] };

/** Valida a sintaxe e lista as variáveis (corpo, cabeçalhos e rodapés). */
export function inspectTemplate(bytes: Uint8Array): InspectResult {
  let doc: Docxtemplater;
  try {
    doc = compile(bytes);
  } catch (e) {
    const err = e as TemplateErrorLike;
    const list = err.properties?.errors?.length ? err.properties.errors : [err];
    return { ok: false, errors: list.slice(0, 5).map(describe) };
  }
  const files = Object.keys((doc as unknown as { compiled: Record<string, unknown> }).compiled).filter((f) =>
    /^word\/(document|header\d*|footer\d*)\.xml$/.test(f),
  );
  const texts = files.sort().map((f) => doc.getFullText(f));
  return { ok: true, parsed: parseTemplateTags(texts) };
}

export function renderTemplate(bytes: Uint8Array, data: Record<string, unknown>): Uint8Array {
  const doc = new Docxtemplater(new PizZip(bytes), {
    ...OPTIONS,
    nullGetter: () => BLANK,
  });
  // Texto vazio também vira linha de preenchimento.
  const withBlanks = JSON.parse(JSON.stringify(data), (_k, v) => (v === "" ? BLANK : v));
  doc.render(withBlanks);
  return doc.getZip().generate({ type: "uint8array", compression: "DEFLATE" });
}
