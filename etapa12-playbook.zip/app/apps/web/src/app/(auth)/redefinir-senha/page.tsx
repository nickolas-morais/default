"use client";

import { useActionState } from "react";
import { resetPassword } from "@/server/actions/auth";
import { Field } from "@/components/ui/field";
import { FormMessage } from "@/components/ui/alert";
import { SubmitButton } from "@/components/ui/button";
import type { FormState } from "@/lib/errors";

export default function ResetPasswordPage() {
  const [state, action] = useActionState<FormState, FormData>(resetPassword, {});
  return (
    <>
      <h1 className="font-serif text-2xl font-semibold">Nova senha</h1>
      <p className="mt-2 text-muted">Escolha a nova senha da sua conta.</p>
      <form action={action} className="mt-8 space-y-5" noValidate>
        <FormMessage state={state} />
        <Field
          label="Nova senha"
          name="password"
          type="password"
          autoComplete="new-password"
          required
          hint="Pelo menos 8 caracteres."
          error={state.fieldErrors?.password}
        />
        <Field
          label="Repita a nova senha"
          name="confirm"
          type="password"
          autoComplete="new-password"
          required
          error={state.fieldErrors?.confirm}
        />
        <SubmitButton className="w-full" pendingLabel="Salvando…">Salvar nova senha</SubmitButton>
      </form>
    </>
  );
}
