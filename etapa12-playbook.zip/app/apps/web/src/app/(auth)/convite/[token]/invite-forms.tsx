"use client";

import { useActionState } from "react";
import { acceptInvitation, signUpWithInvite } from "@/server/actions/auth";
import { Field } from "@/components/ui/field";
import { FormMessage } from "@/components/ui/alert";
import { SubmitButton } from "@/components/ui/button";
import { LegalCheckbox } from "@/components/ui/legal-checkbox";
import type { FormState } from "@/lib/errors";

export function InviteSignUpForm({ token, email }: { token: string; email: string }) {
  const [state, action] = useActionState<FormState, FormData>(signUpWithInvite, {});
  const e = state.fieldErrors ?? {};
  return (
    <form action={action} className="mt-8 space-y-5" noValidate>
      <FormMessage state={state} />
      <input type="hidden" name="token" value={token} />
      <Field label="E-mail" name="email-display" value={email} readOnly hint="O convite vale apenas para este e-mail." />
      <Field
        label="Seu nome completo"
        name="fullName"
        autoComplete="name"
        required
        defaultValue={state.values?.fullName}
        error={e.fullName}
      />
      <Field
        label="Senha"
        name="password"
        type="password"
        autoComplete="new-password"
        required
        hint="Pelo menos 8 caracteres."
        error={e.password}
      />
      <LegalCheckbox error={e.acceptLegal} />
      <SubmitButton className="w-full" pendingLabel="Criando conta…">Criar conta e entrar no escritório</SubmitButton>
    </form>
  );
}

export function AcceptInviteForm({ token }: { token: string }) {
  const [state, action] = useActionState<FormState, FormData>(acceptInvitation, {});
  return (
    <form action={action} className="mt-8 space-y-5">
      <FormMessage state={state} />
      <input type="hidden" name="token" value={token} />
      <SubmitButton className="w-full" pendingLabel="Entrando no escritório…">Aceitar convite</SubmitButton>
    </form>
  );
}
