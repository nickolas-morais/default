import { NextResponse, type NextRequest } from "next/server";
import { codeFromDbError, messageFor } from "@app/shared";
import { validateFile } from "@app/shared/file-validation";
import { inspectTemplate } from "@app/shared/docx-template";
import { mapVariables } from "@app/shared/template-vars";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient, DOCUMENTS_BUCKET } from "@/lib/supabase/admin";
import { MAX_TEMPLATE_BYTES, toStoredVariables } from "@/lib/templates/server";

const json = (body: unknown, status = 200) =>
  NextResponse.json(body, { status, headers: { "Cache-Control": "private, no-store" } });

const fail = (code: Parameters<typeof messageFor>[0], status = 400, details?: string[]) =>
  json({ ok: false, code, message: messageFor(code), details }, status);

/** Envio de modelo (titular e administradores). Valida antes de guardar. */
export async function POST(request: NextRequest) {
  const supabase = await createClient();
  const { data: claims } = await supabase.auth.getClaims();
  if (!claims?.claims?.sub) return fail("NOT_AUTHENTICATED", 401);

  const { data: isAdmin } = await supabase.rpc("is_office_admin");
  if (!isAdmin) return fail("FORBIDDEN", 403);

  const form = await request.formData().catch(() => null);
  const file = form?.get("file");
  const name = String(form?.get("name") ?? "").trim();
  const description = String(form?.get("description") ?? "").trim();
  if (!(file instanceof File)) return fail("TEMPLATE_NOT_DOCX");
  if (name.length < 2) return fail("VALIDATION", 400, ["Informe o nome do modelo."]);
  if (!file.name.toLowerCase().endsWith(".docx")) return fail("TEMPLATE_NOT_DOCX");
  if (file.size > MAX_TEMPLATE_BYTES) return fail("TEMPLATE_TOO_LARGE");

  const bytes = new Uint8Array(await file.arrayBuffer());
  const check = await validateFile(bytes, "docx");
  if (!check.ok) return fail(check.code === "PASSWORD_PROTECTED" ? "PASSWORD_PROTECTED" : "TEMPLATE_NOT_DOCX");

  const inspected = inspectTemplate(bytes);
  if (!inspected.ok) return fail("TEMPLATE_INVALID", 400, inspected.errors);

  const { data: created, error } = await supabase.rpc("create_template", {
    p_name: name,
    p_description: description,
    p_variables: toStoredVariables(inspected.parsed),
    p_size_bytes: bytes.byteLength,
  });
  const row = created?.[0];
  if (error || !row) return fail(codeFromDbError(error));

  const { error: uploadError } = await createAdminClient().storage.from(DOCUMENTS_BUCKET).upload(row.storage_path, bytes, {
    contentType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    upsert: false,
  });
  if (uploadError) {
    await supabase.rpc("delete_template", { p_template_id: row.template_id });
    return fail("STORAGE_UNAVAILABLE", 503);
  }

  return json({ ok: true, templateId: row.template_id, mapping: mapVariables(inspected.parsed) });
}
