import { NextResponse, type NextRequest } from "next/server";
import { buildIcs } from "@app/shared/ics";
import { createClient } from "@/lib/supabase/server";
import { env } from "@/lib/env";

const KIND_LABEL: Record<string, string> = {
  fim_vigencia: "Fim da vigência", aviso_nao_renovacao: "Aviso de não renovação", reajuste: "Reajuste",
  pagamento: "Pagamento", garantia: "Garantia", outro: "Prazo contratual",
};

/**
 * Calendário assinado (Google Agenda, Outlook, Apple). Sem login: o endereço
 * secreto é a credencial. Token inválido, revogado ou de quem saiu do
 * escritório: 404, sem revelar o motivo.
 */
export async function GET(_request: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  const token = (await params).token.replace(/\.ics$/i, "");
  if (!/^[A-Za-z0-9_-]{40,60}$/.test(token)) return new NextResponse("Not found", { status: 404 });

  const supabase = await createClient();
  const [info, events] = await Promise.all([
    supabase.rpc("calendar_feed_info", { p_token: token }),
    supabase.rpc("calendar_feed_events", { p_token: token }),
  ]);
  if (info.error || events.error) return new NextResponse("Temporarily unavailable", { status: 503 });
  const feed = info.data[0];
  if (!feed) return new NextResponse("Not found", { status: 404 });
  const data = events.data;
  const first = feed;
  const ics = buildIcs({
    name: `Prazos · ${first.office_name}`,
    refreshHours: 6,
    events: data.map((d) => ({
      uid: `${d.deadline_id}@prazos`,
      date: d.due_date,
      // Sem detalhes: só o tipo do prazo (o servidor da agenda lê o conteúdo).
      title: first.include_details
        ? `${d.title} · ${d.file_name.replace(/\.(pdf|docx)$/i, "")}`
        : KIND_LABEL[d.kind] ?? "Prazo contratual",
      description: first.include_details && d.clause_ref ? `Cláusula ${d.clause_ref}` : "Detalhes no app (acesso com login).",
      url: `${env.siteUrl}/documentos/${d.document_id}?aba=prazos`,
      recurrence: d.recurrence,
      alarmDaysBefore: [7, 1],
    })),
  });

  return new NextResponse(ics, {
    headers: {
      "Content-Type": "text/calendar; charset=utf-8",
      "Cache-Control": "private, max-age=900",
      "X-Robots-Tag": "noindex",
    },
  });
}
