/** Aceita apenas caminhos relativos do próprio app (evita open redirect). */
export function safeNextPath(value: unknown, fallback = "/documentos"): string {
  if (typeof value !== "string") return fallback;
  if (!value.startsWith("/") || value.startsWith("//") || value.startsWith("/\\")) return fallback;
  return value;
}
