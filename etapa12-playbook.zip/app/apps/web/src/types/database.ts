// Tipos do banco. Escritos à mão na etapa 1; regenere com `pnpm db:types`
// (com o Supabase local rodando) sempre que uma migration mudar o schema.
export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

type OfficeRole = "owner" | "admin" | "member";
type LegalKind = "terms" | "privacy";
type DocumentStatus = "uploading" | "queued" | "preprocessing" | "analyzing" | "ready" | "failed";
type DocumentFileType = "pdf" | "docx";
type AccessAction = "upload" | "view" | "download" | "delete" | "edit" | "export" | "reprocess";
type RiskLevel = "alto" | "medio" | "baixo";
type JobKind = "initial" | "reprocess";
type JobStatus = "queued" | "running" | "retrying" | "succeeded" | "failed";
type ReviewStatus = "pendente" | "em_revisao" | "enviado" | "aprovado";
type RiskResolution = "aberto" | "aceito" | "negociado" | "resolvido";

export type DeadlineRow = {
  id: string; document_id: string; file_name: string; title: string; kind: string; due_date: string | null;
  recurrence: "none" | "yearly" | "monthly"; source: "ai" | "manual"; clause_ref: string; excerpt: string;
  base: "fixed" | "data_inicio" | "data_fim"; offset_days: number; days_left: number | null;
};

export type Database = {
  __InternalSupabase: { PostgrestVersion: "13" };
  public: {
    Tables: {
      offices: {
        Row: {
          id: string; name: string; cnpj: string | null; daily_failure_limit: number; stripe_customer_id: string | null;
          address: string | null; phone: string | null; contact_email: string | null; oab_registration: string | null;
          deletion_scheduled_for: string | null; deletion_requested_by: string | null;
          trial_ends_at: string | null; trial_doc_limit: number | null; suspended_at: string | null;
          suspended_reason: string | null; created_by_platform: boolean;
          created_at: string; updated_at: string;
        };
        Insert: never;
        Update: {
          name?: string; cnpj?: string | null; address?: string | null; phone?: string | null;
          contact_email?: string | null; oab_registration?: string | null;
        };
        Relationships: [];
      };
      profiles: {
        Row: {
          id: string; full_name: string; email: string; phone: string | null; oab_number: string | null;
          notify_analysis_done: boolean; notify_quota: boolean; notify_deadlines: boolean; created_at: string; updated_at: string;
        };
        Insert: never;
        Update: {
          full_name?: string; phone?: string | null; oab_number?: string | null;
          notify_analysis_done?: boolean; notify_quota?: boolean; notify_deadlines?: boolean;
        };
        Relationships: [];
      };
      office_members: {
        Row: { office_id: string; user_id: string; role: OfficeRole; created_at: string };
        Insert: never;
        Update: never;
        Relationships: [
          { foreignKeyName: "office_members_office_id_fkey"; columns: ["office_id"]; isOneToOne: false; referencedRelation: "offices"; referencedColumns: ["id"] },
          { foreignKeyName: "office_members_user_id_fkey"; columns: ["user_id"]; isOneToOne: true; referencedRelation: "profiles"; referencedColumns: ["id"] },
        ];
      };
      office_invitations: {
        Row: {
          id: string; office_id: string; email: string; role: OfficeRole; invited_by: string | null;
          created_at: string; expires_at: string; accepted_at: string | null; accepted_by: string | null;
          revoked_at: string | null;
        };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      documents: {
        Row: {
          id: string; office_id: string; uploaded_by: string | null; file_name: string;
          file_type: DocumentFileType; size_bytes: number; page_count: number | null;
          original_path: string; status: DocumentStatus; error_code: string | null;
          created_at: string; updated_at: string; queued_at: string | null; failed_at: string | null;
          viewer_path: string | null; is_scanned: boolean | null; file_deleted_at: string | null;
          processing_started_at: string | null; processed_at: string | null; usage_counted_at: string | null;
          prompt_version: string | null; client_party_name: string | null; client_party_role: string | null;
          client_id: string | null; assignee_id: string | null; review_status: ReviewStatus;
          review_updated_at: string | null; review_updated_by: string | null;
          parent_document_id: string | null; version_number: number; billing: "normal" | "free_version";
        };
        Insert: never;
        Update: never;
        Relationships: [
          { foreignKeyName: "documents_uploaded_by_fkey"; columns: ["uploaded_by"]; isOneToOne: false; referencedRelation: "profiles"; referencedColumns: ["id"] },
        ];
      };
      extractions: {
        Row: {
          document_id: string; office_id: string; ai_data: Json; edited_data: Json | null;
          edited_by: string | null; edited_at: string | null; created_at: string;
        };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      document_parties: {
        Row: { id: number; document_id: string; office_id: string; name: string; document_number: string | null; role: string | null };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      risks: {
        Row: {
          id: string; document_id: string; office_id: string; position: number; level: RiskLevel; title: string;
          clause_ref: string; excerpt: string; explanation: string; suggestion: string; affected_party: string;
          page_number: number | null; match_score: number | null;
          resolution: RiskResolution; resolution_note: string; resolved_by: string | null; resolved_at: string | null;
          playbook_rule_id: string | null;
        };
        Insert: never;
        Update: never;
        Relationships: [
          { foreignKeyName: "risks_playbook_rule_id_fkey"; columns: ["playbook_rule_id"]; isOneToOne: false; referencedRelation: "office_playbook_rules"; referencedColumns: ["id"] },
        ];
      };
      summaries: {
        Row: {
          document_id: string; office_id: string; ai_content: string; edited_content: string | null;
          edited_by: string | null; edited_at: string | null; created_at: string;
        };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      processing_jobs: {
        Row: {
          id: string; document_id: string; office_id: string; kind: JobKind; status: JobStatus; attempts: number;
          error_code: string | null; created_at: string; finished_at: string | null;
        };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      usage_counters: {
        Row: { office_id: string; period_start: string; documents_processed: number };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      templates: {
        Row: {
          id: string; office_id: string; name: string; description: string; storage_path: string;
          variables: string[]; size_bytes: number; created_by: string | null; created_at: string;
        };
        Insert: never;
        Update: never;
        Relationships: [
          { foreignKeyName: "templates_created_by_fkey"; columns: ["created_by"]; isOneToOne: false; referencedRelation: "profiles"; referencedColumns: ["id"] },
        ];
      };
      draft_exports: {
        Row: { id: number; office_id: string; document_id: string; template_id: string | null; created_by: string | null; created_at: string };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      plans: {
        Row: {
          id: string; name: string; monthly_doc_limit: number; stripe_lookup_key: string; description: string;
          sort_order: number; active: boolean; playbook: boolean;
        };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      subscriptions: {
        Row: {
          office_id: string; plan_id: string | null; stripe_subscription_id: string; stripe_price_id: string | null;
          status: string; current_period_start: string | null; current_period_end: string | null;
          cancel_at_period_end: boolean; updated_at: string;
        };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      manual_contracts: {
        Row: { id: string; office_id: string; plan_id: string | null; doc_limit: number; starts_at: string; ends_at: string; cancelled_at: string | null };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      risk_feedback: {
        Row: { risk_id: string; user_id: string; document_id: string; office_id: string; verdict: "util" | "nao_procede"; comment: string; created_at: string };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      document_feedback: {
        Row: { document_id: string; user_id: string; office_id: string; missing_risks: string; created_at: string };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      calendar_feeds: {
        Row: { user_id: string; office_id: string; include_details: boolean; created_at: string; last_accessed_at: string | null };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      clients: {
        Row: {
          id: string; office_id: string; name: string; document_number: string | null; email: string | null;
          notes: string; archived_at: string | null; created_by: string | null; created_at: string;
        };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      document_comparisons: {
        Row: {
          document_id: string; previous_document_id: string | null; office_id: string; text_changes: Json;
          risk_changes: Json; stats: Json; created_at: string;
        };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      office_playbook_rules: {
        Row: {
          id: string; office_id: string; title: string; instruction: string; min_level: RiskLevel | null;
          contract_types: string; active: boolean; position: number; created_by: string | null; created_at: string; updated_at: string;
        };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      document_failures: {
        Row: { id: number; office_id: string; document_id: string; error_code: string; created_at: string };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      document_access_logs: {
        Row: {
          id: number; office_id: string; document_id: string; user_id: string | null; action: AccessAction;
          file_name: string | null; ip: string | null; user_agent: string | null; created_at: string;
        };
        Insert: never;
        Update: never;
        Relationships: [
          { foreignKeyName: "document_access_logs_user_id_fkey"; columns: ["user_id"]; isOneToOne: false; referencedRelation: "profiles"; referencedColumns: ["id"] },
        ];
      };
      legal_documents: {
        Row: { kind: LegalKind; version: string; published_at: string };
        Insert: never;
        Update: never;
        Relationships: [];
      };
      legal_acceptances: {
        Row: { id: number; user_id: string; kind: LegalKind; version: string; accepted_at: string; ip: string | null; user_agent: string | null };
        Insert: never;
        Update: never;
        Relationships: [];
      };
    };
    Views: { [_ in never]: never };
    Functions: {
      current_office_id: { Args: never; Returns: string | null };
      is_office_admin: { Args: never; Returns: boolean };
      current_membership: {
        Args: never;
        Returns: { office_id: string; office_name: string; role: OfficeRole }[];
      };
      has_accepted_current_legal: { Args: never; Returns: boolean };
      accept_current_legal: {
        Args: { p_terms_version: string; p_privacy_version: string; p_ip?: string | null; p_user_agent?: string | null };
        Returns: undefined;
      };
      create_office_invitation: { Args: { p_email: string; p_role?: OfficeRole }; Returns: string };
      revoke_office_invitation: { Args: { p_invitation_id: string }; Returns: undefined };
      accept_office_invitation: { Args: { p_token: string }; Returns: string };
      get_invitation_preview: {
        Args: { p_token: string };
        Returns: { office_name: string; email: string; role: OfficeRole; status: "valid" | "expired" | "used" | "revoked" }[];
      };
      remove_office_member: { Args: { p_user_id: string }; Returns: undefined };
      create_document_upload: {
        Args: { p_file_name: string; p_size_bytes: number; p_ip?: string | null; p_user_agent?: string | null };
        Returns: { document_id: string; storage_path: string }[];
      };
      cancel_document_upload: { Args: { p_document_id: string }; Returns: undefined };
      log_document_access: {
        Args: { p_document_id: string; p_action: AccessAction; p_ip?: string | null; p_user_agent?: string | null };
        Returns: undefined;
      };
      can_delete_document: { Args: { p_document_id: string }; Returns: boolean };
      delete_document: {
        Args: { p_document_id: string; p_ip?: string | null; p_user_agent?: string | null };
        Returns: undefined;
      };
      mark_document_queued: {
        Args: { p_document_id: string; p_size_bytes: number; p_page_count: number | null };
        Returns: undefined;
      };
      fail_document: {
        Args: { p_document_id: string; p_error_code: string; p_file_deleted?: boolean };
        Returns: undefined;
      };
      create_template: {
        Args: { p_name: string; p_description: string; p_variables: string[]; p_size_bytes: number };
        Returns: { template_id: string; storage_path: string }[];
      };
      delete_template: { Args: { p_template_id: string }; Returns: string };
      record_draft_export: {
        Args: { p_document_id: string; p_template_id: string; p_ip?: string | null; p_user_agent?: string | null };
        Returns: undefined;
      };
      current_entitlement: {
        Args: never;
        Returns: {
          plan_id: string | null; plan_name: string | null; doc_limit: number; period_start: string | null;
          period_end: string | null; source: "contract" | "subscription" | "trial" | "none"; subscription_status: string | null;
          cancel_at_period_end: boolean; used: number; reserved: number; valid_until: string | null; suspended: boolean;
        }[];
      };
      platform_admin_status: { Args: never; Returns: "none" | "needs_mfa" | "ok" };
      admin_list_offices: {
        Args: { p_query?: string | null };
        Returns: {
          office_id: string; name: string; created_at: string; owner_name: string | null; owner_email: string | null;
          members: number; source: string; plan_name: string | null; doc_limit: number; used: number;
          valid_until: string | null; subscription_status: string | null; ai_cost_30d: number; documents_total: number;
          last_activity: string | null; suspended: boolean; deletion_scheduled_for: string | null; created_by_platform: boolean;
        }[];
      };
      admin_office_detail: { Args: { p_office_id: string }; Returns: Json };
      admin_audit_log: {
        Args: { p_limit?: number };
        Returns: { action: string; office_id: string | null; office_name: string | null; admin_email: string | null; details: Json; created_at: string }[];
      };
      admin_create_office: {
        Args: { p_name: string; p_owner_email: string; p_trial_days?: number; p_trial_docs?: number };
        Returns: { office_id: string; invite_token: string }[];
      };
      admin_resend_owner_invite: { Args: { p_office_id: string; p_email: string }; Returns: string };
      admin_set_trial: { Args: { p_office_id: string; p_ends_at: string | null; p_doc_limit: number | null }; Returns: undefined };
      admin_create_contract: {
        Args: {
          p_office_id: string; p_plan_id: string | null; p_doc_limit: number | null; p_starts_at: string; p_ends_at: string;
          p_billing_method: "boleto" | "nota_fiscal" | "transferencia" | "outro"; p_notes?: string;
        };
        Returns: string;
      };
      admin_cancel_contract: { Args: { p_contract_id: string }; Returns: undefined };
      admin_set_suspension: { Args: { p_office_id: string; p_suspended: boolean; p_reason?: string | null }; Returns: undefined };
      admin_set_failure_limit: { Args: { p_office_id: string; p_limit: number }; Returns: undefined };
      stripe_record_event: { Args: { p_event_id: string; p_type: string }; Returns: boolean };
      stripe_set_customer: { Args: { p_office_id: string; p_customer_id: string }; Returns: undefined };
      stripe_upsert_subscription: {
        Args: {
          p_customer_id: string; p_subscription_id: string; p_price_lookup_key: string; p_price_id: string;
          p_status: string; p_period_start: string | null; p_period_end: string | null; p_cancel_at_period_end: boolean;
        };
        Returns: boolean;
      };
      set_member_role: { Args: { p_user_id: string; p_role: OfficeRole }; Returns: undefined };
      transfer_ownership: { Args: { p_user_id: string }; Returns: undefined };
      check_account_deletion: { Args: never; Returns: undefined };
      request_office_deletion: { Args: never; Returns: string };
      cancel_office_deletion: { Args: never; Returns: undefined };
      set_risk_feedback: { Args: { p_risk_id: string; p_verdict: "util" | "nao_procede" | null; p_comment?: string }; Returns: undefined };
      set_document_feedback: { Args: { p_document_id: string; p_missing_risks: string }; Returns: undefined };
      admin_quality_stats: {
        Args: never;
        Returns: {
          prompt_version: string | null; documents: number; risks: number; rated: number; useful: number;
          not_applicable: number; documents_with_missing: number; located_pct: number | null;
        }[];
      };
      notify_claim: { Args: { p_key: string; p_kind: string }; Returns: boolean };
      notify_release: { Args: { p_key: string }; Returns: undefined };
      notify_office_admins: {
        Args: { p_office_id: string; p_only_quota_optin?: boolean };
        Returns: { email: string; full_name: string; office_name: string }[];
      };
      request_document_perspective: {
        Args: { p_document_id: string; p_name: string | null; p_role?: string | null; p_ip?: string | null; p_user_agent?: string | null };
        Returns: undefined;
      };
      list_deadlines: {
        Args: { p_from?: string | null; p_to?: string | null; p_document_id?: string | null };
        Returns: DeadlineRow[];
      };
      save_deadline: {
        Args: { p_id: string | null; p_document_id: string; p_title: string; p_due_date: string; p_recurrence?: string };
        Returns: string;
      };
      complete_deadline: { Args: { p_id: string; p_done?: boolean }; Returns: undefined };
      delete_deadline: { Args: { p_id: string }; Returns: undefined };
      create_calendar_feed: { Args: { p_include_details?: boolean }; Returns: string };
      revoke_calendar_feed: { Args: never; Returns: undefined };
      calendar_feed_info: { Args: { p_token: string }; Returns: { office_name: string; include_details: boolean }[] };
      calendar_feed_events: {
        Args: { p_token: string };
        Returns: {
          office_name: string; include_details: boolean; deadline_id: string; document_id: string; file_name: string;
          title: string; kind: string; due_date: string; recurrence: "none" | "yearly" | "monthly"; clause_ref: string;
        }[];
      };
      search_documents: {
        Args: {
          p_query?: string | null; p_from?: string | null; p_to?: string | null; p_limit?: number; p_offset?: number;
          p_client_id?: string | null; p_assignee_id?: string | null; p_review_status?: ReviewStatus | null; p_no_client?: boolean;
        };
        Returns: {
          id: string; file_name: string; file_type: DocumentFileType; size_bytes: number; page_count: number | null;
          status: DocumentStatus; created_at: string; uploader_name: string | null; parties: string | null;
          total_count: number; client_id: string | null; client_name: string | null; assignee_id: string | null;
          assignee_name: string | null; review_status: ReviewStatus; open_high_risks: number;
        }[];
      };
      list_clients: {
        Args: { p_query?: string | null; p_include_archived?: boolean };
        Returns: {
          id: string; name: string; document_number: string | null; email: string | null; notes: string;
          archived_at: string | null; created_at: string; documents: number; pending: number; in_review: number;
          sent: number; approved: number; open_high_risks: number; last_document_at: string | null;
        }[];
      };
      team_overview: {
        Args: never;
        Returns: {
          assignee_id: string | null; assignee_name: string | null; pending: number; in_review: number; sent: number;
          approved: number; processing: number; open_high_risks: number; overdue_deadlines: number; deadlines_7d: number;
        }[];
      };
      set_document_parent: { Args: { p_document_id: string; p_parent_id: string }; Returns: number };
      document_versions: {
        Args: { p_document_id: string };
        Returns: {
          id: string; version_number: number; file_name: string; status: DocumentStatus; created_at: string;
          review_status: ReviewStatus; has_comparison: boolean;
        }[];
      };
      create_version_upload: {
        Args: { p_parent_id: string; p_file_name: string; p_size_bytes: number; p_ip?: string | null; p_user_agent?: string | null };
        Returns: { document_id: string; storage_path: string; version_number: number; free: boolean }[];
      };
      current_features: { Args: never; Returns: { playbook: boolean } };
      save_playbook_rule: {
        Args: { p_id: string | null; p_title: string; p_instruction: string; p_min_level?: RiskLevel | null; p_contract_types?: string; p_active?: boolean };
        Returns: string;
      };
      delete_playbook_rule: { Args: { p_id: string }; Returns: undefined };
      save_client: {
        Args: { p_id: string | null; p_name: string; p_document_number?: string | null; p_email?: string | null; p_notes?: string };
        Returns: string;
      };
      archive_client: { Args: { p_id: string; p_archived?: boolean }; Returns: undefined };
      set_document_organization: {
        Args: {
          p_document_id: string; p_client_id?: string | null; p_assignee_id?: string | null; p_review_status?: ReviewStatus | null;
          p_clear_client?: boolean; p_clear_assignee?: boolean; p_ip?: string | null; p_user_agent?: string | null;
        };
        Returns: undefined;
      };
      set_risk_resolution: { Args: { p_risk_id: string; p_resolution: RiskResolution; p_note?: string }; Returns: undefined };
      request_document_reprocess: {
        Args: { p_document_id: string; p_ip?: string | null; p_user_agent?: string | null };
        Returns: undefined;
      };
      save_extraction: {
        Args: { p_document_id: string; p_data: Json | null; p_ip?: string | null; p_user_agent?: string | null };
        Returns: undefined;
      };
      save_summary: {
        Args: { p_document_id: string; p_content: string | null; p_ip?: string | null; p_user_agent?: string | null };
        Returns: undefined;
      };
    };
    Enums: {
      office_role: OfficeRole;
      legal_document_kind: LegalKind;
      document_status: DocumentStatus;
      document_file_type: DocumentFileType;
      document_access_action: AccessAction;
      risk_level: RiskLevel;
      job_kind: JobKind;
      job_status: JobStatus;
      review_status: ReviewStatus;
      risk_resolution: RiskResolution;
    };
    CompositeTypes: { [_ in never]: never };
  };
};

export type OfficeRoleEnum = OfficeRole;
export type DocumentStatusEnum = DocumentStatus;
export type AccessActionEnum = AccessAction;
export type RiskLevelEnum = RiskLevel;
export type ReviewStatusEnum = ReviewStatus;
export type RiskResolutionEnum = RiskResolution;
