"use server";

import { redirect } from "next/navigation";
import { codeFromDbError, messageFor } from "@app/shared";
import { createClient } from "@/lib/supabase/server";
import { env } from "@/lib/env";
import { getRequestMeta } from "@/lib/request-meta";
import { safeNextPath } from "@/lib/safe-redirect";
import { codeFromAuthError, formError, type FormState } from "@/lib/errors";
import {
  fieldErrorsOf,
  formToObject,
  inviteSignUpSchema,
  recoverSchema,
  resetPasswordSchema,
  signInSchema,
  signUpSchema,
} from "@/lib/validation";
import { LEGAL_VERSIONS } from "@/content/legal/versions";

export async function signIn(_prev: FormState, formData: FormData): Promise<FormState> {
  const raw = formToObject(formData);
  const values = { email: raw.email ?? "" };
  const parsed = signInSchema.safeParse(raw);
  if (!parsed.success) return formError("VALIDATION", { fieldErrors: fieldErrorsOf(parsed.error), values });

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword(parsed.data);
  if (error) return formError(codeFromAuthError(error), { values });

  redirect(safeNextPath(raw.next));
}

async function signupMetadata() {
  const { ip, userAgent } = await getRequestMeta();
  return {
    terms_version: LEGAL_VERSIONS.terms,
    privacy_version: LEGAL_VERSIONS.privacy,
    signup_ip: ip,
    signup_user_agent: userAgent,
  };
}

export async function signUp(_prev: FormState, formData: FormData): Promise<FormState> {
  const raw = formToObject(formData);
  const values = { fullName: raw.fullName ?? "", officeName: raw.officeName ?? "", email: raw.email ?? "" };
  const parsed = signUpSchema.safeParse(raw);
  if (!parsed.success) return formError("VALIDATION", { fieldErrors: fieldErrorsOf(parsed.error), values });

  const { fullName, officeName, email, password } = parsed.data;
  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: `${env.siteUrl}/auth/confirm`,
      data: { full_name: fullName, office_name: officeName, ...(await signupMetadata()) },
    },
  });
  if (error) return formError(codeFromAuthError(error), { values });

  // Com confirmação de e-mail desligada (dev), a sessão já vem pronta.
  if (data.session) redirect("/documentos");
  // E-mail já cadastrado também cai aqui (o Supabase não revela), de propósito.
  redirect("/confirme-seu-email");
}

export async function signUpWithInvite(_prev: FormState, formData: FormData): Promise<FormState> {
  const raw = formToObject(formData);
  const token = raw.token ?? "";
  const values = { fullName: raw.fullName ?? "" };
  const parsed = inviteSignUpSchema.safeParse(raw);
  if (!parsed.success) return formError("VALIDATION", { fieldErrors: fieldErrorsOf(parsed.error), values });

  const supabase = await createClient();

  // Validação prévia: erros do trigger chegam genéricos pelo Auth.
  const { data: preview, error: previewError } = await supabase.rpc("get_invitation_preview", { p_token: token });
  if (previewError) return formError("UNEXPECTED", { values });
  const invite = preview?.[0];
  if (!invite) return formError("INVITE_INVALID", { values });
  if (invite.status !== "valid") {
    return formError(
      invite.status === "expired" ? "INVITE_EXPIRED" : invite.status === "used" ? "INVITE_USED" : "INVITE_REVOKED",
      { values },
    );
  }

  const { data, error } = await supabase.auth.signUp({
    email: invite.email,
    password: parsed.data.password,
    options: {
      emailRedirectTo: `${env.siteUrl}/auth/confirm`,
      data: { full_name: parsed.data.fullName, invite_token: token, ...(await signupMetadata()) },
    },
  });
  if (error) return formError(codeFromAuthError(error), { values });

  if (data.session) redirect("/documentos");
  redirect("/confirme-seu-email?convite=1");
}

export async function acceptInvitation(_prev: FormState, formData: FormData): Promise<FormState> {
  const token = String(formData.get("token") ?? "");
  const supabase = await createClient();
  const { error } = await supabase.rpc("accept_office_invitation", { p_token: token });
  if (error) return formError(codeFromDbError(error));
  redirect("/documentos");
}

export async function requestPasswordReset(_prev: FormState, formData: FormData): Promise<FormState> {
  const raw = formToObject(formData);
  const parsed = recoverSchema.safeParse(raw);
  if (!parsed.success) {
    return formError("VALIDATION", { fieldErrors: fieldErrorsOf(parsed.error), values: { email: raw.email ?? "" } });
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.resetPasswordForEmail(parsed.data.email, {
    redirectTo: `${env.siteUrl}/auth/confirm?next=/redefinir-senha`,
  });

  // Não revela se o e-mail existe; só avisa sobre limite de envios.
  if (error && codeFromAuthError(error) === "RATE_LIMITED") return formError("RATE_LIMITED");
  return {
    ok: true,
    message: "Se houver uma conta com este e-mail, você receberá um link para redefinir a senha em alguns minutos.",
  };
}

export async function resetPassword(_prev: FormState, formData: FormData): Promise<FormState> {
  const parsed = resetPasswordSchema.safeParse(formToObject(formData));
  if (!parsed.success) return formError("VALIDATION", { fieldErrors: fieldErrorsOf(parsed.error) });

  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({ password: parsed.data.password });
  if (error) {
    if (error.code === "same_password") {
      return { ok: false, message: "A nova senha precisa ser diferente da atual." };
    }
    return formError(error.code === "session_not_found" ? "LINK_INVALID" : codeFromAuthError(error));
  }
  redirect("/documentos");
}

export async function signOut(): Promise<void> {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/entrar");
}

