# App: análise de contratos para escritórios de advocacia

Monorepo (pnpm workspaces):

```
apps/web          Next.js 16 (App Router), interface e server actions
packages/shared   códigos de erro e validação de CPF/CNPJ (usado também pelo worker)
supabase/         migrations, testes de RLS (pgTAP), templates de e-mail e config local
```

apps/worker       worker de processamento (OCR, conversão, IA), roda em Docker

## Requisitos

- Node.js 20.9 ou superior e pnpm 10 (`corepack enable`)
- Docker, para o Supabase local

## Rodando localmente

```bash
pnpm install
pnpm db:start                          # sobe Postgres, Auth e Mailpit e aplica as migrations
cp apps/web/.env.example apps/web/.env.local
# cole em .env.local a URL da API e a Publishable key exibidas pelo db:start
pnpm dev                               # http://localhost:3000
```

Os e-mails locais (confirmação, recuperação de senha) chegam no Mailpit, em
http://localhost:54324.

## Variáveis de ambiente (etapa 1)

| Variável | Onde obter | Exemplo local |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | saída do `pnpm db:start`; em produção, Project Settings → API | `http://127.0.0.1:54321` |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | mesma origem (`sb_publishable_...`; a anon key legada também funciona) | — |
| `NEXT_PUBLIC_SITE_URL` | URL pública do app, usada nos links de convite | `http://localhost:3000` |
| `SUPABASE_SECRET_KEY` (etapa 2) | *Secret key* no `db:start`/`supabase status` (`sb_secret_...`) ou a service_role legada; em produção, Project Settings → API Keys | — |

A `SUPABASE_SECRET_KEY` é **somente servidor**: nunca a prefixe com `NEXT_PUBLIC_`
nem a exponha no navegador. Ela só é usada em `apps/web/src/lib/supabase/admin.ts`.

## Testes automatizados

```bash
pnpm db:test                              # 70 testes pgTAP: isolamento, cadastro, convites, documentos e storage
pnpm --filter @app/shared test            # CPF/CNPJ e validação de arquivos (PDF/DOCX, senha, páginas, corrompido)
pnpm typecheck
```

## Roteiro de teste manual (etapa 1)

1. **Cadastro.** Em `/cadastro`, tente enviar sem marcar o aceite: deve aparecer erro no campo. Marque, crie a conta, abra o e-mail no Mailpit e confirme. Você cai em `/documentos`, com o nome do escritório no topo da barra lateral.
2. **Aceite registrado.** No Studio (http://localhost:54323), tabela `legal_acceptances`: duas linhas (termos e privacidade) com versão, data/hora, IP e navegador.
3. **Convite.** Em Configurações → Membros, gere um convite para outro e-mail e copie o link. Numa janela anônima, abra o link: aparecem o nome do escritório e o e-mail fixo. Crie a conta, confirme pelo Mailpit e verifique que o novo usuário vê o mesmo escritório, como Membro.
4. **Permissões.** Logado como Membro, a seção de convites não aparece e não há botão de remover. O banco também recusa essas ações (coberto pelos testes pgTAP).
5. **Isolamento.** Crie um segundo escritório com outro e-mail. Nenhum dado do primeiro aparece. Para uma prova direta, rode `pnpm db:test`.
6. **Remoção.** Como titular, remova o membro. Na sessão dele, o próximo carregamento leva a `/sem-acesso`. Gere um novo convite e abra o link logado com essa conta: o botão "Aceitar convite" devolve o acesso.
7. **Convite inválido.** Cancele um convite e abra o link: a mensagem é "Este convite foi cancelado…". Um token inventado mostra "Convite não encontrado…".
8. **Nova versão dos termos.** Crie uma migration com
   `insert into legal_documents values ('terms','2026-10-teste', now()), ('privacy','2026-10-teste', now());`,
   atualize `apps/web/src/content/legal/versions.ts` e recarregue: todos são levados a `/aceitar-termos`.
9. **Recuperação de senha.** Em `/recuperar-senha`, peça o link. A mensagem é a mesma para e-mails existentes e inexistentes. Abra o link no Mailpit e defina a nova senha.

## Roteiro de teste manual (etapa 2)

Tenha à mão: um PDF comum, um PDF com mais de 50 páginas, um PDF protegido por
senha, um DOCX e um arquivo qualquer renomeado para `.pdf`.

1. **Envio.** Em Documentos, arraste o PDF comum. A linha passa por "Enviando" (com porcentagem), "Conferindo o arquivo" e "Enviado, na fila para análise". O documento aparece na lista como **Na fila**, com o número de páginas.
2. **Vários arquivos.** Arraste três arquivos de uma vez. Eles são enviados um por vez, cada um com o próprio resultado.
3. **Erros claros.** Envie cada arquivo problemático e confira a mensagem:
   - mais de 50 páginas → "O documento tem mais de 50 páginas…";
   - com senha → "O arquivo está protegido por senha…";
   - renomeado → "Não foi possível abrir o arquivo…" ou "O conteúdo do arquivo não corresponde à extensão…";
   - `.doc`, `.xlsx`, imagem → "Formato não aceito…" (antes de qualquer envio);
   - acima de 25 MB → "O arquivo passa de 25 MB…" (antes de qualquer envio).
   Os que chegam ao servidor e falham aparecem na lista como **Com erro**, e o arquivo é descartado do Storage.
4. **Visualização e download.** Abra o documento: o PDF aparece na página. "Baixar original" baixa com o nome original. No DevTools (aba Rede), o arquivo vem de uma URL do Storage com `token=`; copie essa URL e abra depois de 5 minutos: o acesso é negado.
5. **Acesso direto negado.** Sem login, abra `/api/documentos/<id>/arquivo`: resposta 401. Logado em outro escritório: 404.
6. **Registro de acesso.** Como titular, a página do documento lista quem enviou, visualizou e baixou, com data, hora e IP. Como membro, a seção não aparece.
7. **Exclusão definitiva.** Exclua o documento e confira no Studio: a linha sumiu de `documents`, a pasta sumiu do bucket `documents` e o evento "delete" continua em `document_access_logs`.
8. **Limite de falhas.** No Studio, defina `daily_failure_limit = 2` no seu escritório (tabela `offices`) e envie dois arquivos inválidos. O terceiro envio é bloqueado com "O escritório atingiu o limite de envios com erro…", mesmo que você exclua os documentos com erro. Volte o valor para 20.
9. **Busca.** Filtre por parte do nome do arquivo e por período. A busca por partes do contrato entra na etapa 3.

## Etapa 3, parte 1: worker e processamento

### 1. Aplicar a migration

```bash
pnpm supabase db push      # aplica 20260929000100_processing.sql
```

Ela usa a extensão **pgmq** (fila). Se o push falhar com erro sobre `pgmq`, ative
a extensão no painel (Database → Extensions → pgmq, ou Integrations → Queues) e
rode o push de novo.

### 2. Configurar e subir o worker (Docker)

```bash
cp apps/worker/.env.example apps/worker/.env   # preencha as chaves
pnpm worker:build                              # primeira vez leva alguns minutos
pnpm worker:start
```

| Variável | Onde obter |
|---|---|
| `SUPABASE_URL` | Supabase na nuvem: `https://<ref>.supabase.co`. Supabase local: `http://host.docker.internal:54321` |
| `SUPABASE_SECRET_KEY` | a mesma secret key usada no app web |
| `ANTHROPIC_API_KEY` | https://platform.claude.com → API Keys |
| `ANTHROPIC_MODEL` | padrão `claude-sonnet-5-5` |
| `ANTHROPIC_EFFORT` | `low`, `medium` (padrão) ou `high`: mais esforço, mais custo e tempo |
| `WORKER_CONCURRENCY` | documentos em paralelo (padrão 2) |

O worker registra logs em JSON (sem conteúdo dos documentos). Documentos que já
estavam "Na fila" desde a etapa 2 são processados assim que ele sobe.

### 3. Roteiro de teste

Use o pacote `documentos-de-teste.zip`:

1. Envie `contrato-locacao.pdf`. A página do documento mostra o progresso (Na fila → Preparando → Analisando) e se atualiza sozinha. Em 1 a 3 minutos aparecem riscos, dados extraídos e resumo.
2. Envie `contrato-escaneado.pdf` (só imagem): passa por OCR e chega ao mesmo resultado.
3. Envie `contrato-locacao.docx`: é convertido para PDF, que passa a aparecer na visualização.
4. Envie `contrato-restrito-sem-senha.pdf`: agora é aceito (a proteção é removida). `contrato-com-senha.pdf` continua recusado, pelo worker.
5. Na lista, busque por "Aurora" (parte), por `11.222.333/0001-81` (CNPJ) e pelo nome do arquivo.
6. Em **Uso**, o contador do mês mostra os documentos concluídos. Clique em "Reprocessar" num documento pronto: o contador não aumenta.
7. Pare o worker (Ctrl+C) no meio de uma análise e suba de novo: o documento volta a ser processado (a mensagem reaparece na fila após 15 minutos).
8. Custo: no SQL Editor do Supabase, rode `supabase/queries/custos.sql` para ver custo, tokens e tempo por documento.

### 4. Testes automatizados

```bash
pnpm test        # shared (20) e worker (22; os de OCR/LibreOffice rodam dentro da imagem Docker)
pnpm db:test     # 120 testes pgTAP (precisa do Supabase local)
docker run --rm app-worker node --experimental-strip-types --test apps/worker/src/pipeline/prepare.test.ts
```

### 5. Tela de análise (parte 2)

Abra um documento **Pronto**:

1. **Duas colunas**: o PDF à esquerda (DOCX aparece já convertido; digitalizado aparece com a camada de OCR) e a análise à direita, com as abas Riscos, Dados extraídos e Resumo. Em telas estreitas, as colunas ficam empilhadas.
2. **Destaque**: clique num risco. O documento rola até a página e o trecho fica marcado na cor do nível (vermelho alto, âmbar médio, cinza baixo). Clique de novo para fechar. Risco com "trecho não localizado no PDF" abre a explicação, sem destaque.
3. **Filtro e cópia**: filtre por nível e use "Copiar" para levar a sugestão de redação.
4. **Dados extraídos**: edite partes, valores, datas e multas e clique em "Salvar dados". CPF/CNPJ com dígitos inválidos mostram aviso (sem bloquear). Busque na lista pelo nome que você corrigiu: a busca usa os dados editados. "Restaurar dados da IA" desfaz as edições.
5. **Resumo**: edite, salve e use "Copiar resumo" para colar no e-mail ao cliente.
6. **Registro de acesso**: cada salvamento aparece como "Editou" no log (titular e administradores).
7. **Reprocessar** avisa que as edições serão descartadas.

## Etapa 4: modelos de minuta

### Atualizar

```bash
pnpm install
pnpm supabase db push      # aplica 20261001000100_templates.sql
pnpm dev
```

Não há variável de ambiente nova. O worker não muda nesta etapa.

### Roteiro de teste

Use `exemplos/modelo-notificacao-rescisao.docx` (notificação de rescisão de locação, com variáveis automáticas, manuais e uma lista de partes).

1. **Ajuda**: em Modelos → "Variáveis disponíveis", confira a lista de variáveis padrão, sinônimos aceitos e como montar listas.
2. **Envio** (titular ou administrador): em Modelos, envie o exemplo. A resposta mostra as variáveis preenchidas pelo contrato, a lista de partes e 2 de preenchimento manual (`cidade`, `data_desocupacao`). Desde a etapa 6, `advogado_responsavel` e `oab` vêm de Minha conta.
3. **Modelo inválido**: no Word, apague um `}` de uma variável e envie. A mensagem aponta o trecho ("Marcação sem fechamento perto de…"). Um .doc ou PDF é recusado como "precisa ser DOCX".
4. **Gerar**: abra o `contrato-locacao.pdf` analisado → "Gerar minuta" → escolha o modelo. Preencha os campos manuais, confira os automáticos e clique em "Gerar e baixar DOCX". Campos deixados em branco saem como `__________`.
5. **Dados editados**: corrija um nome na aba "Dados extraídos" e gere de novo: a minuta usa a versão corrigida.
6. **Permissões**: como membro, a seção "Novo modelo" e o botão "Excluir modelo" não aparecem, mas "Gerar minuta" funciona.
7. **Log**: na página do documento (titular/administrador), a geração aparece como "Exportou".

## Etapa 5: planos e pagamentos (Stripe)

### Configurar (modo de teste do Stripe)

1. Crie uma conta em https://stripe.com e, com **Modo de teste** ligado, copie a chave secreta (`sk_test_...`) para `STRIPE_SECRET_KEY` em `apps/web/.env.local`.
2. Crie os produtos e preços dos planos (idempotente):
   ```bash
   STRIPE_SECRET_KEY=sk_test_... pnpm stripe:setup
   ```
   Os valores (R$ 197, R$ 497 e R$ 1.197) são provisórios: ajuste em `apps/web/scripts/stripe-setup.mjs` depois de ver o custo por documento em `supabase/queries/custos.sql`. Os limites de documentos ficam na tabela `plans`.
3. Ative o **portal do cliente** em Stripe → Settings → Billing → Customer portal, permitindo troca entre os três produtos, atualização de pagamento e cancelamento.
4. Webhook local com a [Stripe CLI](https://docs.stripe.com/stripe-cli):
   ```bash
   stripe login
   stripe listen --forward-to localhost:3000/api/stripe/webhook
   ```
   Copie o `whsec_...` exibido para `STRIPE_WEBHOOK_SECRET` e reinicie o `pnpm dev`.
5. Aplique a migration: `pnpm supabase db push` (aplica `20261003000100_billing.sql`).

| Variável | Onde obter |
|---|---|
| `STRIPE_SECRET_KEY` | Stripe → Developers → API keys (`sk_test_...` em teste, `sk_live_...` em produção) |
| `STRIPE_WEBHOOK_SECRET` | `stripe listen` (local) ou Developers → Webhooks → endpoint `https://seu-dominio/api/stripe/webhook` |

Eventos do webhook em produção: `checkout.session.completed`, `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`, `customer.subscription.paused`, `customer.subscription.resumed`, `invoice.paid`, `invoice.payment_failed`.

### Roteiro de teste

1. **Avaliação**: um escritório novo tem 5 documentos por 14 dias (Plano e Uso mostram o consumo). O sexto envio é bloqueado com "O escritório usou todos os documentos do plano…".
2. **Reserva**: envie vários arquivos de uma vez com poucos documentos restantes: os que estão em processamento já contam, e o limite não é ultrapassado.
3. **Assinar**: em Plano → "Assinar" (titular/administrador). No checkout, use o cartão de teste `4242 4242 4242 4242`, qualquer data futura e CVC. Ao voltar, em alguns segundos o plano aparece como atual, com o limite novo.
4. **Trocar/cancelar**: "Gerenciar assinatura e pagamento" abre o portal do Stripe. Troque de plano e confira o novo limite; cancele e confira "Encerra em…".
5. **Pagamento recusado**: no portal, troque o cartão por `4000 0000 0000 0341` e, na Stripe CLI, rode `stripe trigger invoice.payment_failed`. O plano mostra o aviso de pagamento em atraso, mas os envios continuam enquanto o Stripe tenta de novo.
6. **Sem plano**: com a assinatura encerrada (ou a avaliação vencida), envios novos são bloqueados; documentos, análises e minutas existentes continuam acessíveis.
7. **Reprocessar** documento já contado não consome cota.

## Etapa 6, parte 1: configurações de conta e do escritório

```bash
pnpm install
pnpm supabase db push      # aplica 20261005000100_account_settings.sql
pnpm worker:build          # o worker passa a executar exclusões agendadas
```

### Roteiro de teste

1. **Minha conta** (Configurações → Minha conta, ou clique no seu nome na barra lateral): edite nome, telefone e OAB; troque a senha informando a atual; troque o e-mail (o link chega no endereço novo; com "Secure email change" ligado no Supabase, também no atual); "Sair de todos os dispositivos".
2. **Escritório**: preencha endereço, telefone, e-mail e registro na OAB. Gere uma minuta com `{{escritorio_endereco}}`, `{{advogado}}` e `{{advogado_oab}}` (veja a página de ajuda de Modelos).
3. **Papéis** (titular, em Membros): "Tornar administrador"/"Tornar membro" e "Tornar titular". Depois da transferência, você vira administrador.
4. **Excluir conta**: como membro, exclua a própria conta com a senha; os documentos que enviou continuam no escritório. Como titular, a tela orienta a transferir a titularidade primeiro.
5. **Exportar dados** (titular, em Escritório → Zona de risco): baixa um JSON com todos os dados do escritório.
6. **Excluir escritório**: com assinatura ativa, a exclusão é recusada até cancelar no portal do Stripe. Sem assinatura, digite o nome do escritório para agendar: aparece um aviso em todas as páginas, novos envios ficam bloqueados e "Cancelar a exclusão" desfaz. Para testar a execução sem esperar 7 dias, rode no SQL Editor `update offices set deletion_scheduled_for = now() where id = '<id>';` e aguarde até 15 minutos com o worker ligado.

## Etapa 6, parte 2: painel da plataforma, venda assistida e contratos manuais

### Atualizar e criar o primeiro administrador

```bash
pnpm install
pnpm supabase db push      # aplica 20261007000100_platform_admin.sql
```

1. No Supabase, confira em **Authentication → Multi-Factor** que o TOTP (aplicativo autenticador) está habilitado (padrão).
2. Entre no app com a sua conta e, em **Minha conta → Verificação em duas etapas**, ative com o Google Authenticator, Microsoft Authenticator ou 1Password.
3. No **SQL Editor** do Supabase (é o único jeito de criar administradores, de propósito):
   ```sql
   insert into public.platform_admins (user_id)
   select id from auth.users where email = 'seu-email@exemplo.com';
   ```
4. Saia, entre de novo (senha + código) e acesse **/admin**. Para quem não é administrador, o endereço responde "página não encontrada".

### Roteiro de teste

1. **2FA obrigatória**: com uma sessão sem a 2ª etapa, /admin pede a verificação; o banco recusa qualquer consulta do painel sem ela.
2. **Lista**: filtre por "Vencendo em 15 dias", "Em avaliação", "Sem plano" e "Suspensos"; confira uso do período e custo de IA dos últimos 30 dias por escritório.
3. **Venda assistida**: em **Novo cliente**, crie um escritório com o e-mail do titular (use um e-mail seu diferente). Copie o link, abra numa janela anônima e cadastre-se: a pessoa entra como **titular** do escritório criado, com a avaliação definida.
4. **Contrato fora do Stripe**: na página do escritório, registre um contrato (plano ou limite personalizado, boleto/nota, início e fim). No app do cliente, Plano e Uso passam a mostrar "Contrato até…", com a cota renovando mensalmente; os botões de assinatura somem. Nos últimos 15 dias, aparece o aviso de vencimento.
5. **Sobreposição**: um segundo contrato no mesmo período é recusado.
6. **Suspensão**: suspenda o escritório: o cliente vê o aviso em todas as páginas e não consegue enviar documentos, mas acessa tudo o que já existe. Reative.
7. **Avaliação e limite de falhas**: estenda a avaliação ou mude o limite de documentos; ajuste o limite diário de falhas.
8. **Auditoria**: todas as ações acima aparecem em Auditoria e no fim da página do escritório.
9. **Privacidade**: nenhuma tela do painel mostra conteúdo de documentos, dados extraídos, riscos ou resumos.

## Etapa 7, parte 1: qualidade da análise e CI

```bash
pnpm install
pnpm supabase db push      # aplica 20261010000100_quality_feedback.sql
```

### Feedback dos advogados

Na aba Riscos, cada risco aberto tem **Útil** e **Não procede** (com motivo opcional), e o fim da lista tem **Faltou apontar algum risco?**. Os comentários ficam só no escritório; em **/admin → Qualidade** você vê apenas contagens por versão do prompt: % útil, % não procede, documentos com riscos faltando e % de trechos localizados no PDF.

### Avaliação com gabarito (`pnpm eval`)

Conjunto de contratos com a resposta esperada em `evals/casos/`. O primeiro caso é o contrato de locação do pacote de testes, com os 12 riscos conhecidos. Com a `ANTHROPIC_API_KEY` em `apps/worker/.env`:

```bash
pnpm eval
```

O terminal mostra % de extração correta, % de riscos encontrados, % com nível adequado, % de trechos localizados, custo e tempo, com a diferença em relação à execução anterior, e lista os riscos não encontrados. Rode sempre antes de mudar prompt, modelo ou esforço. Para adicionar casos (sempre anonimizados), veja `evals/README.md`.

### CI (GitHub Actions)

`.github/workflows/ci.yml` roda a cada push e pull request, em três jobs: tipos + testes unitários + build do app; migrations e os testes pgTAP num Supabase local; e a imagem do worker com os testes de OCR, LibreOffice e qpdf. Para ativar, basta subir o repositório para o GitHub. Proteja a branch `main` exigindo os três jobs verdes antes do merge.

## Etapa 7, parte 2: avisos por e-mail e monitoramento

```bash
pnpm install
pnpm supabase db push      # aplica 20261012000100_notifications.sql
pnpm worker:build
```

### Avisos

| Aviso | Quem recebe | Quando | Pode desligar? |
|---|---|---|---|
| Análise concluída | quem enviou o documento | ao terminar cada análise | sim (Minha conta) |
| Cota em 80% e esgotada | titular e administradores | uma vez por período, em cada nível | sim (Minha conta) |
| Pagamento não aprovado | titular e administradores | uma vez por fatura (webhook do Stripe) | não |
| Contrato vencendo | titular e administradores | 15 e 3 dias antes do fim do contrato manual | não |
| Fila acumulada | administradores da plataforma | documento parado há mais de 15 min; no máximo 1 por hora | não |

Os envios são deduplicados no banco (`notifications_sent`): nenhum aviso sai duas vezes, mesmo com vários workers; se o envio falhar, é tentado de novo depois.

### Modo de envio (`EMAIL_MODE`, em `apps/web/.env.local` e `apps/worker/.env`)

| Modo | Uso | Configuração |
|---|---|---|
| `console` (padrão) | desenvolvimento: nada sai; o e-mail aparece no terminal e o HTML fica em `.emails/` | nenhuma |
| `smtp` | testar o recebimento real sem domínio (Brevo) | `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `EMAIL_FROM` com o remetente verificado no Brevo |
| `resend` | produção, com domínio verificado no Resend | `RESEND_API_KEY`, `EMAIL_FROM` no seu domínio |

O worker também precisa de `SITE_URL` (link dos e-mails). Com o worker no Docker, o modo `console` salva os arquivos dentro do contêiner; para ver os e-mails do worker em desenvolvimento, use `smtp` com o Brevo ou acompanhe o terminal.

### Monitoramento de erros (Sentry, opcional)

Crie um projeto em https://sentry.io (plano gratuito) e defina o DSN em `NEXT_PUBLIC_SENTRY_DSN` (app) e `SENTRY_DSN` (worker). Sem DSN, nada é enviado. A configuração não coleta usuário, cookies, cabeçalhos, corpos de requisição nem parâmetros de URL; o worker não envia falhas causadas pelo próprio arquivo (com senha, ilegível etc.).

### Roteiro de teste

1. Com `EMAIL_MODE=console`, analise um documento e abra o HTML gerado em `.emails/` (no app, `apps/web/.emails`; no worker, veja o terminal).
2. Com `EMAIL_MODE=smtp` e o Brevo, repita e confira a chegada no Gmail.
3. **Cota**: no painel, dê ao escritório uma avaliação de 5 documentos e conclua 4: chega o aviso de 80% uma vez só.
4. **Contrato**: registre um contrato que termina em 2 dias; em até 5 minutos chega o aviso.
5. **Fila**: pare o worker, envie um documento, espere 15 minutos e suba o worker com o SMTP configurado: os administradores da plataforma recebem o aviso de fila.
6. **Preferências**: desligue "análise concluída" em Minha conta e confira que o aviso deixa de chegar.

## Etapa 8: "Nosso cliente é…"

```bash
pnpm install
pnpm supabase db push      # aplica 20261014000100 e 20261014000200
pnpm worker:build          # prompt 2026-10-v2
```

Na página de um documento pronto, acima da análise, escolha em **Nosso cliente é** a parte que o escritório representa (a lista vem das partes extraídas) e clique em **Refazer análise**. Em 1 a 3 minutos, riscos, sugestões de redação e resumo passam a ser escritos a favor do cliente; o resumo fala com ele ("você"). A escolha aparece no cabeçalho ("Cliente: …") e é mantida em reprocessamentos. "Nenhuma parte" volta à análise neutra.

| O que muda | O que fica |
|---|---|
| Riscos (ordem, nível, explicação, sugestão) e resumo | Dados extraídos e edições feitas neles |
| Avaliações "útil / não procede" e edições do resumo (valiam para a análise anterior) | Cota do plano (não consome) |

Qualquer membro do escritório pode trocar a perspectiva. Trocas e reprocessamentos somam no limite de 3 por documento em 24 horas, para conter o custo de IA.

**Teste:** analise `contrato-locacao.pdf` (neutro), escolha "Café Aurora… (Locatária)" e compare: a multa de 12 aluguéis e a rescisão unilateral da locadora sobem de prioridade, as sugestões protegem a locatária e o resumo passa a falar com ela. Depois escolha a Imobiliária (Locadora): aparecem riscos de cláusulas favoráveis a ela que podem ser anuladas em juízo (multa sem proporcionalidade, foro distante, compartilhamento de dados). Para medir, `pnpm eval locacao-comercial-locataria` roda o gabarito do ponto de vista da locatária.

## Etapa 9, parte 1: prazos e alertas

```bash
pnpm install
pnpm supabase db push      # aplica 20261016000100_deadlines.sql
pnpm worker:build          # prompt 2026-10-v3 (extrai prazos)
```

Documentos analisados antes desta versão não têm prazos extraídos: use **Reprocessar** para extraí-los (ou cadastre à mão).

### O que aparece

- **Aba Prazos** em cada documento: prazos encontrados no contrato (fim da vigência, aviso de não renovação, reajuste, vencimentos pontuais), com cláusula e trecho, e os cadastrados pela equipe. Concluir, editar, excluir e adicionar.
- **Menu Prazos**: calendário do escritório, agrupado por mês (30, 90 dias ou 12 meses), com os vencidos não concluídos no topo e **Baixar calendário (.ics)** para importar no Google Agenda ou no Outlook.
- **Lembretes por e-mail** 30, 7 e 1 dia antes e no dia, para quem enviou o documento e titular/administradores (desligável em Minha conta).

### Como as datas são calculadas

- A IA devolve a data só quando ela está escrita no contrato. Prazo relativo ("180 dias antes do término") vem como regra, e o sistema calcula a data a partir dos dados extraídos. **Corrigir a data de término na aba Dados corrige o prazo.**
- Reajuste anual mostra a próxima ocorrência; "Concluir esta ocorrência" passa para a do ano seguinte.
- Editar um prazo encontrado pela IA fixa a data e o torna manual: novas análises não o alteram. Reanálises substituem só os prazos da IA.
- Trocar a perspectiva ("Nosso cliente é…") não mexe nos prazos.

### Roteiro de teste

1. Reprocesse `contrato-locacao.pdf`. Na aba Prazos: fim da vigência (30/09/2029), aviso de não renovação (180 dias antes: 03/04/2029), reajuste anual a partir de 01/10/2026.
2. Na aba Dados, mude o término para 30/09/2030 e salve: o aviso de não renovação vai para 03/04/2030.
3. Adicione um prazo manual para daqui a 7 dias. Com o worker ligado, o lembrete chega em até 5 minutos (modo `console`: terminal; `smtp`: Gmail).
4. Em Prazos, baixe o `.ics` e importe no Google Agenda: os eventos aparecem como dia inteiro, com alarmes 7 e 1 dia antes e link para o documento.

## Etapa 9, parte 2: assinatura do calendário

```bash
pnpm install
pnpm supabase db push      # aplica 20261018000100_calendar_feeds.sql
```

Em **Prazos → Assinar na sua agenda**, cada usuário gera um endereço secreto e pessoal e usa os botões **Google Agenda**, **Outlook (Microsoft 365)**, **Outlook.com** ou **Apple Calendar**. A agenda consulta o endereço periodicamente (o Google, em geral, a cada algumas horas; o app sugere 6 h), e prazos novos, alterados ou concluídos aparecem sozinhos.

- **Segurança**: o endereço é a credencial (token de 256 bits; o banco guarda só o hash) e é mostrado uma única vez. "Gerar novo endereço" invalida o anterior; "Revogar" desliga na hora. Quem sai do escritório perde o calendário automaticamente. A página mostra quando a agenda leu o endereço pela última vez.
- **Privacidade**: por padrão, os eventos mostram só o tipo do prazo ("Aviso de não renovação"), sem nome do documento nem trecho, porque ficam armazenados nos servidores do Google/Microsoft. Marcar "Incluir o nome do documento e a cláusula" é uma escolha de cada usuário. O link de cada evento leva ao app, que exige login.
- **Desenvolvimento local**: com o app em `localhost`, o Google e a Microsoft não conseguem ler o endereço. Para conferir, abra o endereço gerado no navegador (baixa o `.ics`) ou use "Baixar calendário". A assinatura funciona depois da publicação, com `NEXT_PUBLIC_SITE_URL` apontando para o domínio público.

## Etapa 10, parte 1: cliente, responsável, revisão e situação dos riscos

```bash
pnpm install
pnpm supabase db push      # aplica 20261020000100_organization.sql
```

### Na página do documento

Uma barra acima da análise, que salva a cada mudança:

- **Cliente**: cliente final do escritório. "+ Novo cliente…" cadastra na hora (a página Clientes, com CPF/CNPJ, e-mail e observações, chega na parte 2).
- **Responsável**: advogado responsável; por padrão, quem enviou o documento.
- **Revisão**: Pendente → Em revisão → Enviado ao cliente → Aprovado. Registra quem mudou e quando; cada mudança entra no log de acesso como "Editou".

Em cada risco aberto, **Situação**: Em aberto, Aceito (o cliente assume o risco), Em negociação (proposta enviada à outra parte) ou Resolvido (cláusula ajustada), com anotação opcional. O topo da aba mostra quantos riscos seguem em aberto.

### Na lista de documentos

Filtros por **cliente** (inclusive "Sem cliente"), **responsável** ("Meus documentos") e **revisão**; a busca textual também encontra pelo nome do cliente. Novas colunas: cliente, status de revisão, **riscos altos em aberto** (em vermelho quando houver) e responsável.

### Roteiro de teste

1. No `contrato-locacao.pdf`, crie o cliente "Café Aurora" pela barra, defina um responsável e passe para "Em revisão".
2. Marque a multa de 12 aluguéis como "Em negociação" com uma nota e o foro como "Resolvido". Na lista, "Riscos altos em aberto" diminui.
3. Filtre a lista por "Meus documentos" e por "Em revisão".
4. Com outro membro do escritório, confira que ele vê e altera as mesmas informações.

## Etapa 10, parte 2: clientes e acompanhamento

```bash
pnpm install
pnpm supabase db push      # aplica 20261022000100_clients_overview.sql
```

- **Clientes** (menu): lista com busca por nome ou CPF/CNPJ, documentos, em revisão, enviados, riscos altos em aberto e último envio; cadastro ao lado; arquivados sob demanda.
- **Página do cliente**: indicadores, **envio de documentos já vinculados ao cliente**, documentos com status de revisão e responsável, próximos prazos (90 dias) e dados do cliente (editar, arquivar, reativar). Arquivar tira o cliente das listas de escolha; os documentos continuam vinculados.
- **Acompanhamento** (menu, titular e administradores): por responsável, documentos pendentes, em revisão, enviados, aprovados e processando, riscos altos em aberto (só de documentos não aprovados), prazos vencidos e dos próximos 7 dias. Cada número abre a lista de documentos já filtrada. Documentos sem responsável aparecem numa linha própria.
- Os avisos de **Reprocessar** e **Nosso cliente é…** agora dizem explicitamente que as situações dos riscos serão descartadas.

**Teste**: cadastre dois clientes, envie um documento pela página de cada um, mude status e responsáveis e confira os números em Clientes e em Acompanhamento; clique num número e veja a lista filtrada.

## Etapa 11: comparação de versões

```bash
pnpm install
pnpm supabase db push      # aplica 20261024000100_versions.sql
pnpm worker:build          # o worker passa a comparar versões
```

Na página de um documento pronto, a barra **Versões** mostra o histórico (v1, v2…) e **Enviar nova versão deste contrato**. A nova versão:

- herda cliente, responsável e a perspectiva ("Nosso cliente é…"), e entra como "Em revisão";
- é analisada por inteiro (dados, prazos, riscos, resumo) e **conta na cota** como um documento;
- ao terminar, é comparada com a anterior: **Comparar com a v1** abre a página de comparação.

A comparação mostra:

- **Riscos resolvidos** (existiam na versão anterior e sumiram), **novos** e **mantidos**, com a mudança de nível quando houver. Riscos mantidos **herdam a situação** marcada na versão anterior (aceito, em negociação, resolvido) e a anotação.
- **Alterações no texto**, cláusula a cláusula: alteradas (com o que saiu riscado em vermelho e o que entrou em verde), incluídas e removidas.

O histórico é linear: cada versão tem no máximo uma seguinte; em versões antigas, um aviso leva à mais recente.

**Teste**: no `contrato-locacao.docx` (Word), mude a multa de 12 para 3 aluguéis proporcionais, apague a cláusula 11 (preferência), acrescente uma cláusula de confidencialidade e salve como v2. Na v1, marque a multa como "Em negociação". Envie a v2 pela barra de versões e abra a comparação: a preferência aparece como resolvida, a confidencialidade como nova, a cláusula 9.1 alterada palavra a palavra e, se a multa ainda for apontada, ela chega à v2 com a situação "Em negociação".

## Etapa 12: versões gratuitas e Playbook do escritório

```bash
pnpm install
pnpm supabase db push      # aplica 20261026000100_free_versions_playbook.sql
pnpm worker:build          # prompt 2026-10-v4
```

### Versões gratuitas

As 3 primeiras novas versões de cada contrato (v2 a v4) não consomem a cota; da v5 em diante, cada uma conta. Antes de chamar a IA, o worker compara o texto da nova versão com o da anterior: se forem muito diferentes (semelhança por trincas de palavras abaixo de 0,3), recusa com "O arquivo não parece ser uma nova versão deste contrato", sem custo e sem cota, e orienta a enviar como documento novo.

### Playbook (Configurações → Playbook)

Titular e administradores cadastram até 30 regras: título, critério em linguagem natural, nível mínimo quando violada e, opcionalmente, os tipos de contrato a que se aplica. Há exemplos prontos (foro, multa máxima, reajuste pelo IPCA, LGPD, limitação de responsabilidade). Nas análises seguintes, contrato que não atende a uma regra ganha um risco com a marca **Regra do escritório** e o nível mínimo definido. Regras podem ser desativadas sem excluir.

Disponível nos planos Profissional e Escritório, em contratos manuais e na avaliação gratuita; no Essencial, as regras podem ser cadastradas, mas só entram nas análises após a mudança de plano.

**Teste**: cadastre a regra "Foro na nossa comarca" (exemplo pronto) e reprocesse o `contrato-locacao.pdf`: o foro de Manaus aparece com a marca "Regra do escritório" e nível alto.

## Produção (Supabase na região sa-east-1)

1. Crie o projeto em **South America (São Paulo)** e rode `supabase link` e depois `supabase db push`.
2. Em Authentication → URL Configuration: *Site URL* = domínio do app; *Redirect URLs* = `https://seu-dominio/**`.
3. Em Authentication → Email Templates, copie os arquivos de `supabase/templates/` (confirmação, recuperação e troca de e-mail). Eles usam o fluxo `token_hash` → `/auth/confirm`, que funciona mesmo quando o link é aberto em outro dispositivo.
4. Configure um SMTP próprio (Authentication → SMTP). O SMTP embutido do Supabase tem limite muito baixo de envios.

## Decisões da etapa 1

- **Um escritório por usuário.** A regra vive só na constraint `office_members_one_office_per_user` e em `current_office_id()`. As policies e a aplicação nunca presumem isso; o app resolve o escritório por `current_membership()`.
- **Cadastro atômico.** O trigger `private.handle_new_user` cria perfil, escritório (ou associação por convite) e aceite dos termos na mesma transação que cria o usuário. Sem aceite da versão vigente, o banco recusa o cadastro. Por consequência, criar usuários pelo painel do Supabase falha de propósito.
- **Convites por link.** O token aparece em claro uma única vez; o banco guarda só o hash SHA-256. O envio automático por e-mail (ex.: Resend) pode entrar depois sem mudar o modelo.
- **Ponto jurídico em aberto.** `legal_acceptances` é apagada junto com a conta (`on delete cascade`). Validar com o advogado se o comprovante de aceite deve ser retido após a exclusão.

## Decisões da etapa 2

- **Upload direto ao Storage.** O navegador envia o arquivo com a sessão do usuário; a policy só aceita o caminho exato de um documento `uploading` criado por ele. O arquivo não passa pelo servidor Next.js no envio (sem limite de corpo de requisição).
- **Validação pelo conteúdo.** Depois do envio, o servidor baixa o arquivo e confere assinatura, criptografia, integridade e número de páginas. Extensão e MIME informados pelo navegador não são confiáveis. A validação fica em `@app/shared/file-validation`, para o worker reutilizá-la.
- **PDF com qualquer criptografia é recusado,** inclusive os que abrem sem senha e só restringem impressão ou cópia. Na etapa 3, o worker pode removê-la com qpdf e aceitá-los.
- **Leitura só por URL assinada.** `/api/documentos/:id/arquivo` confere a permissão pela RLS, registra o acesso e redireciona para uma URL válida por 5 minutos (visualizar) ou 60 segundos (baixar). Sem registro no log, não há acesso.
- **Transições confiáveis.** `mark_document_queued` e `fail_document` só podem ser executadas com a secret key. Um usuário não consegue marcar um arquivo como validado.
- **Contador de falhas à prova de exclusão.** `document_failures` não tem FK para `documents`: apagar documentos com erro não zera o limite diário. O limite é por escritório (`offices.daily_failure_limit`, padrão 20) e só pode ser alterado pelo suporte.
- **Pendências para a etapa 3:** limpeza automática de envios `uploading` abandonados (job no worker) e limite de 50 páginas para DOCX após a conversão.
- **Ponto jurídico:** `document_access_logs` guarda o nome do arquivo no momento do acesso, para o log continuar legível após a exclusão. Nome de arquivo pode conter dado pessoal; validar com o advogado.

## Decisões da etapa 3

- **Uma chamada à IA por documento** (Claude Sonnet 5.5, saída estruturada em JSON Schema, validada de novo com Zod). O contrato é lido uma vez só; o system prompt, fixo e sem dados de clientes, fica em cache entre documentos. Cada requisição leva um único documento de um único escritório.
- **Trechos localizados no servidor e no navegador pelo mesmo algoritmo** (`@app/shared/text-match`), tolerante a acentos, quebras de linha e erros de OCR. Trecho não encontrado fica sem destaque, em vez de destacar o lugar errado.
- **PDF que só restringe impressão/cópia é aceito**: o worker remove a proteção com qpdf. PDF com senha de abertura continua recusado.
- **Falhas**: temporárias (IA indisponível, tempo esgotado) voltam para a fila com espera de 1, 2 e 4 minutos, até 3 tentativas, e mantêm o arquivo para "Reprocessar". Problemas no arquivo (ilegível, com senha, mais de 50 páginas) descartam o arquivo.
- **Cota**: `usage_counters` conta cada documento uma vez, na primeira conclusão. Reprocessar não conta; o limite é de 3 reprocessamentos por documento em 24 h.
- **Telemetria de custo** em `ai_usage` e `processing_jobs`, com preços em `ai_model_prices` (atualize com nova linha quando a Anthropic mudar preços). Não é visível para os escritórios.
- **Visualizador com PDF.js (react-pdf)**: páginas renderizadas sob demanda (documentos de 50 páginas não travam a tela); o destaque usa a camada de texto do próprio PDF e o mesmo algoritmo de localização do worker. O worker do PDF.js é copiado para `apps/web/public/` no `pnpm install` (script `postinstall`).
- **Edições separadas da IA**: `extractions.edited_data` e `summaries.edited_content` guardam a versão do advogado; a original da IA é mantida para auditoria e para "Restaurar".
- **Atualização de status por consulta periódica** (a cada 5 s, só enquanto há documento em processamento e com a aba visível), mais simples que Realtime para o MVP.

## Decisões da etapa 4

- **docxtemplater** preenche o modelo preservando a formatação do Word, inclusive em cabeçalhos e rodapés, e junta marcações que o Word divide internamente (`{{Locat` + `ária}}`).
- **Variáveis tolerantes à escrita**: maiúsculas, acentos, feminino e sinônimos (`{{Locatária}}`, `{{inquilino}}`, `{{locataria_cnpj}}`) apontam para o mesmo dado. A lista fica em `packages/shared/src/template-vars.ts` e alimenta a página de ajuda, então ajuda e comportamento nunca divergem.
- **Minuta não é armazenada** (minimização): é montada na hora e baixada. Ficam registrados quem gerou, o documento e o modelo (`draft_exports` e log de acesso).
- **Campo sem valor vira `__________`**, para não passar despercebido na revisão.
- **Modelos são do escritório**: titular e administradores enviam e excluem; todos os membros usam. Limite de 100 modelos e 4 MB por arquivo.

## Decisões da etapa 5

- **Stripe Checkout e portal do cliente**: o app nunca vê dados de cartão; troca de plano, faturas, forma de pagamento e cancelamento ficam no portal do Stripe.
- **Preço no Stripe, limite no banco**: o valor cobrado vem do Stripe (lookup_key), e o limite de documentos, da tabela `plans`. Trocar preço não exige deploy.
- **Direito de uso em uma única função** (`private.office_entitlement`): assinatura ativa, avaliação de 14 dias com 5 documentos, ou nenhum. `past_due` mantém o acesso durante as novas tentativas de cobrança do Stripe; `canceled`/`unpaid` bloqueiam novos envios, sem bloquear o acesso ao que já existe.
- **Período de cobrança do Stripe**, não mês civil: a cota renova na data da assinatura.
- **Reserva de cota**: documentos em processamento contam no limite, para envios simultâneos não o ultrapassarem. Falhas liberam a reserva.
- **Webhook resiliente**: a assinatura é relida da API do Stripe a cada evento (eventos fora de ordem não deixam estado velho), eventos são registrados para evitar reprocessamento, e uma assinatura cancelada antiga não sobrescreve uma nova ativa.

## Decisões da etapa 6 (parte 1)

- **Troca de senha exige a senha atual**, e excluir a conta exige a senha: uma sessão esquecida aberta não basta para tomar a conta.
- **Titular não some**: para sair, transfere a titularidade ou exclui o escritório. O escritório nunca fica sem titular.
- **Exclusão do escritório em 7 dias**, com bloqueio de novos envios e botão de desistir. Executada pelo worker: arquivos no Storage, dados (cascade) e contas dos membros. Exige assinatura cancelada antes, para não haver cobrança de um escritório apagado. O histórico de custo de IA (`ai_usage`) fica, sem dados pessoais.
- **Exportação em JSON** (portabilidade, LGPD), lida com a sessão do titular: só sai o que a RLS permite.
- **Logotipo nas minutas ficou de fora**: inserir imagem por variável exige um módulo pago do docxtemplater. Coloque o logotipo direto no cabeçalho do modelo no Word; ele é preservado nas minutas.
- **Verificação em duas etapas** entra na parte 2, junto com o painel da plataforma (onde será obrigatória).

## Decisões da etapa 6 (parte 2)

- **Administrador da plataforma não é papel de escritório**: fica em `platform_admins`, criado só por SQL. O painel usa funções do banco que conferem admin **e** sessão com 2FA (`aal2` no token) a cada chamada; o app nunca usa a secret key para o painel.
- **Metadados, não conteúdo**: o painel mostra plano, uso, custo, membros e status. Documentos, extrações, riscos e resumos ficam fora (LGPD e sigilo profissional, Estatuto da OAB art. 7º, II). Não há "entrar como o cliente".
- **Direito de uso por prioridade**: contrato manual vigente, assinatura Stripe, avaliação (ajustável por escritório), nenhum. Contrato manual não permite sobreposição e renova a cota mensalmente a partir do início.
- **Convite de titular** só pode ser criado pela plataforma (restrição no banco) e para escritório ainda sem titular.
- **Suspensão bloqueia apenas novos envios**; o acesso ao que já existe e a exportação continuam (o escritório é o controlador dos dados).
- **2FA para todos os usuários, opcional**: quem ativa passa a informar o código a cada login.
- **Pendente**: aviso de vencimento de contrato por e-mail (hoje, aviso na tela e filtro no painel).

## Decisões da etapa 7 (parte 1)

- **Duas medidas de qualidade que se completam**: o gabarito (`pnpm eval`) mede antes de publicar uma versão do prompt; o feedback dos advogados mede depois, com contratos reais. Ambos por `prompt_version`.
- **Comentários de feedback não saem do escritório**: podem citar trechos do contrato. O painel recebe só contagens.
- **Riscos extras não penalizam o gabarito**: a IA pode apontar algo válido que o gabarito não previu; eles aparecem em "extras" para revisão e, se procedentes, entram no gabarito.
- **Feedback é descartado ao reprocessar** (os riscos são substituídos), porque avalia a análise anterior.

## Decisões da etapa 7 (parte 2)

- **Envio independente do provedor** (`@app/shared/email`): o mesmo código com `console`, `smtp` ou `resend`, escolhido por variável de ambiente. Trocar o Brevo pelo Resend em produção não exige mudar código.
- **Deduplicação no banco**, com reserva antes do envio e liberação se falhar: sem avisos repetidos e sem perda por falha temporária.
- **Aviso nunca derruba o processamento**: falha de e-mail só vai para o log (e para o Sentry, se configurado).
- **Avisos de cobrança e contrato são obrigatórios** para titular e administradores; os de conveniência podem ser desligados por cada usuário.
- **Sentry com coleta mínima**: sem dados de usuário, cookies, cabeçalhos, corpos ou parâmetros, porque os documentos são sigilosos. Sem replay de sessão no navegador.
- **Resend e Sentry** passam a ser suboperadores quando ativados: incluir na política de privacidade.

## Decisões da etapa 8

- **Perspectiva só na mensagem, não no system prompt**: o system prompt continua idêntico para todos os documentos (cache), e o nome da parte entra como dado, sanitizado e delimitado, nunca como instrução.
- **Trocar a perspectiva não refaz a extração**: os dados são fatos do contrato e podem ter sido corrigidos pelo advogado; só riscos e resumo dependem do ponto de vista.
- **Cláusulas favoráveis ao cliente que podem ser anuladas também são risco**, para o advogado não negociar algo que cairá em juízo.
- **Versão do prompt 2026-10-v2**: aparece separada em /admin → Qualidade, para comparar com a v1.

## Decisões da etapa 9 (parte 1)

- **A IA não faz contas de data**: devolve a data explícita ou a regra (referência + dias). O sistema calcula, sempre a partir dos dados vigentes (editados, se houver). Menos erro e correção automática quando o advogado ajusta uma data.
- **Prazos são fatos do contrato**, como a extração: mudar a perspectiva não os refaz; reanálise substitui só os da IA; os manuais nunca são tocados.
- **Pagamentos mensais comuns ficam de fora**, para o calendário não virar ruído; prazos pontuais e de renovação entram.
- **Lembretes deduplicados** (um por prazo, data e antecedência), no mesmo mecanismo dos outros avisos.

## Decisões da etapa 9 (parte 2)

- **Endereço por usuário, não por escritório**: cada pessoa revoga o seu sem afetar os colegas, e a saída de alguém do escritório desliga só o calendário dela.
- **Mínimo de conteúdo nos servidores da agenda por padrão**: tipo do prazo e data. Nome do documento e cláusula só com opção explícita; trechos do contrato nunca vão para o feed.
- **Endereço inválido responde 404 sem explicar o motivo**; endereço válido sem prazos responde um calendário vazio, para a agenda não marcar a assinatura como quebrada.

## Decisões da etapa 10 (parte 1)

- **Organização é trabalho de equipe**: qualquer membro altera cliente, responsável, revisão e situação dos riscos; tudo fica no log de acesso do documento.
- **Situação do risco é separada do feedback de qualidade**: "útil / não procede" avalia a IA; "aceito / negociado / resolvido" acompanha o caso. Ambos são substituídos numa reanálise, porque os riscos mudam.
- **Clientes arquivados** saem das listas de escolha, mas os documentos continuam vinculados a eles; nomes de clientes ativos não se repetem no escritório.

## Decisões da etapa 10 (parte 2)

- **Acompanhamento só para titular e administradores**: é visão de gestão; membros veem os próprios documentos pelo filtro "Meus documentos".
- **Riscos altos em aberto** contam só documentos não aprovados, para o indicador refletir trabalho pendente, e não histórico.
- **Envio pela página do cliente** já vincula o documento, eliminando um passo manual e documentos "órfãos".

## Decisões da etapa 11

- **Comparação determinística, sem IA**: texto e riscos são comparados por algoritmo (alinhamento de cláusulas e palavras; casamento de riscos pelo trecho citado). Sem custo adicional e sem risco de a IA "inventar" diferenças; a análise da nova versão já é completa.
- **Herança da situação dos riscos**: o trabalho de negociação não se perde entre rodadas.
- **Nova versão conta na cota**: é uma análise completa, com custo real de IA. Se quiser tratar versões de forma diferente no preço, dá para mudar a regra em `worker_complete_job`.
- **Pendente**: reprocessar uma versão antiga não recalcula a comparação da versão seguinte.

## Decisões da etapa 12

- **3 versões gratuitas por contrato**: incentiva o uso da comparação nas rodadas de negociação sem abrir brecha: a checagem de semelhança acontece antes da IA, e o limite por contrato encerra o abuso residual.
- **Playbook na mensagem, delimitado**: as regras são dados do escritório, sanitizadas e marcadas como critérios, não como instruções; o system prompt continua fixo (cache).
- **Regra aplicada, não imposta**: a IA aponta risco só quando o contrato não atende ao critério, e continua fazendo a análise jurídica completa.
- **Recurso de plano**: controlado no banco (`private.office_has_playbook`); o worker só envia regras se o plano permitir.
