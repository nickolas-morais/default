/**
 * Envio de e-mails, independente do provedor. Somente servidor/worker.
 * Importar via "@app/shared/email".
 *
 * EMAIL_MODE:
 *   console (padrão)  não envia; mostra no terminal e salva o HTML em
 *                     EMAIL_OUTBOX_DIR (padrão ./.emails) para abrir no navegador
 *   smtp              SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS (ex.: Brevo)
 *   resend            RESEND_API_KEY (exige domínio verificado no Resend)
 * EMAIL_FROM: remetente, ex.: "App <nao-responda@seudominio.com.br>"
 */
import { mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import nodemailer from "nodemailer";
import type { EmailContent } from "./email-templates.ts";

export type EmailMessage = EmailContent & { to: string[] };
export type SendResult = { ok: true; id: string } | { ok: false; error: string };

type Env = Record<string, string | undefined>;

let smtp: nodemailer.Transporter | null = null;

export function emailMode(env: Env = process.env): "console" | "smtp" | "resend" {
  const m = env.EMAIL_MODE ?? "console";
  return m === "smtp" || m === "resend" ? m : "console";
}

export async function sendEmail(msg: EmailMessage, env: Env = process.env): Promise<SendResult> {
  const to = [...new Set(msg.to.map((t) => t.trim().toLowerCase()).filter(Boolean))];
  if (!to.length) return { ok: true, id: "sem-destinatarios" };
  const from = env.EMAIL_FROM ?? "App <nao-responda@localhost>";
  const mode = emailMode(env);

  try {
    if (mode === "resend") {
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${env.RESEND_API_KEY ?? ""}`, "Content-Type": "application/json" },
        body: JSON.stringify({ from, to, subject: msg.subject, html: msg.html, text: msg.text }),
        signal: AbortSignal.timeout(15_000),
      });
      const body = (await res.json().catch(() => ({}))) as { id?: string; message?: string };
      return res.ok ? { ok: true, id: body.id ?? "resend" } : { ok: false, error: `resend ${res.status}: ${body.message ?? ""}` };
    }

    if (mode === "smtp") {
      smtp ??= nodemailer.createTransport({
        host: env.SMTP_HOST,
        port: Number(env.SMTP_PORT ?? 587),
        secure: Number(env.SMTP_PORT ?? 587) === 465,
        auth: env.SMTP_USER ? { user: env.SMTP_USER, pass: env.SMTP_PASS } : undefined,
      });
      const info = await smtp.sendMail({ from, to, subject: msg.subject, html: msg.html, text: msg.text });
      return { ok: true, id: info.messageId };
    }

    // console: somente desenvolvimento.
    const dir = env.EMAIL_OUTBOX_DIR ?? path.join(process.cwd(), ".emails");
    mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `${new Date().toISOString().replace(/[:.]/g, "-")}-${msg.subject.replace(/[^\w]+/g, "_").slice(0, 60)}.html`);
    writeFileSync(file, msg.html);
    process.stdout.write(`[e-mail simulado] para ${to.join(", ")}: ${msg.subject}\n  ${file}\n`);
    return { ok: true, id: file };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : String(e) };
  }
}
